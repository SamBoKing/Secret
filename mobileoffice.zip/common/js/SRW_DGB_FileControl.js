
var failCB = function(msg) {
    DGB.Log.e('[DGB.FileControl] ====>> Fail : ' + msg);
};

/**
 * 파일다운로드
 * @param {url, title};
 */
function downloadFile(file) {
	dgbLoading(true);
	window.requestFileSystem(LocalFileSystem.PERSISTENT,
        0,
        function(fileSystem) {
            gotFSuccess(file, fileSystem);
        },
        function(msg){
            failCB("RequestFileSystem : " + msg);
        }
    );
}

function gotFSuccess(file, fileSystem) {
	fileSystem.root.getFile("dummy.html",
        {
            create : true,
            exclusive : false
        },
        function(fileEntry) {
              gotFileEntry(file, fileEntry);
        },
        function (msg){
            failCB("GetFile : " + msg);
        }
    );
}

function gotFileEntry(file, fileEntry) {
	var sPath = fileEntry.fullPath.replace("dummy.html","");
	var fileTransfer = new FileTransfer();
	fileEntry.remove();

	var fileExt = file.name ? DGB.getFileExt(file.name) : DGB.getFileExt(file.url);
	fileExt = fileExt.replace("'}","").replace('"}',''); //내부로 접근하여 파일다운로드시 url 뒤에 '} 들어감.

	var fileName = file.title + fileExt; // 파일명 + 확장자
	var fileDownPath = file.downPath || DGB.fileRoot() + "deposit/";
    sPath = sPath +fileDownPath+ fileName;
	var uri = encodeURI(file.url);
    fileTransfer.download(
              uri
            , sPath
            , function (){
                DGB.Log.l("[DGB.FileControl] ====>> FilePath : " + sPath);
                gotFileEntrySuccess(sPath, file);
            } , function(error) {
            	dgbLoading(false);
                DGB.Log.e("[DGB.FileControl] ====>> download error source " + error.source);
                DGB.Log.e("[DGB.FileControl] ====>> download error target " + error.target);
                DGB.Log.e("[DGB.FileControl] ====>> upload error code" + error.code);
            }, true
        );

}

function gotFileEntrySuccess(url, file) {
	dgbLoading(false);
	showLink(url, file);
	if( file.callback ) file.callback();
}

/**
 * 뷰어 호출
 * @param localURL
 */
function showLink(localUrl, file) {
	if ( DGB.isAndroid() ) {

        if( DGB.isImage(localUrl) )
        {
            // 이미지 스케닝
            AndroidNative.scanPhoto(localUrl);
            DGB.Common.selectList(
                "선택하세요",
                ["이미지 보기", "이미지 공유하기"],
                function(index) {
                    if( index == 0 )
                        window.plugins.fileOpener.open(localUrl);
                    else
                        window.plugins.socialsharing.share(null,null,localUrl,null);
                },
                function(err) {
                    DGB.Log.e("[SRW_DGB_FileControl] ====> showLink : " + err);
                }
            )
        } else {
			window.plugins.fileOpener.open(localUrl);
        }
	} else {
        var activePage = $.mobile.activePage.attr('id');

        if(  DGB.isMovie(localUrl) || DGB.isSound(localUrl) )
        {
            var args={};
            args.localUrl = localUrl;
            args.activePage = activePage;

            DGB.Page.triggerPage("#GRMA003", "parentpage", [args]);
            DGB.Page.changePage('#GRMA003');
        }else{
            ExternalFileUtil.openWith(localUrl, "com.adobe.pdf");
        }

	}
}

window.ExternalFileUtil = {
    openWith: function ( path, uti, success, fail) {
        return cordova.exec(success, fail, "ExternalFileUtil", "openWith", [path, uti]);
    }
};

DGB.filectrl = (function() {

	var getFile = function(pathname, ready, failure, options)
    {
		if (typeof ready !== 'function' || typeof failure !== 'function') {
			return;
		}

		// Get File System
		window.requestFileSystem(LocalFileSystem.TEMPORARY, 0, function(fs){
			fs.root.getFile(pathname, option, function(fe){
				fe.file(function(file){
					ready(file);
				}, function(error){
					failure(error.code);
				});
			}, function(error){
				failure(error.code);
			});
		}, function(evt){
			failure(evt.target.error.code);
		});
	};
	
	var getLocalFileURI = function(uri, ready, failure) {
		if (typeof ready !== 'function' || typeof failure !== 'function') {
			return;
		}
		
		window.resolveLocalFileSystemURI(uri, function(fe){
			fe.file(function(file){
				ready(file);
			}, function(error){
				failure(error.code);
			});
		}, function(evt){
			failure(evt.target.error.code);
		});
		
	};
	
	var getFileAsDataURL = function(file, callback) {
		var reader = new FileReader();
		reader.onloadend = function(evt) {
			var b64 = evt.target.result;
			if (typeof callback === 'function') callback(b64);
		};
		reader.readAsDataURL(file);
	};
	var getFileAsDataURL2 = function(file, index, callback) {
		return $.Deferred(function(dfd){
			// Testing
			if (typeof file === 'undefined') {
				setTimeout(function() {
					dfd.resolve();
				}, Math.floor( 400 + Math.random() * 1000 ) );

				return;
			}
			var reader = new FileReader();
			reader.onerror = function(evt) {
				dfd.reject(evt.target.error);
			};
			reader.onloadend = function(evt) {
				var b64 = index+";"+evt.target.result;
				if (typeof callback === 'function') callback(b64);

				dfd.resolve(b64);
			};
			reader.readAsDataURL(file);
		}).promise();
	};
	
	var removeFileData = function(name, path, fileSystem){
		var filepath = path+name;
		
		fileSystem.root.getFile(filepath, {create:false},
				function(file){ // success find file
			file.remove(function(){
			}, function(error){
			});
		},
		function(error){ // error find file
		}
		);
	};
	
	var removeDirectoryAll = function (sPath) {
		window.requestFileSystem(LocalFileSystem.PERSISTENT
			, 0
			, function(fileSystem) {
				
				fileSystem.root.getDirectory(sPath, {create: true},function(directory){
					var directoryReader = directory.createReader();
					directoryReader.readEntries(function(entries){
						if(entries.length > 0) {
							for (var i=0; i<entries.length; i++) {
								DGB.filectrl.removeFileData(entries[i].name, sPath, fileSystem);
							}
						}
					}, function(error) {
						alert("error");
					});
				});
			}, function(evt){
		});
	};
	
	return {
		'getFile':getFile,
		'getLocalFileURI':getLocalFileURI,
		'getFileAsDataURL':getFileAsDataURL2,
		'removeFileData':removeFileData,
		'removeDirectoryAll':removeDirectoryAll
	};
})();





