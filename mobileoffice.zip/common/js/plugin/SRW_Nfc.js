function Nfc() {
}

Nfc.prototype.is = function (success, error) {
    cordova.exec(success, error, "Nfc", "is", []);
};

Nfc.prototype.setting = function (success, error) {
    cordova.exec(success, error, "Nfc", "setting", []);
};

Nfc.prototype.dialog = function (title, message, btn1, btn2, success, error) {
    cordova.exec(success, error, "Nfc", "dialog", [title, message, btn1, btn2]);
};

cordova.addConstructor(function () {
    if (!window.plugins) {
        window.plugins = {};
    }
    window.plugins.nfc = new Nfc();
    return window.plugins.nfc;
});