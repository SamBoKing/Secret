function Bio() {
}

Bio.prototype.is = function (success, error) {
    cordova.exec(success, error, "Bio", "is", []);
};

Bio.prototype.verify = function (success, error, title, subtitle, description, cancel_text) {
    cordova.exec(success, error, "Bio", "verify", [title, subtitle, description, cancel_text]);
};

cordova.addConstructor(function () {
    if (!window.plugins) {
        window.plugins = {};
    }
    window.plugins.Bio = new Bio();
    return window.plugins.Bio;
});