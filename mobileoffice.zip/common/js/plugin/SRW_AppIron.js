function AppIron() {
}

AppIron.prototype.auth = function (success, error, url) {
    cordova.exec(success, error, "AppIron", "auth", [url]);
};

AppIron.prototype.token = function (success, error, url) {
    cordova.exec(success, error, "AppIron", "token", [url]);
};

cordova.addConstructor(function () {
    if (!window.plugins) {
        window.plugins = {};
    }
    window.plugins.AppIron = new AppIron();
    return window.plugins.AppIron;
});