function TouchID() {
}

TouchID.prototype.is = function (success, error) {
    cordova.exec(success, error, "TouchID", "is", []);
};

TouchID.prototype.verify = function (success, error, message) {
    cordova.exec(success, error, "TouchID", "verify", [message]);
};

cordova.addConstructor(function () {
    if (!window.plugins) {
        window.plugins = {};
    }
    window.plugins.TouchID = new TouchID();
    return window.plugins.TouchID;
});