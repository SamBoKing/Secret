function Fido() {
}

Fido.prototype.exec = function (url, success, error) {
    cordova.exec(success, error, "Fido", "exec", [url]);
};

Fido.prototype.is = function (pkg, success, error) {
    cordova.exec(success, error, "Fido", "is", [pkg]);
};

cordova.addConstructor(function () {
    if (!window.plugins) {
        window.plugins = {};
    }
    window.plugins.fido = new Fido();
    return window.plugins.fido;
});