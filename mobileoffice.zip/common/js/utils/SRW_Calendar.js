(function ($) {
    $.jqmCalendar = function (element, options) {

        var defaults = {
            // Array of events
            events: {},
            // Default properties for events
            begin: "begin",
            end: "end",
            summary: "summary",
            color: "color",
            cid:'cid',
            icon: "icon",
            url: "url",
            // Sting to use when event is all day
            allDayTimeString: '',
            // Theme
            theme: "c",
            // Date variable to determine which month to show and which date to select
            date: new Date(),
            // Version
            version: "1.0.1",
            // Array of month strings (calendar header)
            months: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
            // Array of day strings (calendar header)
            days: ["일", "월", "화", "수", "목", "금", "토"],
            // Most months contain 5 weeks, some 6. Set this to six if you don't want the amount of rows to change when switching months.
            weeksInMonth: undefined,
            // Start the week at the day of your preference, 0 for sunday, 1 for monday, and so on.
            startOfWeek: 0,
            // List Item formatter, allows a callback to be passed to alter the contect of the list item
            listItemFormatter: listItemFormatter
        };
        var cids = '';
        var plugin = this,
            today = new Date();
        plugin.settings = null;

        var SATURDAY = 6;
        var SUNDAY = 0;

        var day = 0;

        var $element = $(element).addClass("jq-calendar-wrapper"),
            $table,
            $header,
            $tbody,
            $listview;

        function init() {
            plugin.settings = $.extend({}, defaults, options);
            plugin.settings.theme = $.mobile.getInheritedTheme($element, plugin.settings.theme);

            $table = $("<table/>");

            // Build the header
            var $thead = $("<thead/>").appendTo($table),
                $tr = $("<tr/>").appendTo($thead),
                $th = $("<th class='ui-bar-" + plugin.settings.theme + " header' colspan='7'/>");

            $("<a href='#' data-role='button' data-icon='arrow-l' data-iconpos='notext' class='previous-btn'>Previous</a>").off('vclick').on('vclick',function () {
                var date = plugin.settings.date;
                refresh(new Date(date.getFullYear(), date.getMonth() - 1, date.getDate()));
                $element.trigger('move', plugin.settings.date);
                return false;
            }).appendTo($th);

            $header = $("<span/>").appendTo($th);

            $("<a href='#' data-role='button' data-icon='arrow-r' data-iconpos='notext' class='next-btn'>Next</a>").off('vclick').on('vclick',function () {
                var date = plugin.settings.date;
                refresh(new Date(date.getFullYear(), date.getMonth() + 1, date.getDate()));
                $element.trigger('move', plugin.settings.date);
                return false;
            }).appendTo($th);

            $th.appendTo($tr);

            $tr = $("<tr/>").appendTo($thead);

            // The way of determing the labels for the days is a bit awkward, but works.
            for (var i = 0, days = [].concat(plugin.settings.days, plugin.settings.days).splice(plugin.settings.startOfWeek, 7); i < 7; i++) {
                $tr.append("<th class='ui-bar-" + plugin.settings.theme + "'><span >" + days[i] + "</span></th>");     //<span class='darker'>
            }

            $tbody = $("<tbody/>").appendTo($table);

            $table.appendTo($element);
//         $listview = $("<ul data-role='listview'/>").insertAfter($table);
            $listview = $("<ul data-role='listview' class='ui-icon-alt'/>").insertAfter($table);
            // Call refresh to fill the calendar with dates
            refresh(plugin.settings.date);
        }

        function _firstDayOfMonth(date) {
            // [0-6] Sunday is 0, Monday is 1, and so on.
            return ( new Date(date.getFullYear(), date.getMonth(), 1) ).getDay();
        }

        function _daysBefore(date, fim) {
            // Returns [0-6], 0 when firstDayOfMonth is equal to startOfWeek, else the amount of days of the previous month included in the week.
            var firstDayInMonth = ( fim || _firstDayOfMonth(date) ),
                diff = firstDayInMonth - plugin.settings.startOfWeek;
            return ( diff > 0 ) ? diff : ( 7 + diff );
        }

        function _daysInMonth(date) {
            // [1-31]
            return ( new Date(date.getFullYear(), date.getMonth() + 1, 0)).getDate();
        }

        function _daysAfter(date, wim, dim, db) {
            // Returns [0-6] amount of days from the next month
            return    (( wim || _weeksInMonth(date) ) * 7 ) - ( dim || _daysInMonth(date) ) - ( db || _daysBefore(date));
        }

        function _weeksInMonth(date, dim, db) {
            // Returns [5-6];
            return ( plugin.settings.weeksInMonth ) ? plugin.settings.weeksInMonth : Math.ceil(( ( dim || _daysInMonth(date) ) + ( db || _daysBefore(date)) ) / 7);
        }


        function addCell($row, date, darker, selected) {

            var $td = $("<td class='ui-body-" + plugin.settings.theme + "'/>").appendTo($row),
                $a = $("<a href='#' class='ui-btn ui-btn-up-" + plugin.settings.theme + "'/>")
                    .html(date.getDate().toString())
                    .data('date', date)
                    .click(cellClickHandler)
                    .appendTo($td);

            if (selected) $a.click();

            if (darker) $td.addClass("darker");

            //토,일표시
            switch( day % 7 ) {
                case SATURDAY: $a.addClass("satday"); break;
                case SUNDAY: $a.addClass("sunday"); break;
            }

            var weekend = day % 7;
            if (weekend == SATURDAY)
            if (weekend == SUNDAY) $a.addClass("sunday");
            day++;

            var importance = 0;
            var events = plugin.settings.events.values();
            // Find events for this date
            var colorStr ='';
            for (var i = 0,
                     event,
                     begin = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0),
                     end = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1, 0, 0, 0, 0);
                 event = events[i]; i++) {
                //if (event[plugin.settings.end] >= begin && event[plugin.settings.begin] < end) {
                if (event[plugin.settings.end] > begin && event[plugin.settings.begin] < end) {
                    if(event[plugin.settings.color]){
                        if(cids.indexOf(event[plugin.settings.cid]) > -1 ){
                            if(importance < 3)
                                colorStr += "<b style ='color:"+event[plugin.settings.color]+";'>&bull;</b>";
                            importance++;

                            //if (importance > 1) break;
                        }
                    }else{
                        importance++;
                        if (importance > 1) break;
                    }

                }
            }
            if (colorStr && importance > 0) {
                $a.append("<span>"+colorStr+"</span>");
            }else if(importance > 0){
                $a.append("<span>&bull;</span>");
            }
            if (date.getFullYear() === today.getFullYear() &&
                date.getMonth() === today.getMonth() &&
                date.getDate() === today.getDate()) {
                $a.addClass("ui-btn-today");
            } else {
                //$a.addClass("importance-" + importance.toString());
                $a.addClass("importance-" + ((importance>0)?"1":"0"));
            }

        }

        function cellClickHandler(event) {
            var $this = $(this),
                date = $this.data('date');

            $tbody.find("a.ui-btn-active").removeClass("ui-btn-active");
            $this.addClass("ui-btn-active");

            if (date.getMonth() !== plugin.settings.date.getMonth()) {
                // Go to previous/next month
                refresh(date);
            } else {
                // Select new date
                $element.trigger('change', date);
            }
        }

        function refresh(date) {
            plugin.settings.date = date = date || plugin.settings.date || new Date();

            day = 0;

            var year = date.getFullYear(),
                month = date.getMonth(),
                daysBefore = _daysBefore(date),
                daysInMonth = _daysInMonth(date),
                weeksInMonth = plugin.settings.weeksInMonth || _weeksInMonth(date, daysInMonth, daysBefore);

            if (((daysInMonth + daysBefore) / 7 ) - weeksInMonth === 0)
                weeksInMonth++;

            // Empty the table body, we start all over...
            $tbody.empty();
            // Change the header to match the current month
            $header.html(year.toString() + "년 " + plugin.settings.months[month]);

            for (var weekIndex = 0,
                     daysInMonthCount = 1,
                     daysAfterCount = 1; weekIndex < weeksInMonth; weekIndex++) {

                var daysInWeekCount = 0,
                    row = $("<tr/>").appendTo($tbody);

                // Previous month
                while (daysBefore > 0) {
                    addCell(row, new Date(year, month, 1 - daysBefore), true);
                    daysBefore--;
                    daysInWeekCount++;
                }

                // Current month
                while (daysInWeekCount < 7 && daysInMonthCount <= daysInMonth) {
                    addCell(row, new Date(year, month, daysInMonthCount), false, daysInMonthCount === date.getDate());
                    daysInWeekCount++;
                    daysInMonthCount++;
                }

                // Next month
                while (daysInMonthCount > daysInMonth && daysInWeekCount < 7) {
                    addCell(row, new Date(year, month, daysInMonth + daysAfterCount), true);
                    daysInWeekCount++;
                    daysAfterCount++;
                }
            }

            $element.trigger('create');
        }

        $element.bind('change', function (event, begin) {
            var nowYear = begin.getFullYear(),
                nowMonth = begin.getMonth(),
                nowDate = begin.getDate();

            var end = new Date(begin.getFullYear(), begin.getMonth(), begin.getDate() + 1, 0, 0, 0, 0);
            // Empty the list
            $listview.empty();

            //달력 선택시 날짜 변경.
            $header.html(nowYear.toString() + "년 " + plugin.settings.months[nowMonth] + " " + nowDate + "일");

            // Find events for this date
            var events = plugin.settings.events.values();

            var isEvent = false;

            for (var i = 0, event; event = events[i]; i++) {
                if(event[plugin.settings.color] && cids.indexOf(event[plugin.settings.cid]) == -1 )
                    continue;

               // if (event[plugin.settings.end] >= begin && event[plugin.settings.begin] < end) {
                if (event[plugin.settings.end] > begin && event[plugin.settings.begin] < end) {
                    isEvent = true;

                    // Append matches to list
                    var summary = event[plugin.settings.summary],
                        //beginTime = (( event[plugin.settings.begin] > begin ) ? event[plugin.settings.begin] : begin ).toTimeString().substr(0, 5),
                        beginTime = ( event[plugin.settings.begin] ).toTimeString().substr(0, 5),
                        endTime = (( event[plugin.settings.end] < end ) ? event[plugin.settings.end] : end ).toTimeString().substr(0, 5),
                        timeString = convert12H(beginTime);//beginTime + "-" + endTime,
                        stateBox = "<span class='state_box2' style='background-color:" + event[plugin.settings.color] + "'></span>",
                        $listItem = $("<li>" + "" + "<a href='#' class='list-item '>" +
                            "<h3 style='margin: 0 0 0 0;color:#000000' class='list-item2 '></h3>" +
                            stateBox+ "<h3 style='margin: 0 0 0 0;font-size: small; color:darkblue' class='list-item3 '></h3>" +
                            "</a></li>").appendTo($listview);

                    plugin.settings.listItemFormatter($listItem, timeString, summary, event);
                }
            }

            if( isEvent)
            {
                listItemSorting();
            }else {
               $("<div style='text-align: center;padding-top: 20px;'><h1> 등록된 일정이 없습니다. </h1></div>").appendTo($listview);
            }

            $listview.trigger('create').filter(".ui-listview").listview('refresh');
        });

        function listItemSorting() {
            var sortListItem = $listview.children('li').get();
            sortListItem.sort(function (a, b) {
                var aItem = JSON.parse($(a).attr('data-item')).begin;
                var bItem = JSON.parse($(b).attr('data-item')).begin;
                return (aItem < bItem) ? -1 : (aItem > bItem) ? 1 : 0;
            });
            $listview.append(sortListItem);
        }

        function listItemFormatter($listItem, timeString, summary, event) {
            var text = ( ( timeString != "00:00-00:00" ) ? timeString : plugin.settings.allDayTimeString ) + " " + summary;

            if (event[plugin.settings.icon]) {
                $listItem.attr('data-icon', event.icon);
            }
            if (event[plugin.settings.url]) {
                $('<a></a>').text(text).attr('href', event[plugin.settings.url]).appendTo($listItem);
            } else {
                $listItem.find('.list-item2').text(text);
                if(!event.CTitle)
                {
                    var description = event.Description? event.Description.replace(/(^\s*)|(\s*$)/gi,"") : "";
                    $listItem.find('.list-item3').text(description || "(상세내용 없음)") ;
                }else{
                    var description = event.Description? " : " + event.Description : "";
                    $listItem.find('.list-item3').text(event.CTitle+"("+event.CMngrName+")" + description ) ;
                }
            }
            $listItem.attr('data-item', JSON.stringify(event));
        }


        function convert12H(time) {

            var _ampmLabel =  [ '오전', '오후' ];
            var _timeRegExFormat = /^([0-9]{2}):([0-9]{2})$/;

            var _timeToken = time.match(_timeRegExFormat);
            if (typeof _timeRegExFormat === 'undefine') {
                // 잘못된 형식
                return null;
            }

            var _intHours = parseInt(_timeToken[1]);
            var _intMinutes = parseInt(_timeToken[2]);
            var _strMinutes = _intMinutes < 10 ? "0"+_intMinutes:""+_intMinutes;
            var _strHours12H = ('0' + (_intHours == 12 ? 12 : _intHours % 12)).slice(-2);

            return _ampmLabel[parseInt(_intHours / 12)] + ' ' + _strHours12H + ':' + _strMinutes;
        }
        $element.bind('refresh', function (event, date) {
            refresh(date);
        });

        $element.bind('update', function (event, ids) {
            cids = ids;
        });

        init();
    }

    $.fn.jqmCalendar = function (options) {
        return this.each(function () {
            if (!$(this).data('jqmCalendar')) {
                $(this).data('jqmCalendar', new $.jqmCalendar(this, options));
            }
        });
    }

})(jQuery);
