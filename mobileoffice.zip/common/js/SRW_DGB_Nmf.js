/*
 * Copyright (c) 2012 mnplus All rights reserved.
 * nmf javascript 
 * 
 * @version 2012.10
 * 
 */
var nmf = nmf || {};
nmf.hostname = null;

var ACCESS_TOKEN = "access_token";

var SEC_INVALID_CLIENT = "invalid_client";
var SEC_UNAUTHORIZED_CLIENT = "unauthorized_client";
var SEC_INVALID_GRANT = "invalid_grant";
var SEC_INVALID_SCOPE = "invalid_scope";
var SEC_INVALID_TOKEN = "invalid_token";
var SEC_INVALID_REQUEST = "invalid_request";
var SEC_REDIRECT_URI_MISMATCH = "redirect_uri_mismatch";
var SEC_UNSUPPORTED_GRANT_TYPE = "unsupported_grant_type";
var SEC_UNSUPPORTED_RESPONSE_TYPE = "unsupported_response_type";
var SEC_ACCESS_DENIED = "access_denied";

var SEC_CLIENT_ID_NOT_FOUND = "client_id_not_found";

/**
 * Ajax
 * 
 */
var _oFail, _oSuccess;
nmf.Ajax = {
	_success: function (data) {
        if (typeof _oSuccess === "function") {
        	_oSuccess(data);
        }
	},
	_fail: function (xhr, error, thrown) {
		if(error === 'timeout') {
			showAlert("오류", "네트워크 접속이 끊어졌습니다.\n잠시후 확인하시기 바랍니다.");
			return;
		}
        if (typeof _oFail === "function") {
        	_oFail(xhr, error, thrown);
        }
	},
	_call: function (options) {
		options["timeout"] = 10000;
    	$.ajax(options);
	},
    request: function (sUrl, sType, aoParameters, oSuccess, oFail) {
    	var aoData = aoParameters;
        if (typeof oSuccess === "function") {
        	_oSuccess = oSuccess;
        }
        if (typeof oFail === "function") {
        	_oFail = oFail;
        }
    	this._call({ "url": HOST_NAME + sUrl,
		         "beforeSend": function (xhr) {
		        	 xhr.withCredentials = true;
		         },
    		     "type": sType,
    		     "data": aoData,
    		     "success": oSuccess,
    		     "error": oFail
    	});
    },
    requestToken: function (sUrl, sType, aoParameters, oSuccess, oFail) {
        var token = aoParameters.access_token || nmf.Store.get(OAUTH2_TOKEN);
    	var headers = {};
       	var aoData = {};

        if (typeof oSuccess === "function") {
        	_oSuccess = oSuccess;
        }
        if (typeof oFail === "function") {
        	_oFail = oFail;
        }
        
        delete aoParameters[ACCESS_TOKEN];
        aoData = aoParameters;
    	
        if(nmf.utils.BrowserDetect.isMobile()) {
         	headers = { "Authorization": "Bearer " + token };
        } else if(!nmf.utils.String.isEmpty(token)) {
        	aoData[ACCESS_TOKEN] = token;
        }
    	this._call({ "url": HOST_NAME + sUrl,
    		     "type": sType,
                 "headers": headers,
    		     "data": aoData,
    		     "success": oSuccess,
    		     "error": oFail
    	});
    }
};

/**
 * Device ID 정보얻기
 */
nmf.Device = {
    deviceId: '',
    message: '',
    mCallback: null,
    register: function () {},
    registerCallback: function (value) {}
};

nmf.Message = {
	/**
	 * @type   : method
	 * @access : public
	 * @object : coMessage
	 * @desc   : 공통메시지에 정의된 메시지를 치환하여 알려준다.
	 * @sig    : message[, paramArray]
	 * @param  : message    required common.js의 공통 메시지 영역에 선언된 메시지 ID
	 * @param  : paramArray optional 메시지에서 '@' 문자와 치환될 스트링 Array. (Array의 index와
	 *           메시지 내의 '@' 문자의 순서가 일치한다.)
	 * @return : 치환된 메시지 스트링
	 */
	get: function (message, params) {
		var index = 0,
		    count = 0;
		if (!message.length) {
			return null;
		}
		if (!params.length) {
			return message;
		}
		while ( (index = message.indexOf("@", index)) != -1) {
			if (!params[count].length) {
				params[count] = "";
			}

			message = message.substr(0, index) + String(params[count]) + message.substring(index + 1);
			index = index + String(params[count++]).length;
		}
		return message;
	}
};

/**
 * 월 달력
 * @example
 * monthCalendarDefault(selector)초기 정보 셋팅
 * parameter : date text가 들어가는 selector
 * 
 */
nmf.monthCalendar = {
    monthCalendarDefault: function (selector) {
    	selector = (!selector) ? '#fromDt' : '#' + selector;
    	selector = $(selector);
    	
        if (typeof $("#monthCalWrapper").val() === 'undefined') {
            $("body").append(nmf.monthCalendar.monthHTML());
        }
        var date = nmf.utils.DateFormat.format(new Date(), 'yymmdd');
		var year = date.substring(0, 4);
		var month = date.substring(4, 6);
		$("#monthCal_year").text(year);
		selector.val(year + "-" + month);
		
		$("#monthCal_left").bind("click", function () {
            var text = parseInt($("#monthCal_year").text());
            $("#monthCal_year").text(text - 1);
	    });
        $("#monthCal_right").bind("click", function () {
            var text = parseInt($("#monthCal_year").text());
            $("#monthCal_year").text(text + 1);
        });
        selector.bind("click", function () {
            var offset = $(this).offset();
            var css = { "left": offset.left, "top": offset.top + 22 };

		    $("#monthCalWrapper").css(css);
		    $("#monthCalWrapper").toggle();
	    });
		$("#monthCal_month_1").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_2").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_3").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_4").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_5").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_6").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_7").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_8").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_9").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_10").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_11").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
			selector.val(month);
	    });
		$("#monthCal_month_12").bind("click", function () {
			var month = nmf.monthCalendar.monthDate($(this));
				selector.val(month);
	    });
	},
	monthDate: function (selector) {
		selector = selector.text();
		var month = nmf.utils.String.parseNumeric(selector);
		var year = $("#monthCal_year").text();
		month = month[1] ? month : "0" + month[0];
		$("#monthCalWrapper").hide();
		return year + "-" + month;
	},
	monthHTML: function () {
		return	 '<div id="monthCalWrapper" class="monthCalendar" style="display: none;">'
				+'<div class="monthCalHeader" id="monthCal">'
				+'<ul>'
				+'<li>'
				+'<a class="ui-datepicker-prev fLeft" id="monthCal_left"><span class="ui-icon ui-icon-circle-triangle-w" style="margin-left:3px;">Prev</span></a>'
				+'</li> '
				+'<li>'
				+'<a class="ui-datepicker-next fRight" id="monthCal_right"><span class="ui-icon ui-icon-circle-triangle-e">Next</span></a>'
				+'</li>'
				+'</ul>'
				+'<h1 id="monthCal_year" style="padding: 2px;font-weight: bold;">2012</h1>'
				+'</div>'
				+'<table id="monthCal_month" class="monthCalMonthArea">'
				+'<tr>'
				+'<td width="40px" height="40" id="monthCal_month_1">1월</td>'
				+'<td width="40px" height="40" id="monthCal_month_2">2월</td>'
				+'<td width="40px" height="40" id="monthCal_month_3">3월</td>'
				+'<td width="40px" height="40" id="monthCal_month_4">4월</td>'
				+'</tr>'
				+'<tr>'
				+'<td width="40px" height="40" id="monthCal_month_5">5월</td>'
				+'<td width="40px" height="40" id="monthCal_month_6">6월</td>'
				+'<td width="40px" height="40" id="monthCal_month_7">7월</td>'
				+'<td width="40px" height="40" id="monthCal_month_8">8월</td>'
				+'</tr>'
				+'<tr>'
				+'<td width="40px" height="40" id="monthCal_month_9">9월</td>'
				+'<td width="40px" height="40" id="monthCal_month_10">10월</td>'
				+'<td width="40px" height="40" id="monthCal_month_11">11월</td>'
				+'<td width="40px" height="40" id="monthCal_month_12">12월</td>'
				+'</tr>'
				+'</table>'
				+'</div>';
	}
};


/**
 * Store
 * 
 */
nmf.Store = {
	localStorageName: 'localStorage',
	globalStorageName: 'globalStorage',
	storage: null,
	isLocalStorageNameSupported: function () {
		try { return (this.localStorageName in window && window[this.localStorageName]); }
		catch(err) { return false; }
    },
	isGlobalStorageNameSupported: function () {
		try { return (this.globalStorageName in window && window[this.globalStorageName]); }
		catch(err) { return false; }
    },
	set: function (key,value) {},
	get: function (key) {},
	remove: function (key) {},
	clear: function () {},
	getAll: function () {},
	serialize: function (value) {
		return JSON.stringify(value);
	},
	deserialize: function (value) {
		if (typeof value !== 'string') { return undefined; }
		try { return JSON.parse(value); }
		catch(e) { return value || undefined; }
	}
};
if(nmf.Store.isLocalStorageNameSupported()) {
	nmf.Store.storage = window[nmf.Store.localStorageName];
	nmf.Store.set = function (key, value) {
		if (value === undefined) { return this.remove(key); }
		this.storage.setItem(key, this.serialize(value));
		return value;
	};
	nmf.Store.get = function (key) { return this.deserialize(this.storage.getItem(key)); };
	nmf.Store.remove = function (key) { this.storage.removeItem(key); };
	nmf.Store.clear = function () { storage.clear(); };
	nmf.Store.getAll = function () {
		var ret = {};
		for (var i=0; i<storage.length; ++i) {
			var key = storage.key(i);
			ret[key] = store.get(key);
		}
		return ret;
	};
} else {
	nmf.Store.storage = window[nmf.Store.globalStorageName][window.location.hostname];
	nmf.Store.set = function (key, val) {
		if (val === undefined) { return this.remove(key); }
		this.storage[key] = this.serialize(val);
		return val;
	};
	nmf.Store.get = function (key) { return this.deserialize(storage[key] && this.storage[key].value); };
	nmf.Store.remove = function (key) { delete storage[key]; };
	nmf.Store.clear = function () { for (var key in this.storage ) { delete this.storage[key]; } };
	nmf.Store.getAll = function () {
		var ret = {};
		for (var i=0; i<storage.length; ++i) {
			var key = storage.key(i);
			ret[key] = store.get(key);
		}
		return ret;
	};
}

nmf.utils = {};
(function() {
	this.BrowserDetect = {};
	this.Date = {};
	this.DateFormat = {};
	this.JSON = {};
	this.Masker = {};
	this.NumberFormat = {};
	this.Object = {};
	this.String = {};
	this.UUID = {};
}).apply(nmf.utils);

(function () {
	var _dataBrowser = [ { string: navigator.userAgent, subString: 'Chrome', identity: 'Chrome' },
                         { string: navigator.userAgent, subString: 'OmniWeb', versionSearch: 'OmniWeb/', identity: 'OmniWeb' },
                         { string: navigator.vendor, subString: 'Apple', identity: 'Safari', versionSearch: 'Version' },
                         { prop: window.opera, identity: 'Opera', versionSearch: 'Version' },
                         { string: navigator.vendor, subString: 'iCab', identity: 'iCab' },
                         { string: navigator.vendor, subString: 'KDE', identity: 'Konqueror' },
                         { string: navigator.userAgent, subString: 'Firefox', identity: 'Firefox' },
                         { string: navigator.vendor, subString: 'Camino', identity: 'Camino' },
                         { string: navigator.userAgent, subString: 'Netscape', identity: 'Netscape' },
                         { string: navigator.userAgent, subString: 'MSIE', identity: 'Explorer', versionSearch: 'MSIE' },
                         { string: navigator.userAgent, subString: 'Gecko', identity: 'Mozilla', versionSearch: 'rv' }
                       ],
        _dataOS = [ { string: navigator.platform, subString: 'Win', identity: 'Windows' },
              { string: navigator.platform, subString: 'Mac', identity: 'Mac' },
              { string: navigator.userAgent, subString: 'iPhone', identity: 'iPhone' },
              { string: navigator.platform, subString: 'Linux', identity: 'Linux' }
        ],
        _isTablet = (/iPad|GT-N8000|GT-P5100|GT-P1000/.test(navigator.userAgent));
  
	_searchString = function (data) {
		for (var i=0;i<data.length;i++) {
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			} else {
				if (dataProp) {
					return data[i].identity;
				}
			}
		}
	};

	_searchVersion = function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	};

	this.rootUrl = function () {
		var root = "";
		if(this.isMobile()) {
			var fullpath = window.location + '';
			//root = fullpath.substr(0, fullpath.lastIndexOf("www/") + 3); //phonegap root URL
			root=fullpath.substr(0,fullpath.lastIndexOf("default/")+7);	//worklight root URL
		}
		return root;
	};
	this.isMobile = function () {
		return (this.getOS() === 'Linux') || (this.getOS() === 'iPhone');
	};
	this.isTablet = function () {
		return _isTablet;
	};
	this.isAndroid = function () {
		return (this.getOS() === 'Linux');
	};
	this.isIOS = function () {
		return (this.getOS() === 'iPhone');
	};
	this.getBrowser = function () {
		return _searchString(_dataBrowser) || 'An unknown browser';
	};
	this.getVersion = function () {
		return _searchVersion(navigator.userAgent) ||
           _searchVersion(navigator.appVersion) || 'an unknown version';
	};
	this.getOS = function () {
		return _searchString(_dataOS) || 'an unknown OS';
	};
	this.getAll = function () {
		return { 'browser': this.getBrowser(),
                 'version': this.getVersion(),
                 'os': this.getOS() };
	};
}).apply(nmf.utils.BrowserDetect);

(function () {
	var _date = new Date();
	var _year = _date.getFullYear(),
    _month = _date.getMonth() + 1,
    _day = _date.getDate(),
    _dayInWeek = _date.getDay(),
    _hour24 = _date.getHours(),
    _ampm = (_hour24 < 12) ? "AM" : "PM",
    _hour12 = (_hour24 > 12) ? (_hour24 - 12) : _hour24,
    _min = _date.getMinutes(),
    _sec = _date.getSeconds(),
    _YYYY = "" + _year,
    _YY = _YYYY.substr(2),
    _MM = (("" + _month).length == 1) ? "0" + _month : "" + _month,
    //MON = GLB_MONTH_IN_YEAR[month-1],
    //mon = GLB_SHORT_MONTH_IN_YEAR[month-1],
    _DD = (("" + _day).length == 1) ? "0" + _day : "" + _day,
    //DAY = GLB_DAY_IN_WEEK[dayInWeek],
    //day = GLB_SHORT_DAY_IN_WEEK[dayInWeek],
    _HH = (("" + _hour24).length == 1) ? "0" + _hour24 : "" + _hour24,
    _hh = (("" + _hour12).length == 1) ? "0" + _hour12 : "" + _hour12,
    _mm = (("" + _min).length == 1) ? "0" + _min : "" + _min,
    _ss = (("" + _sec).length == 1) ? "0" + _sec : "" + _sec
    //SS = "" + this.getMilliseconds()
    ;
	_defaults = {
		shortYearCutoff: '+10',
		dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		monthNames: ['January','February','March','April','May','June', 'July','August','September','October','November','December']
	};
	
	this.getDefaults = function () {
		return _defaults;
	};
    this.parseDate = function (value, pattern) {
      if (pattern == null || value == null) {
        throw 'Invalid arguments';
      }
      value = (typeof value == 'object' ? value.toString() : value + '');
      if (!value.length) {
        return null;
      }
      var shortYearCutoff = _defaults.shortYearCutoff;
      shortYearCutoff = _year % 100 + parseInt(shortYearCutoff, 10);
      var dayNamesShort = _defaults.dayNamesShort;
      var dayNames = _defaults.dayNames;
      var monthNamesShort = _defaults.monthNamesShort;
      var monthNames = _defaults.monthNames;
      var year = -1;
      var month = -1;
      var day = -1;
      var doy = -1;
      var literal = false;
      // Check whether a format character is doubled
      var lookAhead = function(match) {
        var matches = (iFormat + 1 < pattern.length && pattern.charAt(iFormat + 1) == match);
        if (matches) {
          iFormat++;
        }
        return matches;
      };
      // Extract a number from the string value
      var getNumber = function(match) {
        var isDoubled = lookAhead(match);
        var size = (match == '@' ? 14 : (match == '!' ? 20 : (match == 'y' && isDoubled ? 4 : (match == 'o' ? 3 : 2))));
        var digits = new RegExp('^\\d{1,' + size + '}');
        var num = value.substring(iValue).match(digits);
        if (!num) {
          throw 'Missing number at position ' + iValue;
        }
        iValue += num[0].length;
        return parseInt(num[0], 10);
      };
      // Extract a name from the string value and convert to an index
      var getName = function (match, shortNames, longNames) {
        var names = $.map(lookAhead(match) ? longNames : shortNames, function (v, k) {
                                                                       return [ [k, v] ];
                                                                     }).sort(function (a, b) { return -(a[1].length - b[1].length); });
        var index = -1;
        $.each(names, function (i, pair) {
          var name = pair[1];
          if (value.substr(iValue, name.length).toLowerCase() == name.toLowerCase()) {
            index = pair[0];
            iValue += name.length;
            return false;
          }
        });
        if (index != -1) {
          return index + 1;
        } else {
          throw 'Unknown name at position ' + iValue;
        }
      };
      // Confirm that a literal character matches the string value
      var checkLiteral = function() {
        if (value.charAt(iValue) != pattern.charAt(iFormat)) {
          throw 'Unexpected literal at position ' + iValue;
        }
        iValue++;
      };
      var iValue = 0;
      for (var iFormat = 0; iFormat < pattern.length; iFormat++) {
        if (literal) {
          if (pattern.charAt(iFormat) == "'" && !lookAhead("'")) {
            literal = false;
          } else {
            checkLiteral();
          }
        } else {
          switch (pattern.charAt(iFormat)) {
            case 'd':
              day = getNumber('d');
              break;
            case 'D':
              getName('D', dayNamesShort, dayNames);
              break;
            case 'o':
              doy = getNumber('o');
              break;
            case 'm':
              month = getNumber('m');
              break;
            case 'M':
              month = getName('M', monthNamesShort, monthNames);
              break;
            case 'y':
              year = getNumber('y');
              break;
            case '@':
              var date = new Date(getNumber('@'));
              year = date.getFullYear();
              month = date.getMonth() + 1;
              day = date.getDate();
              break;
            case '!':
              var date = new Date((getNumber('!') - this._ticksTo1970) / 10000);
              year = date.getFullYear();
              month = date.getMonth() + 1;
              day = date.getDate();
              break;
            case "'":
              if (lookAhead("'")) {
                checkLiteral();
              } else {
                literal = true;
              }
              break;
            default:
              checkLiteral();
          }
        }
      }
      if (iValue < value.length){
        var extra = value.substr(iValue);
        if (!/^\s+/.test(extra)) {
          throw "Extra/unparsed characters found in date: " + extra;
        }
      }
      if (year == -1) {
        year = new Date().getFullYear();
      } else if (year < 100) {
        year += new Date().getFullYear() - new Date().getFullYear() % 100 + (year <= shortYearCutoff ? 0 : -100);
      }
      if (doy > -1) {
        month = 1;
        day = doy;
        do {
          var dim = this._getDaysInMonth(year, month - 1);
          if (day <= dim) {
            break;
          }
          month++;
          day -= dim;
        } while (true);
      }
      var date = _daylightSavingAdjust(new Date(year, month - 1, day));
      if (date.getFullYear() != year || date.getMonth() + 1 != month || date.getDate() != day) {
        throw 'Invalid date'; // E.g. 31/02/00
      }
      return date;
    };
    _daylightSavingAdjust = function (date) {
		if (!date) return null;
		date.setHours(date.getHours() > 12 ? date.getHours() + 2 : 0);
		return date;
	};
	this.getDays = function (fromDate, toDate) {
		var days = (toDate - fromDate);
		return days / 24 / 3600 / 1000;
	};
    this.addDays = function (date, amount) {
    	if(Object.prototype.toString.call() == "[object Date]") {
    		return null;
    	}
    	return new Date(date.valueOf() + (amount * 24 * 3600 * 1000));
    };
}).apply(nmf.utils.Date);

(function () {
  this.format = function (date, pattern) {
    if (!date) {
      return '';
    }
    var defaults = nmf.utils.Date.getDefaults();
    var dayNamesShort = defaults.dayNamesShort;
    var dayNames = defaults.dayNames;
    var monthNamesShort = defaults.monthNamesShort;
    var monthNames = defaults.monthNames;
    // Check whether a format character is doubled
    var lookAhead = function(match) {
      var matches = (iFormat + 1 < pattern.length && pattern.charAt(iFormat + 1) == match);
      if (matches) {
        iFormat++;
      }
      return matches;
    };
    // Format a number, with leading zero if necessary
    var formatNumber = function(match, value, len) {
      var num = '' + value;
      if (lookAhead(match)) {
        while (num.length < len) {
          num = '0' + num;
        }
      }
      return num;
    };
    // Format a name, short or long as requested
    var formatName = function(match, value, shortNames, longNames) {
      return (lookAhead(match) ? longNames[value] : shortNames[value]);
    };
    var output = '';
    var literal = false;
    if (date) {
      for (var iFormat = 0; iFormat < pattern.length; iFormat++) {
        if (literal) {
          if (pattern.charAt(iFormat) == "'" && !lookAhead("'")) {
            literal = false;
          } else {
            output += pattern.charAt(iFormat);
          }
        } else {
          switch (pattern.charAt(iFormat)) {
            case 'd':
              output += formatNumber('d', date.getDate(), 2);
              break;
            case 'D':
              output += formatName('D', date.getDay(), dayNamesShort, dayNames);
              break;
            case 'o':
              output += formatNumber('o',
                Math.round((new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000), 3);
              break;
            case 'm':
              output += formatNumber('m', date.getMonth() + 1, 2);
              break;
            case 'M':
              output += formatName('M', date.getMonth(), monthNamesShort, monthNames);
              break;
            case 'y':
              output += (lookAhead('y') ? date.getFullYear() : (date.getYear() % 100 < 10 ? '0' : '') + date.getYear() % 100);
              break;
            case '@':
              output += date.getTime();
              break;
            case '!':
              output += date.getTime() * 10000 + this._ticksTo1970;
              break;
            case "'":
              if (lookAhead("'")) {
                output += "'";
              } else {
                literal = true;
              }
              break;
            default:
              output += pattern.charAt(iFormat);
          }
        }
      }
    }
    return output;
  };
}).apply(nmf.utils.DateFormat);

(function() {
  this.ObjectCopy = function (obj) {
	  return JSON.parse(JSON.stringify(obj));
  };
}).apply(nmf.utils.JSON);

/**
 * nmf.utils.Masker
 * 
 */
(function() {
	
	/**
	 * 숫자 형식
	 */
	this.formatNumber = function (num, pattern) {
		return num;
	};
	
	/**
	 * 
	 */
	this.formatString = function (value, pattern) {
		if(!value.length) return "";

		var unformattedString = value,
		    formattedString = "",
		    thisChar;
		var len = unformattedString.length,
		    patternLength = pattern.length,
		    patternIndex = 0,
		    ignoreNumbers = 0;
		
		for (var index = 0; index < len; index++) {
			if (patternIndex < patternLength) {
				var loop = true;
				while(loop) {
					thisChar = pattern.charAt(patternIndex);
					if (thisChar == '#') { break; }
					else if (thisChar == '*') {
						ignoreNumbers++;
						break;
					} else if (thisChar == '$') {
						if ((patternIndex + 1 < patternLength) && (pattern.charAt(patternIndex + 1) == '$')) {
							patternIndex++;
						} else if ((patternIndex + 1 < patternLength) && (pattern.charAt(patternIndex + 1) == '#')) {
							patternIndex++;
						} else if ((patternIndex + 1 < patternLength) && (pattern.charAt(patternIndex + 1) == '*')) {
							patternIndex++;
						}
					}
					formattedString += pattern.charAt(patternIndex);
					patternIndex++;
					if (patternIndex >= patternLength) loop = false;
				}
			}
			if ((patternIndex >= patternLength))
				break;
			if (ignoreNumbers == 1) {
				formattedString += unformattedString.substring(index);
				ignoreNumbers++;
			} else if (ignoreNumbers > 1) {
				// Ignore
			} else {
				formattedString += unformattedString.charAt(index);
			}
			patternIndex++;
		}
		if (patternIndex < patternLength) {
			while (patternIndex < patternLength) {
				var patternChar = pattern.charAt(patternIndex);
				if (patternChar == '#') {
					formattedString += " ";
				} else {
					formattedString += patternChar;
				}
				patternIndex++;
			}
		}
		return formattedString;
	};

	/**
	 * 전화번호 형식변경
	 * @param value
	 * @reurn
	 */
	this.formatPhone = function (value) {
		return value.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,'$1-$2-$3');
	};
}).apply(nmf.utils.Masker);

/**
 * nmf.utils.NumberFormat
 * 
 */
(function() {
  var settings = {
    currency: {
      symbol: "W",		// default currency symbol is '$'
      format: "%s%v",	// controls output: %s = symbol, %v = value (can be object, see docs)
      decimal: ".",		// decimal point separator
      thousand: ",",		// thousands separator
      precision: 2,		// decimal places
      grouping: 3		// digit grouping (not implemented yet)
    },
    number: {
      precision: 0,		// default precision on numbers is 0
      grouping : 3,		// digit grouping (not implemented yet)
      thousand : ",",
      decimal : "."
    }
  };
  
  checkPrecision = function (val, base) {
    val = Math.round(Math.abs(val));
    return isNaN(val)? base : val;
  };
  
  defaults = function (object, defs) {
    var key;
    object = object || {};
    defs = defs || {};
    // Iterate over object non-prototype properties:
    for (key in defs) {
      if (defs.hasOwnProperty(key)) {
        // Replace values with defaults only if undefined (allow empty/zero values):
        if (object[key] == null) object[key] = defs[key];
      }
    }
    return object;
  };

  this.formatNumber = function (number, precision, thousand, decimal) {
    if (nmf.utils.Object.isArray(number)) {
      return map(number, function(val) {
                           return formatNumber(val, precision, thousand, decimal);
                         });
    }

    // Clean up number:
    number = this.unformat(number);

    // Build options object from second param (if object) or all params, extending defaults:
    var opts = defaults(
      (nmf.utils.Object.isObject(precision) ? precision : {
                    precision : precision,
					thousand : thousand,
					decimal : decimal
				    }),
      settings.number
    ),

    // Clean up precision
    usePrecision = checkPrecision(opts.precision),

    // Do some calc:
    negative = number < 0 ? "-" : "",
    base = parseInt(this.toFixed(Math.abs(number || 0), usePrecision), 10) + "",
    mod = base.length > 3 ? base.length % 3 : 0;

    // Format the number:
    return negative + (mod ? base.substr(0, mod) + opts.thousand : "") + base.substr(mod).replace(/(\d{3})(?=\d)/g, "$1" + opts.thousand) + (usePrecision ? opts.decimal + this.toFixed(Math.abs(number), usePrecision).split('.')[1] : "");
  };
  
  map = function (obj, iterator, context) {
    var results = [], i, j;

    if (!obj) return results;

    // Use native .map method if it exists:
    if (nmf.utils.Object.isMap(obj)) return obj.map(iterator, context);

    // Fallback for native .map:
    for (i = 0, j = obj.length; i < j; i++ ) {
      results[i] = iterator.call(context, obj[i], i, obj);
    }
    return results;
  };
  
  this.toFixed = function (value, precision) {
    precision = checkPrecision(precision, settings.number.precision);
    var power = Math.pow(10, precision);

    // Multiply up by precision, round accurately, then divide and use native toFixed():
    return (Math.round(this.unformat(value) * power) / power).toFixed(precision);
  };

  this.unformat = function(value, decimal) {
    // Recursively unformat arrays:
    if (nmf.utils.Object.isArray(value)) {
      return map(value, function(val) {
				          return this.unformat(val, decimal);
			            });
    }

    // Fails silently (need decent errors):
    value = value || 0;

    // Return the value as-is if it's already a number:
    if (typeof value === "number") return value;
      // Default decimal point comes from settings, but could be set to eg. "," in opts:
      decimal = decimal || lib.settings.number.decimal;

      // Build regex to strip out everything except digits, decimal point and minus sign:
      var regex = new RegExp("[^0-9-" + decimal + "]", ["g"]),
        unformatted = parseFloat(
            ("" + value)
            .replace(/\((.*)\)/, "-$1") // replace bracketed values with negatives
            .replace(regex, '')         // strip out any cruft
            .replace(decimal, '.')      // make sure decimal point is standard
        );

      // This will fail silently which may cause trouble, let's wait and see:
      return !isNaN(unformatted) ? unformatted : 0;
  };

}).apply(nmf.utils.NumberFormat);

(function() {
	var nativeMap = Array.prototype.map,
	    nativeIsArray = Array.isArray,
	    toString = Object.prototype.toString;
  
	this.isString = function (obj) {
		return !!(obj === '' || (obj && obj.charCodeAt && obj.substr));
	};

	/**
     * Tests whether supplied parameter is a string
     * from underscore.js, delegates to ECMA5's native Array.isArray
     */
	this.isArray = function (obj) {
		return nativeIsArray ? nativeIsArray(obj) : toString.call(obj) === '[object Array]';
	};
  
	this.isMap = function (obj) {
		return (nativeMap && obj.map === nativeMap) ? true : false;
	};

	/**
     * Tests whether supplied parameter is a true object
     */
	this.isObject = function (obj) {
		return obj && toString.call(obj) === '[object Object]';
	};
	
	this.clone = function (obj) {
		if (null == obj || !this.isObject(obj))
			return obj;
	    var copy = obj.constructor();
	    for (var attr in obj) {
	        if (obj.hasOwnProperty(attr))
	        	copy[attr] = obj[attr];
	    }
	    return copy;
	};
}).apply(nmf.utils.Object);

(function() {
	/**
	 * 
	 */
	this.defaultString = function (str, defaultValue) {
		var val = str;
		if(!nmf.utils.Object.isString(val)) return val;
		if(val === undefined || !(val+'').length) {
			val = (defaultValue === undefined) ? "" : defaultValue;
		}
		return val;
	};
	
	/**
	 * 
	 * @param str
	 */
	this.isBlank = function (str) {
		var value = this.alltrim(str);
		return this.isEmpty(value);
	};

	/**
	 * 
	 * @param str
	 */
	this.isEmpty = function (str) {
		if(!nmf.utils.Object.isString(str)) return false;
		return (str === undefined) || (!(str+'').length);
	};
	
	/**
	 * 
	 * @param value
	 */
	this.parseNumeric = function (str) {
		if(!nmf.utils.Object.isString(str)) return str;
		return (str+'').replace(/\D/g,'');
	};
	
	/**
	 * 
	 * @param str
	 */
	this.alltrim = function (str) {
		if(!nmf.utils.Object.isString(str)) return str;
		return (str+'').replace(/^\s+|\s+$/g, '');
	};
	
	/**
	 * 
	 * @param str
	 */
	this.ltrim = function (str) {
		if(!nmf.utils.Object.isString(str)) return str;
		return (str+'').replace(/^\s+/, '');
	};
	
	/**
	 * 
	 * @param str
	 */
	this.rtrim = function (str) {
		if(!nmf.utils.Object.isString(str)) return str;
		return (str+'').replace(/\s+$/, '');
	};
}).apply(nmf.utils.String);

(function() {
	this.get = function () {
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
		    return v.toString(16);
		});
	};
}).apply(nmf.utils.UUID);

/**
 *  Validate
 * 
 */
nmf.Validate = {
	validItems: [],
	errMsg: "",
	init: function (expression) {},
	parse: function (expression) {
		if (!expression.length) { return; }
	},
	validate: function() {}
};

/**
 * nmf.Device 구현부
 * 
 */
if(nmf.utils.BrowserDetect.isAndroid()) {
	nmf.Device.register = function (deviceCallback) {
		if( typeof deviceCallback === "function" ) {
			nmf.Device.mCallback = deviceCallback;
        }
		var gcm = cordova.require("cordova/plugin/gcmhandler");
		gcm.register(GCM_PROJECT_NO, "nmf.Device.registerCallback", nmf.Device.gcmSuccess, nmf.Device.gcmFail);
	};
	nmf.Device.gcmSuccess = function (e) {
	};
	nmf.Device.gcmFail = function (e) {
	};
	nmf.Device.registerCallback = function (value) {
		nmf.Device.deviceId = '';
		switch(value.event) {
		case 'registered':
			if ( value.regid.length ) {
				nmf.Device.deviceId = value.regid;
				if( typeof callback === "function" ) {
					nmf.Device.mCallback(value.regid);
				}
			} else {
				nmf.Device.message = 'registered number empty';
			}
			if( typeof nmf.Device.mCallback === "function" ) {
				nmf.Device.mCallback(nmf.Device.deviceId);
			}
			break;
		case 'message':
			nmf.Device.message = value.message;
			showAlert(value.message);
		case 'error':
			nmf.Device.message = value.msg;
			break;
		}
	};
} else if(nmf.utils.BrowserDetect.isIOS()) {
	nmf.Device.register = function (deviceCallback) {
		var pushNotification = window.plugins.pushNotification;
		if( typeof deviceCallback === "function" ) {
			nmf.Device.mCallback = deviceCallback;
        }
		pushNotification.registerDevice({alert:true, badge:true, sound:true}, nmf.Device.registerCallback);
	};
	nmf.Device.registerCallback = function (value) {
		nmf.Device.deviceId = value.deviceToken;
		if( typeof nmf.Device.mCallback === "function" ) {
			nmf.Device.mCallback(nmf.Device.deviceId);
		}
	};
}

/**
 * 
 * 
 */
function alertDismissed() {
}

/**
 * 
 * @param val1 타이틀
 * @param val2 메시지
 */
function showAlert(val1, val2, callback) {
	var is = (arguments.length >= 2);
	if( DGB.isDebug() || (DGB.isAndroid() && parseFloat(window.device.version) >= 7) ) {
	// if( DGB.isDebug() ) {
		alert(is ? val2 : val1);
		if( callback ) {
			callback('1');
		}
	} else {
		navigator.notification.alert(
			is ? val2 : val1,
			callback ? callback : alertDismissed,
			nmf.utils.String.defaultString(is ? val1 : '', '알림'),
			'확인'
		);
	}
}

/**
 * @type   : function
 * @access : public
 * @desc   : 상대경로에 HTML파일로 이동을 한다.
 * @param  : url 이동할 페이지 경로 및 파일이름
 * <pre>
 *      nmfFPage(url);
 * </pre>
 * @author : 
 */
function nmfFPage(url) {
	location.href = nmfFURL(url);
}

/**
 * 
 * @type   : function
 * @access : public
 * @desc   : 
 * @param url
 * <pre>
 *      nmfFURL(url);
 * </pre>
 */
function nmfFURL(url) {
	return nmf.utils.BrowserDetect.rootUrl() + url;
}
