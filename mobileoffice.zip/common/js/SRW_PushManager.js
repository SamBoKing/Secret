/**
 * 푸시지원여부
 */
function isPushSupported(){
	var isSupported = false;
	if (WL.Client.Push){
		isSupported = WL.Client.Push.isPushSupported();
	}
    return isSupported;
}

/**
 * 푸시 상태 true/false
 */
function isPushSubscribed(){
	var isSubscribed = false;
	if (WL.Client.Push) {
		isSubscribed = WL.Client.Push.isSubscribed('mySimplePush');
	}
	return isSubscribed;
}

/**
 * 푸시정보 등록
 */
function initSubscribe(){
    if(DGB.isIPhone()){
        WL.Client.Push.registerEventSourceCallback(
            "mySimplePush",
            "SimplePushAdapter",
            "SimplePushEventSource",
            pushNotificationReceived);
    }
    else{
        WL.Client.Push.onReadyToSubscribe = function() {
            console.debug("[SRW_WorkLight_Init] ====>> WL.Client.Push Olleh!");

            WL.Client.Push.registerEventSourceCallback(
                "mySimplePush",
                "SimplePushAdapter",
                "SimplePushEventSource",
                pushNotificationReceived);

            doSubscribe();
        };
    }
}
// --------------------------------- Subscribe ------------------------------------
/**
 * 푸시 사용자 및 디바이스 등록 체크
 */
function doSubscribe(){
    if( WL.Client.Push ) {
		WL.Client.Push.subscribe("mySimplePush", {
			onSuccess: doSubscribeSuccess,
			onFailure: doSubscribeFailure
		});
    }
}

/**
 * 푸시사용자등록 성공
 */
function doSubscribeSuccess(){
    DGB.Log.l("[DGB.PushManager] ====>> SubscribeSuccess");
}

/**
 * 푸시사용자등록 실패
 */
function doSubscribeFailure() {
    DGB.Log.l("[DGB.PushManager] ====>>  SubscribeFailure!");
}

//------------------------------- Unsubscribe ---------------------------------------
/**
 * 푸시정보해제
 */
function doUnsubscribe(){
	WL.Client.Push.unsubscribe("mySimplePush", {
		onSuccess: doUnsubscribeSuccess,
		onFailure: doUnsubscribeFailure
	});
}

function doUnsubscribeSuccess(){
	// doSubscribe();
    DGB.Log.l("[DGB.PushManager] ====>>  UnsubscribeSuccess!");
}

function doUnsubscribeFailure(){
    DGB.Log.l("[DGB.PushManager] ====>>  UnsubscribeFailure!");
}

//------------------------------- Handle received notification ---------------------------------------
/**
 * 푸시메시지
 */
var lastPushId = -1;
var timerPushNotification = 0;
function pushNotificationReceived(props, payload){
    DGB.Log.l("[DGB.PushManager] ====>> Received : " + JSON.stringify({ props : props, payload : payload }));

    if(!DGB || !DGB.isInit) {
        if( timerPushNotification != 0 )
            clearTimeout(timerPushNotification);

        timerPushNotification = setTimeout(function(){
            DGB.Log.l("[DGB.PushManager] ====>> setTimeout Start!");
    		pushNotificationReceived(props, payload);
    	}, 1000);
    	return;
    }

    // 푸시 중복 방지코드
    if( lastPushId != -1 && lastPushId == payload.k1 ) {
        return;
    }
    lastPushId = payload.k1;
    
	var alertMsg = props.alert;
	if ( DGB.isIPhone() ) {
		WL.Badge.setNumber(0);          // IOS뱃지카운트
		alertMsg = props.alert.body;
	}

    /**
     * 파라매터 정의
     * payload.k1   푸시 일련번호
     * payload.k2   메뉴 id
     * payload.k3   링크 url
     * payload.k4   발신자 행번
     * payload.k5   확인되지 않은 메시지 갯수
     * payload.k6   구분코드
    **/
    // 알림센터(1회성, 테이블에 메시지 안남음)
    if( payload.k4 ) {
        switch ( payload.k4 ) {
            // 푸시 알림센터 관리자
            case 'A001':
                var msg = Messages.msg128.replace('{}', payload.k5);
                showConfirm(function(btn){
                    if (btn == '1') {
                        DGB.menuctrl.triggerMenuItem('CO0101');
                    }
                }, msg);
                break;
        }
        return;
    }

    // 푸시인증
    if( alertMsg.indexOf('[DGB오피스]') > -1 ) {
        pushReceiver(alertMsg);
        return;
    }

    var msg = alertMsg + "\n(상세 메시지를 확인하시겠습니까?)";
    setTimeout(function(){
        showConfirm(function(btn){
            if (btn == '1') {
                var detailId = "";
                var args = {};
                if( loginYN ) {
                    detailId = "CO00002";
                    args.pushpopup = "pushpopup";
                    args.menuId = "CO0101";
                    // 푸시 받은 화면이 메시지함인 경우 refresh
                    args.messageRefresh = ($('.ui-page-active').attr('id') == "CO00002");
                } else {
                    detailId = "COPU001";
                    args.payload = payload.k1 + '';
                    args.menuId = payload.k2;
                }

                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
                setTimeout(function () {
                    DGB.Page.changePage("#"+detailId);
                },400);
            }
        }, msg);
    }, 0);
}