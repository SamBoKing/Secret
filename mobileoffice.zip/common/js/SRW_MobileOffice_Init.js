$(function() {
    var _this, _layout, _main_left, _main_light, _main_popup, _main_board, _is_init, _is_mdm;

    var MAIN = {
        IMG_PATH : 'images/main/',
        IMG_OVER : '_over',
        IMG_EXT : '.png',
        LEFT : [
            { TITLE : '도서검색<br>&nbsp;', IMG : 'm_sec_icon01', ID : 'BO0101' },
            { TITLE : '직원통합<br>조회', IMG : 'm_sec_icon02', ID : 'EM0101' },
            { TITLE : '일정관리<br>&nbsp;', IMG : 'm_sec_icon03', ID : 'GW0200' },
            { TITLE : '규정정보<br>&nbsp;', IMG : 'm_sec_icon04', ID : 'LI0001' },
            { TITLE : '윙크톡<br>&nbsp;', IMG : 'm_sec_icon05', ID : 'EM0501' },
            { TITLE : 'DGB<br>맛집', IMG : 'm_sec_icon06', ID : 'FD0001' }
        ],
        RIGHT : [
            {
                TITLE : '커뮤니케이션', IMG : 'm_rnb01', COLOR : '#0fbbdf',
                POPUP : [
                    { TITLE : '쪽지함', ID : 'CO0100', ALERT : true },
                    { TITLE : '윙크톡', ID : 'EM0501' },
                    { TITLE : '메일', ID : 'GR0100', ALERT : true },
                    { TITLE : '경조사', ID : 'EM0201' },
                    { TITLE : '일정관리', ID : 'GW0200' },
                    { TITLE : '직원통합<br>조회', ID : 'EM0101' },
                    { TITLE : 'iM챗봇', ID : 'CHAT01' }
                ]
            },
            {
                TITLE : '마케팅', IMG : 'm_rnb02', COLOR : '#1587d2',
                POPUP : [
                    { TITLE : '금리조회', ID : 'PR0200', ALERT : true },
                    { TITLE : '외환', ID : 'PR0300', ALERT : true },
                    { TITLE : '아파트<br>시세조회', ID : 'PR0104' },
                    { TITLE : '상품관', ID : 'PR0101' },
                    { TITLE : '프로매너', ID : 'GR0501' }
                ]
            },
            {
                TITLE : '스마트워크', IMG : 'm_rnb03', COLOR : '#f0a91d',
                POPUP : [
                    { TITLE : '거액<br>이동명세', ID : 'RE0401' },
                    { TITLE : '영업계수', ID : 'RE0101' },
                    { TITLE : '영업점현황', ID : 'RE0102' },
                    { TITLE : '영업실적', ID : 'RE0103' },
                    { TITLE : '지점알리미<br>수정', ID : 'BA0001' },
                    { TITLE : '지점알리미<br>현황', ID : 'BA0003' }
                ]
            },
            {
                TITLE : '회의/연수', IMG : 'm_rnb04', COLOR : '#eb8145',
                POPUP : [
                    { TITLE : '부점자체<br>연수', ID : 'LE0101' },
                    { TITLE : 'ACT', ID : 'LE0200', ALERT : true },
                    { TITLE : '통신연수', ID : 'LE0301' },
                    { TITLE : '주요 자격증', ID : 'LE0302' },
                    { TITLE : '임원회의', ID : 'RE0201' },
                    { TITLE : '스마트회의', ID : 'DA0001' }

                ]
            }
        ]
    };

    // 신규메뉴 표시
    var new_menu = [];
    if( Messages.opt002 ) {
        var opt = JSON.parse(Messages.opt002.replace(/'/g, '\"')) || {};
        // menu new icon
        if (opt && opt.new_menu.length > 0) {
            new_menu = opt.new_menu;
        }
    }

    for(var j in MAIN.LEFT) {
        var menu_id =  MAIN.LEFT[j].ID;
        if( menu_id && new_menu && new_menu.length ) {
            if( new_menu.indexOf(menu_id) > -1 ) {
                MAIN.LEFT[j].NEW = true;
            }
        }
    }

    // 메인 기본값 셋팅
    for(var i in MAIN.RIGHT) {
        MAIN.RIGHT[i].INDEX = i;
    }

    function tabImgOverClear() {
        var ext = MAIN.IMG_EXT;
        var over = MAIN.IMG_OVER + MAIN.IMG_EXT;
        var imgs = _this.find('.main_right_img');
        for(var i = 0; i < imgs.length; i++) {
            var img = $(imgs[i]);
            var src = img.attr('src');
            if( src.indexOf(over) > -1 ) {
                src = src.replace(over, ext);
                img.attr('src', src).removeClass('main_right_img_over');
            }
        }
    }

    function onRightTabClick() {
        var me = $(this);
        var ext = MAIN.IMG_EXT;
        var over = MAIN.IMG_OVER + MAIN.IMG_EXT;
        var img = me.find('.main_right_img');
        var src = img.attr('src') || '';
        var off = src.indexOf(over) == -1;

        if( off ) {
            tabImgOverClear();
            img.addClass('main_right_img_over');
        } else {
            img.removeClass('main_right_img_over');
        }
        src = src.replace(off ? ext : over, off ? over : ext);
        img.attr('src', src);

        var index = me.data('index');
        var right = MAIN.RIGHT[index] || {};
        if( off ) {
            _main_popup.empty().mustache('freeSv_popup_tmpl', right);
            _main_popup.css('background-color', right.COLOR);
            _main_popup.show();
        } else {
            _main_popup.hide();
        }
        return false;
    }

    function onRightCloseClick() {
        tabImgOverClear();
        _main_popup.hide();
        return false;
    }

    function tabBoardOnClear() {
        var tabs = _this.find('.main_board_tab,.main_board_tab_arrow');
        tabs.each(function() {
            var me = $(this);
            if( me.hasClass('on') ) {
                me.removeClass('on');
            }
        });
    }

    function onBoardTabClick() {
        var me = $(this);
        if( !GLOBAL.MAIN_BOARD ) {
            DGB.Common.userLevel(function(){
                DGB.Menu.trigger('leftPanel', 'updateBadge', {});
                me.trigger('vclick');
            }, true);
            return false;
        }

        var on = me.hasClass('on');
        if( !on) {
            tabBoardOnClear();
            me.addClass('on');
            me.find('.main_board_tab_arrow').addClass('on');

            var board = GLOBAL.MAIN_BOARD[me.data('id')];
            if( !board ) {
                board = { EMPTY : '잠시 후 다시 이용해 주세요.' };
                GLOBAL.MAIN_BOARD = false;
            }
            board.ID = me.data('id');
            _main_board.empty().mustache('freeSv_board_tmpl', board);
            $('.main_board_list_layout').scrollTop(0);
        }
        return false;
    }

    function onMenuItemClick() {
        var id = $(this).data('id');
        var is_alert = $(this).data('alert');
        if( is_alert ) {
            if( id == 'GR0100' && !GLOBAL.IS_EMAIL ) {  // EMAIL Popup
                if ( !DGB.Auth.Sso.isSso ) {
                    DGB.Menu.trigger('leftPanel', 'click', id);
                } else {
                    DGB.Menu.trigger('leftPanel', 'EMail.update', id);
                }
            } else {
                DGB.Menu.trigger('leftPanel', 'clickPopup', id);
            }
        } else {
            DGB.Menu.trigger('leftPanel', 'click', id);
        }
        return false;
    }

    function onBoardItemClick() {
        var me = $(this);
        var empty = me.data('empty');
        if( empty ) {
            return false;
        }

        var list_index = me.data('index');
        var board_index = _this.find('.main_board_tab.on').data('id');
        var board = GLOBAL.MAIN_BOARD[board_index] || {};
        var list = board.LIST[list_index];

        if( board_index == 0 || board_index == 1 ) {
            DGB.Page.triggerPage("#" + board.PAGE, board.EVENT, list.ARGS);
            DGB.Page.changePage('#' + board.PAGE);
        } else {
            if( list.CS_MMT_YN == 'Y' ) {
                showConfirm(function(button){
                    if (button == '1') {
                        if ( list.MSG_VD_YN == 'N' ) {
                            execUpdate(list.PUSH_FW_SEQ);
                        }
                        var args = {
                            id : list.CS_ID,
                            event : 'selectmenu',
                            args : list.ARGS
                        };
                        DGB.Menu.trigger('leftPanel', 'location', args);
                    }
                }, Messages.msg113);
            } else {
                if ( list.MSG_VD_YN == 'N' ) {
                    execUpdate(list.PUSH_FW_SEQ);
                }
                DGB.Page.triggerPage("#" + board.PAGE, board.EVENT, list.ARGS);
                DGB.Page.changePage('#' + board.PAGE);
            }
        }
        return false;
    }

    function execUpdate(seq, cs_id) {
        var options = {
            onSuccess : function() {
                DGB.Menu.trigger('leftPanel', 'updateBadge', {});
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TCO00002',
            parameters : [{
                CS_ID : cs_id,
                PUSH_FW_SEQ : seq
            }]
        };
        callProcedure(inv, options);
    }

	 $(document).on({
		pageinit: function() {
            _this = $(this);
            // IPAD 레이아웃 오류로 인해 스크롤 안씀
            //_layout = new DGB.layout(_this, COMMON_PAGE_HEADER_HEIGHT);

            _main_light = _this.find('#main_light');
            _main_left = _this.find('#main_left');
            _main_popup = _this.find('#main_left_popup');
            _main_board = _this.find('#main_board_list');

            $.Mustache.add('freeSv_right_tmpl', _this.find('#tmpl-main_right_layout').html());
            $.Mustache.add('freeSv_left_tmpl', _this.find('#tmpl-main_left_layout').html());
            $.Mustache.add('freeSv_popup_tmpl', _this.find('#tmpl-main_left_popup').html());
            $.Mustache.add('freeSv_board_tmpl', _this.find('#tmpl-main_board_layout').html());

            _main_left.mustache('freeSv_left_tmpl', MAIN);
            _main_light.empty().mustache('freeSv_right_tmpl', MAIN);
            _main_light.css('background-color', MAIN.RIGHT[MAIN.RIGHT.length - 1].COLOR);

            // 안드로이드 알수없는 출처 체크
            DGB.Common.isUnknownSource();

            // 사용자 레벨
            if( !DGB.isDebug() ) {
                DGB.Common.userLevel(function(){
                    DGB.Menu.trigger('leftPanel', 'updateBadge', {});
                    // set board
                    _this.find('.main_board_tab').first().click();
                });
            }

            // Test Debug
            if( DGB.isDebug() ) {
                if( TEST_INFO ) {
                    USER_INFO.ENOB = TEST_INFO.ENOB;
                    USER_INFO.FSNM = TEST_INFO.FSNM;
                    GLOBAL.ENOB = TEST_INFO.ENOB;
                }

                if( TEST_PAGE ) {
                    DGB.Page.changePage(TEST_PAGE);
                }
            }

            // 앱위변조 체크
            DGB.Auth.AppIron.init();
		},
		pageshow: function() {
			DGB.Common.backMenu();
            DGB.Common.refreshLayout(_layout, 100);

            if( !_is_init ) {
                _is_init = true;

                if( !DGB.isDebug() ) {
                    DGB.Log.l("[SRW_MobileOffice_Init] ====>> device.version : " + parseFloat(window.device.version));
                }

                //공지사항 popup 메시지
                popMessge();

                if( DGB.isAndroid() ) {
                    setTimeout(function() {
                        dgbLoading(false);
                        navigator.splashscreen.hide();
                    }, 500);
                }
            }

            // MDM 설치 여부 체크
            if( !_is_mdm && !TEST_SERVER ) {
                DGB.MDM.is(function () { _is_mdm = true; },
                    function () {
                        showAlert("알림", Messages.msg700, function(){
                            if( DGB.isAndroid() ) {
                                var file = {"url" :Messages.url037, "title":'DGB앱매니저', "downPath": DGB.fileRoot() + 'mdm/',
                                    callback : function() {
                                        setTimeout(function() {
                                            DGB.Common.appExit();
                                        }, 2000);
                                    }
                                };
                                downloadFile(file);
                            } else {
                                window.open(Messages.url037, "_system");
                                window.close();
                                DGB.Common.appExit();
                            }
                        });
                    }
                );
            }
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#freeSv');

    $(document).on('vclick', '#freeSv .main_right_layout', onRightTabClick);
    $(document).on('vclick', '#freeSv .main_left_popup_close', onRightCloseClick);
    // $(document).on('vclick', '#freeSv .main_board_tab', onBoardTabClick);
    $(document).on('vclick', '#freeSv .main_board_tab', function() {
        DGB.Bio.verify(function() {

        });
    });
    $(document).on('vclick', '#freeSv .main_left_li_item', onMenuItemClick);
    $(document).on('vclick', '#freeSv .main_board_list_li', onBoardItemClick);

});