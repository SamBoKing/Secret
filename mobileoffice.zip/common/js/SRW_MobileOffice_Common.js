// DEBUG MODE PAGE RELOAD
if( DGB.isDebug() ) {
    var loc = document.location;
    if( loc.hash && loc.href.indexOf(loc.hash) > -1) {
        document.location.href = document.URL.replace(loc.hash, "");
    }
}

var nowInput = null;
$(function() {
    // IOS input,textarea 에서 입력시 해더가 밀려올라가는 문제 수정.
    function initInputEvent(me){
       me.find('input, textarea').on({
           blur :  function (e) {
               setTimeout( function() {
                   var target = $(e.target)[0];
                   if( target && nowInput ) {
                       if ( target.id == nowInput.id ) {
                           window.scrollTo(0, 0);
                           nowInput = null;
                       }
                   }
               }, 200 );
           },
           focus :  function (e) {
               nowInput = $(e.target)[0];
           }
        });
    }

    // 화면 전환 이벤트( 안드로이드 : Layout : androidDetectOri)
    $(window).on('orientationchange', function() {
        var openPanel = DGB.Menu.isOpen('leftPanel') ? 'leftPanel' : '';
        if( openPanel ) {
            DGB.Menu.close(openPanel);
        }

        if( DGB.isAndroid() ) {
            setTimeout(function(){
                $.mobile.activePage.trigger({ type:'orientationchange' });
            }, 400);
        } else {
            $.mobile.activePage.trigger({ type:'orientationchange' });
        }
    });

    // 공통이벤트 정의
    $(document).on({
        pageinit: function() {
            if( DGB.isIPhone() ) {
                initInputEvent($(this));
            }
        },
        pageshow: function(e) {
            var page = $(e.target);
            DGB.Log.l("[MobileOffice] ====>> PageShow Event : [" + page.attr('id') + "]");
        },
        pagebeforeshow: function(e) {
            var page = $(e.target);

            // 페이지에 사용하는 메뉴 등록
            if( page.find('.jqm-navmenu-link').length ) {
                DGB.Menu.use(['leftPanel'], true);
            } else {
                DGB.Menu.use(['leftPanel'], false);
            }

            // 왼쪽 패널 버튼 클릭
            page.find('a.jqm-navmenu-link').off('vclick').on('vclick', function() {
                DGB.Menu.toggle('leftPanel');
                if( DGB.isAndroid() && DGB.Common.isKeyboardShow() ) {
                    DGB.Common.hideKeyboard();
                }
                page.focus();
                return false;
            });

            // 홈화면 버튼 클릭
            page.find('.jqm-homebtn').off('vclick').on('vclick', function() {
                DGB.Page.changePage('#freeSv');
                return false;
            });

            // 오른쪽 패널 버튼 클릭
            page.find('.jqm-exit-link').off('vclick').on('vclick', function() {
                showConfirm(function (btn) {
                    if (btn == '1') { DGB.Common.appExit(); }
                }, Messages.msg014);
                return false;
            });

            // 뒤로가기 버튼 클릭
            page.find('.jqm-back-link').off('vclick').on('vclick', function(){
                DGB.Page.backPage();
                return false;
            });
        },

        // 템플릿 메뉴 오른쪽 패널 사이즈 버그 수정
        panelopen: function() {
            $('body').css('overflow', 'hidden');
        },
        panelclose: function() {
            $('body').css('overflow', 'auto');
        }
    });
});