/**
 * #######################################
 * #    안드로이드 Native -> Web 값 전달      #
 * #######################################
 */

/**
 * 안드로이드 Webview load End. 페이지 load 완료시 호출
 */
var androidgetPageFlag = true;
var AndroidgetPageFinished = function(url)
{
    /*
	console.debug("----------------------------------------");
	console.debug("[Android-Native] ====> WebPage Finished!");
	console.debug("----------------------------------------");
	*/
};

/**
 * 안드로이드 가로,세로모드 변경시 처리.
 */
var androidDetectOri = function(height,width,statusbarheight) {
    /*
    console.debug("------------------------------------------");
    console.debug("[Android-Native] ====> Orientation Change!");
    console.debug("------------------------------------------");
    */
};


/**
 * 안드로이드 다뷰 진입 체크.
 */
var androidDaviewCycle = function(cycle) {
    console.debug("------------------------------------------");
    console.debug("[Android-Native] ====> Daview LifeCycle : "+ cycle);
    console.debug("------------------------------------------");

    switch(cycle){
        case "DaViewPause":
            DGB.onResume();
            break;
        case "DaViewResume":
            DGB.onPause();
            break;
    }

};

//pull refresh
function pullUpAction(pageId)
{
    $("#"+pageId).trigger("pulluprefresh");
}

//down refresh
function pullDownAction(pageId)
{
    $("#"+pageId).trigger("pulldownrefresh");
}

/******************
 * Layout Manager
 ******************/
DGB.layout = function($page, contentOffset, wrapperOffset, ioptions) {
	
	/******************************
	 * Internal Private Variables *
	 ******************************/
	// Get content & scroll wrapper
	var pageId = $page[0].id;
	var $content = $page.find('div[data-role="content"]');
	var $wrapper = $page.find('div.custWrapper');
	
	// Default offsets are 0
	var _contentOffset = contentOffset || 0;
	var _wrapperOffset = wrapperOffset || 0;
	
	var _iScroller = undefined;
	var pullDownOffset = undefined;
	var pullUpOffset = undefined;
	 
	// iscroll
	var $pullup = $page.find('div.pullUp');
	var $pulldown = $page.find('div.pullDown');
	
	//당겨서새로고침
	var pullDownEl = $pulldown[0];
	if(pullDownEl) {
		pullDownOffset = $pulldown.innerHeight();
	}
	
	var pullUpEl = $pullup[0];
	if(pullUpEl) {
		pullUpOffset = $pullup.innerHeight();
	}
	
	/******************************
	 * Internal Private Functions *
	 ******************************/
	
	// Create _iScroller
	var options = {
		zoom:false,
		hScrollbar:false,
		vScrollbar:true,
		onBeforeScrollStart: function (e) {
			var target = e.target;
			while (target.nodeType != 1) target = target.parentNode;
			
			if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA' && target.tagName != 'textarea') {
				e.preventDefault();
			}
		},
	    //당겨서새로고침
        useTransition: false,
        topOffset: pullDownOffset,
		onRefresh: function () {
			if(pullDownEl != null) {
                if (pullDownEl.className.match('loading')) {
                    pullDownEl.className = '';
                    pullDownEl.className = 'pullDown';
                }
                pullDownEl.querySelector('.pullDownLabel').innerHTML = '';
                //setTimeout(function() {
                    pullDownEl.querySelector('.pullDownLabel').innerHTML = Messages.msg100;
                //}, 1);

			}
			
			if(pullUpEl != null) {

                if (pullUpEl.className.match('loading')) {
                    pullUpEl.className = '';
                    pullUpEl.className = 'pullUp';
                }
                pullUpEl.querySelector('.pullUpLabel').innerHTML = '';
                //setTimeout(function() {
                    pullUpEl.querySelector('.pullUpLabel').innerHTML = Messages.msg101;
                //}, 1);

			}
		},
		onScrollMove: function () {
			if(pullDownEl != null) {
				if (this.y > 5 && !pullDownEl.className.match('flip')) {
                    pullDownEl.className = '';
                    pullDownEl.querySelector('.pullDownLabel').innerHTML = '';
                    //setTimeout(function() {
                        pullDownEl.className = 'pullDown flip';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = Messages.msg102;
                    //}, 1);

					this.minScrollY = 0;
				} else if (this.y < 5 && pullDownEl.className.match('flip')) {
                    pullDownEl.className = '';
                    pullDownEl.querySelector('.pullDownLabel').innerHTML = '';
                    //setTimeout(function() {
                        pullDownEl.className = 'pullDown';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = Messages.msg100;
                    //}, 1);
					this.minScrollY = -pullDownOffset;
				}
			}
			
			if(pullUpEl != null) {
				var wrapperScrollY = (this.wrapperH > this.scrollerH) ? this.minScrollY : this.maxScrollY;
				
				 if (this.y < (wrapperScrollY - (pullUpOffset - 5)) && !pullUpEl.className.match('flip')) {
                     pullUpEl.className = '';
                     pullUpEl.querySelector('.pullUpLabel').innerHTML = '';
                     setTimeout(function() {
                         pullUpEl.className = 'pullUp flip';
                         pullUpEl.querySelector('.pullUpLabel').innerHTML = Messages.msg102;
                     }, 1);
					this.maxScrollY = this.maxScrollY;
				} else if (this.y > (wrapperScrollY + (pullUpOffset - 5)) && pullUpEl.className.match('flip')) {
                     pullUpEl.className = '';
                     pullUpEl.querySelector('.pullUpLabel').innerHTML = '';
                     //setTimeout(function() {
                         pullUpEl.className = 'pullUp';
                         pullUpEl.querySelector('.pullUpLabel').innerHTML = Messages.msg101;
                     //}, 1);
					this.maxScrollY = pullUpOffset;
				}
			}
		},
		onScrollEnd: function () {
			if(pullDownEl != null) {
				if (pullDownEl.className.match('flip')) {
                    pullDownEl.className = '';
                    pullDownEl.querySelector('.pullDownLabel').innerHTML = '';
                    //setTimeout(function() {
                        pullDownEl.className = 'pullDown loading';
                        pullDownEl.querySelector('.pullDownLabel').innerHTML = Messages.msg103;
                        pullDownAction(pageId);	// Execute custom function (ajax call?)
                    //}, 1);
				}
			}
			if(pullUpEl != null) {
				 if (pullUpEl.className.match('flip')) {
                     pullUpEl.className = '';
                     pullUpEl.querySelector('.pullUpLabel').innerHTML = '';
                     //setTimeout(function() {
                         pullUpEl.className = 'pullUp loading';
                         pullUpEl.querySelector('.pullUpLabel').innerHTML = Messages.msg103;
                         pullUpAction(pageId);	// Execute custom function (ajax call?)
                     //}, 1);


				}
			}
		}
	};
	$wrapper && (_iScroller = new iScroll($wrapper[0], $.extend(options, ioptions)));
	
	/********************
	 * Public Functions *
	 ********************/
	var resetLayout = function() {
		if (typeof _iScroller !== 'undefined') _iScroller.destroy();
		$wrapper && (_iScroller = new iScroll($wrapper[0], options));
	};

	var refreshLayout = function(f, delay) {

        var contentHeight = $(window).innerHeight() - _contentOffset;
        var maxHeight = contentHeight-_wrapperOffset;
        // The height will be maxHeight to cover the content area with wrapper
        $wrapper.height(maxHeight);


        if ( DGB.isAndroid() ) {
            $('#'+pageId).css('height', $(window).innerHeight()+'px');
            $('#'+pageId).css('min-height', $(window).innerHeight()+'px');
        }

        // Refresh content scroller
        if (typeof f == 'number') delay = f;
        delay = delay || 300; // default delay is 300 ms

        setTimeout(function(){
            /*
            // Set the height to the jqm content view
            $content.height(contentHeight);

            // Get the original height of element to be scrolled in the wrapper
            var adjustedHeight = $wrapper.children().first().innerHeight();

            // Calculating the top offset about pull down element only.
            if (pullDownEl) adjustedHeight -= pullDownOffset;

            // Limits maximum height
            if (adjustedHeight > maxHeight) adjustedHeight = maxHeight;

            // Set the height to the wrapper
            $wrapper.height(adjustedHeight);
            */
            _iScroller && _iScroller.refresh();
            if (typeof f == 'function') f();
        }, delay);
	};

	var updateOffset = function(offset, f, delay) {
		if (typeof offset === 'undefined') {
            DGB.Log.l('[DGB.Layout] ====>> Offset is undefined');
			return;
		}
		// Update
		_contentOffset = offset.contentOffset || _contentOffset;
		_wrapperOffset = offset.wrapperOffset || _wrapperOffset;

		// Refresh
		refreshLayout(f, delay);
	};

	var scrollTo = function (x, y, time, relative) {
		_iScroller.scrollTo(x, y, time, relative);
	};

	var getScroller = function() {
		return _iScroller;
	};

	return {
		'refreshLayout':refreshLayout,
		'resetLayout':resetLayout,
		'updateOffset':updateOffset,
		'scrollTo':scrollTo,
		'getScroller':getScroller
	};
};
