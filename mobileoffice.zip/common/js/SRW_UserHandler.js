/*
* Licensed Materials - Property of IBM
* 5725-G92 (C) Copyright IBM Corp. 2006, 2013. All Rights Reserved.
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/


var AUTH_STATUS_REQUIRED = 'required';
var AUTH_STATUS_COMPLETED = 'completed';	
var AUTH_STATUS_INVALID = 'invalid';

var AUTH_STATUS_REJECT_TYPE = 'REJECT_TYPE';		//서비스 단말기 유형 제한, 테블릿/폰
var AUTH_STATUS_REJECT_ORT = 'REJECT_ORT';			//서비스 이용시간 제한
var AUTH_STATUS_REJECT_ROLE = 'REJECT_ROLE';		//서비스 권한
var AUTH_STATUS_REJECT_MULTI = 'REJECT_MULTI';		//다중로그인제한
var AUTH_STATUS_REJECT_FORCED = 'REJECT_FORCED';	//강제종료


var userChallengeHandler = WL.Client.createChallengeHandler(USER_REALM_NAME);

userChallengeHandler.isCustomResponse = function(response) {
	if (!response || !response.responseJSON) {
		return false;
	}

	if (response.responseJSON.authStatus != 'undefined') {
		
		if (response.responseJSON.authStatus == AUTH_STATUS_REJECT_TYPE) {
			dgbLoading(false);
			var callback = function(button){
				if (button == '1') {
					DGB.Menu.open('leftPanel');
				}
			};
			//서비스제한기기 체크
			showCusConfirm(callback, '알림', Messages.msg063, '확인');
		} else if (response.responseJSON.authStatus == AUTH_STATUS_REJECT_ORT) {
			dgbLoading(false);
			var callback = function(button){
				if (button == '1') {
					DGB.Menu.open('leftPanel');
				}
			};
			showCusConfirm(callback, '알림', Messages.msg064, '확인');
		} else if (response.responseJSON.authStatus == AUTH_STATUS_REJECT_ROLE) {
			dgbLoading(false);
			showAlert(Messages.msg065);
		} else if (response.responseJSON.authStatus == AUTH_STATUS_REJECT_MULTI) {
			dgbLoading(false);
			userChallengeHandler.doLogout();
			
			var callback = function(button){
				if (button == '1') {
					
					if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
						AndroidNative.exitApp();
					}else {
						window.plugins.actionSheet.exitApp();
					}
				}
			};
			showCusConfirm(callback, '알림', Messages.msg066, '확인');
		} else if (response.responseJSON.authStatus == AUTH_STATUS_REJECT_FORCED){
			dgbLoading(false);
			userChallengeHandler.doLogout();
			
			var callback = function(button){
				if (button == '1') {
					
					if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
						AndroidNative.exitApp();
					}else {
						window.plugins.actionSheet.exitApp();
					}
				}
			};
			showCusConfirm(callback, '알림', Messages.msg068, '확인');
		}else if (response.responseJSON.authStatus == AUTH_STATUS_REQUIRED) {
			//설정화면에서 메일계정등록 시 SSO 로그인 루틴 수행하도록 수정.
			var pageId = $('.ui-page-active').attr('id');
			if(pageId == 'CO00004'){
				var args={};

				GLOBAL.STAT = "PasswordPass";
				GLOBAL.PAGEID = pageId;
		 		GLOBAL.ARGS = args;
				GLOBAL.TEMP_STAT = GLOBAL.STAT;
				GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;

                DGB.Page.triggerPage('#login', "parentpage", [args]);
				DGB.Page.changePage('#login');
				//dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
			}else {
				if( !DGB.Auth.Step.check() ) {
					$('#loginPw').attr('data-enc', '');
					window.regAuthState = '';
					GLOBAL.STAT = GLOBAL.TEMP_STAT;
					GLOBAL.PAGEID = GLOBAL.TEMP_PAGEID;
					showAlert('세션이 종료되었습니다. 로그인 후 다시 이용해 주시기 바랍니다.');
				}
				DGB.Page.triggerPage("#login", "parentpage", []);
				DGB.Page.changePage('#login');
				dgbLoading(false);
			}
		}
	}

	if (response.responseJSON.authStatus)
		return true;
	else 
		return false;
};

userChallengeHandler.handleChallenge = function(response) {	
	var authStatus = response.responseJSON.authStatus;

	if (response.responseJSON.errorMessage) {
		WL.Logger.debug('[userChallengeHandler] Received Error Message: '+response.responseJSON.errorMessage+', authStatus:'+authStatus);
	}
	if (authStatus == AUTH_STATUS_REQUIRED) {
		// Show Authentication Page

		if (typeof userChallengeHandler.__loginAuthInfo === 'undefined') {
			dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
			return;
		}

			
        var auth = userChallengeHandler.__loginAuthInfo;
        userChallengeHandler._submitAuthentication(auth);

        // clear auth-data
        userChallengeHandler.__loginAuthInfo = undefined;
		
	} else if (authStatus == AUTH_STATUS_COMPLETED) {
		
		//로그인 사용자정보 담기
		var publicKey = USER_INFO.PUBLICKEY;
		USER_INFO = response.responseJSON.attributes;
		USER_INFO.PUBLICKEY = publicKey;
		
		// Send original request
		userChallengeHandler.submitSuccess();
		if (typeof userChallengeHandler.__loginCallback === 'function') userChallengeHandler.__loginCallback(true);
	} else if (authStatus == AUTH_STATUS_INVALID) {
		userChallengeHandler.submitFailure();
		if (typeof userChallengeHandler.__loginCallback === 'function') userChallengeHandler.__loginCallback(false, response.responseJSON.errorMessage);
	}
	
	
};

userChallengeHandler.submitLoginFormCallback = function(response) {
	var isLoginFormResponse = userChallengeHandler.isCustomResponse(response);
	if (isLoginFormResponse) {
		userChallengeHandler.handleChallenge(response);
	}
};
/*
userChallengeHandler._submitFormLogin = function(username, password) {
	var reqURL = '/my_custom_auth_request_url';
	var options = {
		parameter:{
			'username':username,
			'password':password
		},
		headers:{}
	};
	
	userChallengeHandler.submitLoginForm(reqURL, options, userChallengeHandler.submitLoginFormCallback);
};
*/
userChallengeHandler._submitAdapterLogin = function(auth) {
	var invocationData = {
		'adapter':'MobileAuthAdapter',
		'procedure':'submitAuthentication',
		'parameters':[auth]
	};
	userChallengeHandler.submitAdapterAuthentication(invocationData, {});
};

userChallengeHandler._submitAuthentication = userChallengeHandler._submitAdapterLogin;
//userChallengeHandler._submitAuthentication = userChallengeHandler._submitFormLogin;

userChallengeHandler.doAuth = function(login, authCallback) {
	userChallengeHandler.__loginCallback = authCallback;
	userChallengeHandler.__loginAuthInfo = {
		'ENOB' : login.ENOB,
		'SYS_ID' : login.SYS_ID,
		'SESSION_ID' : nmf.utils.UUID.get(),
		'DEVC_NATV_NO' : nmf.Store.get(MAC_ADDRESS)
	};


	// Check if it's interacting with user or not
	if (userChallengeHandler.activeRequest) {
		var auth = userChallengeHandler.__loginAuthInfo;
		userChallengeHandler._submitAuthentication(auth);
	} else {
		// Logout first to robust in security
		userChallengeHandler.doLogout();
		userChallengeHandler.doCheckSecurity();
	}
};

userChallengeHandler.doLogout = function() {
	WL.Client.logout(USER_REALM_NAME);
};

userChallengeHandler.doCheckSecurity = function() {
	WL.Client.invokeProcedure({
		'adapter':'MobileAuthAdapter',
		'procedure':'checkSecurity',
		'parameters':[]
	}, {
		'onSuccess':function(data) {
		},
		'onFailure':function(err){
		},
		'onConnectionFailure':function(err){
		}
	}
	);
};