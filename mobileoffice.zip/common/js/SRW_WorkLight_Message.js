/**
 * worklight messages.js에 정의된 메시지 오버라이드
 */
function overrideMessages() {
//a
	WL.ClientMessages.accessDenied = '접근이 거부되었습니다.';
	WL.ClientMessages.authFailure = '애플리케이션의 요청을 처리하는 중 오류가 발생하였습니다.';
	WL.ClientMessages.applicationDenied = '서비스접속이 제한되었습니다.';
// b
	WL.ClientMessages.browserIsNotSupported = '{0}는 현재 지원되지 않습니다.';
// c
	WL.ClientMessages.close = '닫기';
	WL.ClientMessages.cookiesAreDisabled = '쿠키가 현재 사용 중인 브라우저에서 활성화되지 않았습니다. 애플리케이션의 정상 동작을 위해 쿠키를 활성화하십시오.';
	WL.ClientMessages.copyToClipboard = '복사하기';
// d
	WL.ClientMessages.details = "세부사항";
	WL.ClientMessages.diagApp = "앱 진단";
	WL.ClientMessages.diagTime = "시간";
	WL.ClientMessages.diagApplicationName = "애플리케이션 이름";
	WL.ClientMessages.diagApplicationVersion = "애플리케이션 버전";
	WL.ClientMessages.diagServiceURL = "서비스 URL";
	WL.ClientMessages.diagDevicePlatform = "기기 플랫폼";
	WL.ClientMessages.diagDeviceVersion = "기기 버전";
	WL.ClientMessages.diagScreenResolution = "화면 해상도";
	WL.ClientMessages.diagAirplaneMode = "비행 모드";
	WL.ClientMessages.diagUsingNetwork = "네트워크 사용 중";
	WL.ClientMessages.diagWifiName = "WiFi 이름";
	WL.ClientMessages.diagMobileNetworkType = "모바일 네트워크 유형";
	WL.ClientMessages.diagCarrierName = "통신사 이름";
	WL.ClientMessages.diagErrorCode = "오류 코드";
	WL.ClientMessages.diagErrorMessage = "오류 메시지";
	WL.ClientMessages.diagHttpStatus = "HTTP 상태";
	WL.ClientMessages.diagIPAddress = "IP 주소";
	WL.ClientMessages.directUpdateNotificationTitle = '업데이트 알림';
	WL.ClientMessages.directUpdateNotificationMessage = Messages.wlm001;
	WL.ClientMessages.directUpdateErrorTitle = '업데이트 실패';
	WL.ClientMessages.directUpdateErrorMessageNotEnoughStorage = '애플리케이션에 대한 업데이트 사항이 있으나 기기에 충분한 공간이 없습니다(필요 크기= {0} MB, 가용 공간= {1} MB).';
	WL.ClientMessages.directUpdateErrorMessageFailedDownloadingZipFile = '애플리케이션 업데이트 파일 다운로드에 실패했습니다.';
	WL.ClientMessages.directUpdateErrorMessageFailedProcessingZipFile = '애플리케이션 업데이트 파일 처리에 실패했습니다.';
	WL.ClientMessages.downloadAppWebResourcesPleaseSpecifyAppID = '애플리케이션 자원을 다운로드할 수 없습니다. 설정 화면에서 App ID를 설정하십시오.';
	WL.ClientMessages.downloadAppWebResourcesAppIdNotExist = '애플리케이션 "{0}" 을 찾을 수 없습니다. Worklight 서버에 먼저 배치하십시오.';
	WL.ClientMessages.downloadAppWebResourcesPleaseSpecifyAppVersion = '애플리케이션 자원을 다운로드할 수 없습니다. 설정 화면에서 App Version을 설정하십시오.';
	WL.ClientMessages.downloadAppWebResourcesSkinIsNotValid = '애플리케이션 자원을 다운로드할 수 없습니다. 스킨= {0} 이 존재하지 않습니다. getSkinName() 함수가 유효한 스킨으로 결정되는지 확인하시기 바랍니다.';
	WL.ClientMessages.downloadAppWebResourcesAppVersionNotExist = '{2}에 대한 앱 "{0}" {1}를 찾을 수 없습니다.\n앱 삭제 후 Mobile Client에서 DGB오피스를 재설치하여 주십시오.';
	WL.ClientMessages.downloading = '다운로드중입니다.';
	WL.ClientMessages.deviceAuthenticationFail = '연결 오류';
	WL.ClientMessages.downloadAppWebResourcesConnectionToServerUnavailable = '서버에 대한 연결이 가용하지 않습니다. 애플리케이션 자원을 다운로드할 수 없습니다.';
// e
	WL.ClientMessages.expandWindow = '애플리케이션을 사용하려면 확대하십시오.';
	WL.ClientMessages.exit = '나가기';
	WL.ClientMessages.exitApplication = '애플리케이션 나가기';
	WL.ClientMessages.error = '오류';
// f
// g
	WL.ClientMessages.gadgetUpdateAvailable = '애플리케이션 업데이트 사항이 있습니다.';
	WL.ClientMessages.getNewVersion = '앱센터로 이동';
// h
	WL.ClientMessages.handleTimeOut = '{0}에 대한 요청 시간이 지났습니다. 애플리케이션이 호스트 주소를 사용할 수 있는지 확인하십시오.';
// i
	WL.ClientMessages.invalidUsernamePassword = '유효하지 않는 사용자 또는 암호';
// j
// k
	WL.ClientMessages.keepAliveInBackgroundText = '애플리케이션이 백그라운드에서 실행됩니다.';
// l
	WL.ClientMessages.loading = '로드중...';
	WL.ClientMessages.login = '로그인';
// m
	WL.ClientMessages.minimize = '최소화';
	WL.ClientMessages.missingFeatureException= '{0} 을 애플리케이션에서 찾을 수 없어 {1} 을 호출하는 데 실패했습니다.\n앱 삭제 후 Mobile Client에서 DGB오피스를 재설치하여 주십시오.';
// n
	WL.ClientMessages.name = '이름=';
	WL.ClientMessages.noInternet = '서비스에 대한 연결이 가용하지 않습니다.';
	WL.ClientMessages.notificationTitle = '서비스 알림';
	WL.ClientMessages.notificationUpdateFailure = '푸쉬 알림에 대한 등록에 실패했습니다. 애플리케이션이 알림을 받을 수 없습니다.';
	WL.ClientMessages.notAvailable = '가용하지 않음';
// o
	WL.ClientMessages.ok = '확인';
// p
	WL.ClientMessages.password = '암호=';
// q
// r
	WL.ClientMessages.reload = '리로드';
	WL.ClientMessages.restore = '복원';
	WL.ClientMessages.requestTimeout = '애플리케이션이 서비스 연결에 실패했습니다.';
	WL.ClientMessages.responseNotRecognized = '예상치 못한 응답을 받았습니다.';
// s
	WL.ClientMessages.settings = '설정';
	WL.ClientMessages.serverError = '프로시져 호출 오류';
// t
	WL.ClientMessages.tryAgain = '재시도';
// u
	WL.ClientMessages.userInstanceAccessViolationException = '귀하에게 등록되지 않은 애플리케이션에 로그인을 시도하고 있습니다.';
	WL.ClientMessages.unexpectedError = '서버가 애플리케이션의 요청을 처리할 수 없었습니다. 나중에 다시 시도하십시오.';
	WL.ClientMessages.unresponsiveHost = '서비스가 현재 가용하지 않습니다.';
	WL.ClientMessages.update = '업데이트';
	WL.ClientMessages.upgradeGadget = '현재 애플리케이션의 버전은 {0} 입니다. 이 애플리케이션의 버전 {1} 가 있습니다. 예를 눌러 다운로드 및 설치하십시오.';
	WL.ClientMessages.unpacking = '업데이트중입니다.';
// v
// w
	WL.ClientMessages.wlclientInitFailure = '오류';
	WL.ClientMessages.wlSettings = 'Worklight 설정';
// x
// y
// z
}
