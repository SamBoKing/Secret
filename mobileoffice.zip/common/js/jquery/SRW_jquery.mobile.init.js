$(document).bind('mobileinit', function() {
	$.mobile.defaultPageTransition = 'none'; // fade
	$.mobile.pageLoadErrorMessage = 'Page Load failed with error';
    $.mobile.page.prototype.options.domCache = true;
});