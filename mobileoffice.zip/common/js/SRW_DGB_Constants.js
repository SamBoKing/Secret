var TEST_SERVER = false;
var TEST_PAGE = '';
var TEST_INFO = {
	ENOB : '',
	FSNM : ''
};

// 라온 가상키패드 사용 여부
var IS_TRANS_KEY = true;

// 실서버, 테스트 서버 URL 셋팅
var DEF_URL = (TEST_SERVER ? "http://172.18.6.126" : "https://office.dgb.co.kr");
var HOST_URL = DEF_URL + "/worklight";
var DOWN_URL = DEF_URL + "/mobileoffice";
var USER_PHOTO_URL = "http://ehr.daegubank.co.kr";

// EMail File Urlr
var EMAIL_NOT_VIEW = 'zip,dll,war,xml,html';	// 이메일에서 볼수없는 파일

// 사용자정보, 글루벌 정보
var USER_INFO = {
	GROUP_ID : '',
	WORKORG_CD : '',
	JIKHO : ''
};
var GLOBAL = {};

var loginYN = false;	                // 로그인 완료여부
var anonymousUserId = undefined;	    // WorkLight 에서 생성하는 고유 id (앱 재설치, 기기변경 시 값 바뀜)
var searchBranch = undefined;	        // 영업계수, 영업점현황, 영업실적 조회점코드
var searchBranchName = undefined;	    // 영업계수, 영업점현황, 영업실적 조회점명

// Common Element Height
var COMMON_PAGE_HEADER_HEIGHT = 50;
var COMMON_NAVBAR_HEIGHT = 38;
var COMMON_EDIT_HEIGHT = 49+5;
var COMMON_SEARCH_HEIGHT = 49+5;                    // margin-bottom: 5px
var COMMON_MENUBAR_HEIGHT = 49+5;                   // margin-bottom: 5px
var COMMON_DIALOG_HEADER_HEIGHT = 46;
var COMMON_DIALOG_POSITION_OFFSET = 46-15;          // absolution position is -15px
var DEFAULT_NUMBER_OF_LIST_ITEMS = 20;
var SENDMAIL_ATTACHMENTS_SIZE_LIMIT = 10*1024*1024; // 10 MB

// Common Value
var USER_REALM_NAME = 'MobileOfficeUserRealm';  // WL 인증 REALM key
var SYS_ID = 'MOF';                             // 시스템 ID
var FREET_GD_CHECK = "dgb.freetGdCheck";        // 좋아요 중복 체크
var EMAIL_KEY_ID = "dgb.EmailKeyId";            // Email 키값
var MAC_ADDRESS = "dgb.macaddress";
var POP_MESSAGE = "dgb.popmessage";             // 공지사항 메시지
var UNKOWN_SOURCE = "dgb.unknownsource";        // 안드로이드 알수없는 출처 체크

// Error Code
var ErrorCodeInfo = {
	// Mobile Office Server Error
	MOSE0000:'예상되지 않은 오류',
	MOSE0001:'기간계 서버 접속 실패',
	MOSE0002:'잘못된 이메일 인자 수신',
	// Email Service Error
	MOSE0101:'이메일 미등록 사용자',
	MOSE0104:'설정에서 이메일 재등록 바랍니다.',
	MOSE0105:'이메일 사용자 인증 실패',
	MOSE0201:'이메일 주소 오류',
	MOSE9999:'등록되지 않은 오류'
};