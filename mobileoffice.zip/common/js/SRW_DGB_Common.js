/**
 * state machine 
 * @param 현재 상태
 */
var authState = {
    stateCompare : function (menuState) {
        // 현재 인증상태와  요청서비스의 인증단계 비교
        var states = [
            DGB.Auth.Level.ID,
            DGB.Auth.Level.Pass,
            DGB.Auth.Level.Sms,
            DGB.Auth.Level.Bio,
            DGB.Auth.Level.Nfc
        ];

        if( GLOBAL.ENOB && !DGB.Sms.is(GLOBAL.ENOB) ) {
            DGB.Log.i("[DGB.Common] ====>> Sms Auth : " + GLOBAL.ENOB + ", Menu : " + menuState);
            return DGB.Auth.Level.Sms;
        }

        var authStep = states.indexOf(window.regAuthState);
        var menuStep = states.indexOf(menuState);
        var returnState = (authStep < menuStep) ? menuState : 'AUTH_PASSED';
        DGB.Log.i("[DGB.Common] ====>> Auth : " + window.regAuthState + "(" + authStep + "), Menu : " + menuState + "(" + menuStep + "), State : " + returnState);
        return returnState;
    }
};

/**
 * auth process 
 * @param 현재 상태
 */
function authProcess() {
	DGB.Log.i("[DGB.Common] ====>> authProcess >> GLOBAL.STAT : " + GLOBAL.STAT);
	DGB.Auth.Step.call(GLOBAL.STAT, function() {
        DGB.Log.i("[DGB.Common] ====>> authProcess CallBack >> GLOBAL.STAT : " + GLOBAL.STAT);

        dgbLoading(false);
        DGB.Menu.trigger('leftPanel', 'updateProfile', []);     // 로그인 정보 왼쪽 패널 업데이트
        window.regAuthState = GLOBAL.STAT;
        loginYN = true;

        if( isRejectedMenu(GLOBAL.ARGS.menuId) ) {
            DGB.menuctrl.selectFreeService(GLOBAL.PAGEID);
            showAlert(Messages.msg065);
            return;
        }

        var menu_id = GLOBAL.ARGS.menuId;
        switch( menu_id ) {
            case 'RE0501': // M-배치
                DGB.menuctrl.selectFreeService(GLOBAL.PAGEID);
                DGB.Menu.trigger('leftPanel', 'connectEzJob', []);
                break;
            case 'CHAT01': // 챗봇
                DGB.menuctrl.selectFreeService(GLOBAL.PAGEID);
                DGB.Common.openChatBot();
                break;
            case 'GR0100': // 메일
                DGB.Page.changePage("#freeSv");

                DGB.Menu.open('leftPanel');
                setTimeout(function () {
                    DGB.Menu.trigger('leftPanel', 'click', 'GR0100'); // 메일 메뉴 ID
                }, 400);
                break;
            default:
                DGB.Page.triggerPage("#"+GLOBAL.PAGEID, "selectmenu", [GLOBAL.ARGS]);
                DGB.Page.changePage("#"+GLOBAL.PAGEID);
                break;
        }
    });
}

/**
 * 프로시져호출 
 * @param inv
 * @param opt
 */
function callProcedure(inv, opt) {
    inv.parameters[0]['SYS_ID'] = 'MOF';
    inv.parameters[0]['GMNO'] = nmf.utils.UUID.get();
    inv.parameters[0]['TRNS_CD'] = inv.procedure || '';
    inv.parameters[0]['COMP_DVCD'] = 'DGB';
    if( DGB.isDebug() ) {
        DGB.Log.d('[CallProcedure] ====>> Request');
        DGB.Log.l(JSON.stringify(inv));
        inv.parameters = JSON.stringify(inv.parameters);

        $.ajax({
            // url: 'http://172.25.201.171:9080/worklight/invoke',
            url: 'http://172.18.6.126/worklight/invoke',
            method : 'post',
            dataType: 'json',
            data : inv,
            async: true,
            success: function(data) {
                DGB.Log.d('[CallProcedure] ====>> Success');
                DGB.Log.l(JSON.stringify(data));

                var text = data.responseText.replace('/*-secure-\n', '').replace('*/', '');
                var json = { invocationResult : JSON.parse(text || "{}") };
                if( opt.onSuccess ) {
                    console.dir(json);
                    opt.onSuccess(json);
                }
            },
            error: function(data) {
                var text = data.responseText.replace('/*-secure-\n', '').replace('*/', '');
                var json = { invocationResult : JSON.parse(text || "{}") };
                if( data.status == 200 ) {
                    DGB.Log.d('[CallProcedure] ====>> Success');
                    DGB.Log.l(JSON.stringify(data));
                    if( opt.onSuccess ) {
                        console.dir(json);
                        opt.onSuccess(json);
                    }
                } else {
                    DGB.Log.e('[CallProcedure] ====>> Error');
                    DGB.Log.l(JSON.stringify(data));
                    if( opt.onFailure ) {
                        opt.onFailure(json);
                    }
                }
            }
        });

    } else {
        WL.Client.invokeProcedure(inv, opt);
    }
}

// 가상키패드 호출
function onE2K(mode, name, min, max, desc, masking) {
    var is_num = mode.indexOf('num') > -1;
    var is_retry = mode.indexOf('@2x') > -1;
    transKeyShow(name, is_num, is_retry, desc, min, max);
}

var transKeyOptions = { };
function transKeyShow(id, is_num, is_retry, label, min, max) {
    transKeyOptions.id = id;
    transKeyOptions.is_num = is_num;
    transKeyOptions.is_retry = is_retry;
    transKeyOptions.label = label;
    transKeyOptions.min = min;
    transKeyOptions.max = max;
    transKeyOptions.secure = '';

    if ( DGB.isAndroid() ) {
        transKeyOptions.data = {
            mTK_keypadType : is_num ? 4 : 5,
            mTK_inputType : 2,
            mTK_title_label : label,
            mTK_label : label,
            mTK_disableSpace : true,
            mTK_minLength : parseInt(min),
            mTK_maxLength : parseInt(max)
        };

        AndroidNative.hideKeyboard();
        AndroidNative.transKey('transKeyCallBack', JSON.stringify(transKeyOptions.data));
    } else if( DGB.isIPhone() ) {
        transKeyOptions.data = {
            keypadType : is_num ? 1 : 0,    // eng, num
            mTK_inputType : 1,              // text, password
            mTK_inputTitle : label,
            mTK_keypadUpper : false,
            mTK_languageType : 0,           // kor, eng
            mTK_minLength : parseInt(min),
            mTK_maxLength : parseInt(max)
        };

        WL.NativePage.show("TransKeyViewController", function (data) {
            if( data.result == 'success' ) {
                transKeyCallBack(data.plan, data.secure, data.len);
            } else {
                showAlert(Messages.msg033);
            }
        }, transKeyOptions.data );
    } else if( DGB.isDebug() ) {
        transKeyCallBack('9876543211111', '1234567891111', '1234567891111'.length);
    }
}


function transKeyCallBack(plan, secure, len) {
    //if( transKeyOptions.min > len ) {
    //    showAlert('[' + transKeyOptions.label + '] - ' + transKeyOptions.min + '자리 이상 입력하셔야 합니다.\n다시 입력하여 주십시요.');
    //    return;
    //}

    if( !transKeyOptions.secure && transKeyOptions.is_retry ) {
        transKeyOptions.secure = secure;

        if ( DGB.isAndroid() ) {
            transKeyOptions.data.mTK_title_label += ' 재입력';
            transKeyOptions.data.mTK_label += ' 재입력';
            AndroidNative.hideKeyboard();
            setTimeout(function() {
                AndroidNative.transKey('transKeyCallBack', JSON.stringify(transKeyOptions.data));
            }, 500);
        } else if( DGB.isIPhone() ) {
            transKeyOptions.data.mTK_inputTitle += ' 재입력';
            WL.NativePage.show("TransKeyViewController", function (data) {
                if( data.result == 'success' ) {
                    transKeyCallBack(data.plan, data.secure, data.len);
                } else {
                    showAlert(Messages.msg033);
                }
            }, transKeyOptions.data );
        }
        return;
    }

    if( transKeyOptions.is_retry && transKeyOptions.secure != secure ) {
        showAlert('[' + transKeyOptions.label + '] 입력값이 올바르지 않습니다.\n다시 입력하여 주십시요.');
        return;
    }

    var el = $('#'+transKeyOptions.id);
    el.val("*******************".substr(0, len));
    el.attr('data-enc', plan);

    if( transKeyOptions.id == 'loginPw' ) {
        loginCall();
    }
}

// 안드로이드 바이러스 악성코드 및 루팅체크
function vaccineReceive(code) {
    /*
        1000 : EMPTY_VIRUS - 악성코드, 루팅여부 모두 정상
        1010 : EXIST_VIRUS_CASE1 - 악성코드 탐지 후 사용자가 해당 악성코드 앱을 삭제
        1100 : EXIST_VIRUS_CASE2 - 악성코드 탐지 후 사용자가 해당 악성코드 앱을 미삭제
    */
    switch(code) {
        case 1000: break;
        case 1010: break;
        case 1100:
            showAlert('알림', '악성코드가 탐지되었습니다. 악성코드 삭제 후 접속해 주시기 바랍니다.', function () {
                DGB.Common.appExit();
            });
            break;
    }
}


  
/**
 * 데이터 조회 로딩 호출
 * @param status : true/false
 */
var busyIndicator;
function dgbLoading(status) {

    if( DGB.isDebug() ) {
        status ? $.mobile.showPageLoadingMsg() : $.mobile.hidePageLoadingMsg();
        return;
    }

	if ( !busyIndicator ) {
		busyIndicator = new WL.BusyIndicator(null, {text:"로드중...", bounceAnimation:true});
	}

	if( DGB.isAndroid() ) {
		status ? window.plugins.waitingDialog.show() : window.plugins.waitingDialog.hide();
	} else {
		status ? busyIndicator.show() : busyIndicator.hide();
	}
}

/**
 *
 * @param callback(param) //param = 1:확인, 2:취소
 * @param val1 타이틀
 * @param val2 메시지
 */
function showConfirm(callback, val1, val2) {
    var title = val2 ? (val1 || '알림') : '알림';
    var message = val2 || val1;
    if( DGB.isDebug() || (DGB.isAndroid() && parseFloat(window.device.version) >= 7) ) {
    // if( DGB.isDebug() ) {
        callback(confirm(message) ? '1' : '2');
    } else {
        navigator.notification.confirm(message, callback, title, '확인,취소');
    }
}

/**
 *
 * @param callback(param) //param = 1:확인, 2:취소
 * @param val1 타이틀
 * @param val2 메시지
 * @param btn 버튼 이름 ex) '확인, 다시보지않기'
 *
 */
function showCusConfirm(callback, val1, val2, btn) {
    var title = val2 ? (val1 || '알림') : '알림';
    var message = val2 || val1;
    var buttons = btn || '확인,취소';
    var is_true = buttons.indexOf(',') == -1;
    /*
    var btn_arr = buttons.split(',');
    var btn_obj = [];
    btn_obj.push({ text : "확인", handler : function() { callback('1'); } });
    if( !is_true ) {
        btn_obj.push({ text : "취소", handler : function() { callback('2'); } });
    }
    WL.SimpleDialog.show(title, message, btn_obj);
    */
    // 안드로이드 7.0 이상은 다 이걸로 대체함..;
    if( DGB.isDebug() || (DGB.isAndroid() && parseFloat(window.device.version) >= 7) ) {
    // if( DGB.isDebug() ) {
        if( is_true ) {
            callback(confirm(message) ? '1' : '1');
        } else {
            callback(confirm(message) ? '1' : '2');
        }
    } else {
        navigator.notification.confirm(message, callback, title, buttons);
    }
}




/**
 * list 정렬
 * @param id: 실제 정렬이 되는 객체의 아이디 or 클레스(ul)
 * @param sortItem : 정렬할 기준(ex: li 내의 <p>, <h3> 등)
 * @param orderBy : asc, desc
 */
function listviewSorting(id, sortItem, orderBy) {
	var sortId = $(id);
	var sortListItem = sortId.children('li').get();
	
	sortListItem.sort(function(a, b) {
		var aItem = $(a).find(sortItem).text().toUpperCase();
		var bItem = $(b).find(sortItem).text().toUpperCase();
		
		if(orderBy == 'desc') {
			return (bItem < aItem) ? -1 : (bItem > aItem) ? 1 : 0;
		} else {
			return (aItem < bItem) ? -1 : (aItem > bItem) ? 1 : 0;
		}
	});
	
	$(sortId).append(sortListItem);
	
}

/**
 * list 결과내 검색
 * @param list: 실제 검색대상이 되는 list(li)
 * @param searchValue : 검색어
 * @param childElement : li 자식의 태그(*, h3, p)
 * @sample listviewFiltering($('#productListview > li'), productName, 'h3');
 */
function listviewFiltering(list, searchValue, childElement) {
	list.each(function() {
		var currentTitle = $(this).find(childElement).text();
		var showCurrentLi = currentTitle.indexOf(searchValue) !== -1;
		$(this).toggle(showCurrentLi);
	});
}

/**
 * Android Menu Key Event
 * Panel Open Or Close
 */
function onMenuKeyDown() {
    if ( DGB.Menu.isOpen('leftPanel') ) {
        DGB.Menu.close('leftPanel');
    } else {
        DGB.Menu.open('leftPanel');
    }
}

/**
 * 다뷰 문서스트리밍 처리
 */
function callDaview(daviewUrl, title, file) {
	if ( !daviewUrl || !daviewUrl.url) return;
    var url = daviewUrl.url;

    var view = '/dgm/v.html?' + $.param({ url : url.toLowerCase(), server : (TEST_SERVER ? 't' : 'r'), title : (title || ''), mark : USER_INFO.FSNM, file : (file || ''), is_ios : DGB.isIPhone() });
    if( DGB.isAndroid() ) {
        var href = location.href;
        href = href.substring(0, href.lastIndexOf('/'));
        AndroidNative.DGMViewWith(href + view);
    } else {
        window.open('.' + view, "_blank", "enableViewPortScale=yes,location=no,toolbar=no,clearsessioncache=yes,clearcache=yes");
    }
}

/**
 * 카메라 호출
 * @param onFrontPhotoSuccess	callback
 * @param quality	이미지 퀄리티(0~100) 기본 75
 */
function capturePhoto(callback, quality) {
	var _quality = quality || 75;
	navigator.camera.getPicture(
		callback
        , function (message) { }
        , {quality : _quality
            , targetWidth: 600
            , targetHeight : 450
            , correctOrientation: true
            , encodingType : navigator.camera.EncodingType.JPEG
            , destinationType : navigator.camera.DestinationType.DATA_URL//DATA_URL ,NATIVE_URI, FILE_URI
        });
}

function pad(val) {
    return (val < 10 ? '0' : '') + val;
}

/**
 * 년월일시분초밀리세컨드
 *
 * @returns yyyyMMDDHHmmss000
 */
function getYYYYMMDDHHmmss() {
	var d = new Date();
    var year = d.getFullYear();
	var month = pad(d.getMonth()+1);
	var date = pad(d.getDate());
	var hour = pad(d.getHours());
	var minute = pad(d.getMinutes());
	var second = pad(d.getSeconds());
	return year + month + date + hour + minute + second + "000";
}

function formattedFilesize(filesize) {
	var fsize = filesize;
	if (fsize > 1024*1024) fsize = Math.round(fsize/1024/1024*100)/100+' MB';
	else if (fsize > 1024) fsize = Math.round(fsize/1024*10)/10+' KB';
	else fsize = fsize +' bytes';
	return fsize;
}

/**
 * 검색창 키패드에서 이동 or Done 키를 눌렀을 경우 바로 검색 진행
 */
$('.searchInputBox').keypress(function(e) {
    if( e.keyCode == 13 ) {
        $(this.searchBtn).trigger('vclick');
    }
});


/**
 * 백그라운드 체크
 */
var skipOrientationChange = true;
function dummyProcedure() {
    console.debug("------------------------------------------------");
    console.debug("[Android-Native] ====> onResume : DummyProcedure");
    console.debug("------------------------------------------------");

    // 바이러스 체크 후에 패널을 안 닫기위해 최초 한번만 화면 갱신을 안한다.
    if( skipOrientationChange ) {
        skipOrientationChange = false;
        return;
    }

    // 화면 갱신 이벤트 강제 발생
    $(window).trigger('orientationchange');

    var options = {
        onSuccess : function(){},
        onFailure : function(){}
    };

    var inv = {
        adapter : 'DBCommonAdapter',
        procedure : 'callCheck',
        parameters: [{}]        // callProcedure 에서 쓰기때문에 초기화 해줘야함
    };
    callProcedure(inv, options);
}

/**
 * 오류 코드를 입력하여 오류 정보를 얻음
 * @see ErrorCodeInfo which is defined in constants.js
 * @param errcode
 * @returns {String}
 */
function getErrorInfo (errcode) {
	if (typeof errcode === 'undefined ') {
		return ErrorCodeInfo.MOSE9999+':'+errcode;
	}
	var info = ErrorCodeInfo[errcode];
	if (typeof msg === 'undefined ') {
		return ErrorCodeInfo.MOSE9999+':'+errcode;
	}
	
	return '['+errcode+'] '+info;
}

/**
 * EAI socket 통신중 오류발생시 출력 함수
 * @param 표준전문 오류코드
 */
function eaiSocketErrorDisplay(errcode) {
	if (errcode == 'EE01403') {		//조회 데이타가 없습니다.
		showAlert(Messages.msg059);	
	}else if(errcode =='BE21538') { //(CU) 비밀번호 불일치 
		showAlert(Messages.msg108);	
	}else if(errcode =='BE23076') { //(EF) 1 비밀번호는 영문,숫자 포함 6-8자리로 입력
		showAlert(Messages.msg04N);	
	}else if(errcode =='BE20024') { //(EF) 1 조회지정자 거래 오류
		showAlert(Messages.msg04O);	
	}else if(errcode =='BE20100') { //(EF) 1 기신청된 이용자입니다.
		showAlert(Messages.msg04P);	
	}else if(errcode =='BE20072') { //(EF) 이용자 ID가 유효하지 않음.(6자리 이상, 숫자로만 구성X)
		showAlert(Messages.msg04Q);
	}else if(errcode =='BE20024') { //(EF) 입력비밀번호 연속된 3자리 안됨.
		showAlert(Messages.msg04R);
	}else if(errcode =='BE23258') { //(EF) 입력비밀번호 전화번호 사용불가
		showAlert(Messages.msg04S);
	}else if(errcode =='BE23259') { //(EF) 1 변경후 비밀번호가 알맞지 않습니다.(주민번호와 동일합니다.)
		showAlert(Messages.msg04T);
	}else if(errcode =='BE07258') { //(EF) 1 숫자이외에는 입력이 불가능합니다
		showAlert(Messages.msg04U);
	}else if(errcode =='BE23090') { //(EF) 1 숫자이외에는 입력이 불가능합니다
		showAlert('비밀번호에 연속된 영문/숫자 3자이 사용불가');
	}else{
		showAlert(Messages.msg013 + "오류코드 : [" + errcode + "]");
	}
	
}

/**
 * 5분체크룰 및 로그아웃시 접속자정보 업데이트
 */
function logoutUserUpdate() {
	var inv = {
			adapter : 'DBCommonAdapter',
			procedure : 'TCO00010',
			parameters : [{
                DEVC_NATV_NO : nmf.Store.get(MAC_ADDRESS),
				ENOB : USER_INFO.ENOB,
				CS_ID : "CO0001",
				CNNT_STC : "LO",
				SESSION_ID : USER_INFO.SESSION_ID
            }]
	};
	var opt = {
        onSuccess : function(){},
		onFailure : function(){}
	};
	callProcedure(inv, opt);

}

/**
 * 천단위마다 , 붙이고 
 * 소숫점 2자리 표시 함수
 */
function numberWithComma(value) {
	if(!value) return "-";
	var diffValue = parseFloat(value);
    var parts = diffValue.toFixed(2).toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}
/**
 * 천단위마다 , 붙이는 함수
 */
function commaNum(tempNum) {
    var len, point, str;  
    var num, oriNum;
    if(tempNum.indexOf("-") != -1) {
    	var tempArray = tempNum.split('-');
    	num =  tempArray[1];
    	oriNum = num;
    } else {
    	num = tempNum;
    	oriNum = tempNum;
    }
    num = num + "";  
    point = num.length % 3;
    len = num.length;  

    str = num.substring(0, point);  
    while (point < len) {  
        if (str != "") str += ",";  
        str += num.substring(point, point + 3);  
        point += 3;  
    }

    return (oriNum == tempNum) ? str : "-" + str;
}

/**
 * 같은 값을 가지는 행 병합(첫번째행만 체크)
 * @param 테이블 id
 */
function mergeSameRow(tableId){
	var first = true;
	var prevRowspan = 1;
	var prevCell = null;

    var rowNum=0; //병합 td 스트라이프 배경 수정.

	// tr 모두 추출
	var rows = $("#"+tableId+ " > tbody").children();
	for(var i=0;i < rows.length; i++){
		//first row
		if(first){
			prevCell = $(rows[i]).find("td").eq(0);
			first = false;
			continue;
		}

		var row = rows[i]; //row
		var tdList = $(row).find("td"); //row > td list
		var firstCell = $(tdList).eq(0); //첫번째 행.
		var firstCellText = $(firstCell).text(); // 첫번째 행 텍스트

		//두번째 row 부터 텍스트 비교.
		if(prevCell.text() == firstCellText){
			prevRowspan ++;
			$(prevCell).attr("rowspan", prevRowspan);

			$(firstCell).remove();
		}else{
            rowNum++;

            if(rowNum%2 == 0)
                $(firstCell).attr("style", "background-color: rgba(0,0,0,0.04);");
            else
                $(firstCell).attr("style", "background-color: rgba(0,0,0,0);");

			prevRowspan = 1;
			prevCell = firstCell;

		}
	}
}

/**
 * 권한 없는 메뉴 조회.
 * @param 조회 메뉴 ID
 */
function isRejectedMenu(menuId) {
    // M-배치 특별 권한 부여
    if ( menuId == 'RE0501' && (USER_INFO.ORG_CD == '906' || USER_INFO.ORG_CD == '951' || USER_INFO.ORG_CD == '969') ) {
        return false;
    }

    if( USER_INFO.AUTH ) {
        var split = USER_INFO.AUTH.split(",");
        for(var i = 0; i < split.length; i++){
            if( menuId == split[i] ){
                return true;
            }
        }
    }
    return false;
}
/**
 * 한글 초성.
 * @param 한글
 * @return 초성.
 */
function getChoSung(text)  
{  
	 var ChoSeong = new Array (   
			 0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139,   
			 0x3141, 0x3142, 0x3143, 0x3145, 0x3146, 0x3147,   
			 0x3148, 0x3149, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e   
	 );    
	 var chars = new Array();  
	 var v="";
	 for (var i = 0; i < text.length; i++)   
	 {  
		 chars[i] = text.charCodeAt(i);  
		 if (chars[i] >= 0xAC00 && chars[i] <= 0xD7A3)   
		 {  
			 var i1;  
			 i1 = (chars[i] - 0xAC00) / (21 * 28);  
			 v += String.fromCharCode(ChoSeong[parseInt(i1)]);  
		 }else{  
			 v += (String.fromCharCode(chars[i] ));  
		 }  
	 }  
	 return v;  
}

//공지사항 popup 메시지
function popMessge(){
    if(Messages.pop000.indexOf('YES') > -1){
        if( Messages.pop001.indexOf('IOS') > -1 )
        {
            if( DGB.isIPhone() ) {
                checkPopMsg();
            }
        }else  if( Messages.pop001.indexOf('AND') > -1 ) {
            if( DGB.isAndroid() ) {
                checkPopMsg();
            }
        } else {
            checkPopMsg();
        }
    }
}

function checkPopMsg(){
    var ispopmsg = nmf.Store.get(POP_MESSAGE);
    if ( !ispopmsg || ispopmsg != Messages.pop001 ) {
        showCusConfirm(function(btn){
            if ( btn == '2' ) {
                nmf.Store.set(POP_MESSAGE, Messages.pop001 );
            }
        }, '알림', Messages.pop002, '확인, 다시보지않기');
    }
}


// IOS 스키마 호출시 사용 ( Fido 인증 )
function handleOpenURL(url) {
    DGB.Fido.openURL(url);
}

function pushReceiver(push) {
    smsReceiver(push);
}

// 안드로이드 SMS 리시버
function smsReceiver(sms) {
    DGB.Log.d("SMS Receiver : " + sms);
    if( !sms ) return;

    if( sms.indexOf('DGB오피스') == -1 ) return;

    var auth = sms.match(/\d{6}/)[0] || '';
    if( !auth ) return;

    var page_id = $.mobile.activePage.attr('id');
    if( page_id != 'login' ) return;

    $('#login #sms_auth').val(auth);
}

function nfcReceiver(text) {
    DGB.Log.d("NFC Receiver : " + text);
    if( !text ) return;

    var page_id = $.mobile.activePage.attr('id');
    if( page_id != 'login' ) return;

    if( !DGB.Sms.get() ) {
        showAlert('통합인증 및 SMS인증 후 사원증 태그를 사용하실수 있습니다.');
        return;
    }

    // 10자리로 만들기 ( 앞에 0이 있는 번호가 있어서 숫자로 넘어옴 )
    text = nfcFormat(text, 10);
    $('#login #nfc_auth').val(text);
    $('#login #rd_nfc').click();
    setTimeout(function() {
        $('#login #nfc_ok').click();
    }, 400);
}

function nfcFormat(v, n) {
    v = v + '';
    return v.length >= n ? v : new Array(n - v.length + 1).join('0') + v;
}

function nfcStateReceiver(state) {
    DGB.Log.d("NFC State Receiver : " + state);

    var page_id = $.mobile.activePage.attr('id');
    if( page_id != 'login' ) return;

    $('#login').trigger('nfcstatechange', state);
}