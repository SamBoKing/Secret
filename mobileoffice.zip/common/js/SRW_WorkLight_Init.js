// WorkLight Init
function wlCommonInit() {
	DGB.Log.d("[SRW_WorkLight_Init] ====>> wlCommonInit");

	overrideMessages();

    initSubscribe();
	
    if( DGB.isDebug() ) {
        DGB.init();
        return;
    }

	dgbLoading(true);

	// 리소스 업데이트 강제 안함 설정 ( 네이티브 수정시 활용 )
	if( WL.StaticAppProps.APP_VERSION == '1.1' ) {
		WL.EPField.SUPPORT_DIRECT_UPDATE_FROM_SERVER = "";
	}


	// WL Connect
	WL.Client.connect({
		onSuccess : function(){
			dgbLoading(false);
			DGB.init();
		},
		onFailure : function(){
			dgbLoading(false);
			WL.Client.reloadApp();
		}
	});
}

/**
 */
function loginCall(){
	// id pw 전역 저장
	GLOBAL.ENOB = $('#login #loginId').val();
	GLOBAL.PSWD = $('#login #loginPw').attr('data-enc');
	if(GLOBAL.ENOB == undefined || GLOBAL.ENOB.length < 4 || GLOBAL.ENOB.length > 7) {
			showAlert(Messages.msg004);
			return;
	}
	if(GLOBAL.PSWD == undefined || GLOBAL.PSWD.length < 1) {
		showAlert(Messages.msg034);
		return;
	}
	authProcess();
}

/**
 * 텍스트 입력 byte 길이 계산
 * @param str : 입력텍스트
 */
function getMsgLength(str){
	var ll = str.length;
	var tt, cc=0;
	for (var kk=0 ; kk<ll ; kk++) {
		tt = str.charAt(kk);
		if (escape(tt).length > 4) {
			cc = cc + 2;
		} else if (tt == '\r' && str.charAt(kk+1) == '\n') {
			cc = cc + 2;
		}else if (tt != '\n')
		{
			cc ++;
		}
	}
	return cc;
}
/**
 * @param str : 입력텍스트
 * @param maxcnt : 최대입력값 
 */
function getMsgPosition(str, maxcnt) {
	var tt, cc=0;
	var ll = str.length;
	for (var kk=0 ; kk<ll ; kk++) {
		tt = str.charAt(kk);
		if (escape(tt).length > 4) {
			cc = cc + 2;
		} else if (tt == '\r' && str.charAt(kk+1) == '\n') {
			cc = cc + 2;
		} else if (tt != '\n') {
			cc ++;
		}

		if(cc > maxcnt) {
			break;
		}
	}
	return cc+"^"+kk;
}