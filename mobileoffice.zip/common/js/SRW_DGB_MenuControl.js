DGB.menuctrl = (function() {

	var triggerMenuItem = function(menuId) {
		DGB.Menu.trigger('leftPanel', 'click', menuId);
	};

	var triggerMoveMails = function(menuId) {
        var pageId = $('.ui-page-active').attr('id');
		var args = {'menuId':menuId, 'activePage':true};
        DGB.Page.triggerPage("#"+pageId, "selectmenu", [args]);
        DGB.Page.changePage('#'+pageId);
        showAlert(Messages.msg02I);
	};

	var triggerLocMails = function(menuId) {
		//편지쓰기메뉴클릭 후 전송 또는 취소시 받은편지함으로 이동.
		//편지함에서 답장, 전체답장, 전달으로 편지쓰기 이동한 경우 전송 또는 취소시 이전 편지함으로 이동

		if (menuId == 'GR0101') menuId = 'GR0102';
		var args = {'menuId':menuId, 'boxId':'Inbox', 'activePage':false};
        DGB.Page.triggerPage("#GREM002", "selectmenu", [args]);
        DGB.Page.changePage('#GREM002');
	};
	
	//로긴이필요한 서비스에 로그인 후 권한이 없을경우 free Service화면으로 이동
	var selectFreeService = function(curPageId) {
		var args = {'menuId':'CO0002', 'activePage':false};
        DGB.Page.triggerPage('#'+curPageId, "selectmenu", [args]);
        DGB.Page.changePage('#freeSv');
	};

	return {
		'triggerMenuItem':triggerMenuItem,
		'triggerMoveMails':triggerMoveMails,
		'triggerLocMails':triggerLocMails,
		'selectFreeService':selectFreeService,
	};
})();

