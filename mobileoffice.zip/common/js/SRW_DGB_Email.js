DGB.email = (function() {
	
	/******************************
	 * Internal Private Variables *
	 ******************************/
	var adapterName = 'IMAPEmailAdapter';
	
	// For testing with dummy data
	//adapterName = 'TestEmailAdapter';

	var mailboxInfoCache = {};
	var mailboxMapper = {
		'Inbox' : {
			'name':'받은편지함',
			'menuId':'GR0102',
			'pageId':'GREM002',
			'icon':'icon_emailList_0'
		},
		'Sent' : {
			'name':'보낸편지함',
			'menuId':'GR0103',
			'pageId':'GREM002',
			'icon':'icon_emailList_1'
		},
		'Drafts' : {
			'name':'임시편지함',
			'menuId':'GR0104',
			'pageId':'GREM002',
			'icon':'icon_emailList_2'
		},
		'Trash' : {
			'name':'지운편지함',
			'menuId':'GR0105',
			'pageId':'GREM002',
			'icon':'icon_emailList_3'
		},
		'Spam' : {
			'name':'스팸편지함',
			'menuId':'GR0106',
			'pageId':'GREM002',
			'icon':'icon_emailList_4'
		},
		'$reserved$':{
			'pageId':'GREM002',
			'icon':'icon_emailList_5',
			'nocheck':true
		}
	};
	
	// Current Mail Box List
	var _mailboxlist = undefined;

	/******************************
	 * Internal Private Functions *
	 ******************************/
	var __privateFunction = function() {
		
	};
	
	var __hasServerResponse = function(data, callback) {
		var response = data.invocationResult['_server_'];
		if (typeof response !== 'undefined') {
			if (typeof callback === 'function') callback(response);
			return true;
		}
		
		return false;
	};
	
	var __hasServerErrorResponse = function(data, callback) {
		var response = data.invocationResult['_server_'];
		if (typeof response !== 'undefined' && typeof response.errorCode !== 'undefined') {
			if (typeof callback === 'function') callback(response);
			return true;
		}
		
		return false;
	};
	
	/********************
	 * Public Functions *
	 ********************/
    var __primaryKey = function() {
    	return nmf.Store.get(EMAIL_KEY_ID) || '';
    };

	var isDefaultBox = function(boxId){
		if (typeof mailboxMapper[boxId] == 'undefined')
			 return false;
		else
			return true;
	};
	var getMailBoxList = function(menuId, successCB, errorCB) {
		var invocationData = {
			adapter : adapterName,
			procedure : 'TGR00010',
			parameters : [{
				CS_ID : menuId, 
				ENOB  : USER_INFO.ENOB,
				__PRIVATE_KEY__: __primaryKey(),
				DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
			}]
		};
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}
				var result = data.invocationResult.resultSet || {};

				var boxes = result.boxes;
				var draftsIndex = -1;       //Drafts(임시보관함 삭제)
                for (var i in boxes) {
					var box = boxes[i];

                    //Drafts(임시보관함 삭제)
                    if(box.MAILBOX_NAME == 'Drafts') {
                        draftsIndex = i;
                        continue;
                    }

					var prop = mailboxMapper[box.MAILBOX_NAME];
					if (typeof prop == 'undefined') {
						prop = mailboxMapper['$reserved$'];
						box['name'] = box.MAILBOX_NAME;
						box['menuId'] = 'GR011'+i;
					}
					$.extend(box, prop);

					// Override box name
					var bname = box['MAILBOX_NAME_DECODE'];
					if (typeof bname === 'undefined' || bname == '') {
						box['MAILBOX_NAME_DECODE'] = box.name;
					}
				}
                //Drafts(임시보관함 삭제)
                if(draftsIndex != -1)
                    result.boxes.splice(draftsIndex,1);


				// deep copy
				mailboxInfoCache = nmf.utils.Object.clone(result);
				
				/*
				// Set generic mail boxes
				for(var i=0;i<5;i++) {
					var box = result.boxes[i];
					box['menuId'] = 'GR010'+(i+2);
					box['pageId'] = 'GREM002';
					box['icon'] = 'icon_emailList_'+(i);
				}
				
				// Set customized mail boxes
				for(;i<result.boxes.length;i++) {
					var box = result.boxes[i];
					box['menuId'] = 'GR010'+(i+2);
					box['pageId'] = 'GREM002';
					box['icon'] = 'icon_emailList_5';
					box['nocheck'] = true;
				}
				*/
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};
	
	var searchMails = function(menuId, boxId, startMailId, length, keyword, successCB, errorCB) {
		var procedure = 'TGR00021';
		if (typeof keyword === 'function') {
			successCB = keyword;
			keyword = undefined;
		}

		// invalid keyword string means searching all
		if (typeof keyword !== 'string') {
			keyword = undefined;
			procedure = 'TGR00020';
		}
		
		var invocationData = {
			adapter : adapterName,
			procedure : procedure,
			parameters : [{
				CS_ID : menuId, 
				ENOB  : USER_INFO.ENOB, 
				__PRIVATE_KEY__: __primaryKey(),
				DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
			}, boxId, startMailId, length, keyword]
		};
		
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult.resultSet;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};
	
	var getMailContent = function(menuId, boxId, mailId, successCB, errorCB) {
		var invocationData = {
			adapter : adapterName,
			procedure : 'TGR00030',
			parameters : [{
				CS_ID : menuId, 
				ENOB  : USER_INFO.ENOB, 
				__PRIVATE_KEY__: __primaryKey(),
				DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
			}, boxId, mailId]
		};
		
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult.resultSet;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};
	
	var emptyMailBox = function(menuId, boxId, successCB, errorCB) {
		if (boxId != 'Junk' && boxId != 'Trash' && boxId != 'Spam') {
			// Not allowed to empty the box
			if (typeof successCB === 'function') successCB();
			return;
		}
		var invocationData = {
				adapter : adapterName,
				procedure : 'TGR00022',
				parameters : [{
					CS_ID : menuId, 
					ENOB  : USER_INFO.ENOB, 
				    __PRIVATE_KEY__: __primaryKey(),
				    DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
				}, boxId]
			};
		
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};

	var deleteMails = function(menuId, boxId, mailIds, successCB, errorCB) {
		// alternative impl: moveMails(menuId, boxId, mailIds, 'Trash', successCB);
		var invocationData = {
				adapter : adapterName,
				procedure : 'TGR00033',
				parameters : [{
					CS_ID : menuId, 
					ENOB  : USER_INFO.ENOB, 
				    __PRIVATE_KEY__: __primaryKey(),
				    DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
				}, boxId, mailIds]
			};
			
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};
	
	var moveMails = function(menuId, boxId, mailIds, toBoxId, successCB, errorCB) {
		var invocationData = {
				adapter : adapterName,
				procedure : 'TGR00032',
				parameters : [{
					CS_ID : menuId, 
					ENOB  : USER_INFO.ENOB, 
				    __PRIVATE_KEY__: __primaryKey(),
				    DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
				}, boxId, mailIds, toBoxId]
			};
			
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};

	var sendMail = function(menuId, to, cc, bcc, subject, body, attachments, mailId, successCB, errorCB) {
		
		var options = {};
		
		if (typeof cc !== 'undefined') options['cc'] = cc;
		if (typeof bcc !== 'undefined') options['bcc'] = bcc;
		if (typeof attachments !== 'undefined') options['attachments'] = attachments;
		if (typeof mailId !== 'undefined') options['mailId'] = mailId;
		
		var invocationData = {
				adapter : adapterName,
				procedure : 'TGR00031',
				parameters : [{
					CS_ID : menuId, 
					ENOB  : USER_INFO.ENOB, 
				    __PRIVATE_KEY__: __primaryKey(),
				    DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
				}, to, subject, body, options]
			};
			
		callProcedure(invocationData, {
			onSuccess : function(data){
				if (__hasServerErrorResponse(data, errorCB)) {
					return;
				}

				var result = data.invocationResult;
				
				if (typeof successCB === 'function') successCB(result);
			},
			onFailure : function(error){
				var msg = error.errorCode+':'+error.errorMsg;
				if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
			},
			invocationContext : {}
		});
	};

    var sendSecretMail = function(menuId,  subject, body, isSecret, successCB, errorCB) {

        var invocationData = {
            adapter : adapterName,
            procedure : 'TGR00034',
            parameters : [{
                CS_ID : menuId,
                ENOB  : USER_INFO.ENOB,
                __PRIVATE_KEY__: __primaryKey(),
                DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS)
            }, subject, body, isSecret, Messages.com003]
        };

        callProcedure(invocationData, {
            onSuccess : function(data){
                if (__hasServerErrorResponse(data, errorCB)) {
                    return;
                }

                var result = data.invocationResult;

                if (typeof successCB === 'function') successCB(result);
            },
            onFailure : function(error){
                var msg = error.errorCode+':'+error.errorMsg;
                if (typeof errorCB === 'function') errorCB({'errorCode':'MOSE0000', 'errorMessage':msg});
            },
            invocationContext : {}
        });
    };

	return {
		'getMailBoxName': function(boxId) {
			//var box = mailboxMapper[boxId];
			//if (typeof box === 'undefined') return boxId;
			//return box.name;
			if (typeof mailboxInfoCache == 'undefined') return boxId;
			for (var i in mailboxInfoCache.boxes) {
				var box = mailboxInfoCache.boxes[i];
				if (boxId == box.MAILBOX_NAME) {
					return box['MAILBOX_NAME_DECODE'];
				}
			}
		},
		'getCachedMailBoxInfo':function() {
			return mailboxInfoCache;
		},

		'isDefaultBox':isDefaultBox,
		'getMailBoxList':getMailBoxList,
		'searchMails':searchMails,
		'getMailContent':getMailContent,
		'emptyMailBox':emptyMailBox,
		'deleteMails':deleteMails,
		'moveMails':moveMails,
		'sendMail':sendMail,
        'sendSecretMail':sendSecretMail,
		'getKey' : __primaryKey
	};
})();
