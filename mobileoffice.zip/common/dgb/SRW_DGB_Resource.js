var DEBUG = document.URL.indexOf('localhost') > -1;
if( DEBUG ) {
    // Define WL namespace.
    var WL = WL ? WL : {};
    /**
     * WLClient configuration variables.
     * Values are injected by the deployer that packs the gadget.
     */
    WL.StaticAppProps = {
        "APP_DISPLAY_NAME": "DAEGUBANK",
        "APP_ID": "mobileoffice",
        "APP_SERVICES_URL": "\/DGB\/apps\/services\/",
        "APP_VERSION": "2.0.4",
        "ENVIRONMENT": "preview",
        "LOGIN_DISPLAY_TYPE": "embedded",
        "PREVIEW_ENVIRONMENT": "android",
        "WORKLIGHT_PLATFORM_VERSION": "6.1.0.00.20131126-0630",
        "WORKLIGHT_ROOT_URL": "\/MobileOfficeWeb\/wl\/"
    };
}

var DGB_RESOURCE = {
    css : [
        { href : "wl/css/wlclient.css", debug : true },
        { href : "css/jquery.mobile-1.3.1.css" },
        { href : "css/jqm-override.css" },
        { href : "css/slidemenu.css" },
        { href : "css/header.css" },
        { href : "css/email.css" },
        { href : "css/staffDetail.css" },
        { href : "css/custombutton/custom-buttons.css" },
        { href : "css/custombutton/app-reset.css" },
        { href : "css/calendar/SRW_jqm_cal.ios7.css" },
        { href : "css/jquery-clockpicker.min.css" },
        { href : "css/MobileOffice.css" },
        { href : "css/MobileOffice.New.css" },
        { href : "css/MobileOffice.Menu.css" },
        { href : "css/MobileOffice.Food.css" },
        { href : "css/MobileOffice.Jquery.css" },
        { href : "css/MobileOffice.Theme.Office.css", "id" : "theme_office" },
        { href : "css/MobileOffice.Theme.Bank.css", "id" : "theme_bank" }
    ],
    js : [
        { src : "wl/cordova.js", debug : true },
        { src : "wl/wljq.js", debug : true },
        { src : "wl/worklight.js", debug : true },
        { src : "wl/checksum.js", debug : true },
        { src : "wl/analytics.js", debug : true },
        { src : "js/jquery/SRW_jquery-1.9.1.min.js" },
        { src : "js/jquery/SRW_jquery.mustache.js" },
        { src : "js/jquery/SRW_jquery.mobile.init.js" },
        { src : "js/jquery/SRW_jquery.mobile-1.3.1.js" },
        { src : "js/jquery/SRW_jquery-clockpicker.min.js" },
        { src : "js/SRW_PushManager.js" },
        { src : "js/plugin/SRW_ActionSheet.js" },
        { src : "js/plugin/SRW_WaitingDialog.js" },
        { src : "js/plugin/SRW_VideoPlayer.js" },
        { src : "js/plugin/SRW_MacAddress.js" },
        { src : "js/plugin/SRW_DevInfo.js" },
        { src : "js/plugin/SRW_FileOpener.js" },
        { src : "js/plugin/SRW_SocialSharing.js" },
        { src : "js/plugin/SRW_Fido.js" },
        { src : "js/plugin/SRW_Nfc.js" },
        { src : "js/plugin/SRW_AppIron.js" },
        { src : "js/plugin/SRW_Bio.js" },
        { src : "js/plugin/SRW_TouchID.js" },
        { src : "js/editor/SRW_Raphael.js" },
        { src : "js/editor/SRW_Editor.js" },
        { src : "js/editor/SRW_Shape.js" },
        { src : "js/editor/SRW_Tracker.js" },
        { src : "js/utils/SRW_AutoLink.js" },
        { src : "js/utils/SRW_ImageLoader.js" },
        { src : "js/utils/SRW_IScroll.js" },
        { src : "js/utils/SRW_Mustache.js" },
        { src : "js/utils/SRW_Calendar.js" },
        { src : "js/utils/SRW_HideShowPassword.js" },
        { src : "js/utils/SRW_FileSize.js" },
        { src : "js/SRW_DGB_Constants.js" },
        { src : "dgb/SRW_DGB.js" },
        { src : "js/SRW_DGB_Common.js" },
        { src : "js/SRW_DGB_MenuControl.js" },
        { src : "js/SRW_DGB_Nmf.js" },
        { src : "js/SRW_DGB_Layout.js" },
        { src : "js/SRW_DGB_FileControl.js" },
        { src : "js/SRW_DGB_Email.js" },
        { src : "js/SRW_RemoteHandler.js" },
        { src : "js/SRW_UserHandler.js" },
        { src : "js/SRW_WorkLight_Message.js" },
        { src : "js/SRW_WorkLight_Options.js" },
        { src : "js/SRW_WorkLight_Init.js" },
        { src : "js/SRW_MobileOffice_Common.js" },
        { src : "js/SRW_MobileOffice_Init.js" }
    ]
};

function initResource() {
    var time = new Date().getTime();
    for(var i in DGB_RESOURCE.css ) {
        var css = DGB_RESOURCE.css[i];
        if( ( DEBUG && css.debug ) || !css.debug ) {
            var href = css.href + '?_=' + time;
            var id = css.id ? 'id="' + css.id + '"' : '';
            document.writeln('<link rel="stylesheet" href="' + href + '" ' + id + ' >');
        }
    }

    for(var j in DGB_RESOURCE.js ) {
        var js = DGB_RESOURCE.js[j];
        if( ( DEBUG && js.debug ) || !js.debug ) {
            var src = js.src + '?_=' +time;
            document.writeln('<script src="' + src + '"></script>');
        }
    }
}
initResource();