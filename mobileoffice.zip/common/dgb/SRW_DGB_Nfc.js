DGB.Nfc = {
    is : function(callback) {
        window.plugins.nfc.is(callback, callback);
    },

    setting : function() {
        window.plugins.nfc.setting();
    },

    dialog : function() {
        window.plugins.nfc.dialog();
    },

    auth : function(auth) {
        GLOBAL.TRF_CDNO = auth;
        GLOBAL.STAT = DGB.Auth.Level.Nfc;
        GLOBAL.TEMP_STAT = GLOBAL.STAT;
        GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
        authProcess();
    }
};