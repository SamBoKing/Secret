/**
 * @author d320462
 * @see 다른곳에서  DGB 네임스페이스를 사용중이기 때문에 상속 받아서 써야함
 */
var DGB = DGB || {};
(function() {
    console.debug("#####################################################");
    console.debug("               [DGB Javascript Module]               ");
    console.debug("#####################################################");

    // Debug Mode Set
    var DEBUG = document.URL.indexOf('localhost') > -1;
    this.isInit = false;

    // DGB Module File Load
    $.ajax({
        url : "config/SRW_DGB.json",
        async: false,
        dataType : "json",
        success : function(files) {
            for(var f in files) {
                $.ajax({
                    url : files[f].url,
                    async: false,
                    dataType : "script",
                    success : function(data) {
                        console.debug("[DGB] ====>> '" + files[f].namespace + "' Module Load Success");
                    },
                    error : function(data) {
                        console.error("[DGB] ====>> '" + files[f].namespace + "' Module Load Failed - Url : " + files[f].url);
                    }
                });
            }
        },
        error : function(data) {
            console.error("[DGB] ====>> Module JSON File Load Failed - Url : " + this.url);
        }
    });

    if( !DEBUG ){
        // 도메인이 변경시에 동기방식이 안됨
        var message_url = HOST_URL + '/js/SRW_message.js?_=' + new Date().getTime();
        document.writeln('<script src="' + message_url + '"></script>');
    }

    this.init = function() {
        DGB.Log.d("[DGB] ====>> init");

        // 기본값 셋팅
        if( DGB.isIPhone() ) {
            WL.Badge.setNumber(0);		// IOS 뱃지카운트
        }

        // Mac Address
        var addr = nmf.Store.get(MAC_ADDRESS) || '';
        if ( !addr || addr.indexOf(':') > -1 ) {    // 이전 디바이스 정보 업데이트
            WL.Device.getID({
                onSuccess: function (data) {
                    nmf.Store.set(MAC_ADDRESS, data.deviceID);
                },
                onFailure: function () {
                    nmf.Store.set(MAC_ADDRESS, nmf.Store.UUID.get());
                }
            });
        }

        // Device Info
        WL.Device.getNetworkInfo(function(info) {
            GLOBAL.NETWORK = info;
        });

        DGB.Theme.init();
        DGB.Page.init();
        DGB.Menu.init();
        DGB.Auth.Step.init();
        DGB.MyMenu.init();
        DGB.Setting.init();
        DGB.Fido.init();
        DGB.MDM.init();
        DGB.Alive.init();
        DGB.Sms.init();
        DGB.Calendar_Alios.init();

        // Wait for device API libraries to load
        document.addEventListener("deviceready", onDeviceReady, false);

        // 시작페이지 실행
        DGB.Page.changePage('#freeSv');
        this.isInit = true;

        DGB.Log.d("[DGB] ==>> init finish!");
    };

    /**
     * @private
     * @see 디바이스 로드 이벤트
     */
    var onDeviceReady = function() {
        var emailPath = "";	//이메일첨부파일 삭제경로 지정
        var msgPath = "";	//메세지함첨부파일 삭제경로 지정

        if( DGB.isAndroid() ) {
            document.addEventListener("menubutton", onMenuKeyDown, false);
            emailPath = DGB.fileRoot();
            msgPath = DGB.fileRoot();

            //안드로이드 네이티브 Push 횟수 전송
            var vibObj = DGB.Setting.get(DGB.Setting.Keys.PushVibration);
            AndroidNative.pushVibratorSet(vibObj.loop, vibObj.vibe,vibObj.stop );
        }
        emailPath += "email/";
        msgPath += "message/";

        //이메일에서 저장된 첨부파일 삭제
        DGB.filectrl.removeDirectoryAll(emailPath);
        DGB.filectrl.removeDirectoryAll(msgPath);

        document.addEventListener("resume",DGB.onResume,false);
        document.addEventListener("pause",DGB.onPause,false);
    };

     this.onResume = function(){
         DGB.Timer.checkRequest();
         dummyProcedure();
    };

    this.onPause = function(){
    	DGB.Timer.setRequest();
    };

    this.msg = function(msg) {
        if( DEBUG || TEST_SERVER ) {
            alert(msg);
        }
    };

    this.test = function() {
        DGB.Log.w('#####################################################');
        DGB.Log.w('                == Test Mode Start  ==               ');
        DGB.Log.w('#####################################################');
    };

    this.isPreView = function() {
        return (WL.Client.getEnvironment() == WL.Environment.PREVIEW);
    };

    this.isIPhone = function() {
        return (WL.Client.getEnvironment() == WL.Environment.IPHONE ||
            WL.Client.getEnvironment() == WL.Environment.IPAD);
    };

    this.isAndroid = function() {
        return (WL.Client.getEnvironment() == WL.Environment.ANDROID);
    };

    this.getDeviceVersion = function(){
    	return parseFloat(window.device.version);
    };

    this.getFileExt = function(name) {
        return name.substr(name.lastIndexOf(".")).toLowerCase();
    };

    this.isImage = function(name) {
        var ext = name.substr(name.lastIndexOf(".")).toLowerCase();
        var imgExt = ['.jpg', '.png', '.bmp', '.gif'];
        return imgExt.indexOf(ext) > -1;
    };

    this.isSound = function(name) {
        var ext = name.substr(name.lastIndexOf(".")).toLowerCase();
        var sodExt = ['.wav', '.mp3'];
        return sodExt.indexOf(ext) > -1;
    };

    this.isMovie = function(name) {
        var ext = name.substr(name.lastIndexOf(".")).toLowerCase();
        var movExt = ['.mp4', '.wmv','.avi'];
        return movExt.indexOf(ext) > -1;
    };

    this.isMovieAVI = function(name) {
        var ext = name.substr(name.lastIndexOf(".")).toLowerCase();
        var aviExt = ['.avi'];
        return aviExt.indexOf(ext) > -1;
    };

    this.isMovieWMV = function(name) {
        var ext = name.substr(name.lastIndexOf(".")).toLowerCase();
        var wmvExt = ['.wmv'];
        return wmvExt.indexOf(ext) > -1;
    };

    this.isDebug = function() {
        return DEBUG;
    };

    this.fileRoot = function() {
        return "MobileOffice/";
    };

    this.skyHost = function() {
        if( TEST_SERVER )
            return 'http://tkms.daegubank.co.kr';
        else
            return 'http://kms.daegubank.co.kr';
    };

    this.homeHost = function() {
        if( TEST_SERVER )
           return "http://172.18.6.126/worklight";
        else
            return "https://office.dgb.co.kr/worklight";
    };

    this.homeDown = function() {
        if( TEST_SERVER )
            return "http://172.18.6.126/mobileoffice";
        else
            return "https://office.dgb.co.kr/mobileoffice";
    };

    this.dgbHost = function() {
        return 'https://www.dgb.co.kr';
    };

    this.homeAttach = function() {
        return this.homeDown() + "/attach";
    };

    this.debugMessage = function() {
        DGB.Log.w("###### [DGB.Debug] ###### ====>> Debug Mode Success!!!");
    };

    this.format = function() {
        var str = arguments[0];
        for (var i = 1; i < arguments.length; i++) {
            var regEx = new RegExp("\\{" + (i - 1) + "\\}", "gm");
            str = str.replace(regEx, arguments[i]);
        }
        return tr;
    };

}).apply(DGB);
