DGB.Page = {

    // 페이지 소스를 관리하는 맵
    pageMap : new DGB.HashMap(),
    triggerList : [],

	init: function() {
		DGB.Log.d("[DGB.Page] ====>> init");
		this.pageLoad();
	},
	
	pageLoad: function() {
        var me = this;
		$.ajax({
			url: 'config/SRW_DGB_Page.json',
			dataType: 'json',
			async: false,
			success: function(data) {
                // Save Page Data
                for(var i in data) {
                    me.pageMap.put(data[i].id, data[i]);
                }
			},
			error: function() { DGB.Log.e('[DGB.Page] ====>> Page JSON file load failed!'); }
		});
	},
 
    jsLoad: function(url) {
        var isSuccess = false;
        $.ajax({
            url : url + "?_="+ new Date().getTime(),
            dataType : 'script',
            async: false,
            cache: false,
            success : function(data) {
                isSuccess = true;
                DGB.Log.d('[DGB.Page] ====>> [' + this.url + '] script load success ');
            },
            error : function(xhr, status, err) {
                isSuccess = false;
                DGB.Log.e('[DGB.Page] ====>> [' + this.url + '] script load failed : ' + err);
            }
        });
        return isSuccess;
    },

    // Custom mobile.chagePage method
    changePage: function(page_id, option) {
        var me = this;
        var id = $.mobile.activePage.attr('id');

        // 같은 화면일시 패널 닫기
        if( page_id == ('#' + id) ) {
            // 로그인과 받은편지함 일때 인증 구분 때문에 화면 변경
            // if( page_id == '#login' || page_id == '#GREM002' || page_id == '#EMST001' || page_id == '#COPU001' || page_id == '#CO00002' ) {
                me.triggerCommit();
                // $.mobile.changePage(page_id);
            // }
            if(DGB.Menu.isOpen('leftPanel')) DGB.Menu.close('leftPanel');
            return;
        }

        //권한 없는 메뉴로 진입되지 않도록.
        var menuId = DGB.Menu.trigger('leftPanel', 'getRejectedMenuId', page_id);

        if (isRejectedMenu(menuId) ) {
            // 메일 성공시 왼쪽 메뉴 열리고 메일선택되도록 수정
            showCusConfirm(function(button){}, "알림", Messages.msg065, "확인");
            return;
        }

        var page = this.pageMap.get(page_id);
        if( page ) {
            // Javascript File Load
            if( !page.load ) {
                page.load = this.jsLoad(page.url + '.js');
            }

            // Dom Cache
            if( !$(page_id).length ) {
                $.mobile.loadPage(page.url + '.html', { async: false } );
            }
        }

        // 키보드 있을시 딜레이 후 화면 이동(안드로이드)
        if( DGB.isAndroid() ) {
            if( DGB.Common.isKeyboardShow() ) {
                DGB.Common.hideKeyboard();
                setTimeout(function() {
                    me.triggerCommit();
                    $.mobile.changePage(page_id,option);
                }, 350);
            } else {
                me.triggerCommit();
                $.mobile.changePage(page_id,option);
            }
        } else {
            DGB.Common.hideKeyboard();
            me.triggerCommit();
            $.mobile.changePage(page_id,option);
        }
    },

    loadPage: function(url, id) {
        $.ajax({
            url : url + "?_="+ new Date().getTime(),
            dataType : 'html',
            async: false,
            cache: false,
            success : function(data) {
                $(data).insertAfter($("body > div[data-role='page']").first());
            },
            error : function(xhr, status, err) {
                DGB.Log.e('[DGB.Page] ====>> [' + this.url + '] html load failed : ' + err);
            }
        });
    },

    triggerPage: function(page_id, event, args) {
        this.triggerList.push({
            page_id : page_id,
            event : event,
            args : args
        });
    },

    triggerCommit: function() {
        for(var i = 0; i < this.triggerList.length; i++) {
            var item = this.triggerList[i];
            $(item.page_id).trigger(item.event, item.args);
        }

        for(var i = 0; i < this.triggerList.length; i++) {
            this.triggerList.pop();
        }
    },

    backPage: function() {
        if( DGB.Common.isKeyboardShow() ) {
            DGB.Common.hideKeyboard();
            setTimeout(function() {
                $.mobile.back();
            }, 350);
        } else {
            DGB.Common.hideKeyboard();
            $.mobile.back();
        }
    }
};