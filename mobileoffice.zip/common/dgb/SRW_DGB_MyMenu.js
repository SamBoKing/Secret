DGB.MyMenu = {};
(function() {
	// 나의 메뉴 스트로지 이름
	var STORAGE_NAME = "dgb.mymenu";
	var STORAGE_DATA = "{\"menu\":\"\",\"menubackup\":\"\"}";

    //메세지함 TCO0101 -> CO0101 변경.
    this.init = function() {
        if( this.findMenu("TCO0101") ){
           this.removeMenu("TCO0101");
           this.insertMenu("CO0101");
        }
    };

	//  백업을 내용 저장
	this.save = function() {
		var data = this.getData();
		data.menu = data.menubackup;
        nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};
	
	// 내용을 백업에 저장
	this.backup = function() {
		var data = this.getData();
		data.menubackup = data.menu;
        nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};
	
	// Backup 내용 삭제
	this.clearBackup = function() {
		var data = this.getData();
		data.menubackup = "";
		nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};

	// 나의 메뉴 등록 및 삭제후 자동 갱신
	this.add = function() {
		var me = this;
        var menu_id = me.getMenuId();
		var find = me.findMenu(menu_id);
		showConfirm(function(btn){
			if (btn == '1') {
				// 등록 및 삭제
				( find ) ? me.removeMenu(menu_id) : me.insertMenu(menu_id);
			}},
			find ? Messages.msg005 :  Messages.msg003);
	};
	
	// 적용 데이타 가져오기
	this.getData = function() {
		var data = nmf.Store.get(STORAGE_NAME);
		if( !data ) {
			nmf.Store.set(STORAGE_NAME, STORAGE_DATA);
			data = STORAGE_DATA;
		}
		return JSON.parse(data);
	};
	
	// 메뉴 데이타 가져오
	this.getMenu = function() {
		return this.getData().menu;
	};
	
	// 백업 데이타 가져오기
	this.getBackup = function() {
		return this.getData().menubackup;
	};
	
	// 메뉴 등록여부
	this.findMenu = function(menu_id) {
		return (this.getMenu().toString().indexOf(menu_id) > -1);
	};

    this.getMenuId = function() {
        var page = $.mobile.activePage;
        var page_id = page.attr('id');
        var menu_item = page.find('[pageid="' + page_id + '"]');
        var menu_id = menu_item.attr('id');
        var title = page.find('.jqm-header h1').text();
        if( title == '통합조회' ) {
            menu_id = 'EM0101';
        } else if( title == '전화번호조회' ) {
            menu_id = 'EM0102';
        } else if( page_id =='GRCO001' || page_id =='CO00002' || page_id == 'REFN001' || page_id == 'GREM002' || page_id == 'GWWA001'){
            menu_id = page.data('menu_id');
            if( menu_id ) {
                menu_id = menu_id.replace('_', '');
            }
        }
        return menu_id;
    }
	
	// 백업 등록여부
	this.findBackup = function(menu_id) {
		return (this.getBackup().toString().indexOf(menu_id) > -1);
	};
	
	// 메뉴 추가
	this.insertMenu = function(menu_id) {
        //등록된 화면이 아닌경우
        if ( !this.findMenu(menu_id) ) {
            var data = this.getData();
            data.menu = data.menu + "," + menu_id;
            nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
        }
	};
	
	// 백업 추가
	this.insertBackup = function(menu_id) {
		var data = this.getData();
		data.menubackup = data.menubackup + "," + menu_id;
		nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};
	
	// 메뉴 삭제
	this.removeMenu = function(menu_id) {
		var data = this.getData();
		if (data.menu == menu_id) {
			data.menu = data.menu.replace(menu_id,"");
		} else if (data.menu.indexOf(menu_id) == 0) {
			data.menu = data.menu.replace(menu_id + ",", "");
		} else {
			data.menu = data.menu.replace("," + menu_id, "");
		}
		nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};
	
	// 백업 삭제
	this.removeBackup = function(menu_id) {
		var data = this.getData();
		if (data.menubackup == menu_id) {
			data.menubackup = data.menubackup.replace(menu_id,"");
		} else if (data.menubackup.indexOf(menu_id) == 0) {
			data.menubackup = data.menubackup.replace(menu_id + ",", "");
		} else {
			data.menubackup = data.menubackup.replace("," + menu_id, "");
		}
		nmf.Store.set(STORAGE_NAME, JSON.stringify(data));
	};

    this.reset = function() {
        nmf.Store.set(STORAGE_NAME, STORAGE_DATA);
    };

}).apply(DGB.MyMenu);