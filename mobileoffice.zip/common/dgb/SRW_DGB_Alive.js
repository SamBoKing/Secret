DGB.Alive = new function() {
    var me = this;

    // Interval Config
    var IS_ALIVE = false;
    var INTERVAL_COUNT = 12;
    var INTERVAL_TIME = 60000 * 5;

    var intervalCount = 0;
    var intervalId = -1;

    me.init = function() {
        var CONFIG = {};
        var OPTION = Messages.opt004;
        if( OPTION ) {
            CONFIG = JSON.parse(OPTION.replace(/'/g, '\"')) || {};
        }
        IS_ALIVE = CONFIG.alive;
        INTERVAL_COUNT = CONFIG.count || 12;
        INTERVAL_TIME = CONFIG.time || (60000 * 5);
    };

    me.start = function() {
        if( !IS_ALIVE ) return;

        me.end();
        intervalId = setInterval(alive, INTERVAL_TIME);
    };

    me.end = function() {
        clearInterval(intervalId);
        intervalCount = 0;
        intervalId = -1;
    };

    function alive() {
        if( ++intervalCount > INTERVAL_COUNT ) {
            me.end();
            return;
        }

        var inv = {
            adapter : 'ShareAdapter',
            procedure : 'ALIVE001',
            parameters : [{}]
        };
        callProcedure(inv);
    }
}();