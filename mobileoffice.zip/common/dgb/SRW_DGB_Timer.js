/**
 * Created with IntelliJ IDEA.
 * User: d320462
 * Date: 2013. 12. 23.
 * Time: 오후 1:35
 */
DGB.Timer = DGB.Timer || {};
(function(){
    // 임원회의, 부점자체연수, 동영상연수 예외처리
    var SKIP_PAGE_ID = [
        'REME001',
        'GRCO001',
        'LECT001',
        'LECT002',
        'LECT003',
        'LECT004',
        'DAMO001'
    ];

    var TIME_PAGE_ID = [
        // { 'id': 'freeSv', 'time' : 9 }
    ];

    var LIMIT = 60000;       // 타이머 시간
    var TIME_DEFAULT = 9;    // 기본 횟수 10분
    var initDefTime = false;

    var timer = null;
    var count = -1;
    var request = 0;

    var exitAlertShow = false;  // 종료팝업 발생여부
    var getHours = function() {
        return Math.round(Date.now() / (1000 * 60));
    };

    this.start = function() {
        count = -1;
        timer = setInterval(this.exec, LIMIT);
    };

    this.reset = function() {
        // 서버에서 받아온 시간으로 다시 설정
        if( !initDefTime ) {
            initDefTime = true;
            if( Messages && Messages.opt001 ) {
                try {
                    TIME_DEFAULT = parseInt(Messages.opt001);
                } catch (e) { }
            }
        }
        this.stop();
        this.start();
    };

    this.stop = function() {
        clearInterval(timer);
    };

    this.exec = function() {
        // timer counting
        count++;

        var time = TIME_DEFAULT;
        var pageid = $.mobile.activePage.attr('id');

        // time page checking
        for(var i in TIME_PAGE_ID){
            if(TIME_PAGE_ID[i].id == pageid) {
                time = TIME_PAGE_ID[i].time;
                break;
            }
        }

        if( time > count ) {
            return;
        }

        // skip page checking
        for(var i in SKIP_PAGE_ID) {
            if( SKIP_PAGE_ID[i] == pageid ){
                DGB.Timer.stop();
                return;
            }
        }

        // exit app
        if( DGB.isIPhone() || (time  < count) ) {
            DGB.Timer.exit();
        } else {
            DGB.Timer.confirm();
        }
    };

    this.confirm = function() {
        var me = this;
        if( DGB.isDebug() ) {
            // 사용안함
            //if( !confirm(Messages.msg210)  ) {
            //    DGB.Common.appExit();
            //}
        } else {
            var callback = function(btn) {
                if ( btn == '1' ) {
                    me.reset();
                    dummyProcedure();
                }
            };

            if( !exitAlertShow ) {
                // KJS수정
                showCusConfirm(callback, '알림', Messages.msg210, '연장,취소');
                // navigator.notification.confirm(Messages.msg210, callback, '알림', '연장, 취소');
            }
        }
    };

    this.exit = function() {
        this.stop();
        if( DGB.isDebug() ) {
            //alert(Messages.msg110);
            //DGB.Common.appExit();
        } else {
            var callback = function() {
                DGB.Common.appExit();
            };

            if(!exitAlertShow) {
                // KJS수정
                showCusConfirm(callback, '알림', Messages.msg110, '확인');
                // navigator.notification.confirm(Messages.msg110, callback, '알림', '확인');
            }
            exitAlertShow = true;
        }
    };

    this.getCheckTime = function() {
        var pageid = $.mobile.activePage.attr('id');
        for(var i in SKIP_PAGE_ID) {
            if( SKIP_PAGE_ID[i] == pageid ){
                return (TIME_DEFAULT + 1) * 6;
            }
        }
        return TIME_DEFAULT + 1;
    };

    this.getRequest = function() {
        if( request == 0 ) {
            this.setRequest();
        }
        return request;
    };

    this.setRequest = function() {
        request = getHours();
    };

    this.checkRequest = function() {
        var hours = getHours() - this.getRequest();
        var time = this.getCheckTime();
        if (hours >= time) {
            this.exit();
        } else {
            this.setRequest();
        }
    };

    // start timer event
    $(document).on('tap', function() {
        DGB.Timer.reset();
    });

}).apply(DGB.Timer);