DGB.HashMap = function(obj) {

    var map = (obj) ? cloneObject(obj) : new Object();

    /**
     * @public
     * @param key
     * @param value
     */
    this.put = function(key, value) {
        map[key] = value;
    };

    /**
     * @public
     * @param key
     * @return value
     */
    this.get = function(key) {
        return map[key];
    };

    /**
     * @public
     * @param key
     */
    this.remove = function(key) {
        if( map[key] ) {
            delete map[key];
        }
    };

    /**
     * @public
     * @return key array
     */
    this.keys = function() {
        var keys = [];
        for(var k in map) {
            keys.push(k);
        }
        return keys;
    };

    /**
     * @public
     * @return value array
     */
    this.values = function() {
        var values = [];
        for(var k in map) {
            values.push(map[k]);
        }
        return values;
    };

    /**
     * @public
     * @param key
     * @return boolean
     */
    this.containsKey = function(key) {
        return (map[key] != undefined);
    };

    /**
     * @public
     * @return boolean
     */
    this.isEmpty = function() {
        return (this.size() == 0);
    };

    /**
     * @public
     */
    this.clear = function() {
        for(var k in map)
            delete map[k];
    };

    /**
     * @public
     * @return map size
     */
    this.size = function() {
        var size = 0;
        for(var k in map) {
            size++;
        }
        return size;
    };

    /**
     * @public
     * @return map size
     */
    this.getObject = function() {
        return cloneObject(map);
    };

    /**
     * @private
     * @return object or json format object
     */
    var cloneObject = function(obj) {
        var cloneObj = {};
        for(var o in obj) {
            cloneObj[o] = obj[o];
        }
        return cloneObj;
    }
};