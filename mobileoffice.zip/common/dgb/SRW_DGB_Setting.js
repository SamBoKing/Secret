DGB.Setting = DGB.Setting || {};
(function() {
    var STORAGE_NAME = 'dgb.setting';

    this.Keys = {
        PushVibration : 'PushVibration'
    };

    var Items = [
        {
            key : this.Keys.PushVibration,
            def : {loop:2, vibe:500, stop:1000} //진동횟수,진동시간,쉬는시간
        }
    ];

    var Setting = { Settings: {} };

    // Private Function
    var save = function() {
        nmf.Store.set(STORAGE_NAME, JSON.stringify(Setting));
    };

    var reset = function() {
        for(var i in Items) {
            Setting.Settings[Items[i].key] = Items[i].def;
        }
    };

    // Public Function
    this.init = function() {
        var data = nmf.Store.get(STORAGE_NAME);
        if( !data ) {
            reset();
        } else {
            Setting = JSON.parse(data);
        }
    };

    this.get = function(key) {
        return Setting.Settings[key];
    };

    this.set = function(key, value) {
        Setting.Settings[key] = value;
        save();
    };

    this.remove = function(key) {
        for(var i in Items) {
            if( Items[i].key == key ) {
                Setting.Settings[Items[i].key] = Items[i].def;
            }
        }
        save();
    };

    this.clear = function() {
        reset();
        save();
    };
}).apply(DGB.Setting);