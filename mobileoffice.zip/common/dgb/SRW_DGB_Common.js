DGB.Common = {
	appExit: function() {
		DGB.Log.w("=========================");
		DGB.Log.w("    Application Exit     ");
		DGB.Log.w("=========================");

        if( !DGB.isDebug() ) {
            if( loginYN ) {
//                logoutUserUpdate();	//로그아웃시 접속자정보 업데이트
                userChallengeHandler.doLogout();
            }
        }

        if ( DGB.isAndroid() ) {
            AndroidNative.exitApp();
        } else if( DGB.isIPhone() ) {
            window.plugins.actionSheet.exitApp();
        } else {
            document.location.reload();
        }
	},

    hideKeyboard: function() {
        if( DGB.isAndroid() ) {
            AndroidNative.hideKeyboard();
        }

        var page = $.mobile.activePage;
        var page_id = page.attr('id');
        if(page_id == 'login'){
            $.mobile.activePage.find("input")[0].blur();
        }else{
            $.mobile.activePage.find("input").blur();
        }

    },

    isKeyboardShow: function() {
        if( DGB.isAndroid() ) {
            return AndroidNative.isKeyboardShowing();
        }
        return false;
    },

    refreshLayout: function(layout, time) {
        if( layout ) {
            layout.refreshLayout(time || 300);
        }
    },

    // 안드로이드 이벤트
    backMenu: function() {
        WL.App.overrideBackButton(function() {
            dgbLoading(false);

            if( DGB.Menu.isOpen('leftPanel') ) {
            	//종료 토스트 팝업
                var preTime = GLOBAL.EXIT_PRETIME || 0;
                var curTime = Date.now();
                var doExit = !((curTime - preTime) > 3500);
                if(doExit) {
                    AndroidNative.exitApp();
                } else {
                    GLOBAL.EXIT_PRETIME = Date.now();
                    WL.Toast.show(Messages.msg624);
                }
            } else {
                DGB.Menu.open('leftPanel');
            }
        });
    },

    backPage: function() {
        WL.App.overrideBackButton(function() {
            dgbLoading(false);
            DGB.Page.backPage();
        });
    },

    selectList: function(title, items, success, failure) {
        if ( DGB.isAndroid() ) {
            var list = [title];
            items.forEach(function(item) {
                list.push(item);
            });

            cordova.exec(
                function(idx) { success(idx - 1); }, // title - 1
                function(err) { failure(err); },
                "AlertList", "alertlist", list);
        } else if( DGB.isIPhone() ) {
            items.push('취 소');
            var cancelIndex = items.length - 1;
            var actionSheet = window.plugins.actionSheet;
            actionSheet.create({
                title : title,
                items : items,
                cancelButtonIndex : cancelIndex
            }, function(val, idx) {
                if( cancelIndex != idx )
                    success(idx);
            });
        } else {
            alert("title : " + title + "\n" + "items : " + items.join(','));
            success(0);
        }
    },

    userLevel : function(success, is_loading) {
        // Level 0 : 기기등록 안됨
        // Level 1 : 기기등록 됨, 사용자 정보 없음(퇴직자)
        // Level 2 : 정상 등록됨
        var inv = {
            adapter : 'DBCommonAdapter',
            procedure : 'doUserLevel',
            parameters : [{
                CONFIG : Messages.com002,
            	DEVC_NATV_NO : nmf.Store.get(MAC_ADDRESS),
                ENOB : DGB.Sms.get()
            }]
        };
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                var result = data.invocationResult;

                USER_INFO.LEVEL = result.level || 0;
                USER_INFO.MSG_COUNT = result.msg_count || 0;
                USER_INFO.MSG_COUNT2 = result.msg_count2 || 0;
                GLOBAL.HIDDEN_MENU = result.hidden_menu || '';
                GLOBAL.SAVE_ID = result.enob || '';
                GLOBAL.MAIN_BOARD = result.main_board || [];

                // 바이오인증에 사용할 최근 로그인 ID
                DGB.Fido.setEnob(DGB.Sms.get());

                // 숨김메뉴
                DGB.Common.hiddenMenu(GLOBAL.HIDDEN_MENU);

                if( USER_INFO.LEVEL == 1 ) {
                    showAlert(Messages.err002, Messages.err003, function() { DGB.Common.appExit(); });
                    return;
                }

                if( typeof success == 'function'){
                    success();
                }
            },
            onFailure : function(err) {
                dgbLoading(false);
                showAlert(Messages.err001 + '\n' + JSON.stringify(err));
            },
            invocationContext : {}
        };

        if( is_loading ) {
            dgbLoading(true);
        }
        callProcedure(inv, opt);
    },

    hiddenMenu : function(menu_data) {
        DGB.Menu.trigger('leftPanel', 'hideMenu', menu_data);
    },

    log : function(cs_id) {
        var inv = {
            adapter : 'DBCommonAdapter',
            procedure : 'doLog',
            parameters : [{
                CS_ID : cs_id,
                ENOB : USER_INFO.ENOB
            }]
        };
        callProcedure(inv, {});
    },

    isUnknownSource: function() {
        if( DGB.isAndroid() ) {
            // 한번만 체크
            var isUnkownSource = nmf.Store.get(UNKOWN_SOURCE);
            if ( isUnkownSource == 'CHECK' ) {
                return;
            }

            if( !Messages || !Messages.obj000 ) {
                DGB.Log.w("isUnknownSource is not Message class");
                return;
            }

            var obj = Messages.obj000.split("^");
            if( obj.length != 5 ) {
                DGB.Log.w("isUnknownSource is not Object");
                return;
            }

            if( obj[0] == 'true' ) {
                // title, message, button1, button2 : button2 == "" 경우 hide
                AndroidNative.isUnknownSource(obj[1], obj[2], obj[3], obj[4]);
            }
        }
    },

    // 네이티브에서 호출
    callBackUnKnownSource : function() {
        nmf.Store.set(UNKOWN_SOURCE, 'CHECK');
    },

    isAdminMember : function() {
        //002 : 임원 , 007: 관리자
        if( USER_INFO.GROUP_ID == "G002" || USER_INFO.GROUP_ID == "G007" )
            return true;

        try {
            var obj = JSON.parse(Messages.com004.replace(/'/g, '\"')) || {};
            if( !obj ) {
                DGB.Log.e("isAdminMember object is null");
                return false;
            }

            var user_work_org_cd = Number(USER_INFO.WORKORG_CD) || 0;
            var work_org_cds = obj.WORKORG_CDS || [];
            if( work_org_cds.indexOf(user_work_org_cd) == -1 ) {
                return false;
            }


            var user_level = Number((USER_INFO.JIKHO || '').substr(0, 1));
            var jikho_level = Number(obj.JIKHO_LEVEL || -1);
            if( !user_level || jikho_level == -1 || user_level > jikho_level ) {
                return false;
            }
            // alert(JSON.stringify(obj) + ", user_work_org_cd : " + user_work_org_cd + ", user_level : " +  user_level);
        } catch(e) {
            DGB.Log.e("isAdminMember Exception : " + e.message);
            return false;
        }
        return true;
    },

    openChatBot : function() {
        // 챗봇 데이터 삭제
        GLOBAL.CHATBOT = null;

        var CHAT_URL = Messages.url038 || '';
        var ip = (GLOBAL.NETWORK || {}).ipAddress || '';
        var enob = USER_INFO.ENOB || '';
        var param = {
            userId : enob,
            botCode : TEST_SERVER ? 'FWSFNBKQT2' : 'XR3A5K0KWM',
            ssoToken : DGB.Util.b64e(enob + ',' + ip),
            channel : 'MOBILE',
            agent : DGB.isAndroid() ? 'android' : 'iphone'
        };

        var url  = CHAT_URL + '?' + $.param(param);
        if( DGB.isAndroid() ) {
            AndroidNative.openChatBot(url);
        } else {
            WL.NativePage.show("ChatBotViewController", function (data) {
                DGB.Common.callbackChatBot(data.data);
            }, { url : url });
        }
    },

    callbackChatBot : function(data) {
        var obj = {};
        try {
            obj = JSON.parse( decodeURIComponent(data) ) || {};
        } catch (e) {
            DGB.Log.e('Exception - ' + JSON.stringify(e));
            DGB.msg('Exception : ' + JSON.stringify(e));
        }

        if( obj.error ) {
            var error = '페이지를 불러올수 없습니다. 잠시 후 다시 이용해 주시기 바랍니다.\n\nError Code[ ' + obj.error + ' ]';
            var description = obj.description ? (' : ' + obj.description) : '';
            showAlert(error + description);
            return;
        }

        if( obj.page ) {
            GLOBAL.CHATBOT = obj;
            DGB.Menu.trigger('leftPanel', 'click', obj.page);
        }
    }
};