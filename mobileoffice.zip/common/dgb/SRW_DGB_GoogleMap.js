DGB.GoogleMap = {};
(function() {
    this.MODE_VIEW = 0;
    this.MODE_EDIT = 1;

    var MESSAGE_TOKEN = ',';

    // Define Values
    var DEF_LAT = 35.8588106,   // 대구은행 본점 좌표
        DEF_LNG = 128.6156056,
        DEF_TILT = 0,           // 기울기
        DEF_ZOOM = 15,          // 크기
        DEF_BEARING = 0,        // 방향
        DEF_DURATION = 500;     // 지속시간

    // Map Object
    var _map;

    // User Object
    var _success;
    var _mode;

    // Marker Object
    var _marker;
    var _marker_temp;
    var marker_title = Messages.msg500;
    var marker_snippet = Messages.msg501;
    var marker_snippet_default = Messages.msg502;
    var marker_snippet_loading = Messages.msg503;
    var marker_error1 = Messages.msg504;
    var marker_error2 = Messages.msg505;

    // Input Dialog
    var dlg_title = Messages.msg506;
    var dlg_btn_text1 = Messages.msg507;
    var dlg_btn_text2 = Messages.msg508;
    var dlg_message = Messages.msg509;
    var dlg_msg_err1 = Messages.msg511;

    // Search Dialog
    var search_title = Messages.msg517;
    var search_message = Messages.msg518;
    var search_error1 = Messages.msg519;

    this.init = function() {
        _map = plugin.google.maps.Map.getMap({
            'controls':{
                'myLocationButton' : true
            },
            'camera': {
                'latLng': new plugin.google.maps.LatLng(DEF_LAT, DEF_LNG),
                'zoom': DEF_ZOOM,
                'tilt': DEF_TILT,
                'bearing': DEF_BEARING
            }
        });

        if( _map ) {
            _map.addEventListener(plugin.google.maps.event.MAP_READY, ready);
        } else {
            DGB.Log.e('[DGB.GoogleMap] == > init is not found map');
        }
        //안드로이드, IOS GPS 설정 문구 다름.
        marker_error1 = DGB.isAndroid() ? Messages.msg504 : Messages.msg523;
    };

    var ready = function() {
        _map.on(plugin.google.maps.event.MAP_CLICK, mapClick);
        _map.on(plugin.google.maps.event.MY_LOCATION_BUTTON_CLICK, myLocationClick);
        _map.on(plugin.google.maps.event.BUTTON1_CLICK, button1Click);
        _map.on(plugin.google.maps.event.BUTTON2_CLICK, button2Click);
        _map.on(plugin.google.maps.event.BUTTON3_CLICK, button3Click);
    };

    var mapClick = function(latlng) {
        switch( _mode ) {
            case DGB.GoogleMap.MODE_VIEW:
                break;
            case DGB.GoogleMap.MODE_EDIT:
                DGB.GoogleMap.marker({
                    position :latlng,
                    title : marker_title,
                    snippet : marker_snippet
                });
                break;
            default:
                DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap default mode');
                break;
        }
    };

    var myLocationClick = function() {
        switch( _mode ) {
            case DGB.GoogleMap.MODE_VIEW:
                break;
            case DGB.GoogleMap.MODE_EDIT:
                _map.getMyLocation(function(location) {
                    if( location.latLng.lat == 0 || location.latLng.lng == 0 ) {
                        if( _marker ) _marker.remove();
                        _marker = null;
                        showAlert(marker_error1);
                    }
                });
                break;
            default:
                DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap default mode');
                break;
        }
    };

    var button1Click = function() {
        switch( _mode ) {
            case DGB.GoogleMap.MODE_VIEW:
                if( _marker ) {
                    _map.animateCamera({
                        'target': _marker.getLatLng(),
                        'duration': DEF_DURATION
                    }, function() {});
                } else {
                    showAlert(Messages.msg511);
                }
                break;
            case DGB.GoogleMap.MODE_EDIT:
                navigator.notification.prompt(
                    search_message,
                    function(obj) {
                        if( obj.buttonIndex == 1 ) {
                            var text = obj.input1;
                            if( text.indexOf(' ') == 0 ) {
                                text = text.replace(' ','');
                            }

                            if( text.length < 2 ) {
                                showAlert(search_error1);
                                return;
                            }
                            searchList(text);
                        }
                    },
                    search_title, ['검 색', '닫 기'], ' '
                );
                break;
            default:
                DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap default mode');
                break;
        }
    };

    var button2Click = function() {
    };

    var button3Click = function() {
        DGB.GoogleMap.close();
    }

    var searchList = function(address) {
        searchAddrToGeo(address, function(results) {
            var markers = parserResultToMarkers(results);
            if( !markers.length ) {
                showAlert(Messages.msg521);
                return;
            }

            var titles = [];
            for(var i = 0; i < markers.length; i++) {
                titles.push(markers[i].title);
            }

            DGB.Common.selectList('[' + address + '] 검색결과 - ' + markers.length + '건',
                titles,
                function(index) {
                    DGB.GoogleMap.marker(markers[index]);
                },
                function() { }
            );
        });
    };

    var parserResultToMarkers = function(results) {
        if( !results || results.length == 0 )
            return [];

        var list = [];
        for(var i = 0; i < results.length; i++) {
            var result = results[i];
            list.push({
                position  : new plugin.google.maps.LatLng(
                    result.geometry.location.lat,
                    result.geometry.location.lng
                ),
                title : parserResultToAddress(result),
                snippet : marker_snippet
            });
        }
        return list;
    };

    var parserResultToAddress = function(result) {
        if( !result )
            return '';

        return result.formatted_address.replace('대한민국 ', '');
    };

    var searchGeoToAddr = function(lat, lng, success, failure) {
        /*
        var request = {
            position : new plugin.google.maps.LatLng(lat, lng)
        };
        _map.geocode(request, function(results) {
            if( results.length ) {
                if( success && success instanceof Function ) {
                    var title = results[0].thoroughfare.replace('대한민국 ', '');
                    success(title);
                }
            } else {
                if( failure && failure instanceof Function )
                    failure();
            }
        });
        */

        $.ajax({
            url : 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + lng + '&sensor=false&language=ko',
            dataType : 'json',
            timeout: 3000,
            success : function(data) {
                var status = googleStatusMessage(data.status);
                if( status ) {
                    showAlert(status);
                    return;
                }

                var address = parserResultToAddress(data.results[0]);
                if( address && success && typeof success == 'function' ) {
                    success(address);
                } else if( failure && typeof failure == 'function' ) {
                    failure();
                }
            },
            error : function() {
                if( failure && typeof failure == 'function' )
                    failure();
            }
        });
    };



    var searchAddrToGeo = function(address, success) {
        /*
        var request = {
            address : address
        };
        _map.geocode(request, function(results) {
            success(results);
        });
        */

        $.ajax({
            url : 'http://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURI(address) + '&sensor=false&language=ko',
            dataType : 'json',
            timeout: 3000,
            success : function(data) {
                var status = googleStatusMessage(data.status);
                if( status ) {
                    showAlert(status);
                    return;
                }

                if( data.results && data.results.length ) {
                    if( success && typeof success == 'function' )
                        success(data.results);
                } else {
                    showAlert(Messages.msg521);
                }
            },
            error : function() {
                showAlert(Messages.msg520);
            }
        });
    };

    var googleStatusMessage = function(status) {
        var message = '';
        switch( status ) {
            case 'OK':
                break;
            case 'ZERO_RESULTS':
                message = '반환된 결과가 없습니다.';
                break;
            case 'OVER_QUERY_LIMIT':
                message = '조회 활당량을 초과하였습니다.';
                break;
            case 'REQUEST_DENIED':
                message = '요청이 거부 되었습니다.';
                break;
            case 'INVALID_REQUEST':
                message = '요청 쿼리가 잘못되었습니다.';
                break;
            default:
                message = '알수 없는 오류가 발생하였습니다.';
                break;
        }
        return message;
    };

    this.marker = function(add_marker) {
        if( _marker ) {
            if(add_marker.position.lat == _marker.getLatLng().lat &&
                add_marker.position.lng == _marker.getLatLng().lng) {
                _map.animateCamera({
                    'target': add_marker.position,
                    'duration': DEF_DURATION
                }, function() {});
                return;
            }
        }

        // 타이틀 유지
        if( _marker_temp ) add_marker.title = _marker_temp.getTitle();

        _map.addMarker(add_marker, function(marker) {
            if( _marker ) _marker.remove();
            _marker = marker;

            _map.animateCamera({
                'target': add_marker.position,
                'duration': DEF_DURATION
            }, function() {
                marker.hideInfoWindow();
                marker.showInfoWindow();
                marker.addEventListener(plugin.google.maps.event.INFO_CLICK, markerClick);
            });
        });
    };

    this.defaultMarker = function() {
        if( !_map ) {
            DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap defaultMarker not found map!!!!');
            return;
        }

        _marker_temp = null;
        _map.getMyLocation(function(location) {
            if( location.latLng.lat == 0 || location.latLng.lng == 0 ) {
                if( _marker ) _marker.remove();
                _marker = null;

                showAlert(marker_error1);
            } else {
                DGB.GoogleMap.marker({
                    'position': location.latLng,
                    'title': marker_title,
                    'snippet': marker_snippet
                });
            }
        });
    };

    var markerClickNShow = function(){
        if( !_marker ){
            DGB.Log.e('[DGB.GoogleMap] ==> markerClickNShow marker is not found');
            return;
        }
        showAlert("위치알림", _marker.getTitle() + "\n\n주소 : " + _marker.getSnippet());
    };

    var markerClick = function() {
        switch( _mode ) {
            case DGB.GoogleMap.MODE_VIEW:
                var snippet = _marker.getSnippet();
                if( snippet && snippet != marker_error2 && snippet != marker_snippet_default ) {
                    markerClickNShow();
                    return;
                }

                _marker.setSnippet(marker_snippet_loading);
                _marker.hideInfoWindow();
                _marker.showInfoWindow();
                var latLng = _marker.getLatLng();
                searchGeoToAddr(latLng.lat, latLng.lng,
                    function(address) {
                        _marker.setSnippet(address);
                        _marker.hideInfoWindow();
                        _marker.showInfoWindow();
                        markerClickNShow();
                    },
                    function() {
                        _marker.setSnippet(marker_error2);
                        _marker.hideInfoWindow();
                        _marker.showInfoWindow();
                        markerClickNShow();
                    }
                );
                break;
            case DGB.GoogleMap.MODE_EDIT:
                navigator.notification.prompt(
                    dlg_message,
                    function(obj) {
                        if( obj.buttonIndex == 1 ) {
                            if( !obj.input1.length || obj.input1 == ' ' ) {
                                showAlert(dlg_msg_err1);
                                return;
                            }

                            if( _success && _success instanceof Function) {
                                _marker.setTitle(obj.input1);
                                _marker.hideInfoWindow();
                                _marker.showInfoWindow();
                                _marker_temp = _marker;
                                _success(_marker);
                            }
                        }
                    },
                    dlg_title, [dlg_btn_text1, dlg_btn_text2],
                    _marker_temp ? _marker_temp.getTitle() : ' '
                );
                break;
            default:
                DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap default mode');
                break;
        }
    };

    this.show = function() {
        if( !_map ) {
            DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap show not found map!!!!');
            return;
        }

        var buttons = {};
        switch( _mode ) {
            case DGB.GoogleMap.MODE_EDIT:
                buttons = {
                    'buttons' : {
                        'button1' : '검 색',
                        'button3' : '닫 기'
                    }
                };
                break;
            case DGB.GoogleMap.MODE_VIEW:
                buttons = {
                    'buttons' : {
                        'button1' : '위 치',
                        'button3' : '닫 기'
                    }
                };
                break;
        }
        _map.showDialog(buttons);
    };

    this.close = function() {
        if( !_map ) {
            DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap close not found map!!!!');
            return;
        }
        _map.closeDialog();
    };

    this.use = function(mode, success) {
        if( !_map ) {
            DGB.Log.e('[DGB.GoogleMap] ==> GoogleMap use not found map!!!!');
            return;
        }
        _mode = mode;
        _success = success;
    };

    this.getLatLng = function(lat, lng){
        return new plugin.google.maps.LatLng(lat, lng);
    };

    this.getMsgToMarker = function(title, latLng){
        var me = this;
        var items = latLng.split(MESSAGE_TOKEN);
        if( items.length != 2 ) {
            DGB.Log.e('[DGB.GoogleMap] ==> getMsgToMarker item is error : ' + latLng);
            return null;
        }

        return  {
            'position': me.getLatLng(items[0], items[1]),
            'title': title,
            'snippet': marker_snippet_default
        }
    };

    this.getMarkerToMsg = function(marker) {
        if( !marker ) {
            DGB.Log.e('[DGB.GoogleMap] ==> getMarkerToMsg marker is not found');
            return '';
        }

        var latLng = marker.getLatLng();
        return [latLng.lat, latLng.lng].join(MESSAGE_TOKEN);
    };

    this.clear = function() {
        if( _marker ) _marker.remove();
        _marker = null;
        _marker_temp = null;
    };

    this.viewMarker = function(push_cn, link_url) {
        var marker = DGB.GoogleMap.getMsgToMarker(push_cn, link_url);
        if(!marker) {
            showAlert(Messages.msg511);
            return;
        }
        DGB.GoogleMap.clear();
        DGB.GoogleMap.use(DGB.GoogleMap.MODE_VIEW, null);
        DGB.GoogleMap.show();
        DGB.GoogleMap.marker(marker);
    };
}).apply(DGB.GoogleMap);
