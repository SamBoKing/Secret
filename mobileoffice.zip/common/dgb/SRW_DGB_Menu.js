DGB.Menu = DGB.Menu || {};
(function() {
    // 전체 메뉴 정보
    var _menus = {};
    var _page = {};               // 이전 페이지
    var _use_swipe = false;

    /**
     * 메뉴 초기화 작업
     */
    this.init = function() {
        this.swipeInit();
        this.loadMenu();
    };

    /**
     * 사용하는 메뉴 로드
     */
    this.loadMenu = function() {
        var me = this;
        $.ajax({
            url: 'config/SRW_DGB_Menu.json',
            dataType: 'json',
            async: false,
            success: function(menus) {
                _menus = menus;
                me.loadTemplate("html", "html");
                me.loadTemplate("js", "script");
            },
            error: function() {
                DGB.Log.e("[DGB.Menu] ====>> JSON File Load Failed - Url : " + this.url);
            }
        });
    };

    /**
     * 스와이프 커스텀 이벤트 초기화
     */
    this.swipeInit = function() {
        // var SWIPE_EVENT_OFFSET = 70;
        // $.event.special.swipe.durationThreshold = 1000;             // More time than this, and it isn't a swipe.
        // $.event.special.swipe.horizontalDistanceThreshold = 40;     // Swipe horizontal displacement must be more than this.
        // $.event.special.swipe.verticalDistanceThreshold = 20;       // Swipe vertical displacement must be less than this.

        $.event.special.swipe.handleSwipe = function( start, stop ) {
            if ( stop.time - start.time < $.event.special.swipe.durationThreshold &&
                Math.abs( start.coords[0] - stop.coords[0] ) > $.event.special.swipe.horizontalDistanceThreshold &&
                Math.abs( start.coords[1] - stop.coords[1] ) < $.event.special.swipe.verticalDistanceThreshold ) {


                // Custom Swipe Event Check
                // Check if the panel is closed first
                // var panelFinish = $.mobile.activePage.jqmData( "finish" );
//                if (panelClosed && start.coords[0] > SWIPE_EVENT_OFFSET && start.coords[0] < $(window).innerWidth()-SWIPE_EVENT_OFFSET) {
//                    return;
//                }
                start.origin.trigger("swipe").trigger(start.coords[0] > stop.coords[0] ? "swipeleft" : "swiperight");
            }
        };
    };

    /**
     * 템플릿 페이지 로드
     */
    this.loadTemplate = function(type, dataType) {
        for(var i in _menus) {
            var menu = _menus[i];
            $.ajax({
                url: menu.template + "." + type,
                dataType: dataType,
                async: false,
                success: function(html) {
                    if( type == 'html' ) {
                        var panel = $('<div>').attr({
                            'id': menu.id,
                            'data-role': 'panel',
                            'data-display': menu.display,
                            'data-position': menu.position
                        });
                        menu.panel = panel.html(html);
                    } else if( type == 'js' ) {
                        menu.delegate = eval(menu.listener);
                        if( !menu.delegate ) {
                            DGB.Log.e('[DGB.Menu] ====>> Menu delegate undefined - listener : ' + menu.listener);
                        }
                    }
                    DGB.Log.d('[DGB.Menu] ====>> Menu Template File Load success - Url : ' + this.url);
                },
                error: function() {
                    DGB.Log.e('[DGB.Menu] ====>> Menu Template File Load Failed - Url : ' + this.url);
                }
            });
        }
    };


    /**
     * 메뉴사용
     */
    this.use = function(menu_list, use) {
        // 현재페이지 정보
        var page = $.mobile.activePage;

        // 화면변경시 화면에서 사용하는 메뉴정보 초기화
        if( page === _page ) {
            DGB.Log.e("[DGB.Menu] ====>>  use :: this page == prev page");
            return;
        }

        // 페이지 정보 초기화
        this.reset();
        for(var i in menu_list) {
            // 메뉴 찾기
            var menu = this.find(menu_list[i]);
            if( menu && menu.panel ) {
                menu.panel.appendTo(page).panel()
                    .off('panelclose').on('panelclose', menu.delegate.close);

                menu.use = use;

                // 메뉴 이벤트 등록
                menu.delegate.init(menu.panel);

                // 메뉴 관련 초기화 작업
                if( !menu.init ) {
                    menu.init = true;
                    menu.iscroll = [];

                    // 스크롤 정보 초기화(document 정보를 넘겨줘야함)
                    var wrapper = menu.panel.find('.' + menu.wrapper);
                    for(var i = 0; i < wrapper.length; i++) {
                        menu.iscroll.push(new iScroll(wrapper[i], {
                            hScroll:false,
                            vScrollbar:false,
                            bounce:true,
                            momentum:true
                        }));
                    }
                }
            } else {
                DGB.Log.e("[DGB.Menu] ====>>  use :: menu or panel were not found [menu id : " + menu_list[i]);
            }
        }

        if( menu_list.length > 0 ) {
            // 스와이프 화면 스크롤 핸들러( 스와이프 사용안함 )
            _use_swipe = false;
            // this.swipeHandler(page);
            // 현재 사용하는 페이지 아이디 저장
            _page = page;
        }
    };

    /**
     * 화면 스크롤에 대한 이벤트 정의
     * 메뉴들중에 사용하고 있는 처음에 등록된 메뉴만 이벤트 적용
     * @param me
     * @param page_id
     */
    this.swipeHandler = function(page) {
        var me = this;
        page.off('swiperight swipeleft').on({
            'swiperight':function(e) {
                if( !_use_swipe ) return;

                if( $.mobile.activePage.jqmData( "finish" ) == 'open' ) {
                    for(var i in _menus) {
                        if( _menus[i].use && _menus[i].position == 'right' ) {
                            me.close(_menus[i].id);
                            return;
                        }
                    }
                    return;
                }

                for(var i in _menus) {
                    if(_menus[i].use && _menus[i].position == 'left' ) {
                        me.toggle(_menus[i].id);
                        return;
                    }
                }
            },
            'swipeleft':function(e) {
                if( !_use_swipe ) return;

                if( $.mobile.activePage.jqmData( "finish" ) == 'open' ) {
                    for(var i in _menus) {
                        if( _menus[i].use && _menus[i].position == 'left' ) {
                            me.close(_menus[i].id);
                            return;
                        }
                    }
                    return;
                }

                for(var i in _menus) {
                    if(_menus[i].use && _menus[i].position == 'right' ) {
                        me.toggle(_menus[i].id);
                        return;
                    }
                }
            }
        });
    };

    /**
     * 스크롤 사이즈 변경
     * @param menu
     */
    this.refreshHeight = function(menu) {
        var win = $(window);
        var header = menu.panel.find('#' + menu.header);

        var WH = win.innerHeight();
        var HH = header.outerHeight(true);
        var height = WH - HH;

        var wrapper = menu.panel.find("." + menu.wrapper);
        wrapper.css("height", height + "px");
    };


    /**
     * 메뉴 열기
     * @param menu_id
     */
    this.open = function(menu_id) {
        var me = this;
        if( $.mobile.activePage == _page ) {
            var showing = DGB.Common.isKeyboardShow();
            DGB.Common.hideKeyboard();

            var menu = this.find(menu_id);
            if( menu && menu.panel && menu.use ) {
                if( showing ) {
                    setTimeout(function(){
                        me.refreshHeight(menu);
                        menu.panel.panel('open');
                        for(var i in menu.iscroll ) {
                            menu.iscroll[i].refresh();
                        }
                    }, 350);
                } else {
                    me.refreshHeight(menu);
                    menu.panel.panel('open');
                    for(var i in menu.iscroll ) {
                        menu.iscroll[i].refresh();
                    }
                }
            } else {
                DGB.Log.e("[DGB.Menu] ====>> open :: the menu panel was not found! - [menu_id : " + menu_id + "]");
            }
        }
    };

    /**
     * 메뉴 닫기
     * @param menu_id
     */
    this.close = function(menu_id) {
        if( $.mobile.activePage == _page ) {
            var menu = this.find(menu_id);
            if( menu && menu.use ) {
                menu.panel.panel('close');
            } else {
                DGB.Log.e("[DGB.Menu] ====>> close :: the menu panel was not found! - [menu_id : " + menu_id + "]");
            }
        }
    };

    /**
     * 메뉴 토글
     * @param menu_id
     */
    this.toggle = function(menu_id) {
        if( this.isOpen(menu_id) ) {
            this.close(menu_id);
        } else {
            this.open(menu_id);
        }
    };

    /**
     * 메뉴 이벤트 핸들러에 강제 이벤트 발생
     * @param menu_id
     * @param event
     * @param args
     */
    this.trigger = function(menu_id, event, args) {
        var returnValue = undefined;
        var menu = this.find(menu_id);
        if ( menu ) {
            var fn = undefined;
            switch( event ) {
                case 'reload':
                    fn = menu.delegate.reload;
                    break;
                case 'getRejectedMenuId':
                    fn = menu.delegate.getRejectedMenuId;
                    break;
                case 'updateBadge':
                    fn = menu.delegate.updateBadge;
                    break;
                case 'location':
                    fn = menu.delegate.location;
                    break;
                case 'updateAuth':
                    fn = menu.delegate.updateAuth;
                    break;
                case 'EMail.update':
                    fn = menu.delegate.EMail.update;
                    break;
                case 'updateProfile':
                    fn = menu.delegate.updateProfile;
                    break;
                case 'connectEzJob':
                    fn = menu.delegate.connectEzJob;
                    break;
                case 'click':
                    fn = menu.delegate.click;
                    break;
                case 'clickPopup':
                    fn = menu.delegate.clickPopup;
                    break;
                case 'hideMenu':
                    fn = menu.delegate.hideMenu;
                    break;
            }
            return (typeof fn == 'function') ? fn(menu.panel, args) : undefined;
        } else {
        	DGB.Log.e("[DGB.Menu] ====>> trigger :: the menu panel was not found! - [menu_id : " + menu_id + "]");
        }
        return returnValue;
    };

    /**
     * 메뉴 패널 새로고침
     */
    this.refresh = function() {
        for(var i in _menus) {
            if(_menus[i].use && _menus[i].panel.hasClass("ui-panel-open") ) {
                this.refreshHeight(_menus[i]);
                for(var j in _menus[i].iscroll) {
                    _menus[i].iscroll[j].refresh();
                }
                return;
            }
        }
    };

    /**
     * 메뉴 열림 상태 여부
     * @param menu_id
     * @returns {boolean}
     */
    this.isOpen = function(menu_id) {
        var menu = this.find(menu_id);
        if( menu && menu.panel.hasClass("ui-panel-open") ) {
            return true;
        }
        return false;
    }


    /**
     * 패널 이벤트 콜백 등록
     * @param menu_id
     * @param event
     * @param callback
     */
    this.callback = function(menu_id, event, callback) {
        var menu = this.find(menu_id);
        if( menu && menu.panel ) {
            menu.panel.on(event, callback);
        } else {
            DGB.Log.e("[DGB.Menu] ====>> callback :: the menu panel was not found! - [menu_id : " + menu_id + "]");
        }
    };

    /**
     * 로드된 메뉴정보를 리턴한다.
     * @param menu_id
     * @returns menu object
     */
    this.find = function(menu_id) {
        for(var i in _menus) {
            if ( _menus[i].id == menu_id ) {
                return _menus[i];
            }
        }
        return undefined;
    };

    /**
     *  메뉴정보 사용여부를 초기화한다.
     */
    this.reset = function() {
        for(var i in _menus) {
            // 패널이 다 붙음
            // if( _menus[i].use ) {
                _menus[i].panel.remove();
            // }
            _menus[i].use = false;
        }
        _use_swipe = false;
    };

    /**
     *  스와이프 사용 여부 셋팅
     */
    this.useSwipe = function(use) {
        _use_swipe = use;
    };

    this.scrollTo = function(menu_id, el) {
        var menu = this.find(menu_id);
        if( menu && menu.panel ) {
            if (el.size() > 1) {
                throw new Error("Cannot be a node!");
            }

            if( menu.iscroll ){
                var index = menu.iscroll.length - 1;
                var top = el.position().top * -1;
                menu.iscroll[index].useAnimateY = false;
                menu.iscroll[index].scrollTo(0, top, 1000);
                setTimeout(function() {
                    menu.iscroll[index].useAnimateY = true;
                }, 1000);
                menu.iscroll[index].refresh();
            }
        } else {
            DGB.Log.e("[DGB.Menu] ====>> scrollTo :: the menu panel was not found! - [menu_id : " + menu_id + "]");
        }
    };
}).apply(DGB.Menu);