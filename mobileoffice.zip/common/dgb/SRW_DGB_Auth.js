// 인증 관련 클래스.
DGB.Auth = DGB.Auth || {};

DGB.Auth.Level = {
	ID : 'OnlyIDPass',
	Pass : 'PasswordPass',
	Sms : 'SmsPass',
	Bio : 'BioPass',
	Nfc : 'NfcPass'
};

DGB.Auth.Step = {};
(function() {
	
    var backup = {};
    var process = [];
	var is_login = false;
    
    this.init = function() {
    	DGB.Log.d("[DGB.Auth.Step] ==>> init");
    	
    	var me = this;
		backup = {};
		process = [];

		me.add(DGB.Auth.Level.ID, DGB.Auth.AppIron.call);
    	me.add(DGB.Auth.Level.ID, DGB.Auth.OnlyID.call);
    	me.add(DGB.Auth.Level.ID, DGB.Auth.WorkLight.call);
    	me.add(DGB.Auth.Level.ID, DGB.Auth.User.call);
		me.add(DGB.Auth.Level.ID, DGB.Auth.Sms.check);

		me.add(DGB.Auth.Level.Pass, DGB.Auth.AppIron.call);
    	me.add(DGB.Auth.Level.Pass, DGB.Auth.Sso.call);
    	me.add(DGB.Auth.Level.Pass, DGB.Auth.WorkLight.call);
    	me.add(DGB.Auth.Level.Pass, DGB.Auth.User.call);
		me.add(DGB.Auth.Level.Pass, DGB.Auth.Sms.check);

		me.add(DGB.Auth.Level.Sms, DGB.Auth.AppIron.call);
        me.add(DGB.Auth.Level.Sms, DGB.Auth.Sso.call);
        me.add(DGB.Auth.Level.Sms, DGB.Auth.WorkLight.call);
        me.add(DGB.Auth.Level.Sms, DGB.Auth.User.call);
		me.add(DGB.Auth.Level.Sms, DGB.Auth.Sms.call);

		me.add(DGB.Auth.Level.Bio, DGB.Auth.AppIron.call);
		me.add(DGB.Auth.Level.Bio, DGB.Auth.Bio.call);
		me.add(DGB.Auth.Level.Bio, DGB.Auth.WorkLight.call);
		me.add(DGB.Auth.Level.Bio, DGB.Auth.User.call);

		me.add(DGB.Auth.Level.Nfc, DGB.Auth.AppIron.call);
		me.add(DGB.Auth.Level.Nfc, DGB.Auth.Nfc.call);
		me.add(DGB.Auth.Level.Nfc, DGB.Auth.WorkLight.call);
		me.add(DGB.Auth.Level.Nfc, DGB.Auth.User.call);
    };

    this.add = function(level, callback) {
        process.push({use:false, callback: callback, level: level});
    };

	this.check = function() {
		if( is_login ) {
			$.each(process, function (i) {
				process[i].use = false;
			});
			is_login = false;
			return false;
		} else {
			return true;
		}
	};

    this.exec = function() {
        for(var i = 0; i < process.length; i++) {
            var proc = process[i];
            if( proc.level == backup.level && !proc.use ) {
            	backup.callback = proc.callback;
            	backup.callback();
                return;
            }
        }

        if( typeof backup.result == "function" ) {
        	backup.result();
			is_login = true;
        }
    };

    this.call = function(level, result) {
        // BackUp
        backup.level = level;
        backup.result = result;
        this.exec();
    };

    this.use = function() {
        for(var i = 0; i < process.length; i++) {
        	var proc = process[i];
            if( proc.callback == backup.callback ) {
            	proc.use = true;
                if( proc.level == backup.level ) {
                	setTimeout(this.exec, 100);
                }
            }
        }
    };
}).apply(DGB.Auth.Step);


/**
 * 앱위변조 확인
 */
DGB.Auth.AppIron = {
	URL1 : 'http://mbanking.dgb.co.kr:8030/authCheck.call',
	URL2 : 'http://mbanking.dgb.co.kr:8030/authDoubleCheck.jsp',
	ERROR : {
		'0000' : 'Transaction is complete.',
		'1100' : 'Network Error',
		'1101' : 'CURL Library Init Error',
		'1102' : 'Couldn’t Resolve Host',
		'1103' : 'Couldn’t Connect to Server',
		'1105' : 'Server Response Timeout',
		'2001' : 'Client Key Init Error.',
		'2004' : 'Server Response SESSION ID is Empty',
		'2005' : 'Server Response PROTOCOL Error(BASE64 DECODE)',
		'2006' : 'Server Response SESSION ID is Empty',
		'2007' : 'Key Final Error',
		'3002' : 'Server Response PROTOCOL Error(Decrypt)',
		'3003' : 'Server Response Nonce is Empty',
		'3004' : 'Server Response ENC ID is Empty',
		'3005' : 'Server Response ENC ID value is not supported',
		'3006' : 'Server Response authType is Empty',
		'3007' : 'Server Response authType value is not supported',
		'3008' : 'Server Response skipYn is Empty',
		'3009' : 'Server Response skipYn value is not supported',
		'3010' : 'Server Response hashTarget is Empty',
		'3011' : 'Server Response hashTarget value is not supported',
		'3012' : 'Server Response abendYn is Empty',
		'3013' : 'Server Response abendYn value is not supported',
		'5003' : 'Server Response Token is Empty',
		'5101' : 'authValue is null.(AppMac)',
		'6000' : 'request parameter Error.',
		'6001' : 'request pattern Error.',
		'6002' : 'opcode Error.',
		'6500' : 'data pattern Error.',
		'6600' : 'not found session id Error',
		'6601' : 'session expired Error',
		'6602' : 'castoff session id Error',
		'6900' : 'Core Library Error',
		'8000' : 'not found app',
		'8001' : 'missmatched app Error',
		'9000' : 'Detect simulator device',
		'9001' : 'Detect faked app',
		'9002' : 'Detect rooting device',
		'9003' : 'Detect faked lib',
		'9004' : 'Detect black app',
		'9998' : 'not supported method.',
		'9999' : 'Unknown Error.'
	},
	init : function() {
		DGB.Auth.AppIron.auth(
			true,
			function() { DGB.Log.i('DGB AppIron Init Success!'); },
			function(msg) {
				showAlert('알림', msg, function() {
					DGB.Common.appExit();
					return false;
				});
			}
		);
	},
	call : function() {
		dgbLoading(true);
		DGB.Auth.AppIron.auth(
			false,
			function() { DGB.Log.i('DGB AppIron Call Success!'); },
			function(msg) {
				dgbLoading(false);
				showAlert('알림', msg, function() {
					DGB.Common.appExit();
					return false;
				});
			}
		);
	},
	auth : function(init, success, error) {
		// 앱위변조 체크 여부
		if( Messages.opt006 != 'true' ) {
			DGB.Log.i('DGB AppIron Skip!');
			if( !init ) { DGB.Auth.Step.use(); }
			return;
		}

		var me = DGB.Auth.AppIron;
		window.plugins.AppIron.auth(
			function(result) {
				if( DGB.isDebug() ) {
					DGB.Log.d('AppIron - Result : ' + JSON.stringify(result));
				}

				if( result.code == '0000' ) {
					if( !result.session || !result.token ) {
						error('앱위변조 인증 에러메시지 : 요청정보가 올바르지 않습니다. 확인 후 다시 이용해 주시기 바랍니다.');
						return;
					}

					if( success ) { success(); }
					if( !init ) {
						me.exec(result.session, result.token);
					}
				} else if( error ) {
					var opt = JSON.parse((Messages.opt007 || '').replace(/'/g, '\"')) || {};
					var skip = opt.skip || [];
					for(var i in skip) {
						if( skip[i] && result.code == skip[i] ) {
							DGB.Log.e('DGB AppIron Error Skip! : ' + result.code);
							if( !init ) { DGB.Auth.Step.use(); }

							var inv = {
								adapter : 'ShareAdapter',
								procedure : 'LOG',
								parameters : [{
									MSG : 'DGB AppIron Error Skip! : ' + result.code,
									ENOB : GLOBAL.ENOB
								}]
							};
							callProcedure(inv, {});
							return;
						}
					}
					var err = (me.ERROR[result.code] + '(Code : ' + result.code + ')')  || ('알수없는 오류 : ' + JSON.stringify(result));
					error('앱위변조 인증 에러메시지 : ' + err);
				}
			}, error, me.URL1);
	},
	exec: function(session, token) {
		var inv = {
			adapter : 'AppIronAdapter',
			procedure : 'APP0001',
			parameters : [session, token]
		};
		var opt = {
			onSuccess : DGB.Auth.AppIron.onSuccess,
			onFailure : DGB.Auth.AppIron.onFailure,
			invocationContext : {}
		};

		setTimeout(function() {
			callProcedure(inv, opt);
		}, 200);
	},
	onSuccess: function(data) {
		dgbLoading(false);
		var result = data.invocationResult;
		if( result.success ) {
			DGB.Auth.Step.use();
		} else {
			var msg = DGB.Auth.AppIron.ERROR[result.code] || result.msg || '알수없는 오류';
			showAlert('알림', '앱위변조 인증 에러메시지 : ' + msg, function() {
				DGB.Common.appExit();
				return false;
			});
		}
	},

	onFailure: function(err) {
		dgbLoading(false);
		showAlert(Messages.msg002 + "\nError : " + JSON.stringify(err));
	}
};

/**
 * WorkLight 통신.
 */
DGB.Auth.WorkLight = {
	CODE_TOKEN: 'CODE_RESPONSE_TOKEN',
	CODE_CMD : 'CODE_RESPONSE_CMD',
	
	/**
	 * 인증서 RA DB 인증
	 * 앱위변조 방지 토큰값
	 */
	
	call: function() {
		DGB.Log.l("[DGB.Auth.WorkLight] ====>> Call");
		
		var login = { "ENOB":GLOBAL.ENOB, "SYS_ID":SYS_ID};
		userChallengeHandler.doAuth(login, 
			function(isSuccess){
				if (isSuccess) {
                    dgbLoading(true);
					DGB.Auth.WorkLight.exec();
				} else {
					showAlert(Messages.msg002);
				}
			}
		);
	},
    exec: function() {
        var inv = {
            adapter : 'SimplePushAdapter',
            procedure : 'bindUser',
            parameters : [GLOBAL.ENOB]
        };
        var opt = {
            onSuccess : DGB.Auth.WorkLight.onSuccess,
            onFailure : DGB.Auth.WorkLight.onFailure,
            invocationContext : {}
        };

        setTimeout(function() {
            callProcedure(inv, opt);
        }, 200);

    },
	onSuccess: function(data) {
        dgbLoading(false);

		var item = data.invocationResult;
		if( item.MSG_CD && Messages[item.MSG_CD] ) {
			showAlert('알림', Messages[item.MSG_CD], function() {
				DGB.Common.appExit();
			});
		} else {
			// 푸시정보 등록
			doSubscribe();
			DGB.Auth.Step.use();
		}
	},
	
	onFailure: function(err) {
		dgbLoading(false);
		showAlert(Messages.msg002 + "\nError : " + JSON.stringify(err));
	}
};

/**
 * 행번 검증
 */
DGB.Auth.OnlyID = {
	call: function() {
		DGB.Log.l("[DGB.Auth.OnlyID] ====>> Call");
		
		//암호화시 키패드별로 암호화 대상 키값을 넣어줌	 ex) ENCODE_STR :"PSWD,APP_VERSION", ENCODE_NUM:"ENOB"
		var inv = {
				adapter : 'DBCommonAdapter',
				procedure : 'doIDPass',
				parameters : [{
					ENOB : GLOBAL.ENOB,
					CS_ID:"CO0001"
				}]
		};
		var opt = {
				onSuccess : DGB.Auth.OnlyID.onSuccess,
				onFailure : DGB.Auth.OnlyID.onFailure,
				invocationContext : {}
		};

		dgbLoading(true);
        callProcedure(inv, opt);
	},
	
	onSuccess: function(data) {
		var item = data.invocationResult;
		if(item.PASS_VALIDATION == false) {
			dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
			showAlert(Messages[item.MSG_CD]);
			if(item.MSG_CD === "msg00C") {
				var args = {};
				GLOBAL.STAT = "PasswordPass";
				GLOBAL.PAGEID = "freeSv";
		 		GLOBAL.ARGS = args;

				// 세션종료시 이전 상태로 복구를 위해 상태 저장
				GLOBAL.TEMP_STAT = GLOBAL.STAT;
				GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
                DGB.Page.triggerPage("#login", "parentpage", [args]);
				DGB.Page.changePage('#login');
			}
            return false;
		}
		window.regAuthState = DGB.Auth.Level.ID;
		DGB.Auth.Step.use();
	},
	
	onFailure: function(err) {
		dgbLoading(false);
		showAlert(Messages.msg002 + "\nError : " + JSON.stringify(err));
	}
};

/**
 * SSO 통신.
 */
DGB.Auth.Sso = {
    isSso : false,
	call: function() {
		DGB.Log.l("[DGB.Auth.Sso] ====>> Call");
		
		//암호화시 키패드별로 암호화 대상 키값을 넣어줌	 ex) ENCODE_STR :"PSWD,APP_VERSION", ENCODE_NUM:"ENOB"
		var inv = {
				adapter : 'DBCommonAdapter',
				procedure : 'doLogin',
				parameters : [{
					ENOB : GLOBAL.ENOB,
					PSWD :GLOBAL.PSWD,
					DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS),
					CS_ID:"CO0001",
					ENCODE_STR : "PSWD",
					TRANS_KEY : IS_TRANS_KEY
				}]
		};
		var opt = {
				onSuccess : DGB.Auth.Sso.onSuccess,
				onFailure : DGB.Auth.Sso.onFailure,
				invocationContext : {}
		};
		
		dgbLoading(true);
		setTimeout(function() {
			callProcedure(inv, opt);
		}, 200);
	},
	
	onSuccess: function(data) {
		// 로그인 도중 로딩바 사라지는 문제로 인해 dgbLoading을 각각호출
		var item = data.invocationResult;
		switch( item.MSG_CD ) {
			case "TIMEOUT":
				dgbLoading(false);
				showAlert('알림', Messages.msg052, function() {
					DGB.Common.appExit();
				});
				return;
		}
		
		switch( item.IS_LOGIN ) {
			case "0":
				dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
				$('#login #loginPw').val('');
				$('#login #loginPw').attr('data-enc','');
				showAlert("["+item.CODE+"]"+Messages[item.MSG_CD]);
				return;
			case "1":
				dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
				$('#login #loginPw').val('');
				$('#login #loginPw').attr('data-enc','');
				showAlert(Messages[item.MSG_CD]);
				return;
		}
		DGB.Auth.Sso.isSso = true;
		window.regAuthState = DGB.Auth.Level.Pass;

		// SSO 성공후 이용동의 미체크시 이동
		if ( !item.LT_AG_DTHR ) {
			dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
			DGB.Page.changePage("#CO00007");
			return false;
		}
		DGB.Auth.Step.use();
	},
	
	onFailure: function() {
		dgbLoading(false);
		showAlert(Messages.msg002);
	}	
};

/**
 * 사용자 체크.
 */
DGB.Auth.User = {
	call: function() {
		DGB.Log.l("[DGB.Auth.User] ====>> Call");
		var inv = {
				adapter : 'DBCommonAdapter',
				procedure : 'TCO00010',
				parameters : [{
					DEVC_NATV_NO : nmf.Store.get(MAC_ADDRESS),
					ENOB : GLOBAL.ENOB,
					CS_ID : "CO0001",
					CNNT_STC : "LI", 					// 접속 코드
					SESSION_ID : USER_INFO.SESSION_ID
				}]
		};
		var opt = {
			onSuccess : DGB.Auth.User.onSuccess,
			onFailure : DGB.Auth.User.onFailure
		};
		callProcedure(inv, opt);
	},
	
	onSuccess: function(data) {
		var result = data.invocationResult || {};
		dgbLoading(false); // 로그인 도중 로딩바 사라지는 문제.
		if(result.statusCd == '2') {
			showAlert(Messages.msg00D);
			DGB.Page.changePage('#freeSv');
			return false;
		}

		// 로그인 후 메일 게시판 업데이트
		GLOBAL.MAIN_BOARD = result.main_board || [];

		// 바이오 로그인시 다음 접속시 바로 접속하기 위함
		DGB.Fido.login( DGB.Auth.Bio.isLogin );

		// 바이오인증에 사용할 ID 저장
		DGB.Fido.setEnob(DGB.Sms.get());

		DGB.Auth.Step.use();
	},
	
	onFailure: function(err) {
		dgbLoading(false);
        showAlert(Messages.msg002 + "\nError : " + JSON.stringify(err));
	}
};

/**
 * 바이오 검증
 */
DGB.Auth.Bio = {
	isLogin : false,
	call: function() {
		DGB.Log.l("[DGB.Auth.Bio] ====>> Call");
		var inv = {
			adapter : 'DBCommonAdapter',
			procedure : 'doBioAuth',
			parameters : [{
				ENOB : DGB.Fido.id(true)
			}]
		};
		var opt = {
			onSuccess : DGB.Auth.Bio.onSuccess,
			onFailure : DGB.Auth.Bio.onFailure,
			invocationContext : {}
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	},

	onSuccess : function(data) {
		var result = data.invocationResult;
		if ( !result.success ) {
			dgbLoading(false);
			showAlert(result.msg);
			return false;
		}

		if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
			var key = DGB.Fido.id(true);
			if (result.success && ( !result.key || result.key != DGB.Util.sha256(key) )) {
				showAlert('알림', '올바르지 않은 접근입니다!', function () {
					DGB.Common.appExit();
				});
				return;
			}
		}

		DGB.Auth.Bio.isLogin = true;
		DGB.Auth.Sso.isSso = true;
		DGB.Auth.Step.use();
	},
	onFailure : function() {
		dgbLoading(false);
		showAlert(Messages.msg002);
	}
};

/**
 * Sms 인증화면
 */
DGB.Auth.Sms = {
	isLogin : false,
	check : function() {
		// 최초 SMS 인증을 위한 함수
		DGB.Log.l("[DGB.Auth.Sms] ====>> Check");
		if( !DGB.Sms.is(GLOBAL.ENOB) ) {
			dgbLoading(false);
			GLOBAL.STAT = DGB.Auth.Level.Sms;
			DGB.Page.triggerPage("#login", "parentpage");
			DGB.Page.changePage('#login');
			return;
		}
		DGB.Auth.Step.use();
	},
	call : function() {
		// 메뉴권한에 따른 인증 함수
		DGB.Log.l("[DGB.Auth.Sms] ====>> Call");
		if( !DGB.Auth.Sms.isLogin ) {
			dgbLoading(false);
			GLOBAL.STAT = DGB.Auth.Level.Sms;
			DGB.Page.triggerPage("#login", "parentpage");
			DGB.Page.changePage('#login');
			return;
		}
		DGB.Auth.Step.use();
	}
};

/**
 * 신분증인증
 */
DGB.Auth.Nfc = {
	isLogin : false,
	call: function() {
		DGB.Log.l("[DGB.Auth.Nfc] ====>> Call");
		var inv = {
			adapter : 'DBCommonAdapter',
			procedure : 'doNfcAuth',
			parameters : [{
				ENOB : DGB.Sms.get(),
				TRF_CDNO : GLOBAL.TRF_CDNO
			}]
		};
		var opt = {
			onSuccess : DGB.Auth.Nfc.onSuccess,
			onFailure : DGB.Auth.Nfc.onFailure,
			invocationContext : {}
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	},

	onSuccess : function(data) {
		var result = data.invocationResult;
		if ( !result.success ) {
			dgbLoading(false);
			showAlert(result.msg);
			return false;
		}

		if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
			if (result.success && ( !result.key || result.key != DGB.Util.sha256(GLOBAL.TRF_CDNO) )) {
				showAlert('알림', '올바르지 않은 접근입니다!', function () {
					DGB.Common.appExit();
				});
				return;
			}
		}

		GLOBAL.ENOB = DGB.Sms.get();
		DGB.Auth.Nfc.isLogin = true;
		DGB.Auth.Sso.isSso = true;
		DGB.Auth.Step.use();
	},
	onFailure : function() {
		dgbLoading(false);
		showAlert(Messages.msg002);
	}
};

