DGB.Theme = {
    THEMES : [
        { 'name' : '모바일오피스 테마', 'id' : 'theme_office' },
        { 'name' : '스마트뱅킹 테마', 'id' : 'theme_bank' }

    ],
    DEFAULT_THEME : "theme_bank",
    USE_THEME : "USE_THEME",

    init : function() {
        DGB.Log.d("[DGB.Theme] ====>> init");
        var theme = nmf.Store.get(this.USE_THEME);
        if( !theme ) {
            nmf.Store.set(this.USE_THEME, this.DEFAULT_THEME);
            theme = this.DEFAULT_THEME;
        }
        this.use(theme);
    },

    use : function(theme) {
        var links = document.getElementsByTagName("link");
        for(var i = 0; i < links.length; i++) {
            if( (links[i].rel.indexOf( "stylesheet" ) != -1) && links[i].id ) {
                var enable = (links[i].id == theme);
                links[i].disabled = !enable;
                if( enable ) {
                    nmf.Store.set(this.USE_THEME, theme);
                }
                DGB.Log.d('[DGB.Theme] ====>> using theme ' + links[i].id + ' : ' + enable);
            }
        }
    },

    getThems : function() {
        return this.THEMES;
    },

    getTheme : function() {
        return nmf.Store.get(this.USE_THEME);
    }
};