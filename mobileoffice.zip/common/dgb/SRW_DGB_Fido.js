DGB.Fido = {
    PRO : 'dgbbio://',
    APP : 'dgboffice',
    SCHEME : 'dgboffice://',
    PKG : 'kr.co.dgb.dgbrn',
    REAL_TOKEN : '_',
    CMD : {
        REGIST : 'regist_bio',
        AUTH : 'auth_bio',
        DEREGIST : 'deregist_bio',
        IS_REGISTED : 'is_registed_bio'
    },

    BIO_ID : 'BIO_ID_NEW',      // 새로운 로컬에 저장할 ID(행번) 키값
    BIO_ID_OLD : 'BIO_ID',      // 이전 로컬에 저장할 ID(행번) 키값
    BIO_TYPE : 'BIO_TYPE',  // 로컬에 저장할 타입 키값
    BIO_LOGIN : 'BIO_LOGIN',// 로컬에 저장할 로그인 키값

    ENOB : '',              // 이전 로그인 ID(행번)
    DEVICE_ID : '',         // 기기고유 번호
    onSuccess : null,       // IOS 콜백
    onFailure : null,       // IOS 콜백

    init : function() {
        WL.Device.getID({
            onSuccess : function(data) { DGB.Fido.DEVICE_ID = data.deviceID; },
            onFailure : function(data) { showAlert('getDivice Error : ' + JSON.stringify(data)); }
        });
    },

    check : function() {
        var me = this;
        var id = me.id();
        return ( id && (id == me.getEnob()) );
    },

    setEnob : function(enob) {
        // 기존에 사용하던 바이오정보를 위한 로직
        if( this.get(this.BIO_ID_OLD) ) {
            this.ENOB = enob;
        } else {
            this.ENOB = enob + this.REAL_TOKEN + this.DEVICE_ID;
        }
    },

    getEnob : function() {
        return this.ENOB;
    },

    is : function(success, error) {
        var pkg = DGB.isAndroid() ? DGB.Fido.PKG : DGB.Fido.PRO;
        window.plugins.fido.is(pkg, success, error);
    },

    install : function() {
        // 셋팅 초기화
        var me = this;
        me.set('', '');
        me.login(false);
        showCusConfirm(
            function(btn) {
                if( btn == '1' ) {
                    if( DGB.isAndroid() ) {
                        $(location).attr('href', Messages.url034);
                    } else if( DGB.isIPhone() ) {
                        window.open(Messages.url035, "_system");
                    }
                }
            }, '알림', Messages.msg626, '설치하기, 닫 기'
        );
    },

    auth : function(bio_type, success, error) {
        var me = this;
        me.exec(DGB.Fido.CMD.AUTH, bio_type, '',
            function(data) {
                var msg = me.message(data);
                if( msg ) {
                    showAlert(msg);
                    return;
                }

                if( !data.TOKEN ) {
                    showAlert('오류가 발생하였습니다. 잠시 후 다시 이용해 주세요.\n\nError : ' + JSON.stringify(data));
                    return;
                }


                var opt = {
                    onSuccess : function(response) {
                        dgbLoading(false);
                        var result = response.invocationResult || {};
                        if( result.success ) {

                            if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
                                if (!result.key || result.key != DGB.Util.sha256(data.TOKEN)) {
                                    showAlert('알림', '올바르지 않은 접근입니다!', function () {
                                        DGB.Common.appExit();
                                    });
                                    return;
                                }
                            }

                            if( success ) { success(result); } else { alert('auth success not found!'); }
                        } else {
                            showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(result));
                        }
                    },
                    onFailure : function(response) {
                        dgbLoading(false);
                        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(response));
                        if( error ) error(response);
                    },
                    invocationContext : { }
                };

                var inv = {
                    adapter : 'FidoAdapter',
                    procedure : 'FIAUTH0002',
                    parameters : [{ TOKEN : data.TOKEN }]
                };
                dgbLoading(true);
                callProcedure(inv, opt);
            }
        );
    },

    regist : function(bio_type, success, error) {
        var me = this;
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                var result = data.invocationResult || {};
                if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
                    if (result.success && ( !result.key || result.key != DGB.Util.sha256(me.getEnob()) )) {
                        showAlert('알림', '올바르지 않은 접근입니다!', function () {
                            DGB.Common.appExit();
                        });
                        return;
                    }
                }
                DGB.Fido.exec(DGB.Fido.CMD.REGIST, bio_type, result.authorizationCode, success, error);
            },
            onFailure : function(data) {
                dgbLoading(false);
                showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
            },
            invocationContext : { }
        };

        var inv = {
            adapter : 'FidoAdapter',
            procedure : 'FIAUTH0001',
            parameters : [{
                FIDO_ENOB : me.getEnob(),
                DEVICE_ID : me.DEVICE_ID,
                IS_IPHONE : DGB.isIPhone()
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    },

    deregist : function(id, dvc_id, bio_type, success, error) {
        DGB.Fido.exec(DGB.Fido.CMD.DEREGIST, bio_type, id, success, error, dvc_id);
    },

    url : function(cmd, type, id, auth, dvc_id) {
        var me = this;
        var param = { APP:me.APP, BIO_TYPE:type, USER_ID:id, DEVICE_ID : dvc_id || me.DEVICE_ID };
        if( auth ) param.AUTH_CODE = auth;
        return me.PRO + cmd + '?' + $.param(param);
    },

    exec : function(cmd, type, auth, success, error, dvc_id) {
        var me = this;
        me.is(
            function() {
                var id = '';
                switch( cmd ) {
                    case me.CMD.REGIST: id = me.getEnob(); break;
                    case me.CMD.DEREGIST:
                        // auth 넘겨온 값으로 사용
                        id = auth;
                        auth = '';
                        break;
                    default: id = me.id(); break;
                }

                if( id ) {
                    me.onSuccess =  success;
                    me.onFailure =  error;
                    window.plugins.fido.exec(me.url(cmd, type, id, auth, dvc_id),
                        function(data) {
                            if( DGB.isAndroid() ) {
                                try {
                                    if( typeof data === 'string' ) {
                                        data = JSON.parse(data);
                                    }
                                } catch(e) { }
                                me.success(cmd, type, id, data, success, error);
                            }
                            // IOS callback => openURL
                        },
                        function(data) {
                            if( DGB.isAndroid() ) {
                                try {
                                    if( typeof data === 'string' ) {
                                        data = JSON.parse(data);
                                    }
                                } catch(e) { }
                                me.cancel(cmd, type, id, data);
                            }
                            // IOS callback => openURL
                        }
                    );
                } else {
                    me.failure(cmd);
                }
            },
            function() { me.install(); }
        );
    },

    failure : function(cmd) {
        switch( cmd ) {
            case DGB.Fido.CMD.REGIST:
                showAlert('로그인 정보가 없습니다 통합인증 및 SMS인증 후 사용하실 수 있습니다.');
                break;
            case DGB.Fido.CMD.DEREGIST:
                showAlert('저장되어 있는 [바이오] 정보가 없습니다. 바이오 등록 후 사용해 주시기 바랍니다.');
                break;
            case DGB.Fido.CMD.AUTH:
                showAlert('저장되어 있는 [바이오] 정보가 없습니다. 바이오 등록 후 사용해 주시기 바랍니다.');
                break;
        }
    },

    cancel : function(cmd, type, id, data) {
        // showAlert('요청이 취소되었습니다.\n\nCode : ' + JSON.stringify(data));
    },

    error : function(cmd, type, id, data, callback) {
        if( callback ) callback(data);
    },

    success : function(cmd, type, id, data, success, error) {
        var me = this;
        var msg = '';

        switch( cmd ) {
            case DGB.Fido.CMD.REGIST:
                msg = me.message(data);
                if( !msg ) {
                    me.set(id, type);
                    me.login(true);
                    showAlert('바이오 정보가 등록되었습니다.');
                    if( success ) success(data);
                } else {
                    showAlert(msg);
                    if( error ) error(data);
                }
                break;
            case DGB.Fido.CMD.AUTH:
                msg = me.message(data);
                if( !msg ) {
                    if( success ) success(data);
                } else {
                    showAlert(msg);
                    if( error ) error(data);
                }
                break;
            case DGB.Fido.CMD.DEREGIST:
                msg = me.message(data);
                if( !msg ) {
                    // 현재기기의 정보삭제시
                    if( me.id() == id ) {
                        me.set('', '');
                        me.login(false);
                    }
                    showAlert('바이오 정보가 삭제되었습니다.');
                    if( success ) success(data);
                } else {
                    showAlert(msg);
                    if( error ) error(data);
                }
                break;
            case DGB.Fido.CMD.IS_REGISTED:
                var finger = '지문코드 : ' + data.IS_FINGER;
                var iris = '홍체코드 : ' + data.IS_IRIS;
                showAlert(finger + '\n' + iris);
                break;
        }
    },

    set : function(id, type) {
        if( this.get(this.BIO_ID_OLD) ) {
            nmf.Store.set(this.BIO_ID_OLD, id);
        } else {
            nmf.Store.set(this.BIO_ID, id);
        }
        nmf.Store.set(this.BIO_TYPE, type);
    },

    get : function(key) {
        return nmf.Store.get(key);
    },

    id : function(real) {
        if( this.get(this.BIO_ID_OLD) ) {
            return this.get(this.BIO_ID_OLD) || '';
        } else {
            var id = this.get(this.BIO_ID) || '';
            return real ? id.split(this.REAL_TOKEN)[0] || '' : id;
        }
    },

    type : function() {
        return this.get(this.BIO_TYPE);
    },

    login : function(is) {
        nmf.Store.set(this.BIO_LOGIN, is);
    },

    message : function(data) {
        var msg = '';
        switch( data.RESULT ) {
            case 'Y': break;
            case 'N': msg = '인증에 실패하였습니다.'; break;
            case 'F': msg = '시스템 오류입니다.'; break;
            case 'U': msg = '미지원 단말입니다.'; break;
            default: msg = '알 수 없는 오류가 발생하였습니다.\n\nError : ' + JSON.stringify(data); break;
        }
        return msg;
    },

    openURL : function(url) {
        var me = this;
        if( !url || url.indexOf(me.SCHEME) == -1 ) {
            showAlert('ERROR : ' + url);
            return;
        }

        var data = url.replace(me.SCHEME, '').split('?');
        if( data.length != 2 ) {
            // showAlert('FORMAT ERROR : ' + url);
            return;
        }
        var cmd = data[0];
        var obj = me.url2obj(data[1]);
        me.success(cmd, obj.BIO_TYPE, obj.USER_ID || '', obj, DGB.Fido.onSuccess,  DGB.Fido.onFailure);
    },

    url2obj : function(url) {
        var obj = { };
        url.replace(/([^=&]+)=([^&]*)/g, function(m, key, value) {
            obj[decodeURIComponent(key)] = decodeURIComponent(value);
        });
        return obj;
    }

};