DGB.Sms = new function() {
    var SMS_AUTH = 'SMS_AUTH';
    var INTERVAL_TIME = 1000;
    var INTERVAL_COUNT = 59;
    var FAILURE_COUNT = 5;
    var SEND_COUNT = 5;

    var intervalId = -1;
    var intervalCount = INTERVAL_COUNT;
    var failureCount = FAILURE_COUNT;
    var sendCount = SEND_COUNT;

    var me = this;

    me.init = function() { };

    me.count = function() {
        return INTERVAL_COUNT;
    };

    me.failure = function() {
        return (--failureCount) > 0;
    };

    me.send = function() {
        return (--sendCount > 0);
    };

    me.is = function(enob) {
        var auth = nmf.Store.get(SMS_AUTH);
        return (auth && enob && (auth == enob));
    };

    me.get = function() {
        if( DGB.isDebug() ) {
            return TEST_INFO.ENOB;
        }
        return nmf.Store.get(SMS_AUTH) || '';
    };

    me.set = function(enob) {
        nmf.Store.set(SMS_AUTH, enob);
    };

    me.start = function(counting, finish) {
        me.end();
        intervalId = setInterval(function() {
            if( --intervalCount < 0 ) {
                me.end();
                if( finish ) finish();
            } else {
                if( counting ) counting(intervalCount);
            }
        }, INTERVAL_TIME);
    };

    me.end = function() {
        clearInterval(intervalId);
        intervalCount = INTERVAL_COUNT;
        intervalId = -1;
    };

    me.req = function(enob, ymd, callback) {
        if( !DGB.Sms.send() ) {
            showAlert('알림', 'SMS전송 횟수(' + SEND_COUNT + '회)를 초과하였습니다. 잠시 후 다시 이용해 주시기바랍니다', function() {
                DGB.Common.appExit();
            });
            return;
        }

        var inv = {
            adapter : 'DBCommonAdapter',
            procedure : 'doSmsRequest',
            parameters : [{
                ENOB : enob,
                BIR_YMD : ymd
            }]
        };
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                var result = data.invocationResult;

                if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
                    if( result.success && ( !result.key || result.key != DGB.Util.sha256(ymd) ) ) {
                        showAlert('알림', '올바르지 않은 접근입니다!', function() {
                            DGB.Common.appExit();
                        });
                        return;
                    }
                }

                if( !result.success && !DGB.Sms.failure() ) {
                    showAlert('알림', 'SMS인증 횟수를 초과하였습니다. 잠시 후 다시 이용해 주시기바랍니다', function() {
                        DGB.Common.appExit();
                    });
                    return;
                }
                if( callback ) callback(result.success, result.message);
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    me.auth = function(enob, auth, callback) {
        var inv = {
            adapter : 'DBCommonAdapter',
            procedure : 'doSmsAuth',
            parameters : [{
                ENOB : enob,
                AUTH : auth
            }]
        };
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                var result = data.invocationResult;

                if( DGB.isDebug() ) {   // 앱 취약점 점검을 위한 로직
                    if (result.success && ( !result.key || result.key != DGB.Util.sha256(auth) )) {
                        showAlert('알림', '올바르지 않은 접근입니다!', function () {
                            DGB.Common.appExit();
                        });
                        return;
                    }
                }

                if( !result.success && !DGB.Sms.failure() ) {
                    showAlert('알림', 'SMS인증 횟수를 초과하였습니다. 잠시 후 다시 이용해 주시기바랍니다', function() {
                        DGB.Common.appExit();
                    });
                    return;
                }
                if( callback ) callback(result.success, result.message);
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };
}();