DGB.Bio = {
    ERROR_AND : {
        NOT_SDK : '지원하지 버전입니다.',
        NOT_SUPPORTED : '지원하지 않는 기기입니다.',
        NOT_AVAILABLE : '지문 정보가 없습니다. 등록 후 사용하시기 바랍니다.',
        NOT_PERMISSION : '사용권한이 없습니다.'
    },

    ERROR_IOS : {
        '-128' : '', // Cancel
        '-9' : '앱에서 인증을 취소하였습니다.',
        '-4' : '시스템이 인증을 취소하였습니다.',
        '-2' : '사용자가 인증을 취소하였습니다.',
        '-8' : '실패한 시도가 너무 많아 Touch ID 또는 Face ID가 잠겼습니다.',
        '-6' : '기기에서 Touch ID 또는 Face ID를 사용할 수 없습니다. 설정 확인 후 사용하시기 바랍니다.',
        '-7' : '등록된 Touch ID 또는 Face ID가 없습니다.',
        '-1' : '사용자 인증에 실패하였습니다. 잠시 후 다시 이용해 주시기 바랍니다.',
        '-10' : '이전 데이터가 무효화되었습니다.',
        '-1004' : '필수 인증 사용자 인터페이스 표시는 금지되어 있습니다.',
        '-5' : '기기에 암호가 설정되어 있지 않습니다. 암호설정 후 사용하기시 바랍니다.',
        '-3' : '인증 정책에 대체 기능을 사용할 수 없음',
        '-25293' : '인증에 실패 하였습니다. 잠시 후 다시 이용해 주시기 바랍니다.'
    },

    verify : function(success) {
        if( DGB.isAndroid() ) {
            window.plugins.Bio.verify(success,
                function(result) {
                    var msg = DGB.Bio.ERROR_AND[result.state] || '';
                    if( msg ) {
                        showAlert(msg);
                    }
                }, '지문인증', '', '지문을 인식시켜 주세요.', '취 소');
        } else if( DGB.isIPhone() ) {
            window.plugins.TouchID.is(function () {
                    window.plugins.TouchID.verify(success,
                        function(result) {
                            var error = DGB.Bio.ERROR_AND[result.code] || '';
                            if (error) {
                                showAlert(error);
                            }
                        }, "지문을 인식시켜 주세요.");
                },
                function(result) {
                    var error = DGB.Bio.ERROR_IOS[result.code] || '';
                    if (error) {
                        showAlert(error);
                    }
                });
        } else {
            showAlert("바이오 인증 성공!");
        }
    }
};