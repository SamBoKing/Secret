DGB.MDM = {
    PRO : 'mguard://',
    PKG : 'com.raonsecure.touchen_mguard_4_0',

    init : function() { },

    is : function(success, error) {
        var pkg = DGB.isAndroid() ? DGB.MDM.PKG : DGB.MDM.PRO;
        // Fido 쪽에 만들어 놓은거 사용.( 공통으로 빼야함. )
        window.plugins.fido.is(pkg, success, error);
    }
};
