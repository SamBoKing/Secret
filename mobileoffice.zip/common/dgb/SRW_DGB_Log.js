
/**
 * Web Test Debug
 */
function dir(msg) {
	if( console ) console.dir(msg);
}

DGB.Log = {
	// 로그 필터 셋팅
	filter: { d: true, e: true, w: true, i: true, l: true },
	
	d: function(msg) { if( this.filter.d ) console.debug(msg); },
	e: function(msg) { if( this.filter.e ) console.error(msg); },
	w: function(msg) { if( this.filter.w ) console.warn(msg); },
	i: function(msg) { if( this.filter.i ) console.info(msg); },
	l: function(msg) { if( this.filter.l ) console.log(msg); },
	t: function(msg) { console.log("[Log Test] ==============>> " + msg); }
};

console.debug('#####################################################');
console.debug('#              DGB.Log Filter Settting              #');
console.debug('#####################################################');
console.debug(' ========> [debug] 	: ' + DGB.Log.filter.d);
console.error(' ========> [error] 	: ' + DGB.Log.filter.e);
console.warn(' ========> [warn] 	: ' + DGB.Log.filter.w);
console.info(' ========> [info] 	: ' + DGB.Log.filter.i);
console.log(' ========> [log] 	: ' + DGB.Log.filter.l);
console.debug('=====================================================');