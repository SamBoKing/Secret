DGB.Calendar_Alios = {};
(function() {
    var _events, _dates;
    var KEY_TOKEN = "_";
    this.init = function() {
        _events = new DGB.HashMap();
        _dates = new DGB.HashMap();
    };

    var _pad = function(num) {
        num = parseInt(num);
        return (num > 9) ? ('' + num)  : ('0' + num);
    };

    var _add = function(item) {
        item.StartHour = _pad(item.StartHour);
        item.StartMinute = _pad(item.StartMinute);
        item.EndHour = _pad(item.EndHour);
        item.EndMinute = _pad(item.EndMinute);
        item.summary = item.Title;
        item.color = item.Color;
        item.cid = item.CID;
        item.begin = new Date(item.StartDate.split('-').join('/') + ' ' + item.StartHour + ':' + item.StartMinute);
        item.end = new Date(item.EndDate.split('-').join('/') + ' ' + item.EndHour + ':' + item.EndMinute);
        _events.put(_getKey(item), item);
    };

    var _isDate = function(date) {
        var key = date.getFullYear() + '-' + date.getMonth();
        return _dates.containsKey(key);
    };

    var _addDate = function(date) {
        var key = date.getFullYear() + '-' + date.getMonth();
        return _dates.put(key, true);
    };

    var _getKey = function(item) {
        return item.ID + KEY_TOKEN + item.CID;
    };

    this.getCIds = function(id) {
        var result = [];
        var keys = _events.keys();
        for(var i in keys) {
            var key = keys[i];
            var key_obj = key.split(KEY_TOKEN);
            var key_id = key_obj[0];
            if( id ==  key_id ) {
                result.push(key_obj[1]);
            }
        }
        return result;
    };

    var formatData = function(data) {
        return data.invocationResult;
    };

    this.events = function() {
        return _events;
    };

    this.load = function(date, callback) {
        if( !date || !callback ) {
            DGB.Log.e("[SRW_Calendar_Alios] ==> load failure");
            return;
        }

        if( _isDate(date) )
            return;

        var opt = {
            onSuccess : function(data) {
                _addDate(date);
                data = formatData(data);
                if( data && data.items ) {
                    for(var i = 0; i < data.items.length; i++) {
                        _add(data.items[i]);
                    }
                }
                callback(true);
                dgbLoading(false);
            },
            onFailure : function() {
                callback(false);
                dgbLoading(false);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'GroupWareAdapter',
            procedure : 'GWCL0001',
            parameters : [{
                CS_ID : 'GWCL001',
                Enob : USER_INFO.ENOB,
                Date : DGB.Calendar_Alios.formatDate(date)
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    this.save = function(event, callback) {
        event.ID = event.ID || -1;
        var opt = {
            onSuccess : function(data) {
                data = formatData(data);
                if( data && data.items ) {
                    // 수정
                    if( event.ID != -1 ) {
                        var events = _events.values();
                        for(var i in events) {
                            var ev = events[i];
                            if( ev.ID == event.ID ) {
                                _events.remove(_getKey(ev));
                            }
                        }
                    }

                    for(var i = 0; i < data.items.length; i++) {
                        _add(data.items[i]);
                    }
                }
                callback(true);
                dgbLoading(false);
            },
            onFailure : function() {
                callback(false);
                dgbLoading(false);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'GroupWareAdapter',
            procedure : 'GWCL0003',
            parameters : [{
                CS_ID : (event.ID == -1) ? 'GWCL003' : 'GWCL004',
                Enob : USER_INFO.ENOB,
                Event : {
                    Title : event.Title.replace(/(\")/g,'\''),
                    Description : event.Description.replace(/(\")/g,'\''),
                    StartDate : event.StartDate,
                    StartHour : event.StartHour,
                    StartMinute : event.StartMinute,
                    EndDate : event.EndDate,
                    EndHour : event.EndHour,
                    EndMinute : event.EndMinute,
                    ID : event.ID,
                    CalendarIds : event.CalendarIds
                }
             }]
         };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    this.remove = function(ID, callback) {
        var opt = {
            onSuccess : function(data) {
                data = formatData(data);
                if( data && data.success ) {
                    var events = _events.values();
                    for(var i in events) {
                        var event = events[i];
                        if( event.ID == ID ) {
                            _events.remove(_getKey(event));
                        }
                    }
                }
                callback(true);
                dgbLoading(false);
            },
            onFailure : function() {
                callback(false);
                dgbLoading(false);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'GroupWareAdapter',
            procedure : 'GWCL0004',
            parameters : [{
                CS_ID : 'GWCL004',
                Enob : USER_INFO.ENOB,
                ID : ID
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    this.clear = function() {
        _events.clear();
        _dates.clear();
    };

    this.formatDate = function(_date) {
        var year = _date.getFullYear();
        var month = _pad(_date.getMonth() + 1);
        var day = _pad(_date.getDate());
        return year + '-' + month + '-' + day;
    };
}).apply(DGB.Calendar_Alios);