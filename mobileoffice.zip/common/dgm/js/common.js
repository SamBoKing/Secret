﻿var DGB = {
    LOGGER : { DEBUG : true },
    IS_IOS : false,
    CONFIG : {
        REQUEST_CONVERT : false,
        SKIP_ERROR : false,
        COMPLETE : false,
        IMG_COUNT : 0,
        TYPE : 'jpg',               // 변환 확장자
        REQUEST_TIME : 3000,        // 해더 재요청 시간
        TEMP_PAGECOUNT : -1
    },
    SERVER : { URL : '', IMAGE : '' },
    CALLBACK : {},
    HEADER : {},
    DATA : {},
    EXT : ['hwp','doc','docx','ppt','pptx','pdf','xml','xls','xlsx','tif','tiff', 'rtf','dot','png','jpeg','jpg','gif','dwg','dxf','txt','bmp','htm', 'html','mht','eml','pps','ppsx','url','gul','pptm','csv'],
    ERROR : {
        ERROR_TIMEOUT : '변환 파일 생성 시간 초과',
        ERROR_DOWNLOADFAIL : '원본 문서 다운로드 실패',
        ERROR_CONVERTCOUNT_OVER : '동시 변환 수 초과',
        ERROR_CURRENT_CONVERTING_FILE : '해당 문서를 이미지 변환중에 있습니다. 잠시 기다려주시기 바랍니다.',
        ERROR_UNSUPPORTED_FORMAT : '지원하지 않는 포맷',
        ERROR_UNZIP_FAIL : '압축파일 해제 실패',
        ERROR_TOTALPAGEOVER : '변환된 총 페이지 수 보다 초과된 페이지번호 호출함',
        ERROR_CREATE_FILE_FAIL : '변환 파일 생성 실패',
        ERROR_INVALID_FORMAT : '알 수 없는 포맷',
        ERROR_ACCESS_DENIED : '접근 제한된 클라이언트',
        ERROR_NOTSUPPORTED : '지원하지 않는 클라이언트 OS',
        ERROR_DECRYPT_FAIL : '암호화 문서 복호화 실패',
        ERROR_DRMFILE_UNKNOWN : '알 수 없는 DRM 파일',
        ERROR_DRMFILE_SHADOWCUBE : 'ShadowCube Tech DRM 파일',
        ERROR_DRMFILE_FASOOSECURE : 'FasooSecure DRM 파일',
        ERROR_DRMFILE_NASCA : 'Nasca DRM 파일',
        ERROR_DRMFILE_SOFTCAMP : 'Softcamp DRM 파일',
        ERROR_DRMFILE_MARKANYV2 : 'Markany v2 DRM 파일',
        ERROR_DRMFILE_MARKANYV3 : 'Markany v3 DRM 파일',
        ERROR_PASSWORD_INCORRECT : '비밀번호가 필요한 문서입니다.',
        ERROR_DOCUMENT_OPEN_FAIL : '문서 열기 실패',
        ERROR_DOCUMENT_PRINT_FAIL : '문서 인쇄 실패',
        ERROR_SPOOLFILE_CREATE_FAIL : '스풀 파일 생성 실패',
        ERROR_SPOOLFILE_READ_FAIL : '스풀 파일 읽기 실패',
        ERROR_HWP_SECURITY_FAIL : 'HWP 파일 보안체크 실패',
        ERROR_PDF_IMEXE_FAIL : 'PDF 변환기 체크',
        'Number of pages exceeds the allowable range mobile' : '페이지수가 모바일 허용범위를 초과',
        'Number of pages(1000) exceeds the allowable range' : '페이지가 허용 범위(1000Page)를 초과 초과',
        'Document conversion failed, the total page count of 0, the original check required[1]' : 'Unknown, 문서 분석 필요[1]',
        'Document conversion failed, the total page count of 0, the original check required[2]' : 'Unknown, 문서 분석 필요[2]',
        'Document conversion failed, the total page count of 0, the original check required[3]' : 'Unknown, 문서 분석 필요[3]',
        ERROR_CONVERT_ERROR : '기타 파일 변환 실패 사유'
    },

    error : function(code) {
        code = decodeURIComponent(code);
        return ( 'ERROR_NONE' === code ) ? '' : this.ERROR[code] || ('기타 오류 : ' + code);
    },

    isExt : function(ext) {
        return this.EXT.indexOf(ext) > -1;
    },

    getExt : function(url) {
        return (url || '').split('.').pop().toLowerCase();
    },

    getFileName : function (url) {
        return (url || '').split('/').pop();
    },

    params : function() {
        var url = location.href;
        var regex = /([^=&?]+)=([^&#]*)/g, params = {}, parts, key, value;
        while((parts = regex.exec(url)) != null) {
            key = parts[1], value = parts[2];
            var isArray = /\\[\\]$/.test(key);
            if( isArray ) {
                params[key] = params[key] || [];
                params[key].push(value);
            } else {
                params[key] = decodeURIComponent(value).replace(/\+/g, " ");
            }
        }
        return params || {};
    },

    init : function(url, name, mark) {
        var data = this.params();
        data.server = data.server || 't';

        this.LOGGER.DEBUG = (data.server == 't') ? true : data.debug;
        this.LOGGER.DEBUG = true;

        this.IS_IOS = data.is_ios || false;
        this.SERVER.URL = 'http://' + data.server+ 'mdm.dgb.co.kr:47158';
        this.SERVER.IMAGE = 'http://' + data.server + 'mdm.dgb.co.kr:8181/image.php';

        data.mark = data.mark || '';
        data.title = data.title || this.getFileName(data.file || data.url);
        data.ext = data.ext || this.getExt(data.file || data.url);
        this.DATA = data;

        if( url ) {
            this.DATA.mark = mark || '';
            this.DATA.url =  url || this.DATA.url;
            this.DATA.title = this.getFileName(name || url) || this.DATA.title;
            this.DATA.ext = this.getExt(name || url) || this.DATA.ext;
        }

        debug('========= CONFIG =========');
        debug('IMAGE TYPE       : ' + this.CONFIG.TYPE);
        debug('REQUEST TIME     : ' + this.CONFIG.REQUEST_TIME);
        debug('MODE             : ' + (url ? 'TEST' : 'REAL'));
        debug('========= PARAMS =========');
        debug('FILE URL         : ' + (data.url || ''));       // 필수
        debug('FILE EXT         : ' + (data.ext || ''));       // 자동
        debug('TITLE            : ' + (data.title || ''));     // 선택
        debug('FILE NAME        : ' + (data.file || ''));      // 선택
        debug('WATERMARK        : ' + (data.mark || ''));      // 선택
    },

    request : function(success, error) {
        var me =  DGB;
        me.CALLBACK.SUCCESS = success;
        me.CALLBACK.ERROR = error;
        if( !me.isExt(me.DATA.ext) && me.CALLBACK.ERROR ) {
            me.CALLBACK.ERROR('지원하지 않는 파일 형식입니다. \n\nURL : ' + me.DATA.url);
            return;
        }
        me.header();
    },

    header : function() {
        var me = DGB;   // 타이머를 쓰는 관계로 this가 Window로 변경됨
        var param = { url : encodeURIComponent(me.DATA.url), ext : me.DATA.ext, page : 1, type: me.CONFIG.TYPE };
        if( me.CONFIG.REQUEST_CONVERT ) {
            param.action = 'empty';
        }
        $.ajax({
            url : me.SERVER.URL,
            data : $.param(param),
            beforeSend : function() { debug("REQUEST HEADER : " + this.url); },
            success : function(data) {
                var header = {};
                if( data.indexOf('MO_') > -1 ) {
                    var datas = data.split('\r\n');
                    for(var i in datas) {
                        var values = datas[i].split(':');
                        var key = values[0];
                        var val = values[1] || '';
                        if( key && key.indexOf('MO_') > -1 ) {
                            header[key] = val;
                        }
                    }
                }
                // 해더값 설정
                me.HEADER.MO_STATE = header.MO_STATE || '';
                me.HEADER.MO_CONVERTING = header.MO_CONVERTING || '';
                me.HEADER.MO_HASHCODE = header.MO_HASHCODE;
                me.HEADER.MO_ERRCODE = header.MO_ERRCODE;
                me.HEADER.MO_PAGECOUNT = parseInt(header.MO_PAGECOUNT || 0);
                me.HEADER.MO_PAGEWIDTH = parseInt(header.MO_PAGEWIDTH || 0);
                me.HEADER.MO_PAGEHEIGHT = parseInt(header.MO_PAGEHEIGHT || 0);
                debug("REQUEST HEADER SUCCESS : " + JSON.stringify(me.HEADER));

                var error = me.error(me.HEADER.MO_STATE || '');
                if( error && me.CALLBACK.ERROR ) {
                    me.CALLBACK.ERROR(error);
                    return;
                }

                // 캐시파일이 없을시 이전 페이지 사이즈를 저장
                if( me.HEADER.MO_PAGEWIDTH == 0 && me.HEADER.MO_PAGEHEIGHT == 0 ) {
                    me.CONFIG.TEMP_PAGECOUNT = me.HEADER.MO_PAGECOUNT;
                    debug("REQUEST HEADER SUCCESS 1 : " + me.CONFIG.TEMP_PAGECOUNT);
                    setTimeout(me.header, me.CONFIG.REQUEST_TIME);
                    return;
                }

                if( me.CONFIG.TEMP_PAGECOUNT != -1 && me.CONFIG.TEMP_PAGECOUNT != me.HEADER.MO_PAGECOUNT ) {
                    me.CONFIG.REQUEST_CONVERT = true;
                    debug("REQUEST HEADER SUCCESS 2 : " + me.CONFIG.TEMP_PAGECOUNT + ", " + me.HEADER.MO_PAGECOUNT);
                    me.CONFIG.TEMP_PAGECOUNT = me.HEADER.MO_PAGECOUNT;
                    setTimeout(me.header, me.CONFIG.REQUEST_TIME);
                    return;
                }

                if( me.CALLBACK.SUCCESS ) {
                    setTimeout(function() { me.CALLBACK.SUCCESS(); }, me.CONFIG.REQUEST_CONVERT ? 1000 : 100);
                }
            },
            error : function(data) {
                if( !me.CONFIG.SKIP_ERROR ) {
                    me.CONFIG.SKIP_ERROR = true;
                    setTimeout(me.header, me.CONFIG.REQUEST_TIME);
                } else {
                    if( me.CALLBACK.ERROR ) {
                        me.CALLBACK.ERROR('파일 변환요청에 실패하였습니다. 잠시 후 다시 이용해 주세요.\n\nERROR : ' + data.statusText);
                    }
                }
            }
        });
    },

    convert : function() {
        var me = DGB;
        $.ajax({
            url: me.SERVER.URL,
            data: $.param({ url:  encodeURIComponent(me.DATA.url), ext: me.DATA.ext, page: 1, type: me.CONFIG.TYPE }),
            beforeSend : function() { debug("REQUEST CONVERT : " + this.url); },
            success : function() { debug('REQUEST CONVERT SUCCESS!'); me.header(); },
            error : function(data) {
                if( me.CALLBACK.ERROR ) {
                    me.CALLBACK.ERROR('파일 변환요청에 실패하였습니다. 잠시 후 다시 이용해 주세요.\n\nERROR : ' + data.statusText);
                }
            }
        });
    },

    image : function(page, thumb) {
        var me = this;
        return me.SERVER.IMAGE + '?' + $.param({ hash : me.HEADER.MO_HASHCODE, page : page,  type : me.CONFIG.TYPE, thumb : thumb ? 'y' : '' });
    }
};

function debug(msg) {
    if( DGB.LOGGER.DEBUG && console ) { console.debug('DEBUG =====> ' + msg); }
}

function err(msg) {
    if( console ) { console.error("ERROR =====> " + msg); }
}

function dir(val) {
    if( console ) { console.dir(val);}
}