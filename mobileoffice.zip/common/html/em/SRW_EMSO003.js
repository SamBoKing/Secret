(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _famEventGb = undefined;	// 결혼/부고 구분(결혼:10, 부고:20)
	var _rcvEnob = undefined;		// 메시지 받을 사람의 행번 
	var _name = undefined;			// 메시지 받을 사람의 성명 
	var msgSendProcedure = undefined;
    var _layout;

	var pageinit = function(instance) {
		$this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		
		$this.find("#emsoMsgSendBtn").off('vclick').on('vclick',function(){
            //키보드 내리기
            DGB.Common.hideKeyboard();

            $this.find('#emsoMsgSendBtn').focus();

            var freetMaxLan = 80; //byte로 계산 한글 40자, 영문 80자
			var pushCn = $('#emsoSoMsgSend').val();
			if (pushCn == "") {
				showAlert(Messages.msg053);
				return false;
			}
			
			//2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
			pushCn = pushCn.replace( /(\')/g,'\"');
			
			var srccount = getMsgLength(pushCn);
			
			if( srccount > freetMaxLan){
				showAlert("한글 40자,영문 80" + Messages.msg116);
				return;
			}
			
			msgSendProcedure.call(pushCn);
			return false;
		});
		
		msgSendProcedure = {
			options : {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
			},
			call : function(pushCn) {
				dgbLoading(true);
				var invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00005',
					parameters : [{CS_ID :_menuId,
								   SYS_ID : SYS_ID, 
								   DSPT_ENOB : USER_INFO.ENOB,
								   DSPT_COMP_DVCD : USER_INFO.ENTER_CD,
								   RCV_ENOB : _rcvEnob,
								   PUSH_CN :pushCn,
								   ORG_CD :USER_INFO.ORG_CD,
								   D_SENDER :USER_INFO.HP,
								   CS_MMT_YN :"N",	//메시지함 화면 이동여부
								   PSNM : USER_INFO.FSNM,
                                   MESS_USE_YN: 'N'
								   }]
				};
				
				callProcedure(invocationData, this.options);
			}
		};
		
		function displayResult(data) {
			dgbLoading(false);
			showAlert(Messages.msg008);
		}

		function displayError() {
			dgbLoading(false);
			showAlert(Messages.msg008);
		}
	};
	
	function setContents() {
	
		// selectbox value 찾기  - $('#id:selected').val(); , text();
		
		if(_famEventGb == 20) {
			$('#emsoMarryMessageDiv').hide();
			$('#emsoDieMessageDiv').show();
			$('#emsoSoMsgSend').attr("placeholder", "위로메시지를 입력하세요.");
			$('.emsoMessageName').text("부고 위로 메시지");
		} else {
			$('#emsoDieMessageDiv').hide();
			$('#emsoMarryMessageDiv').show();
			$('#emsoSoMsgSend').attr("placeholder", "축하메시지를 입력하세요.");
			$('.emsoMessageName').text("결혼 축하 메시지");
		} 
		$('.emsoReceiveMan').text(_name);
		

		$this.find('.selectBox').change(function() {	
			var selectedVal = "";		// 셀렉트박스에서 선택된 value
			var selectedText = "";		// 셀렉트박스에서 선택된 메시지내용 
			selectedVal = $this.find('.selectBox:visible option:selected').val();
			selectedText = $this.find('.selectBox:visible option:selected').text();
			
			if(selectedVal != 4){
				$this.find('#emsoSoMsgSend').val(selectedText);
			}
			else
			{
				$this.find('#emsoSoMsgSend').val("");
			}	
			
			return false;
		});
		DGB.Common.backPage();
	//	_layout.refreshLayout();
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			//initMenu();
			$('#emsoMarryMessageDiv').hide();
			$('#emsoDieMessageDiv').hide();
			setContents();
            _layout.refreshLayout();
		},
		pagebeforehide: function(evt, ui) {
			$('#emsoSoMsgSend').val('');
			$this.find('.selectBox').val('4');
			$('#emsoMarryMessage').selectmenu('refresh',true);
			$('#emsoDieMessage').selectmenu('refresh',true);
			//dropMenu();
            _menuId = undefined;
            _famEventGb = undefined;
            _rcvEnob = undefined;
            _name = undefined;
		},
		parentpage :function(evt, param) {
			_famEventGb = param.famEventGb;
			_rcvEnob = param.rcvEnob;
			_name = param.name;
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            _layout.refreshLayout();
            return false;
		}
	}, '#EMSO003');
})();
