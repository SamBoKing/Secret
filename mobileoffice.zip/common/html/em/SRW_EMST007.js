(function() {
	var $this = undefined;
	var inqDvcd = "1";  // 조회구분 : 전체(1), 성명(2), 부점(3), 행번(4), 전화번호(5)
	var _menuId = undefined;
	var _layout = undefined;
	var listSearch = null;
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 50; // 한페이지 갯수	
	var btnPress = false; //검색버튼누른경우 flag
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	var _leftmenuinit = false; // left메뉴통해서 들어올경우 입력박스및 nav바 전체검색으로 초기화.
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var _msgReciever = [];
	var _receiverSabun = "";
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);

		$this.find('.searchBtn').on('vclick', function() {
			
			setTimeout(function () {
				emst07Search();
			}, 300);
		});
		
		$this.find('.searchInputBox').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('.searchBtn').focus();
				
				setTimeout(function () {
					emst07Search();
				}, 300);
				
				return false;
			}
		});
		
		//추가확인버튼
		$this.find('#emst07AddFinsh').off('vclick').on('vclick', function(){
			
			var ids = __selectedLists();
			if (ids.length == 0) {
				showAlert(Messages.msg075);
				return false;
			}else{

				locDetailview = true;
				var detailId ="EMST006";
				var args = {};
				args.menuId = _menuId;
				
				args.msgReciever = ids;
				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);

				setTimeout(function () {
					DGB.Page.changePage('#'+detailId,{changeHash: false});
				},400);
				
			}
								
			return false;

		});

	};
	
	//체크박스 선택된 리스트
	var __selectedLists = function() {
		var ids = [];
		$this.find('.emst05-list a.oncheck').each(function(){
			var $li = $(this);
			ids.push(JSON.parse($li.attr('data-item')));
		});
		
		return ids;
	};
	
	function emst07Search(){
		
		_layout.resetLayout(); //스크롤위치 초기화
		_iscrollEnd = false;
		$("#staffListview4").html('');
		$("#emst07Noresult").addClass("displayNone");
		$('#emst07pullUp').css("display", "none");
		
		var param = $this.find('.searchInputBox').val().toUpperCase();

		
		//공백 제거
		param = trim(param);
		
		if (param == "") {
			
			showAlert(Messages.msg021);
			return;
		}
	
		//2자이상 입력하도록
		if( param.length < 2){
			showAlert("2"+Messages.msg115);
			return;
		}
		
		//검색버튼누른경우
		btnPress = true;
		
		//키보드 내리기
		if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
			AndroidNative.hideKeyboard();	
		}
		
		setTimeout(function () {
			listSearch.call(param);
		}, 300);
	}
	
	listSearch = {	
			options : {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
			},

			call : function(param1, param2, param3) {
				
				dgbLoading(true);
				if (arguments.length != 3) {
					param2 = 1; // START_NUM 기본값
					param3 = _pageSize; // EDD_NUM 기본값
					/* 페이징 */
					$('#emst07StNum').val(param2), $('#emst07EdNum').val(param3);
					/* //페이징 */
				}

				invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00009',
					parameters : [{SEARCH : param1
								 , START_NUM : param2
								 , END_NUM : param3
								 , INQ_DVCD : inqDvcd
								 , CS_ID:_menuId
								 , ENCODE_STR : ""}]
				};

				callProcedure(invocationData, this.options);
			}

		};
	
	function displayResult(data) {
		var item = data.invocationResult.resultSet;
		if(item.length === 0) {
			_layout.refreshLayout(function(){
				dgbLoading(false);
				$("#staffListview4").html('');
				$('#emst07pullUp').css("display", "none");
				_iscrollEnd = false;
				btnPress = false;
				$("#emst07Noresult").removeClass("displayNone");
				$("#emst07InputText").text($('#EMST007 .searchInputBox').val());
				
			}, 500);
			
		}
//		else if(item.length === 1) {	// 1명인 경우에는 상세조회화면으로 바로 이동
//
//			locDetailview = true;
//			var detailId ="EMST006";
//			var args = {};
//			args.menuId = _menuId;
//			args.msgReciever = item; //MsgRecieverArray;
//			$("#"+detailId).trigger("parentpage",[args]);
//			
//			setTimeout(function () {
//				DGB.Page.changePage('#'+detailId);
//			},400);
//
//		}
		else {
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].SABUN == "") break;
				var officeTel = item[i].OFFICE_TEL.split(" ");
				//var displayTel = officeTel[1] == undefined ? "053740"+officeTel[0] : officeTel[1]; 
				var displayTel = officeTel[0]; 
				if(_receiverSabun.indexOf(item[i].SABUN) == -1){
				html =  "<li>"+
						"<a href='#' class='emst005List downHeight' data-enob='"+item[i].SABUN+"' data-item='"+JSON.stringify(item[i])+"' data-ispush='"+item[i].ISPUSH+"'>"+	
								"<fieldset class='ui-grid-b'>" +
								"<div class='ui-block-a'>" +
								"<b><h3>"+item[i].NAME+
								"</h3></b>"+
								"<p><font color=darkblue><strong>"+item[i].JIKCHAK+"</strong></font></p>"+
								"</div>" +
								"<div class='ui-block-b' style='width: 20%;padding-top: 6px;'>";
								if (item[i].ISPUSH == "true"){
									html += "<img width='40px' height='40px' src='images/icn_listPush.png'>";
								}
						html +=	"</div> " +				
								"<div class='ui-block-c'> " +
								"<p>&nbsp;</p>"+
								"<p>"+item[i].ORG_NM+"</p>"+
								"<p>"+displayTel+"</p>"+
								"</div>" +
							"</fieldset>" +
						"</a>"+
						"</li>";
						listItems[i] = html;	
				}
			}
				
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#emst07pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#emst07pullUp').css("display", "block");
					$('#emst07StNum').val(
							parseInt($('#emst07StNum').val()) + _pageSize);
					$('#emst07EdNum').val(
							parseInt($('#emst07EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#emst07pullUp').css("display", "none");
			}
			/* //페이징 */
			
			//검색버튼누른경우
			if(btnPress == true) 
			{
				$("#staffListview4").html(listItems.join(''));
				btnPress = false;
			}	
			else
			{
				$("#staffListview4").append(listItems.join(''));
			}	
			listItems = null;
            item = null;
            html = "";
			$("#staffListview4").listview( "refresh" );
			$("#staffListview4").trigger("updatelayout");
			
			//리스트클릭 이벤트  
			$('#staffListview4').find('li a').off('vclick').on("vclick", function(e) {
				e.preventDefault();//href이벤트 막기
				
				var $emst07List = $(this);
				// Check it is under the edit mode.
				if ($this.find('div.emst05-list').hasClass('editMode')) {
					
					$emst07List.toggleClass('oncheck');
					return false;
				}
			});
			
			_layout.refreshLayout(function(){
			   dgbLoading(false);
			}, 500);
		}
	}
	
	function displayError() {
		dgbLoading(false);
	}
	
	function initPageDOM() {
		
		if(locDetailview == false) {
			//화면 초기화
			$("#staffListview4").html(''); //jkhtest
			$('#EMST007 .searchInputBox').val("");
			$("#emst07Noresult").addClass("displayNone");
			$('#emst07pullUp').css("display", "none");
			_iscrollEnd = false;
			btnPress = false;
		}
		locDetailview = false;
	}

	function _pageshow() {
		initPageDOM();
		var receiverName = "";
		_msgReciever.forEach(function(elem) {
			receiverName += elem.NAME + ", ";
			_receiverSabun +=elem.SABUN+ ", ";
		});
				
		var html = "";
		for (var i=0; i<_msgReciever.length; i++) {
			if(_msgReciever[i].SABUN == "") break;
			var officeTel = _msgReciever[i].OFFICE_TEL.split(" ");
			var displayTel = officeTel[0]; 
			html += "<li>";// +
			html += "<a href='#'  class='emst005List downHeight oncheck' data-enob='"+_msgReciever[i].SABUN+"' data-item='"+JSON.stringify(_msgReciever[i])+"' data-ispush='"+_msgReciever[i].ISPUSH+"'>";	
			html +=			"<fieldset class='ui-grid-b'> " +
							"<div class='ui-block-a'> " +
							"<b><h3>"+_msgReciever[i].NAME;
			html += 		"</h3></b>";
			html +=			"<p><font color=darkblue><strong>"+_msgReciever[i].JIKCHAK+"</strong></font></p>"+
							"</div> " +
							"<div class='ui-block-b' style='width: 20%;padding-top: 6px;'> ";
							if (_msgReciever[i].ISPUSH == "true"){
								html += "<img width='40px' height='40px' src='images/icn_listPush.png'>";
							}
					html +=	"</div> " +				
							"<div class='ui-block-c'> " +
							"<p>&nbsp;</p>"+
							"<p>"+_msgReciever[i].ORG_NM+"</p>"+
							"<p>"+displayTel+"</p>"+
							"</div> " +
						"</fieldset> " +
					"</a>"+
					"</li>";
		
		}
		$("#emst07RecieverList").html(html);
		$("#emst07RecieverList").listview( "refresh" );
		$("#emst07RecieverList").trigger("updatelayout");
		
		//리스트클릭 이벤트  
		$('#emst07RecieverList').find('li a').off('vclick').on("vclick", function(e) {
			e.preventDefault();//href이벤트 막기
			
			var $emst07ReceList = $(this);
			// Check it is under the edit mode.
			if ($this.find('div.emst05-list').hasClass('editMode')) {
				$emst07ReceList.toggleClass('oncheck');
				return false;
			}
		});

		DGB.Common.backPage();
		_layout.refreshLayout();
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#EMST007 .searchInputBox').val().toUpperCase(),
			param2 = $('#emst07StNum').val(),
			param3 = $('#emst07EdNum').val();
		if( $this.find('.searchInputBox').val() != "")
		{
			listSearch.call(param1, param2, param3);
		}	
		
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagehide: function(evt, ui) {
			_leftmenuinit = false;
			//초기화
			$('#staffListview4').empty();
			$('#EMST007 .searchInputBox').val("");
			$("#emst07Noresult").addClass("displayNone");
			$('#emst07pullUp').css("display", "none");
			_msgReciever = [];
			_receiverSabun = "";
		},
		parentpage :function(evt, param) {
			_msgReciever = param.msgReciever;
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}

		}
	}, '#EMST007');

	//공백 제거
	function trim(str){
		return str.replace( /(\s*)/g,'');
	}
	
})();
