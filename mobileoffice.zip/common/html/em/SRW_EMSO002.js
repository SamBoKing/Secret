(function() {
	var $this;
    var _layout;
	var _menuId;
	var _eventGb;
	var _eventNo;
	var _item = {};
	
	var pageinit = function(instance) {
		$this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		//푸쉬메시지이동
        $this.find('.transEMSO003').off('vclick').on('vclick',function(){
			if(!loginYN) {
            	return;
            }
			var detailId = "EMSO003";
			var args={};
			args.menuId = _menuId;
			args.famEventGb = $this.find('#emsoFamEventGb').text();
			args.rcvEnob = $this.find('#emsoSabun').text();
			args.name = $this.find('.emsoJikweeName:first').text();

            DGB.Page.triggerPage("#" + detailId, "parentpage", [args]);
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
			return false;
		});
	};
	
	function emsoSetContents() {
		$this.find('#emsoSabun').text(_item.SABUN);							// 행번
        $this.find('#emsoFamEventGb').text(_eventGb);								// 경조사구분(결혼/부고)
        $this.find('.emsoEventTitle').text(_item.TITLE);						// 제목
        $this.find('.emsoOrgNm').text(_item.ORG_NM);							// 소속
        $this.find('.emsoJikweeName').text(_item.JIKWEE+" "+_item.NAME);		// 직위/성명
        $this.find('.emsoFamEventDate').text(_item.FAM_EVENT_DATE);			// 결혼일시, 별세일
        $this.find('.emsoFamEventPlace').text(_item.FAM_EVENT_PLACE);			// 장소, 상가
        $this.find('.emsoGjNo').text(maskingMemo(_item.GJ_NO));								// 메모사항, 계좌번호
		
		if(_eventGb == "20") {		// 부고 
            $this.find('.emsoFamEventContent').text(_item.FAM_EVENT_CONTENT);	// 내용
            $this.find('.emsoTelNo').text(maskingTel(_item.TEL_NO));						// 연락처
            $this.find('.emsoFamEventDateBal').text(_item.FAM_EVENT_DATE_BAL);	// 발인일시
            $this.find('.emsoFamEventJangji').text(_item.FAM_EVENT_JANGJI);	// 장지
            $this.find('#emsoMarry').hide();
            $this.find('#emsoDie').show();
		} else {   // 결혼
            $this.find('#emsoDie').hide();
            $this.find('#emsoMarry').show();
		}
	}

    function maskingTel(tel) {
        /*
        if( !DGB.Auth.Sso.isSso ) {
            var val = tel.split('-');
            if( val.length == 3 ) {
                return '***-****-' + val[2];
            }
            return '***-****-****';
        }
        */
        return tel;
    }

    function maskingMemo(memo) {
        /*
        if( !DGB.Auth.Sso.isSso ) {
            return Messages.msg00F;
        }
        */
        return memo;
    }
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
            DGB.Common.backPage();

			if(!loginYN) {
                $this.find(".storyIcon").addClass("displayNone");
	        } else{
                $this.find(".storyIcon").removeClass("displayNone");
	        }
			emsoSetContents();
            _layout.refreshLayout();
		},
		pagehide: function() {
            $this.find('.initContents').text("");
		},
		parentpage :function (evt, param) {
			_eventGb = param.eventGb;
			_eventNo = param.eventNo;
			_menuId = param.menuId;
			_item = JSON.parse(param.item);
		},
		orientationchange : function() {
            _layout.refreshLayout();
            return false;
		}
	}, '#EMSO002');
	
})();
