(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var _workOrgCd = undefined;	
	var _branchName = undefined;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	var jc1Code = "111,113,139,151,169"; // 책임자
	var jc2Code = "159,191,201,204"; //담당자
	var jc0 ="총괄";
	var jc1 ="책임자";
	var jc2 ="담당자";

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight,_searchHeight);


	};
	
	function searchTaskInfo(){
		dgbLoading(true);
		var invocationData = {
	            adapter : 'SocketTransactionAdapter',
	            procedure : 'TRE00107',
				parameters : [{SEARCHORG_CD : _workOrgCd, CS_ID:_menuId}]
		};
		
		var options = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};
		
		setTimeout(function () {
			callProcedure(invocationData, options);
		}, 300);
		
	}
	function displayResult(data) {
		var item = data.invocationResult.resultSet;
		var html = "";
		var listItems = [];
	
		if(item.length > 0) {
			for (var i=0; i<item.length; i++) {
				var jikchak = item[i].JIKCHAK;
				var split = item[i].TASK_NM.split("]");
				var telNo =item[i].OFFICE_TEL_GUK;
				var task = split[1];
				var faxNo = item[i].FAX;
				if(item[i].MASTER=='Y'){
					jikchak = jc0;
				}else if(item[i].JIKCHAK_CD !="" && jc1Code.indexOf(item[i].JIKCHAK_CD) > -1 ){
					jikchak = jc1;
				}else if(item[i].JIKCHAK_CD !="" && jc2Code.indexOf(item[i].JIKCHAK_CD) > -1 ){
					jikchak = jc2;
				}
				telNo = telNo ||"번호없음";
				faxNo = faxNo ||"번호없음";
				faxNo = faxNo.replace(/^(\d{4})(\d{3})(\d{4})$/,"$1-$2-$3");
				task = task ||"등록된 담당업무가 없습니다.";
//				if(!telNo){
//					telNo = "번호없음";
//				}
//				if(!faxNo){
//					faxNo = "번호없음";
//				}
//				if(!task){
//					task = "등록된 담당업무가 없습니다.";
//				}
				html = "<li>"+
							"<a href='#' class='emtk002List downHeight' id='emtk001List_"+i+"' data-item='"+item[i].OFFICE_TEL_GUK+"' >"+ 
							"<h3><strong  style='color:darkblue;'> - "+task+"</strong></h3>" + 
							"<p style='font-size:14px'><strong> &nbsp;&nbsp;&nbsp;전화 : "+telNo+"&nbsp;&nbsp; ["+jikchak +"]</strong></p>"+
							"<p style='font-size:14px'><strong> &nbsp;&nbsp;&nbsp;팩스 : "+faxNo+"</strong></p>";	
				html +=			"</a>"+
						"</li>";
				listItems[i] = html;
			}
			
			$("#emtk002ListView").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#emtk002ListView").listview( "refresh" );
			$("#emtk002ListView").trigger("updatelayout");
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500); 
		}
		
		//리스트클릭 이벤트
		$('#emtk002ListView').find('li a.emtk002List').off('vclick').on('vclick',function(){
			
			var telNo = $(this).attr('data-item');
			if(telNo){
				location.href ="tel:" + telNo;
			}
			return false;
		});
	}
	function displayError() {
		dgbLoading(false);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backPage();
		},
		pageshow: function() {
			_layout.refreshLayout();
			$("#emtk002SubTitle").html("<strong style='color:darkblue;'>"+_branchName+"</strong> 조회내역입니다. ");
			searchTaskInfo();
		},
		pagehide: function(evt, ui) {
			$("#emtk002ListView").html("");
			$('#EMTK002 #emtkInputSearch').val("");
		},
		parentpage :function (evt, param) {
			parentId = param.parentId;
			_menuId = param.menuId;
			_workOrgCd = param.searchBranch;
			_branchName = param.branchName;
			
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#EMTK002');
})();
