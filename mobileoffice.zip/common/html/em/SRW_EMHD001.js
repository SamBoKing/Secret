(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false

	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_NAVBAR_HEIGHT);

		$this.find('.emhd01BirMsgBtn').off('vclick').on('vclick', function() {
			var checkedItems = $('.emhdBirCheckbox:checked');
			if(checkedItems.length <= 0) {
                showAlert(Messages.msg075);
			} else {
                showDetail(checkedItems, 'birthday');
            }
			return false;
		});
		
		$this.find('.emhd01MarMsgBtn').off('vclick').on('vclick', function() {
			var checkedItems = $('.emhdMarCheckbox:checked');
			if(checkedItems.length <= 0) {
                showAlert(Messages.msg075);
			} else {
                showDetail(checkedItems, 'marryday');
			}
			return false;
		});
	};

    function showDetail(checkedItems, event) {
        var items = [];
        checkedItems.each(function(){
            items.push(JSON.parse($(this).val()));
        });

        var args = {
            menuId : _menuId,
            msgReciever : items,
            eventGb : event
        };
        DGB.Page.triggerPage('#EMHD002', 'parentpage', [args]);
        setTimeout(function () {
            DGB.Page.changePage('#EMHD002');
        },400);
    }

    function sendData() {
        dgbLoading(true);
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TEM00006',
            parameters : [{CS_ID:_menuId, TELLER_NUM : USER_INFO.ENOB}]
        };
        callProcedure(inv, opt);
    };
	
	function onSuccess(data) {
        dgbLoading(false);
		if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
			eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
			return;
		}
        /*
        data.invocationResult.resultSet = [{
                GUBUN2 : '0',
                NAME : 'ABCD',
                ORG_NM : 'YMCA',
                ISPUSH : 'true',
                SABUN : '7130000'
            }
        ];
        */
		var item = data.invocationResult.resultSet;
		var birthListItems = [];
		var marryListItems = [];
		var tempHtml = "";
        var chkClass = "";

		for (var i=0,j=0,k=0; i<item.length; i++) {

			// 용역직원 제외
			if(item[i].SABUN.substr(0,1) == '8') {
				continue;
			}

			if(item[i].SABUN == "")
				break;

			chkClass = (item[i].GUBUN2 == "0") ? 'emhdBirCheckbox' : 'emhdMarCheckbox';

			tempHtml = "<li class='emhdHappdaylist' style='padding: 0; border: 0; margin:0;'>"+
				
			"<fieldset  style='margin: 0;width: 100%;' data-iconpos='right'>"+
			"<input type='checkbox' name='check-choice' id='check-choice-"+i+"' class='" + chkClass + "' value='"+JSON.stringify(item[i])+"' />"+
			"<label for='check-choice-"+i+"' style='border-radius: 0; margin:0;'>"+
			"<div style='float: left; padding-right: 10px;' ><h3>"+ item[i].NAME+
			"</h3><p><strong>"+ item[i].ORG_NM+"</strong></p></div>"+
			"<div class='ui-block-b' style='padding-top: 6px;'>";
			if (item[i].ISPUSH == "true"){
				tempHtml += "<img width='40px' height='40px' src='images/icn_listPush.png'>";
			}
			tempHtml += 			"</div>"+
			"</label>"+
			"<div style='text-align:left; padding:0; margin:0;'>"+
			//"<a href='' style='margin-top:0px; margin-bottom: 10px; height:28px;' class='employee_search' data-enob='"+ item[i].SABUN+"' data-role='button' data-mini='false' data-inline='true' data-theme='b'>직원상세정보</a>"+
			"<button style='margin-top:2px; margin-bottom: 10px; height:28px;' class='employee_search' data-enob='"+ item[i].SABUN+"' data-role='none' >직원정보조회</button>"+
			"</div>"+
			"</fieldset>"+

			"</li>";

			if(item[i].GUBUN2 == "0")
				birthListItems[j++] = tempHtml;
			else
				marryListItems[k++] = tempHtml;
		}

		$("#birthListview:last").append(birthListItems.join(''));
		$("#marryListview:last").append(marryListItems.join(''));

		//리스트클릭 이벤트
		$("#birthListview").find('button.employee_search').off('vclick').on('click',function(){
			var sabun = $(this).attr('data-enob');
			goEmployeeInfo(sabun);
			return false;
		});
		//리스트클릭 이벤트
		$("#marryListview").find('button.employee_search').off('vclick').on('click',function(){
			var sabun = $(this).attr('data-enob');
			goEmployeeInfo(sabun);
			return false;
		});
		birthListItems = null;
		marryListItems = null;
		item = null;
		$(".emhdHappdaylist").trigger("create");
		$("#birthListview").listview( "refresh" );
		$("#marryListview").listview( "refresh" );

		locDetailview = true;
		_layout.refreshLayout();
	}

	function goEmployeeInfo(sabun) {
		var detailId ="EMST002";
		var args={};
		args.menuId = _menuId;
		args.sabun = sabun;

		DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
		setTimeout(function () {
			DGB.Page.changePage('#'+detailId);
		},400);
	}
	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}
	function _pageshow() {
		_layout.refreshLayout();
		DGB.Common.backMenu();
		if( !locDetailview ) {
            sendData();
		}
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
			//2번째 li 부터 삭제
			$("#birthListview").children().not('li:first').remove();
			$("#marryListview").children().not('li:first').remove();
		},
		pagebeforeshow: function() {
			$this.find('#emhd01Navbar').on('vclick','a', function () {
				switch ( $(this).text() ) {
                    case "생일보기":
                        $this.find('#emhd01NavBirth').addClass("ui-state-persist");
                        $this.find("#emhd01NavMarry").removeClass("ui-state-persist");
                        $this.find("#birthListview").removeClass("displayNone");
                        $this.find("#marryListview").addClass("displayNone");
                        $this.find("#birthListview").listview( "refresh" );
                        break;
                    case "결혼기념일보기":
                        $this.find('#emhd01NavMarry').addClass("ui-state-persist");
                        $this.find("#emhd01NavBirth").removeClass("ui-state-persist");
                        $this.find("#marryListview").removeClass("displayNone");
                        $this.find("#birthListview").addClass("displayNone");
                        $this.find("#marryListview").listview( "refresh" );
                        break;
                    default:
                        break;
				}
				_layout.refreshLayout();
			});
			
		},
		pageshow: _pageshow,
		pagebeforehide: function(evt, ui) {
			//체크박스 초기화
			$this.find('[type="checkbox"]').attr("checked",false).checkboxradio('refresh');
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#EMHD001');
})();
