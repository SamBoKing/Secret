(function() {
	var _this, _layout, _menuId, prevPage, is_user;
	var _rcvEnob, _rcvName, _title, btn_edit, btn_send, btn_search;
	var name_area, first_area, second_area, second_area_input, third_area;
	var search_input, name_input, first_select, second_select, second_input, third_select, content;
	var openSenderOn, openSenderOff, openStoryOn, openStoryOff;
	var wink_codes = { codes : [{ items : [] }], moneys : [{ items : []}], isSuccessful : false, isFirst : false };
	var result = { code : {}, money : {} };

	//var selbox1, selbox2, sealValue;
	//selbox1 = ['[선택]','칭찬WINK','감사WINK','격려WINK','축하WINK','사과WINK','기원WINK','나만의 WINK','DGB사랑나눔카드 WINK','해피데이 WINK','스페셜데이 WINK','감사(칭찬,격려)마라톤 WINK','아이디어 PLUS WINK'];
	//selbox2 = new Array();
	//selbox2[0] = ["[선택]"];
	//selbox2[1] = ["[선택]","최고에요","대단해요","당신뿐이에요","You're the best"];
	//selbox2[2] = ["[선택]","감사합니다","고맙습니다.","Thank you"];
	//selbox2[3] = ["[선택]","고생했어요","수고했어요","힘내세요","Cheer up"];
	//selbox2[4] = ["[선택]","축하합니다.","Congratulations"];
	//selbox2[5] = ["[선택]","미안합니다","죄송합니다","화이팅 해요","I'm sorry"];
	//selbox2[6] = ["[선택]","소원합니다","기원합니다","행복하세요","I wish"];
	//selbox2[7] = ["[선택]","나만의 WINK"];
	//selbox2[8] = ["[선택]","별일없제!!",thisYear+"년 기원인사","최고에요","감사합니다","힘내세요","축하합니다","미안합니다","화이팅해요","소원합니다"];
	//selbox2[9] = ["[선택]","생일축하카드","결혼기념일축하카드","수상축하카드","승진축하카드","영전축하카드"];
	//selbox2[10] = ["[선택]","발렌타인데이 사랑카드","화이트데이 사랑카드","빼빼로데이 사랑카드","크리스마스 사랑카드","새해 복 많이 받으세요","넉넉하고 풍요로운 한가위되세요"];
	//selbox2[11] = ["[선택]","당신은 내게 특별한 사람입니다","수고했어요. 역시 최고내요","이번 일은 덕분에 잘 끝났어요","내가 뭐 도와줄 건 없을까요","그래, 당신을 믿어요",
	//	"감각이 돋보여요","조금만 더 참고 고생합시다.","오늘 내가 한잔 살께요.","무엇이든지 잘 할수 있어요.","괜찮아. 실수할 수도 있어요."];
	//selbox2[12] = ["[선택]","조금만 더 다듬으면 보석!","이렇게 하면 좋을 것 같아요.","이건 꼭 필요한 것 같아요.","이건 꼭 개선해 주세요.","이건 꼭 반영해 주세요"];
	//selbox2[13] = ["[선택]","100원","300원","500원"];
	//sealValue = ['0','100','300','500'];
	
	var _pageinit = function() {
		_this = $(this);
		_layout = new DGB.layout(_this, COMMON_PAGE_HEADER_HEIGHT);
		initControl();
	};

	function initControl() {
		// control
		name_area = _this.find('#wk_name_area');
		first_area = _this.find('#wk_first_area');
		second_area = _this.find('#wk_second_area');
		second_area_input = _this.find('#wk_second_area_input');
		third_area = _this.find('#wk_third_area');

		search_input = _this.find('#wk_search_input');
		name_input = _this.find('#wk_name_input');
		first_select = _this.find('#wk_first_select');
		second_select = _this.find('#wk_second_select');
		second_input = _this.find('#wk_second_input');
		third_select = _this.find('#wk_third_select');
		content = _this.find('#wk_content');
		openSenderOn = _this.find('#wk_isOpenSender_on1');
		openSenderOff = _this.find('#wk_isOpenSender_off1');
		openStoryOn = _this.find('#wk_isOpenStory_on');
		openStoryOff = _this.find('#wk_isOpenStory_off');

		btn_edit = _this.find('#btn_edit');
		btn_send = _this.find('#btn_send');
		btn_search = _this.find('#btn_search');

		// event
		btn_edit.on('vclick', onClickSend);
		btn_send.on('vclick', onClickSend);
		btn_search.on('vclick', function() {
			if( is_user ) {
				alert ('[' + result.code.title + '] 윙크할사람을 변경할 수 없습니다.');
			} else if ( searchValueCheck() ) {
				searchRequest();
			}
			return false;
		});

		first_select.on('change',function() {
			if( is_user ) {
				name_area.val('');
				name_area.hide();
				is_user = false;
			}

			_title = "";
			result.money = wink_codes.moneys[0];

			// 하위메뉴 아이템이 없으면 입력화면으로 전환
			var index = first_select.find('option:selected').attr('data-index') || 0;
			result.code = wink_codes.codes[index];
			if( result.code && result.code.items ) {
				second_area.show();
				second_area_input.hide();
			} else {
				second_area.hide();
				second_area_input.show();
			}

			if( result.code.users && result.code.users.length > 0 ) {
				is_user = true;
				var user = result.code.users[0];
				_rcvEnob = user.enob;
				_rcvName = user.name;
				name_area.show();
				name_input.val(_rcvName +"("+_rcvEnob+")");
				_layout.refreshLayout();
			}
			initSecondSelection();
			return false;
		});

		third_select.on('change',function(){
			var index = third_select.find('option:selected').attr('data-index');
			result.money = wink_codes.moneys[index];
			return false;
		});

		search_input.on('keypress', function(e){
			if( e.keyCode == 13 ) {
				if( searchValueCheck() ){
					DGB.Common.hideKeyboard();
					btn_search.focus();
					setTimeout(searchRequest, 300);
				}
				return false;
			}
		});
	}

	var _pagebeforeshow = function() {
		DGB.Common.backPage();
		prevPage = $('#EMWK001');

		if( wink_codes.isSuccessful )
			initSelection();
		else
			requestCode();

		content.height('150px').val('');
		_layout.refreshLayout();
	};

	function requestCode() {
		var opt = {
			onSuccess: onSuccessCode,
			onFailure: onFailureCode,
			invocationContext: {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GW_WINK0007',
			parameters : [{
				CS_ID : _menuId
			}]
		};

		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessCode(data) {
		dgbLoading(false);
		wink_codes = data.invocationResult;
		initSelection();
	}

	function onFailureCode() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}


	function sendWinkTalk() {
		var opt = {
			onSuccess: onSuccess,
			onFailure: onFailure,
			invocationContext: {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GW_WINK0004',
			parameters : [{
				CS_ID : _menuId,
				ENOB : USER_INFO.ENOB,
				NAME : USER_INFO.FSNM,
				RCVENOB : _rcvEnob,
				RCVNAME : _rcvName,
				TITLE : result.code.code,
				SUBTITLE : _title.replace(/(\")/g,'\''),
				CONTENT : content.val().replace(/(\")/g,'\''),
				SEALMOUNT : result.money.code || '0',
				OPENYN : openSenderOn.prop("checked")?'Y':'N',
				OPENYN2 : openStoryOn.prop("checked")?'Y':'N'
			}]
		};

		// OID, ENOB, NAME, RCVENOB, RCVNAME, RCVDEPT, TITLE, SUBTITLE, CONTENT, SEALMOUNT, ISOPENSENDER, ISOPENSTORY
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		dgbLoading(false);
		// Data : { "success" : "true", "OID" : "114121112572061" }
		var item = data.invocationResult;
		var success = ( item.OID && item.OID > -1 );
		showAlert(success ? Messages.msg618 : Messages.msg619);

		if(success) {
			if( prevPage ) prevPage.data('refresh', true);
			initSelection();
		}
	}

	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	function searchRequest() {
		var opt = {
			onSuccess: onSearchSuccess,
			onFailure: onSearchFailure,
			invocationContext: {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GW_WINK0006',
			parameters : [{
				CS_ID : _menuId,
				SEARCH : search_input.val() || '',
				START : '1',
				END : '500'
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSearchSuccess(data) {
		dgbLoading(false);

		var result = data.invocationResult;
		var items = result.items;
		if(items.length == 0){
			showAlert(Messages.msg620);
		} else {
			var nameList =[];
			for(var i = 0; i < items.length;i++){
				var item = items[i];
				// 자기자신한테 윙크톡 안보내짐
				if( item.UniqueName == USER_INFO.ENOB )
					continue;

				var company = item.DGBFN_NAME.replace('대구', '').replace('DGB', '');
				var title = item.WinkName + "(" + company + ") - " + item.Dept_Name;
				nameList.push(title);
			}

			DGB.Common.selectList('검색결과 - ' + nameList.length + '건',
				nameList,
				function (index) {
					_rcvEnob = items[index].UniqueName;
					_rcvName = items[index].WinkName;
					name_area.show();
					search_input.val('');
					name_input.val(_rcvName +"("+_rcvEnob+")");
					name_input.focus();
					_layout.refreshLayout();
				},
				function () { }
			);
		}
	}

	function onSearchFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	var onClickSend = function() {
		DGB.Common.hideKeyboard();
		content.blur();

		if( !valueCheck() )
			return false;

		sendWinkTalk();
	};

	var searchValueCheck = function() {
		var text = search_input.val() || '';
		if( text.length < 2 ){
			showAlert(Messages.msg518);
			return false;
		}
		return true;
	};

	var valueCheck = function() {
		// 나만의 윙크여부에 따라 입력한 내용을 전송
		_title = ( result.code.items ) ? second_select.find('option:selected').val() : second_input.val();
		if ( !_rcvEnob ) {
			showAlert(Messages.msg617);
			return false;
		} else if( !content.val() ) {
			showAlert(Messages.msg610);
			return false;
		} else if( first_select.find('option:selected').val() == '' ) {
			showAlert(Messages.msg614);
			return false;
		} else if( !_title ){
			showAlert(Messages.msg615);
			return false;

		} else if( result.code.is_money && third_select.find('option:selected').val() == '' ){
			showAlert(Messages.msg616);
			return false;
		}
		return true;
	};

	// 선택 영역 초기화
	function initSelection(){
		initFirstSelection();
		initSecondSelection();
		initThirdSelection();
		initOther();
	}

	function initOther(){
		name_area.hide();
		third_area.hide();
		second_area_input.hide();
		second_input.val('');
		second_area.show();
		search_input.val('');
		name_input.val('');
		openSenderOn.prop('checked', true).checkboxradio("refresh");
		openSenderOff.prop('checked', false).checkboxradio("refresh");
		openStoryOn.prop('checked', false).checkboxradio("refresh");
		openStoryOff.prop('checked', true).checkboxradio("refresh");

		_title = '';
		_rcvEnob = '';
		_rcvName = '';
		content.val('');
	}

	// 선택 박스 초기화
	function initFirstSelection() {
		if( !wink_codes.isFirst ) {
			var codes = wink_codes.codes;
			for(var i = 0; i < codes.length; i++) {
				var code = codes[i];
				first_select.append("<option data-index=" + i + " value='" + (code.code || '') + "'>" + code.title + "</option>");
			}
			wink_codes.isFirst = true;
		}

		if( wink_codes.codes.length > 0 ) {
			first_select.find('option:selected').attr("selected", false);
			first_select.selectmenu('refresh');
			first_select.find('option:eq(0)').attr("selected", "selected");
			result.code = wink_codes.codes[0];
		}
		first_select.selectmenu('refresh');
	}

	function initSecondSelection() {
		second_select.html('');
		if( result.code.items ) {
			for(var i = 0; i < result.code.items.length; i++) {
				var item = result.code.items[i];
				second_select.append("<option data-index=" + i + " value='" + (item.code || '') + "'>" + item.title + "</option>");
			}
			second_select.selectmenu('refresh');
		}

		if( result.code.is_money ) {
			third_area.show();
			third_select.val('[2]');
			third_select.selectmenu('refresh',true);
		} else {
			third_area.hide();
		}
		_layout.refreshLayout();
	}

	function initThirdSelection(){
		if( !third_select.find('option:selected').val() ) {
			var moneys = wink_codes.moneys;
			for(var i = 0; i < moneys.length; i++) {
				var money = moneys[i];
				third_select.append("<option data-index=" + i + " value='" + (money.code || "") + "'>" + money.title + "</option>");
			}
		} else {
			third_select.find('option:eq(0)').attr("selected", "selected");
		}
		third_select.selectmenu('refresh');
	}

	$(document).on({
		pageinit : _pageinit,
		pagebeforeshow : _pagebeforeshow,
		parentpage : function(evt, param) {
			_menuId = param.menuId;
		},
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
			_layout.refreshLayout();
			return false;
		}
	}, '#EMWK002');
})();