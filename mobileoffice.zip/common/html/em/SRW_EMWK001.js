(function() {
	var $this;
	var _menuId;
	var _layout;
	var _recvTotalCnt = 0, _sendTotalCnt = 0;

	var _pageinit = function() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		$this.find('#btnOpenWkSendPage').off('vclick').on('vclick', onClickSend);
		$this.find('#emwkMajorListview').find('li a.emwk001List').off('vclick').on('vclick',onClickSend);
	};

	var onClickSend = function() {
		var pageId = $(this).attr('data-pageId');
		var args = {
			menuId : $(this).attr('data-menuId'),
			totalCnt : (_menuId == 'EM0503') ? _recvTotalCnt : _sendTotalCnt
		};

		if( pageId ) {
			DGB.Page.triggerPage("#"+pageId, 'selectmenu', [args]);
			DGB.Page.changePage('#'+pageId);
		}
		return false;
	};

	function _pageshow() {
		DGB.Common.backMenu();
		$this.find('#recvWinkMenu').text('받은 윙크톡 ('+_recvTotalCnt+')');
		$this.find('#sendWinkMenu').text('보낸 윙크톡 ('+_sendTotalCnt+')');
		_layout.refreshLayout();
		if( $this.data('refresh') || (_recvTotalCnt == 0 && _sendTotalCnt == 0 ) ) {
			$this.data('refresh', false);
			request();
		}
	}

	function request() {
		var opt = {
			onSuccess: onSuccess,
			onFailure: onFailure,
			invocationContext: {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GW_WINK0001', // 윙크톡등록
			parameters : [{
				CS_ID : _menuId,
				ENOB : USER_INFO.ENOB
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		dgbLoading(false);
		//{ "success" : "true", "RECVCOUNT" : [0, 1, 2...], "SNDCOUNT" : [0, 1, 2...] }
		var item = data.invocationResult;
		if(item.RECVCOUNT && item.SNDCOUNT ) {
			_recvTotalCnt = 0;
			_sendTotalCnt = 0;
			for(var i = 0; i < item.RECVCOUNT.length; i++){
				_recvTotalCnt += item.RECVCOUNT[i];
				_sendTotalCnt += item.SNDCOUNT[i];
			}
		}
		$('#recvWinkMenu').text('받은 윙크톡 ('+_recvTotalCnt+')');
		$('#sendWinkMenu').text('보낸 윙크톡 ('+_sendTotalCnt+')');
		DGB.Common.refreshLayout(_layout);
	}

	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
		DGB.Common.refreshLayout(_layout);
	}

	$(document).on({
		pageinit: _pageinit,
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulldownrefresh : function() {
			request();
		}
	}, '#EMWK001');
})();