(function() {
	var $this = undefined;
	var inqDvcd = "1";  // 조회구분 : 전체(1), 성명(2), 부점(3), 행번(4), 전화번호(5)
	var _menuId = undefined;
	var _layout = undefined;
	var listSearch = null;
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수	
	var btnPress = false; //검색버튼누른경우 flag
	
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _navbarHeight = COMMON_NAVBAR_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight, _navbarHeight+_searchHeight);

		// Header Button Event Handler
		$this.find('.searchBtn').off('vclick').on('vclick', function() {
			
			_layout.resetLayout(); //스크롤위치 초기화
			_iscrollEnd = false;
			$("#staffListview2").empty();
			$("#emst04Noresult").addClass("displayNone");
			$('#emst04pullUp').css("display", "none");
			
			var param = $this.find('.searchInputBox').val();
			
			if (param == "") {
				showAlert(Messages.msg021);
				return;
			}

			//검색버튼누른경우
			btnPress = true;
            //키보드 내리기
            DGB.Common.hideKeyboard();

            setTimeout(function () {
                listSearch.call(param);
            }, 300);

			return false;
		});
	};

	var __responseResult = function(detailId ,mailuser, mailId) {
		var args={};
		args.usermail = "'"+mailuser+"'<"+mailId+">";

        DGB.Page.triggerPage("#"+detailId, "response", [args]);
        setTimeout(function () {
            DGB.Page.changePage("#"+detailId);
        }, 100);
	};
	
	listSearch = {	
			options : {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
			},

			call : function(param1, param2, param3) {

				dgbLoading(true);
				if (arguments.length != 3) {
					param2 = 1; // START_NUM 기본값
					param3 = _pageSize; // EDD_NUM 기본값
					/* 페이징 */
					$('#emst04StNum').val(param2), $('#emst04EdNum').val(param3);
					/* //페이징 */
				}

				var invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00001',
					parameters : [{SEARCH : param1
								 , START_NUM : param2
								 , END_NUM : param3
								 , INQ_DVCD : inqDvcd
								 , CS_ID:_menuId
								 , ENCODE_STR : ""}]
				};

				callProcedure(invocationData, this.options);
			}

		};
	
	
	
	function displayResult(data) {
		var item = data.invocationResult.resultSet;
		var startPage = $('#emst04StNum').val() + '';
		if(item.length === 0) {
			$("#emst04Noresult").removeClass("displayNone");
			$("#emst04InputText").text( $this.find('.searchInputBox').val() );
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
			
		} else if(item.length === 1 && startPage == '1') {	// 1명인 경우에는 상세조회화면으로 바로 이동
			dgbLoading(false);
			__responseResult("GREM001" , item[0].NAME, item[0].MAIL);
		} else {
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				var officeTel = item[i].OFFICE_TEL.split(" ");
				//var displayTel = officeTel[1] == undefined ? "053740"+officeTel[0] : officeTel[1]; 
				var displayTel = officeTel[0]; 
				html = "<li>" +
							"<a href='#'  class='emst004List' data-mailUser='"+item[i].NAME+"' data-mailId='"+item[i].MAIL+"' >" + 
								"<fieldset class='ui-grid-b'> " +
									"<div class='ui-block-a'> " +
										"<b><h3>"+item[i].NAME+"</h3></b>"+
										"<p><font color=darkblue><strong>"+item[i].JIKCHAK+"</strong></font></p>"+
									"</div> " +
									"<div class='ui-block-b'> " +
										"<p>&nbsp;</p>"+
										"<p>"+item[i].ORG_NM+"</p>"+
										"<p>"+displayTel+"</p>"+
									"</div> " +
								"</fieldset> " +
							"</a>"+
						"</li>";
				listItems[i] = html;
			}
				
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#emst04pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#emst04pullUp').css("display", "block");
					$('#emst04StNum').val(
							parseInt($('#emst04StNum').val()) + _pageSize);
					$('#emst04EdNum').val(
							parseInt($('#emst04EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#emst04pullUp').css("display", "none");
			}
			/* //페이징 */
			//검색버튼누른경우
			if(btnPress == true) 
			{
				$("#staffListview2").html(listItems.join(''));
				btnPress = false;
			}	
			else
			{
				$("#staffListview2").append(listItems.join(''));
			}	
			listItems = null;
            item = null;
            html = "";
			$("#staffListview2").listview( "refresh" );
			$("#staffListview2").trigger("updatelayout");

			//리스트클릭 이벤트
			$('#staffListview2').find('li a.emst004List').off('vclick').on('vclick',function(){
				var mailuser = $(this).attr('data-mailUser');
				var mailId = $(this).attr('data-mailId');
				__responseResult("GREM001", mailuser, mailId);
				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}
	}

	function displayError() {
		dgbLoading(false);
        showAlert(Messages.err001);
	}
	
	function initPageDOM() {
		
		//통합조회
		$this.find("h1").text('통합조회');
		$this.find('.searchInputBox').attr("placeholder","성명(초성)/부점/행번");
		$this.find('[data-role="navbar"]').show();
		$this.find('[data-role="navbar"] a:first').addClass("ui-btn-active");
		
		//화면 초기화
		$("#staffListview2").empty();
		$('#EMST004 .searchInputBox').val("");
		$("#emst04Noresult").addClass("displayNone");
		$('#emst04pullUp').css("display", "none");
		_iscrollEnd = false;
		btnPress = false;
	}

	function _pageshow() {
        DGB.Common.backPage();

		initPageDOM();
		_layout.refreshLayout();
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#EMST004 .searchInputBox').val(),
			param2 = $('#emst04StNum').val(),
			param3 = $('#emst04EdNum').val();
		if( $('#EMST004 .searchInputBox').val() != "") {
			listSearch.call(param1, param2, param3);
		}	
		
	}
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			$this.find('#emstNavbar2').off('vclick').on('vclick', 'a', function () {
				var currentNav = $(this).text();
                var placeholder = "";
				switch (currentNav) {
                    case "성명":
                        inqDvcd = "2";
                        placeholder = "성명(초성)";
                        break;
                    case "부점":
                        inqDvcd = "3";
                        placeholder = "부점";
                        break;
                    case "행번":
                        inqDvcd = "4";
                        placeholder = "행번";
                        break;
                    default:
                        inqDvcd = "1";
                        placeholder = "성명(초성)/부점/행번";
                        break;
				}
                $this.find('.searchInputBox').val("");
                $this.find('.searchInputBox').attr("placeholder", placeholder);
                return false;
			});
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			var options = param.options;
			if (options) {
				inqDvcd = options.type;
				$('#EMST004 .searchInputBox').val(options.keyword);
				$('#EMST004 .searchBtn').trigger('vclick');
			}
			if (param.activePage) { //pageshow와 동일한동작
				_pageshow();
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#EMST004');
})();
