(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT*2;
	var arrChosung =[] ;
	var arrORGData=[];
	var arrSearchIdx=[];
	var searchCount = 0;
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$this.find('#emtkSearchBtn').on('vclick', function() {
			//emtk01Search();
			DGB.Common.hideKeyboard();
			setTimeout(function () {
				searchText();
			}, 300);
			
			
		});
		
		$this.find('#emtkInputSearch').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('#emtkSearchBtn').focus();
				//emtk01Search();
				DGB.Common.hideKeyboard();
				setTimeout(function () {
					searchText();
				}, 300);
				return false;
			}
		});
		
	};
	
	function emtk01Search(){
		
		dgbLoading(true);
		var invocationData = {
				adapter : 'DBTransactionAdapter',
				procedure : 'TRE00003',
				parameters : [{SEARCH_ORG_NM : '', CS_ID:_menuId}]
				//parameters : [{SEARCH_ORG_NM : param, CS_ID:_menuId}]
		};
		
		var options = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};
		
		setTimeout(function () {
			callProcedure(invocationData, options);
		}, 300);
		
	}

	function isChoSungSearching(text) {
		return (text == getChoSung(text));
	}

	function searchText(){
		var searchText = $('#EMTK001 #emtkInputSearch').val().toUpperCase();
		searchText = searchText.replace(/</gi, '&lt;').replace(/>/gi, '&gt;');

		if (searchText.length < 2) {
			showAlert(Messages.msg057);
			//dgbLoading(false);
			return;
		}
		if(arrChosung.length < 2 && searchCount < 2){
			searchCount++;
			emtk01Search();
			return;
		}
		searchCount = 0;
		arrSearchIdx =[];
		var j=0;
		if(isChoSungSearching(searchText)){
			for(var i=0; i< arrChosung.length;i++){
				if(arrChosung[i].indexOf(searchText) >-1){
					arrSearchIdx[j++]=i;
				}
			}
		}else{
			for(var i=0; i< arrORGData.length;i++){
				if(arrORGData[i].indexOf(searchText)>-1){
					arrSearchIdx[j++]=i;
				}
			}	
		}
		setListView(searchText);
	}
	function setListView(searchText){
		var html = "";
		var listItems = [];
		if(arrSearchIdx.length == 0) {
			dgbLoading(false);
			$("#emtk001Listview").html("");
        	$("#emtk001SubTitle").html("<strong style='color:darkblue;'>"+searchText +"</strong>에 대한 검색 결과가 없습니다.");
       		return;
		}		
		$("#emtk001SubTitle").html("<strong style='color:darkblue;'>"+searchText +"</strong>에 대한 검색 결과가 <strong style='color:darkblue;'>"+arrSearchIdx.length+"건</strong> 있습니니다.");
		
		for (var i=0; i<arrSearchIdx.length; i++) {
			html =  "<li>"+
						"<a href='#' class='emtk001List' id='emtk001List_"+i+"' data-brnm='"+arrORGData[arrSearchIdx[i]]+"'>"+ 
							"<h3>"+arrORGData[arrSearchIdx[i]]+"</h3>"+
						"</a>"+
					"</li>";
			listItems[i] = html;
		}
		
		$("#emtk001Listview").html(listItems.join(''));
		listItems = null;
        item = null;
        html = "";

		$("#emtk001Listview").listview( "refresh" );
		$("#emtk001Listview").trigger("updatelayout");
		if(arrSearchIdx.length == 1) {
			var args={};
			var detailId ="EMTK002"; 
			var branchName = arrORGData[arrSearchIdx[0]];
			args.searchBranch = Number(branchName.substring(1,4));
			args.branchName = branchName;
			args.menuId = _menuId;
            DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
			
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
			return;
		}
		_layout.refreshLayout(function(){
			//dgbLoading(false);
		}, 500); 
		

		//리스트클릭 이벤트
		$('#emtk001Listview').find('li a.emtk001List').off('vclick').on('vclick',function(){
			var branchName = $(this).attr('data-brnm');
			var orgCd = Number(branchName.substring(1,4));
			var detailId ="EMTK002"; 
			var args={};
			args.searchBranch = orgCd;
			args.branchName = branchName;
			args.menuId = _menuId;
            DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
			
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
			return false;
		});
	}
	function displayResult(data) {
    	arrChosung=[];
    	arrORGData=[];
		var item = data.invocationResult.resultSet;
		for (var i=0; i<item.length; i++) {
			var chosung = getChoSung(item[i].ORG_NM);
			arrChosung[i] = chosung;
			arrORGData[i] = item[i].ORG_NM;
		}
		dgbLoading(false);
		if(searchCount > 0){
			searchText();
		}
	}

	function displayError() {
		dgbLoading(false);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function() {
			if(arrChosung.length < 2)
				emtk01Search();
			_layout.refreshLayout();
		},
		pagehide: function(evt, ui) {
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		parentpage :function (evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#EMTK001');
})();
