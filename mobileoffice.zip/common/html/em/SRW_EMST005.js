(function() {
	var $this = undefined;
	var inqDvcd = "1";  		// 조회구분 : 전체(1), 성명(2), 부점(3), 행번(4), 전화번호(5)
	var _menuId = undefined;
	var _layout = undefined;
	var _iscrollEnd = false; 	// 마지막 페이지
	var _pageSize = 50; 		// 한페이지 갯수	
	var btnPress = false; 		// 검색버튼누른경우 flag
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	var _buttonHeight = 57;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight, _searchHeight+_buttonHeight);

		$this.find('.searchBtn').off('vclick').on('vclick', function() {
            //키보드 내리기
            DGB.Common.hideKeyboard();
            $this.find('.searchBtn').focus();
            setTimeout(function () {
                search();
            }, 300);
            return false;
		});
		
		$this.find('.searchInputBox').off('keypress').on('keypress', function(e){
			if( e.keyCode == 13 ) {
                //키보드 내리기
                DGB.Common.hideKeyboard();
                $this.find('.searchBtn').focus();
                setTimeout(function () {
                    search();
                }, 300);
                return false;
			}
		});

        // 메시지 전송 버튼
        $this.find('#emst05SendBtn').off('vclick').on('vclick', function(){
            var items = getSelectList();
            if (items.length == 0) {
                showAlert(Messages.msg075);
            } else {
                showDetail(items);
            }
            return false;
        });
	};

    function search() {
        _layout.resetLayout(); //스크롤위치 초기화
        _iscrollEnd = false;
        $("#staffListview3").html('');
        $("#emst05Noresult").addClass("displayNone");
        $('#emst05pullUp').css("display", "none");

        var param = $this.find('.searchInputBox').val().toUpperCase();
        param = param.replace( /(\s*)/g,'');        // 공백 제거
        if( param == "" ) {
            showAlert(Messages.msg021);
            return;
        }

        //2자이상 입력하도록
        if( param.length < 2){
            showAlert("2" + Messages.msg115);
            return;
        }

        //검색버튼누른경우
        btnPress = true;

        // 리스트 요청
        sendData(param);
    }

    function sendData(param1, param2, param3) {
        dgbLoading(true);

        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        }

        if (arguments.length != 3) {
            param2 = 1; // START_NUM 기본값
            param3 = _pageSize; // EDD_NUM 기본값

            /* 페이징 */
            $('#emst05StNum').val(param2);
            $('#emst05EdNum').val(param3);
        }

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TEM00009',
            parameters : [{SEARCH : param1
                , START_NUM : param2
                , END_NUM : param3
                , INQ_DVCD : inqDvcd
                , CS_ID:_menuId
                , ENCODE_STR : ""}]
        };
        callProcedure(inv, opt);
    }

	function onSuccess(data) {
		var item = data.invocationResult.resultSet;
		if(item.length === 0) {
			_layout.refreshLayout(function(){
                dgbLoading(false);
				$("#staffListview3").html('');
				$('#emst05pullUp').css("display", "none");
				_iscrollEnd = false;
				btnPress = false;
				$("#emst05Noresult").removeClass("displayNone");
				$("#emst05InputText").text($('#EMST005 .searchInputBox').val());
			}, 500);
		} else if(item.length === 1) {	// 1명인 경우에는 상세조회화면으로 바로 이동
            showDetail(item);
		} else {
			var html = '';
            var listHtml = [];
			for (var i = 0; i < item.length; i++) {
				if(item[i].SABUN == "")
                    break;

				var officeTel = item[i].OFFICE_TEL.split(" ");
				var displayTel = officeTel[0];

				html += "<li>" +
						"<a href='#'  class='emst005List downHeight' data-enob='"+item[i].SABUN+"' data-item='"+JSON.stringify(item[i])+"' data-ispush='"+item[i].ISPUSH+"'>" + 
							"<fieldset class='ui-grid-b'> " +
								"<div class='ui-block-a'> " +
								"<b><h3>"+item[i].NAME;
				html += 		"</h3></b>";
				html +=			"<p><font color=darkblue><strong>"+item[i].JIKCHAK+"</strong></font></p>"+
								"</div> " +
								"<div class='ui-block-b' style='width: 20%;padding-top: 6px;'> ";
								if (item[i].ISPUSH == "true"){
									html += "<img width='40px' height='40px' src='images/icn_listPush.png'>";
								}
				html +=	        "</div> " +
								"<div class='ui-block-c'> " +
								"<p>&nbsp;</p>"+
								"<p>"+item[i].ORG_NM+"</p>"+
								"<p>"+displayTel+"</p>"+
								"</div> " +
							"</fieldset> " +
						"</a>"+
						"</li>";

                listHtml.push(html);
                html = '';
			}
				
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#emst05pullUp').css("display", "none");
					_iscrollEnd = true;
				} else {
					$('#emst05pullUp').css("display", "block");
					$('#emst05StNum').val(parseInt($('#emst05StNum').val()) + _pageSize);
					$('#emst05EdNum').val(parseInt($('#emst05EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#emst05pullUp').css("display", "none");
			}

			//검색버튼누른경우
			if( btnPress ) {
				$("#staffListview3").html(listHtml.join(''));
			} else {
				$("#staffListview3").append(listHtml.join(''));
			}
            listHtml = null;
            btnPress = false;
			
			$("#staffListview3").listview( "refresh" );
			$("#staffListview3").trigger("updatelayout");
			
			//리스트클릭 이벤트  
			$('#staffListview3').find('li a').off('vclick').on("vclick", function(e) {
				var $emst05List = $(this);
				// Check it is under the edit mode.
				if ($this.find('div.emst05-list').hasClass('editMode')) {
					$emst05List.toggleClass('oncheck');
				}
                return false;
			});
			
			// 선택 취소버튼
			$this.find('#emst05NoBtn').off('vclick').on('vclick', function(){
                $this.find('.emst05-list a').removeClass('oncheck');
                return false;
			});

			// 전체 선택버튼
			$this.find('#emst05AllBtn').off('vclick').on('vclick', function(){
                $this.find('.emst05-list a').addClass('oncheck');
                return false;
			});
			
			_layout.refreshLayout(function(){
                dgbLoading(false);
			}, 500);
		}
	}
	
	function onFailure() {
		dgbLoading(false);
        showAlert(Messages.err001);
	}

    function getSelectList() {
        var items = [];
        $this.find('.emst05-list a.oncheck').each(function() {
            items.push(JSON.parse($(this).attr('data-item')));
        });
        return items;
    }

    function showDetail(itmes) {
        var args = {
            menuId : _menuId,
            msgReciever : itmes
        };
        DGB.Page.triggerPage("#EMST006", "parentpage", [args]);
        DGB.Page.changePage('#EMST006');
    }

	function _pageshow() {
		$('#emst05pullUp').css("display", "none");
		DGB.Common.backMenu();
		_layout.refreshLayout();
	}

	// 당겨서 추가
	function pullUpAdd() {
        if( $this.find('.searchInputBox').val() != "" ) {
            var param1 = $('#EMST005 .searchInputBox').val().toUpperCase(),
                param2 = $('#emst05StNum').val(),
                param3 = $('#emst05EdNum').val();

			sendData(param1, param2, param3);
		}
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagehide: function() {
			//화면 초기화
			$("#staffListview3").html(''); //jkhtest
			$('#EMST005 .searchInputBox').val("");
			$("#emst05Noresult").addClass("displayNone");
			$('#emst05pullUp').css("display", "none");
			_iscrollEnd = false;
			btnPress = false;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			if (param.activePage) {
				_pageshow();
			}
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#EMST005');
})();
