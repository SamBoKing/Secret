(function() {
	var $this;
    var _layout;
	var _menuId;
	var msgSendProcedure;
	var _msgReciever = [];
	var _msgeventGb = "";
	var _issms = false; //sms 전송자 체크
	
	var pageinit = function(instance) {
		$this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		
		$this.find('#emhd02HappydayMsgBtn').off('vclick').on('vclick', function() {
            DGB.Common.hideKeyboard();
            $this.find('#emhd02HappydayMsgBtn').focus();

			// 푸쉬 전송 처리
			var param = _msgReciever;	// 메시지 받을 사람 배열 파라미터
			var rcvEnobs = "";	        // 받을사람행번
			var rcvNames = "";	        // 받을사람이름
			var freetMaxLan = 80;       // byte 로 계산 한글 40자, 영문 80자
			var pushCn = "";            // 전송메시지

			$.each(param, function(index, value) {
				if (index != 0) {
					rcvEnobs += "," + value.SABUN;
					rcvNames += "," + value.NAME;
				}else {
					rcvEnobs = value.SABUN;
					rcvNames = value.NAME;
				}
			});
            pushCn = $this.find('#emhd02HappydayMsgTxt').val();

			var srccount = getMsgLength(pushCn);
			if (pushCn == "") {
				showAlert(Messages.msg053);
				return false;
			}
			//2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
			pushCn = pushCn.replace( /(\')/g,'\"');
			if(_issms  && (srccount > freetMaxLan) ){
				showAlert("한글 40자,영문 80" + Messages.msg116);
				return;
			}

			if(_msgReciever.length > 1) {
				var s_data = rcvNames;
				var arr_data = s_data.split(",");
				var first_name = arr_data[0];
				var sendcount = _msgReciever.length -1;
				showConfirm(function(btn){
					if (btn == '1') {
						msgSendProcedure.call(rcvEnobs, rcvNames, pushCn);
					}
				},  Messages.msg124+"\n전송 : "+first_name + " 외 "+ sendcount +"명" );
			}
			else
			{
				msgSendProcedure.call(rcvEnobs, rcvNames, pushCn);
			}
			return false;
		});
		
		msgSendProcedure = {
			options : {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
			},
			call : function(rcvEnobs, rcvNames, pushCn) {
                var checked = $this.find('#ckbMessUseYn').prop('checked');

				dgbLoading(true);
				var invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00007',
					parameters : [{CS_ID :_menuId,
								   SYS_ID : SYS_ID, 
								   DSPT_ENOB : USER_INFO.ENOB,
								   DSPT_COMP_DVCD : USER_INFO.ENTER_CD,
								   RCV_ENOBS : rcvEnobs,
								   RCV_NAMES : rcvNames,
								   PUSH_CN :pushCn,
								   D_SENDER :USER_INFO.HP,
								   ORG_CD :USER_INFO.ORG_CD,
								   CS_MMT_YN :"N",	//메시지함 화면 이동여부
								   PSNM : USER_INFO.FSNM,
                                   MESS_USE_YN : checked ? 'Y' : 'N'
								   }]
				};
				callProcedure(invocationData, this.options);
			}
		};
		
		function displayResult(data) {
            dgbLoading(false);
			var result = data.invocationResult;
			if (result.count == 0) {
				showAlert(Messages.msg010);	//메시지전송 실패하였습니다.
                return;
			}

            var s_data = result.RCV_NAMES;
            var arr_data = s_data.split(",");
            var first_name = arr_data[0];
            var sendcount = result.count - 1;
            $this.find('#emhd02HappydayMsgTxt').val('');
            $this.find('#ckbMessUseYn').prop('checked', false).checkboxradio('refresh');
            if(result.count == 1) {	// 1명인 경우
				showAlert(Messages.msg008+"\n전송 : "+result.RCV_NAMES);
			} else {
				showAlert(Messages.msg008+"\n전송 : "+first_name + " 외 "+ sendcount +"명" );
			}
		}

		function displayError() {
			dgbLoading(false);
			showAlert(Messages.msg010);
		}
	};
	
	function setContents() {
		var receiverName = "";
		_msgReciever.forEach(function(elem) {
			receiverName += elem.NAME + ", ";
		});
		
		var last = receiverName.lastIndexOf(',');
		receiverName = receiverName.substr(0,last);
		
		$this.find('#emhdReciever').text(receiverName);
		
		if(_msgeventGb == "birthday") {
			$this.find('#emhd02MardayMsgDiv').hide();
			$this.find('#emhd02BirMsgDiv').show();
			$this.find('.emhd02MessageName').text("생일 축하 메시지");
			if(_issms){
                $this.find('#emhd02BirMessage option[value="4"]').text("직접입력(한글 40자,영문 80자 이하)");
                $this.find('#emhd02BirMessage').selectmenu('refresh',true);
			}
		} else {
			$this.find('#emhd02BirMsgDiv').hide();
			$this.find('#emhd02MardayMsgDiv').show();
			$this.find('.emhd02MessageName').text("결혼기념일 축하 메시지");
			if(_issms){
                $this.find('#emhd02MarMessage option[value="4"]').text("직접입력(한글 40자,영문 80자 이하)");
                $this.find('#emhd02MarMessage').selectmenu('refresh',true);
			}
		}
        $this.find('#ckbMessUseYn').prop('checked', false).checkboxradio('refresh');

		$this.find('.selectBox').change(function() {
			var selectedVal = $this.find('.selectBox:visible option:selected').val();
			var selectedText = $this.find('.selectBox:visible option:selected').text();
            $this.find('#emhd02HappydayMsgTxt').val((selectedVal != 4) ? selectedText : "");
			return false;
		});

		if( _issms ) {
            showAlert(Messages.msg123);
        }
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			$.each(_msgReciever, function(index, value) {
				if(value.ISPUSH == "false") {
					_issms = true;
					return false;
				}
			});
		},
		pageshow: function() {
            DGB.Common.backPage();
			setContents();
            _layout.refreshLayout();
		},
		pagehide: function(e) {
            var page = $(e.target);
            page.find('#emhd02HappydayMsgTxt').val('');
			page.find('.selectBox').val('4');
            page.find('#emhd02BirMessage option[value="4"]').text("직접입력");
            page.find('#emhd02MarMessage option[value="4"]').text("직접입력");
            page.find('#emhd02BirMessage').selectmenu('refresh',true);
            page.find('#emhd02MarMessage').selectmenu('refresh',true);

			_issms = false;
            _msgReciever = [];
            _menuId = undefined;
            _msgeventGb = "";
		},
		parentpage :function(e, param) {
            var page = $(e.target);
            page.find('.initContents').text("");
            page.find('#emhd02HappydayMsgTxt').val("");

			_msgReciever = param.msgReciever;
			_menuId = param.menuId;
			_msgeventGb = param.eventGb;
		},
		orientationchange : function() {
            _layout.refreshLayout();
            return false;
		}
	}, '#EMHD002');
})();