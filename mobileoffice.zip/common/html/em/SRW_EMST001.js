(function() {
	var $this = undefined;
	var inqDvcd = "1";  // 조회구분 : 전체(1), 성명(2), 부점(3), 행번(4), 전화번호(5)
	var _menuId = undefined;
	var _layout = undefined;
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수	
	var btnPress = false; //검색버튼누른경우 flag
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	var _leftmenuinit = false; // left메뉴통해서 들어올경우 입력박스및 nav바 전체검색으로 초기화.
	
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_NAVBAR_HEIGHT+COMMON_SEARCH_HEIGHT);

		//android input number placeholder 버그
		if ( DGB.isAndroid() ) {
			$this.find('#emstInputSearch').on('focusin',function(){
				if($('#emstInputSearch').hasClass('inputNumber')){
					$this.find('.inputNumber')[0].type="number";
				}
			});
			$this.find('#emstInputSearch').bind('blur',function(){
				$this.find('#emstInputSearch')[0].type="text";
			});
		}else {	//ios
			$this.find('#emstInputSearch').on('focusin',function(){
				if($('#emstInputSearch').hasClass('inputNumber')){
					$this.find('.inputNumber').attr('pattern', '[0-9]*');
					$this.find('.inputNumber')[0].type="text";
				}
			});
			$this.find('#emstInputSearch').bind('blur',function(){
				$this.find('.inputNumber').removeAttr('pattern');
			});
		}



		$this.find('#staffSearchBtn').on('vclick', function() {
			setTimeout(function () {
				emst01Search();
			}, 300);
		});


		$this.find('#emstInputSearch').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('#staffSearchBtn').focus();
				setTimeout(function () {
					emst01Search();
				}, 300);
				return false;
			}
		});

	};
	
	function emst01Search(){
		//초기화
		_layout.resetLayout(); //스크롤위치 초기화
		_iscrollEnd = false;
		$("#staffListview").html('');
		$("#emst01Noresult").addClass("displayNone");
		$('#emst01pullUp').css("display", "none");
		
		var param = $('#emstInputSearch').val().toUpperCase();
		
		//공백 제거
		param = trim(param);
		
		if (param == "") {
			
			showAlert(Messages.msg021);
			return;
		}
		//통합조회
		if(_menuId.indexOf('EM0101') != -1){
			if(inqDvcd != "4" && param.length < 2){
				showAlert("2"+Messages.msg115);
				return;
			}
			
			if(inqDvcd == "4" && param.length < 4){
				showAlert("행번은 4"+Messages.msg115);
				return;
			}
		}
		else{ //전화번호조회
			if(param.length < 4){
				showAlert("4"+Messages.msg115);
				return;
			}
		}
	
		//검색버튼누른경우
		btnPress = true;
		
		//키보드 내리기
		DGB.Common.hideKeyboard();
		setTimeout(function () {
			onSearch(param);
		}, 300);
	}

	function onSearch(param1, param2, param3) {
		if (arguments.length != 3) {
			param2 = 1; // START_NUM 기본값
			param3 = _pageSize; // EDD_NUM 기본값
			$('#emst01StNum').val(param2);
			$('#emst01EdNum').val(param3);
		}

		var	opt = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};

		var inv = {
			adapter : 'DBTransactionAdapter',
			procedure : 'TEM00001',
			parameters : [{
				SEARCH : param1,
				START_NUM : param2,
				END_NUM : param3,
				INQ_DVCD : inqDvcd,
				CS_ID:_menuId,
				ENCODE_STR : ""
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function displayResult(data) {
//        var item = [
//             {
//                 OFFICE_TEL : '053-000-1111',
//                 ORG_NM : 'ORG_NM',
//                 JIKCHAK : 'JIKCHAK',
//                 ISPUSH : 'true',
//                 SABUN : '7130000'
//             },
//             {
//                 OFFICE_TEL : '053-000-1111',
//                 ORG_NM : 'ORG_NM',
//                 JIKCHAK : 'JIKCHAK',
//                 ISPUSH : 'true',
//                 SABUN : '7130000'
//             }
//         ];

		var item = data.invocationResult.resultSet;
		if(item.length === 0) {
		
			_layout.refreshLayout(function(){
				dgbLoading(false);
				$("#staffListview").html('');
				$('#emst01pullUp').css("display", "none");
				_iscrollEnd = false;
				btnPress = false;
				
				$("#emst01Noresult").removeClass("displayNone");
				$("#emst01InputText").text($('#emstInputSearch').val());
				
			}, 500);
			
		} else if(item.length === 1) {	// 1명인 경우에는 상세조회화면으로 바로 이동
			var sabun = item[0].SABUN;
			var detailId ="EMST002"; 

			var args={};
			args.menuId = _menuId;
			args.sabun = sabun;
			args.ispush = item[0].ISPUSH;
			
			// $("#"+detailId).trigger("parentpage",[args]);
            DGB.Page.triggerPage("#" + detailId, "parentpage", [args]);
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
		} else {
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].SABUN == "") break;
				var officeTel = item[i].OFFICE_TEL.split(" "); 
				var displayTel = officeTel[0]; 
				html = "<li>" +
						"<a href='#'  class='emst001List downHeight' data-enob='"+item[i].SABUN+"' data-ispush='"+item[i].ISPUSH+"' >" + 
							"<fieldset class='ui-grid-b'> " +
								"<div class='ui-block-a' style='width: 43%'> " +
								"<b><h3>"+item[i].NAME+"</h3></b>"+
								"<p><font color=darkblue><strong>"+item[i].JIKCHAK+"</strong></font></p>"+
								"</div>" +
                                "<div class='ui-block-b' style='width: 20%;padding-top: 6px;'> ";

                                if (item[i].ISPUSH == "true"){
                                    html += "<img class='img_push'>";
                                }

				html +=			"</div><div class='ui-block-c'> " +
								"<p>&nbsp;</p>"+
								"<p>"+item[i].ORG_NM+"</p>"+
								"<p>"+displayTel+"</p>"+
								"</div> " +
							"</fieldset> " +
						"</a>"+
						"</li>";
				listItems[i] = html;
			}
				
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#emst01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#emst01pullUp').css("display", "block");
					$('#emst01StNum').val(
							parseInt($('#emst01StNum').val()) + _pageSize);
					$('#emst01EdNum').val(
							parseInt($('#emst01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#emst01pullUp').css("display", "none");
			}
			/* //페이징 */

			//검색버튼누른경우
			if(btnPress == true) 
			{
				$("#staffListview").html(listItems.join(''));
				btnPress = false;
			}	
			else
			{
				$("#staffListview").append(listItems.join(''));
			}	
			
			listItems = null;
            item = null;
            html = "";
			$("#staffListview").listview( "refresh" );
			$("#staffListview").trigger("updatelayout");

			//리스트클릭 이벤트  
			$('#staffListview').find('li a.emst001List').off('vclick').on('vclick',function(){
				var sabun = $(this).attr('data-enob');
				var ispush = $(this).attr('data-ispush');
				var detailId ="EMST002"; 

				var args={};
				args.menuId = _menuId;
				args.sabun = sabun;
				args.ispush = ispush;
				
				locDetailview = true;
				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#" + detailId, "parentpage", [args]);
				
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				return false;
			});
			
			_layout.refreshLayout(function(){
			   dgbLoading(false);
			}, 500);
		}
	}
	
	function displayError() {
		dgbLoading(false);
		showAlert(Messages.msg002);
	}
	
	function initPageDOM() {
		if (_menuId.indexOf('EM0101') != -1) {
			$this.find("h1").text('통합조회');
			$('#emstInputSearch').blur();
			$this.find('[data-role="navbar"]').show();
			
			//left메뉴로 진입시에는 전체 검색으로 동작하도록
			if(_leftmenuinit){
				$('#emstInputSearch').val("");
				$('#emstInputSearch').attr("placeholder","성명(초성)/부점/행번");
				$('#emstInputSearch').removeClass("inputNumber");
				$this.find('[data-role="navbar"] a').removeClass("ui-btn-active");
				$this.find('[data-role="navbar"] a:first').addClass("ui-btn-active");
				$this.find('#emst01NavAll').addClass("ui-state-persist");
				$this.find("#emst01NavName").removeClass("ui-state-persist");
				$this.find("#emst01NavBujum").removeClass("ui-state-persist");
				$this.find("#emst01NavHangNum").removeClass("ui-state-persist");
			}
			else
			{
				switch ($this.find('.ui-state-persist').attr('id')) {
				case 'emst01NavAll':
					$this.find('#emstInputSearch').attr("placeholder","성명(초성)/부점/행번");
					$this.find('#emstInputSearch').removeClass("inputNumber");
					break;
				case 'emst01NavName':
					$this.find('#emstInputSearch').attr("placeholder","성명(초성)");
					$this.find('#emstInputSearch').removeClass("inputNumber");
					break;
				case 'emst01NavBujum':
					$this.find('#emstInputSearch').attr("placeholder","부점");
					$this.find('#emstInputSearch').removeClass("inputNumber");
					break;
				case 'emst01NavHangNum':
					$this.find('#emstInputSearch').attr("placeholder","행번");
					$this.find('#emstInputSearch').addClass("inputNumber");
					break;
				default:
					break;
				}
			}

			inqDvcd = "1";
			_layout.updateOffset({wrapperOffset:COMMON_NAVBAR_HEIGHT+COMMON_SEARCH_HEIGHT});
		}else {
			
			$this.find("h1").text('전화번호조회');
			$this.find('#emstInputSearch').blur();
			$this.find('#emstInputSearch').attr("placeholder","전화번호(끝 4자리 입력)");
			$this.find('#emstInputSearch').addClass("inputNumber");
			$this.find('[data-role="navbar"]').hide();
			
			inqDvcd = "5";
			_layout.updateOffset({wrapperOffset:COMMON_SEARCH_HEIGHT});
		}
		
		if(locDetailview == false) {
			//화면 초기화
			$("#staffListview").html('');
			$('#emstInputSearch').val("");
			$("#emst01Noresult").addClass("displayNone");
			$('#emst01pullUp').css("display", "none");
			_iscrollEnd = false;
			btnPress = false;
		}
		locDetailview = false;
	}

	function _pageshow() {
		initPageDOM();

		DGB.Common.backMenu();

		_layout.refreshLayout();
		dgbLoading(false);
	}

	// 당겨서 추가
	function pullUpAdd() {

		var param1 = $('#emstInputSearch').val().toUpperCase(),
			param2 = $('#emst01StNum').val(),
			param3 = $('#emst01EdNum').val();
		if( $('#emstInputSearch').val() != "")
		{
			onSearch(param1, param2, param3);
		}	
		
	}

	$(document).on({
		pageinit: function() {
            if( GLOBAL.ARGS ) {
                _menuId = GLOBAL.ARGS.menuId;
            }
			pageinit($(this));
		},
		pagebeforeshow: function(evt, ui) {
			$this.find('#emstNavbar').on('vclick','a', function () {
				var currentNav = $(this).text();
				switch (currentNav) {
				case "전체":
					inqDvcd = "1";
					$('#emstInputSearch').val("");
					$('#emstInputSearch').attr("placeholder","성명(초성)/부점/행번");
					$('#emstInputSearch').removeClass("inputNumber");
					$this.find('#emst01NavAll').addClass("ui-state-persist");
					$this.find("#emst01NavName").removeClass("ui-state-persist");
					$this.find("#emst01NavBujum").removeClass("ui-state-persist");
					$this.find("#emst01NavHangNum").removeClass("ui-state-persist");

					break;
				case "성명":
					inqDvcd = "2";
					$('#emstInputSearch').val("");
					$('#emstInputSearch').attr("placeholder","성명(초성)");
					$('#emstInputSearch').removeClass("inputNumber");
					$this.find('#emst01NavAll').removeClass("ui-state-persist");
					$this.find("#emst01NavName").addClass("ui-state-persist");
					$this.find("#emst01NavBujum").removeClass("ui-state-persist");
					$this.find("#emst01NavHangNum").removeClass("ui-state-persist");
					break;
				case "부점":
					inqDvcd = "3";
					$('#emstInputSearch').val("");
					$('#emstInputSearch').attr("placeholder","부점");
					$('#emstInputSearch').removeClass("inputNumber");
					$this.find('#emst01NavAll').removeClass("ui-state-persist");
					$this.find("#emst01NavName").removeClass("ui-state-persist");
					$this.find("#emst01NavBujum").addClass("ui-state-persist");
					$this.find("#emst01NavHangNum").removeClass("ui-state-persist");
					break;
				case "행번":
					inqDvcd = "4";
					$('#emstInputSearch').val("");
					$('#emstInputSearch').attr("placeholder","행번");
					$('#emstInputSearch').addClass("inputNumber");
					$this.find('#emst01NavAll').removeClass("ui-state-persist");
					$this.find("#emst01NavName").removeClass("ui-state-persist");
					$this.find("#emst01NavBujum").removeClass("ui-state-persist");
					$this.find("#emst01NavHangNum").addClass("ui-state-persist");
					break;
				default:
					inqDvcd = "1";
					$('#emstInputSearch').val("");
					$('#emstInputSearch').attr("placeholder","성명(초성)/부점/행번");
					$this.find('#emst01NavAll').addClass("ui-state-persist");
					$this.find("#emst01NavName").removeClass("ui-state-persist");
					$this.find("#emst01NavBujum").removeClass("ui-state-persist");
					$this.find("#emst01NavHangNum").removeClass("ui-state-persist");
					break;
				}
			});
			
		},
		pageshow: _pageshow,
		pagehide: function(evt, ui) {
			_leftmenuinit = false;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			var options = param.options;
			
			_leftmenuinit = true;

			if (options) {
				inqDvcd = options.type;
				$('#emstInputSearch').val(options.keyword);
				$('#staffSearchBtn').trigger('vclick');
			}

			if (param.activePage) {//pageshow와 동일한동작
				_pageshow();
			}
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#staffSearchBtn").focus();
            }
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd )
			{
				pullUpAdd();
			}

		}
	}, '#EMST001');

	//공백 제거
	function trim(str){
		return str.replace( /(\s*)/g,'');
	}
	
})();
