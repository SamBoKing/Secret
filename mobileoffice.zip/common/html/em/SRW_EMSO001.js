(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _navbarHeight = COMMON_NAVBAR_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight,_navbarHeight);
		
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2) {

					dgbLoading(true);
					if (arguments.length != 2) {
						param1 = 1; // START_NUM 기본값
						param2 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#emso01StNum').val(param1), $('#emso01EdNum').val(param2);
						/* //페이징 */
					}

					invocationData = {
						adapter : 'DBTransactionAdapter',
						procedure : 'TEM00003',
						parameters : [{CS_ID:_menuId,  START_NUM:param1, END_NUM:param2, TELLER_NUM : USER_INFO.ENOB}]
					};

					callProcedure(invocationData, this.options);
				}


			};
	
		
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet || {};			// JSON 리턴데이터
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].FAM_EVENT_NO == "") break;
				html = "<li>"+
							"<a href='#' class='emso001List downHeight' id='emso001List_"+i+"' data-eventGb='"+item[i].FAM_EVENT_GB+"' data-eventNo='"+item[i].FAM_EVENT_NO+"' data-item='"+JSON.stringify(item[i])+"' >"+ // onclick='transEMSO002("+item[i].FAM_EVENT_GB+","+item[i].FAM_EVENT_NO+")' >"+
							"<h3 style='white-space: pre-line;'>"+item[i].TITLE+"</h3>"+
							"<p><strong style='color:darkblue;'>"+item[i].FAM_EVENT_DATE+"</strong></p>";
							
							if(item[i].FAM_EVENT_PLACE ==""){
				html +=				"<p class='colordarkblue'>&nbsp;</p>";
							}
							else
							{
				html +=				"<p class='paddingright15'><strong style='color:darkblue;'>"+item[i].FAM_EVENT_PLACE+"</strong></p>";
							}			
							
				html +=			"</a>"+
						"</li>";
				listItems[i] = html;
			}
			
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#emso01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#emso01pullUp').css("display", "block");
					$('#emso01StNum').val(parseInt($('#emso01StNum').val()) + _pageSize);
					$('#emso01EdNum').val(parseInt($('#emso01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#emso01pullUp').css("display", "none");
			}
			/* //페이징 */

			$("#emsoListview").append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#emsoListview").listview( "refresh" );
			$("#emsoListview").trigger("updatelayout");
			
//			dgbLoading(false);
			
			$('#emsoListview').find('li a.emso001List').off('vclick').on('vclick',function(){
				
				var eventGb = $(this).attr('data-eventGb');
				var eventNo = $(this).attr('data-eventNo');
				var item = $(this).attr('data-item');
				var detailId ="EMSO002"; 
				
				var args={};
				args.menuId = _menuId;
				args.eventGb = eventGb;
				args.eventNo = eventNo;
				args.item = item;

				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#" + detailId, "parentpage", [args]);
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				
				return false;
			});

			locDetailview = true;
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}
		function displayError() {
			dgbLoading(false);
		}
		//listSearch.call();
	};
	
	function _pageshow() {
		_layout.refreshLayout();
		DGB.Common.backMenu();
		
		if(locDetailview == false) {
			listSearch.call("");
		}

	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#emso01StNum').val(),
			param2 = $('#emso01EdNum').val();

		listSearch.call(param1, param2);
	}
	$(document).on({
		pageinit: function() {
			pageinit($(this));
			$('#emso01pullUp').css("display", "none");
		},
		pagebeforeshow: function(evt, ui) {
			$this.find('#emso01Navbar').on('vclick','a', function () {	
				var currentNav = $(this).text();
				
				switch (currentNav) {
				case "결혼보기":
					listviewFiltering($('#emsoListview > li'), "결혼", 'h3');
					listviewSorting("#emsoListview", "p", "desc");
					$("#emso01NavDie").removeClass("ui-state-persist");
					$("#emso01NavMarry").addClass("ui-state-persist");
					break;
				case "부고보기":
					listviewFiltering($('#emsoListview > li'), "부고", 'h3');
					listviewSorting("#emsoListview", "p", "desc");
					$("#emso01NavMarry").removeClass("ui-state-persist");
					$("#emso01NavDie").addClass("ui-state-persist");
					break;
				default:
					break;
				}

				$("#emsoListview").listview( "refresh" );
				_layout.refreshLayout();
			});
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#EMSO001');
	
})();
