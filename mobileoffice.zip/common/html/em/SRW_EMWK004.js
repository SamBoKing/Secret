(function() {
	var _this, _layout, _menuId, prevPage;
	var _content, openSenderOn, openStoryOn,_btn_edit;
	var _item;
	var _title,_subtitle,_seal;

	var _pageinit = function() {
		_this = $(this);
		_layout = new DGB.layout(_this, COMMON_PAGE_HEADER_HEIGHT);
		initControl();
	};

	var _pageshow = function() {
		DGB.Common.backPage();
		prevPage = $('#EMWK003');
		initData();
		_layout.refreshLayout();
	};

	var onClickSend = function() {
		DGB.Common.hideKeyboard();
		_content.blur();
		if(!valueCheck())
			return false;

		updateWinkTalk();
	};
	var valueCheck = function() {
		if( !_content.val() ){
			showAlert(Messages.msg610);
			return false;
		}
		return true;
	};
	function updateWinkTalk() {
		var opt = {
			onSuccess: onSuccess,
			onFailure: onFailure,
			invocationContext: {}
		};

		/*
		 showAlert('내이름  : ' + USER_INFO.FSNM +'\n수신행번 : '+_rcvEnob + '수신이름 : \n' + _rcvName );
		 showAlert('타이틀  : ' + selbox1[gubunIndex] +'\n서브타이틀 : '+_title + '씰금액 : \n' + sealValue[sealIndex]+ '씰금액인덱스 : \n' + sealIndex  );
		 */
		var inv = {
			// adapter : 'ExternalAdapter',
			// procedure : 'WINK0005', // 윙크톡등록
			adapter : 'GroupWareAdapter',
			procedure : 'GW_WINK0005',
			parameters : [{
				CS_ID : _menuId,
				ENOB : USER_INFO.ENOB,
				NAME : USER_INFO.FSNM,
				OID : _item.OID,
				RCVENOB : _item.WINKUNIQUENAME,
				RCVNAME : _item.WINKNAME,
				TITLE : _item.TITLE.replace(/(\")/g,'\''),
				SUBTITLE : _item.SUBTITLE.replace(/(\")/g,'\''),
				CONTENT : _content.val().replace(/(\")/g,'\''),
				SEALMOUNT :_item.SEALMOUNT,
				OPENYN : openSenderOn.prop("checked")?'Y':'N',
				OPENYN2 : openStoryOn.prop("checked")?'Y':'N'
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		dgbLoading(false);

		// Data : { "success" : "true", "OID" : "114121112572061" }
		var item = data.invocationResult;
		var success = ( item.OID && item.OID > -1 );
		showAlert(success ? Messages.msg622 : Messages.msg623);

		if(success){
			if( prevPage ) {
				prevPage.data('refresh', true);
			}
			DGB.Page.backPage();
		}
	}

	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	function initControl () {
		_btn_edit = _this.find('#btn_edit');
		_btn_edit.off('vclick').on('vclick', onClickSend);
		_content = _this.find('#description');
		_title = _this.find('#wk_dv_first');
		_subtitle = _this.find('#wk_dv_second');
		_seal = _this.find('#wk_dv_third');
		openSenderOn = _this.find('#wk_isOpenSender_on1');
		openStoryOn = _this.find('#wk_isOpenStory_on1');
		_this.find('#btn_winkAction').off('vclick').on('vclick', onClickSend);
		_content.val('');
	}

	function initData(){

		// 나눔씰 보기 여부
		if( _item.SEALMOUNT && _item.SEALMOUNT > 0 )
			_this.find('#wk_dv_third_area').show();
		else
			_this.find('#wk_dv_third_area').hide();

		if(_menuId == 'EM0503'){ // 받은 윙크톡 상세
			_this.find("#wk_page_title").text("받은윙크 내용");
			_this.find("#btn_winkAction").val("PUSH/SMS 회신");
			_this.find("#winkForSend").hide();
			_this.find("#btn_winkAction").hide();
			_btn_edit.hide();
			_content.attr("readonly",true);

		}else{	//보낸 윙크톡 상세
			_this.find("#wk_page_title").text("보낸윙크 내용");
			_this.find("#btn_winkAction").val("수정");
			// _this.find("#btn_winkAction").show();
			 _this.find("#winkForSend").show();
			_this.find("#btn_winkAction").hide();

			_content.attr("readonly",false);
			_btn_edit.hide();

			if(_item.OPENYN=='Y'){
				_this.find('#wk_isOpenSender_on1').prop('checked', true).checkboxradio("refresh");
				_this.find('#wk_isOpenSender_off1').prop('checked', false).checkboxradio("refresh");
			}else{
				_this.find('#wk_isOpenSender_on1').prop('checked', false).checkboxradio("refresh");
				_this.find('#wk_isOpenSender_off1').prop('checked', true).checkboxradio("refresh");
			}

			if(_item.OPENYN2=='Y'){
				_this.find('#wk_isOpenStory_on1').prop('checked', true).checkboxradio("refresh");
				_this.find('#wk_isOpenStory_off1').prop('checked', false).checkboxradio("refresh");
			}else{
				_this.find('#wk_isOpenStory_on1').prop('checked', false).checkboxradio("refresh");
				_this.find('#wk_isOpenStory_off1').prop('checked', true).checkboxradio("refresh");
			}
		}
		_title.val(_item.TITLE);
		_subtitle.val(_item.SUBTITLE);
		_seal.val(_item.SEALMOUNT+'원');
		_content.html(_item.CONTENT);
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		parentpage : function(evt, param) {
			_menuId = param.menuId;
			_item = param.item;
		},
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			_item = param.item;
		},
		orientationchange : function() {
			_layout.refreshLayout();
			return false;
		}
	}, '#EMWK004');
})();