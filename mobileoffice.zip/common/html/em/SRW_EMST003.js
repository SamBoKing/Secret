(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _rcvEnob = undefined;
	var _name = undefined;
	var _HP = undefined;
	var _isPush = false;
	
	var pageinit = function(instance) {
		$this = instance;
		
		$this.find('#emstMsgSendBtn').off('vclick').on('vclick', function() {

			var msgSMSMaxLan = 80; //byte로 계산 한글 40자, 영문 80자
			var msgPushMaxLan = 4000; //byte로 계산 한글 2000자, 영문 4000자

            DGB.Common.hideKeyboard();
            $this.find('#emstMsgSendBtn').focus();

			var pushCn = $("#emstMsgInput").val();
			if (pushCn == "") {
				showAlert(Messages.msg053);
				return false;
			}

			//2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
			pushCn = pushCn.replace( /(\')/g,'\"');
			var srccount = getMsgLength(pushCn);
            if( _isPush == "true" && srccount > msgPushMaxLan){
                showAlert(Messages.msg121);
                return;
            } else if( srccount > msgSMSMaxLan){
                showAlert(Messages.msg122);
                return;
            }

            var checked = $this.find('#ckbMessUseYn').prop('checked');
            dgbLoading(true);
            onSendPush(pushCn, checked ? 'Y' : 'N');
			return false;
		});

        function onSendPush(PUSH_CN, MESS_USE_YN) {
            dgbLoading(true);
            var invocationData = {
                adapter : 'DBTransactionAdapter',
                procedure : 'TEM00008',
                parameters : [{CS_ID :_menuId,
                    SYS_ID : SYS_ID,
                    DSPT_ENOB : USER_INFO.ENOB,
                    DSPT_COMP_DVCD : USER_INFO.ENTER_CD,
                    RCV_ENOB : _rcvEnob,
                    PUSH_CN :PUSH_CN,
                    MOB_NUMBER : _HP,
                    D_SENDER :USER_INFO.HP,
                    ORG_CD : USER_INFO.ORG_CD,
                    CS_MMT_YN :"N",	            // 메시지함 화면이동여부
                    PSNM : USER_INFO.FSNM,
                    MESS_USE_YN: MESS_USE_YN
                }]
            };

            var options = {
                onSuccess : displayResult,
                onFailure : displayError,
                invocationContext : {}
            };
            callProcedure(invocationData, options);
        };
		
		function displayResult(data) {
            dgbLoading(false);
			if (data.invocationResult.result == "1") {	//data 성공 :1, 실패 0
                initData();
				showAlert(Messages.msg008);
			} else {
				showAlert(Messages.msg010);
			}
		}

		function displayError() {
			dgbLoading(false);
			showAlert(Messages.msg010);
		}
	};

    function initData(page) {
        if( !page ) {
            page = $.mobile.activePage;
        }
        page.find('#ckbMessUseYn').prop('checked', false).checkboxradio('refresh');
        page.find('#emstMsgInput').val("");
        page.find('#emstMsgInput').css("height","80px");
    }

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
            $('#emstRecieverENOB').val(_rcvEnob);
            $('#emstReciever').text(_name);
		},
		pagebeforehide: function(e) {
            initData($(e.target));
			$('#EMST003 .initContents').text("");
		},
		parentpage :function(evt, param) {
			_rcvEnob = param.sabunHd;
			_name = param.name;
			_menuId = param.menuId;
			_HP = param.hp;
			_isPush = param.ispush;
		},
		orientationchange : function(evt) {
            return false;
		}
	}, '#EMST003');
})();
