(function() {
	var $this = undefined;
	var allOfficeTel = "";
	var locPushMsg = false;
	var _menuId = undefined;
	var _sabun = "";
	var _layout = undefined;
	var _HP = undefined;
	var _ispush = false;
	
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		$("a.celPhone").off('vclick').on('vclick',  function() {
			if($('#emstHp').text() === "****") {
				return false;
			}
			if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
				var numberlist = [ "선택하세요", "전화하기", "문자보내기" ];
				thelist = numberlist;
				cordova.exec(

					function(listitem) {

						if (thelist[listitem] == numberlist[1]) {
							location.href = "tel:"+ $('#emstHp').text();

						} else {

							if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
								AndroidNative.sendSms($('#emstHp').text());
							} else {
	                            location.href = "sms:"+ $('#emstHp').text();
							}

						}

					}, function(error) {
					}, "AlertList", "alertlist",thelist);
			} else if(WL.Client.getEnvironment() == WL.Environment.IPHONE){ // iphone
				// After device ready, create a local alias
				var actionSheet = window.plugins.actionSheet;

				// Complex
				actionSheet.create({
					title : '선택하세요',
					items : [ '전화하기', '문자보내기', '취소' ],
					destructiveButtonIndex : 1,
					cancelButtonIndex : 2
				}, function(buttonValue, buttonIndex) {
					switch (buttonIndex) {
                        case 0:
                            location.href = "tel:"+ $('#emstHp').text();
                            break;
                        case 1:
                            location.href = "sms:"+ $('#emstHp').text();
                            break;
					default:
						break;
					}
				
				});
			} else {
				showAlert(Messages.msg055);
			}
			
		});
		
		$("a.officePhone").off('vclick').on('vclick',  function() {			
			location.href ="tel:" + allOfficeTel;
			
		});
		$("a.homePhone").off('vclick').on('vclick',  function() {
			if($('#emstHome_tel').text() === "****") {
				return false;
			}
			location.href ="tel:" + $('#emstHome_tel').text();
		});

        $("a.sendEmail").off('vclick').on('vclick',  function() {
            if($('#emstMail').text() === "") {
                return false;
            }

            if (nmf.Store.get(EMAIL_KEY_ID) == undefined) {
                showAlert(Messages.msg020 +"\n"+ Messages.msg02J);
                return false;
            }

            var mailuser = $("#emstName").text();
            var mailId = $("#emstMail").text();
            var to = "'"+mailuser+"'<"+mailId+">";

            // Show the mail writer
            DGB.Page.triggerPage("#GREM001", "writemail", [{
                menuId: 'GR0102',
                boxId: undefined,
                TO: to
            }]);
            setTimeout(function () {
                DGB.Page.changePage('#GREM001');
            },400);

        });

		$('.divEmployeePush').off('vclick').on("vclick", "img", function () {
			
			if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
				
				var andrItem = [ "선택하세요", "연락처 저장하기", "SMS 메시지보내기"];
				if (_ispush == "true") {
					andrItem = [ "선택하세요", "연락처 저장하기", "Push 메시지보내기"];
				}
				
			    thelist = andrItem;
				 cordova.exec( function(listitem) {
					           				
					 if(thelist[listitem] == andrItem[1] )
					 {
						 showConfirm(function(button){
								if (button == '1') {
									findContacts($('#emstName').text()); 
								}else if(button == '2') {
									return;
								}
							}, Messages.msg203);
						 
					 }
					 else
					 {
						emstPushSend();
					  //푸쉬메시지 보내기
					 }
				 }, 
				  function(error) {
				  }, "AlertList", "alertlist", thelist );
			}else if (WL.Client.getEnvironment() == WL.Environment.PREVIEW) {
			}else //iphone
		    {
				// After device ready, create a local alias
				var actionSheet = window.plugins.actionSheet;
				var iosItem = [ '연락처 저장하기', 'SMS 메시지보내기', '취소' ];
				if (_ispush == "true") {
					iosItem = [ '연락처 저장하기', 'Push 메시지보내기', '취소' ];
				}
				
				// Complex
				actionSheet.create({
					title : '선택하세요',
					items : iosItem,
					destructiveButtonIndex : 1,
					cancelButtonIndex : 2
				}, function(buttonValue, buttonIndex) {
					switch (buttonIndex) {
					case 0:
						
						 showConfirm(function(button){
								if (button == '1') {
									findContacts($('#emstName').text());
								}else if(button == '2') {
									return;
								}
							}, Messages.msg203);
						break;
					case 1:
						emstPushSend();
						//푸쉬메시지 보내기
						break;
					default:
						break;
					}
				
				});
		    }		
		});
		
		//폰북 새로만들기
		function AddContacts() {
			var contact = navigator.contacts.create();
			contact.displayName = $('#emstName').text();
			var name = new ContactName();
			name.givenName = $('#emstName').text();
			contact.name = name;

			// store contact phone numbers in ContactField[]
			var phoneNumbers = [];
			phoneNumbers[0] = new ContactField('work', allOfficeTel,false);
			if($('#emstHp').text() != "****" )
			{
				phoneNumbers[1] = new ContactField('mobile', $('#emstHp').text(), true); // preferred number
			}
			if($('#emstHome_tel').text() != "****" )
			{
				phoneNumbers[2] = new ContactField('home', $('#emstHome_tel').text(), false);
			}	
			
			contact.phoneNumbers = phoneNumbers;

			var emails = [];
			emails[0] = new ContactField('work', $('#emstMail').text(), false);
			contact.emails = emails;

			contact.save(onSuccess, onError);
		}
		
		//폰북 overwrite
		function EditContacts(contacts)
		{
			var contact = contacts[0];
			contact.displayName = $('#emstName').text();
			var name = new ContactName();
			name.givenName = $('#emstName').text();
			contact.name = name;

			// store contact phone numbers in ContactField[]
			var phoneNumbers = [];
			phoneNumbers[0] = new ContactField('work', allOfficeTel,false);

			
			if($('#emstHp').text() != "****" )
			{
				phoneNumbers[1] = new ContactField('mobile', $('#emstHp').text(), true); // preferred number
			}
			if($('#emstHome_tel').text() != "****" )
			{
				phoneNumbers[2] = new ContactField('home', $('#emstHome_tel').text(), false);
			}	
			
			//핸드폰 번호로 검색하기때문에 contact.phoneNumbers[0]은 핸드폰 번호임.
			if(contact.phoneNumbers[0].value == undefined || contact.phoneNumbers[0].value == null)
			{
				contact.phoneNumbers[0] =  phoneNumbers[0];
				
			}else{
				contact.phoneNumbers[0].type = phoneNumbers[0].type;
				contact.phoneNumbers[0].value = phoneNumbers[0].value;
			}
			
			if($('#emstHp').text() != "****" )
			{
				if(contact.phoneNumbers[1] == undefined || contact.phoneNumbers[1] == null)
				{
					contact.phoneNumbers[1] =  phoneNumbers[1];
					
				}else{
					contact.phoneNumbers[1].type = phoneNumbers[1].type;
					contact.phoneNumbers[1].value = phoneNumbers[1].value;
				}
			}
			
			if($('#emstHome_tel').text() != "****" )
			{

				if(contact.phoneNumbers[2] == undefined || contact.phoneNumbers[2] == null)
				{
					contact.phoneNumbers[2] =  phoneNumbers[2];
				}else{
					contact.phoneNumbers[2].type = phoneNumbers[2].type;
					contact.phoneNumbers[2].value = phoneNumbers[2].value;
				}
				
				
			}
			
			var emails = [];
			emails[0] = new ContactField('work', $('#emstMail').text(), false);

			if(contact.emails == undefined || contact.emails == null)
			{
				contact.emails =  emails;
			}else{
				contact.emails[0].type = emails[0].type;
				contact.emails[0].value = emails[0].value;
			}

			contact.save(onSuccess, onError);
		}
		
		//전화번호 중복 체크
		function findContacts(contactName){
			var contactFindOptions = new ContactFindOptions();
			contactFindOptions.filter = contactName;			
			contactFindOptions.multiple = false; //true
			var ContactField = ["displayName","phoneNumbers","emails"]; //찾아서 리턴할값 현재 이름,전화번호,이메일을 리턴하고 있음.
			navigator.contacts.find(ContactField, findSuccess, findError, contactFindOptions);

		}
		
		function findSuccess(contacts)
		{
			var findPhoneNm;
			var phoneNm = $('#emstHp').text();
			if( phoneNm ) {
				phoneNm = phoneNm.replace(/-/gi,"");
			}

			
			if(contacts.length == 0)
			{
				 AddContacts();
			}
			else{
				for(var i=0; i < contacts.length; i ++)
				{
					for(var j=0; j < contacts[i].phoneNumbers.length; j++)
					{

						findPhoneNm = contacts[i].phoneNumbers[j].value.replace(/-/gi,"");
						 
						   if( (contacts[i].phoneNumbers[j].type == "mobile" || contacts[i].phoneNumbers[j].type == "home") && ( findPhoneNm == phoneNm) )
						   {
							  // showAlert(Messages.msg201);
							   
							   showConfirm(function(button){
									if (button == '1') {
										dgbLoading(true);
										EditContacts(contacts);
									}else if(button == '2') {
										return;
									}
								}, Messages.msg201);
							   
							   return;
						   }	   
						 	
					}	
				 
				}
			}
	
		}
		
		function findError(contact) { }

		/**
		 * 푸쉬화면으로 이동
		 */
		function emstPushSend() {
			locPushMsg = true;
			var detailId ="EMST003";

			var args={};
			args.menuId = _menuId;
			args.sabunHd = $('#emstSabunHd').val();
			args.name = $('#emstName').text().trim();
			args.ispush = _ispush;
			args.hp = (_HP || '').replace(/-/gi,"");

            DGB.Page.triggerPage("#" + detailId, "parentpage", [args]);
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
		}
	
	};
	
	function displayResult(data) {
		if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
			dgbLoading(false);
			eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
			return false;
		}

		var item = data.invocationResult.resultSet;
		if(item.length == 0) {
			dgbLoading(false);
			showAlert(Messages.msg10A);
			DGB.Common.backPage();
			return;
		}

		var jikho = item[0].JIKHO.indexOf("1급") != -1 ? "1급" : item[0].JIKHO;
		$('#emstName').text(item[0].NAME);								// 성명
		$('#emstSabun').text(jikho+"("+item[0].SABUN.substring(0,3)+"****" + ")");	// 호봉(행번)
		$('#emstSabunHd').val(item[0].SABUN);
		$('#emstOrg_nm').text(item[0].ORG_NM);							// 부점
		$('#emstJikchak').text(item[0].JIKCHAK);						// 직책
		$('#emstOffice_tel').text(item[0].OFFICE_TEL);					// 내선번호
		allOfficeTel = item[0].OFFICE_TEL_GUK;							// 내선번호 국번포함
		_HP = item[0].HP;
		
		if((item[0].HID_HP == "Y") || (item[0].HP == "")) {	// 휴대폰번호
			$('#emstHp').text("****");
			$('#emstHpIcon').hide();
		} else {
			$('#emstHp').text(item[0].HP);
			$('#emstHpIcon').show();
		}
		if((item[0].HID_HOM_TEL == "Y") || (item[0].HOME_TEL == "")) {	// 집전화번호
			$('#emstHome_tel').text("****");
			$('#emstHome_telIcon').hide();
		} else {
			$('#emstHome_tel').text(item[0].HOME_TEL);
			$('#emstHome_telIcon').show();
		}
		
		$('#emstFax').text(item[0].FAX);								// 팩스번호
		if((item[0].MAIL == "")) {
			$('#emstMail').text("");
			$('#emstMailIcon').hide();
		} else {
			$('#emstMail').text(item[0].MAIL);							// 이메일주소
			$('#emstMailIcon').show();
		}
		
		$('#emstTask_nm').text(item[0].TASK_NM);						// 담당업무

		item[0].PHOTO_URL = DOWN_URL+"/download?parameters={'URL':'http://ehr.daegubank.co.kr/EHR/HR_FILE/PICTURE/DGB/" + item[0].PHOTO_FILE + "'}";
		if (item[0].PHOTO_URL) {
			$('#employeePic').attr("src", item[0].PHOTO_URL);			// 담당업무
			$('#emst02popupImg').attr("src", item[0].PHOTO_URL);		// jkhtest
			
			//이미지 불러오는것 계산(imagesloaded 사용)
			$('#employeePic').imagesLoaded()
			  .always( function( instance ) { })
			  .done( function( instance ) { })
			  .fail( function() {
				  DGB.Log.e('[SRW_EMST002] ====>> all images loaded, at least one is broken');
				  $('#employeePic').removeAttr('src');
				  $('#emst02popupImg').removeAttr('src');
			  })
			  .progress( function( instance, image ) {
			    var result = image.isLoaded ? 'loaded' : 'broken';
			    DGB.Log.d('[SRW_EMST002] ====>> image is ' + result + ' for ' + image.img.src );
			  });
			
		}
		
		$('#emst02EmpPic').off('vclick').on('vclick',function(e){
			e.preventDefault();//href이벤트 막기
			setTimeout(function () {
				$('#emst02popupPhoto').popup('open');
			},300);
			
			return false;
		});
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
		
	}

	function displayError() {
		dgbLoading(false);
        showAlert(Messages.err001);
	}

	function onSuccess() {
		dgbLoading(false);
	    showAlert(Messages.msg200);
	}
	function onError() {
		dgbLoading(false);
		showAlert(Messages.msg202);
	}
	
	function setContents() {
		var inv = {
			adapter : 'SocketTransactionAdapter',
			procedure : 'TEM00002',
			parameters : [{
				CS_ID:_menuId,
				SELECT_ENOB : _sabun,
				TELLER_NUM : USER_INFO.ENOB
			}]
		};
		
		var opt = {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
			//직원조회푸쉬메시지에서 들어온경우 다시 조회하지 않음
			if ($('#emstName').text().trim() == "") {
				setContents();
			}else {
				//푸쉬메시지에서 들어온경우 플래그 초기화
				locPushMsg = false;
			}

			DGB.Common.backPage();
			_layout.refreshLayout();
		},
		pagebeforehide: function(evt, ui) {
			//직원조회푸쉬메시지로 이동시 화면내용은 그대로 유지
			if (locPushMsg == false) {
				$('#EMST002 .initContents').text("");
				$('#employeePic').removeAttr('src');
				$('#emst02popupImg').removeAttr('src');
			}
		},
		parentpage :function(evt, param) {
			$('#EMST002 .initContents').text("");
			_sabun = param.sabun;
			_menuId = param.menuId;
			_ispush = param.ispush;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#EMST002');
})();
