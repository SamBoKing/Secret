(function() {
	var $this;
	var _menuId;
	var _layout;
	var _iscrollEnd; // 마지막 페이지
	var _pageSize = 20, _totalCount = 0, pageCount = 0; // 한페이지 갯수

	var items=[];
	var preScenMode = 0; // 0(nothing) ,1(수신),2(발신)
	var procedureName;
	var winkCSSArray = [];
	var startNum = 1,
		endNum = _pageSize;
	var listView;

	var _pageinit = function() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		listView = $this.find('#rcvWinkListview');
		initWinkThumb();
	};

	function initWinkThumb() {
		for(var i = 0; i < 12; i++) {
			winkCSSArray.push('winkIcon'+String.fromCharCode(65+i));
		}
	}

	function request() {
		var opt = {
			onSuccess: onSuccess,
			onFailure: onFailure,
			invocationContext: {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			// adapter : 'ExternalAdapter',
			procedure : procedureName, // 윙크톡등록
			parameters : [{
				CS_ID : _menuId,
				ENOB : USER_INFO.ENOB,
				START : startNum + '',
				END: endNum + ''
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(result) {
		var data = result.invocationResult;
		var preItemSize = items.length;
		items = items.concat(data.items || []);
		var html = "";
		var listItems = [];
		var user = '';
		for (var i=preItemSize; i<items.length; i++) {
			if( preScenMode == 1 ) {
				if( items[i].OPENYN == 'Y' )
					user = items[i].SENDNAME+" ("+items[i].SENDUNIQUENAME + ")";
				else
					user = "비공개";
			} else {
				user = items[i].WINKNAME+" ("+items[i].WINKUNIQUENAME + ")";
			}

			html = "<li>"+
				"<a href='#' class='wink001List downHeight' data-index='"+i+"' >"+
				"<div class='ui-block-a' style='padding: 8px 4px 0 0;'> " +
				"<img id='"+winkCSSArray[items[i].TITLEIDX]+"' class='winkIcon'>"+
				"</div>" +
				"<div class='ui-block-b' style='padding-top: 1px;'> " +
				"<h3 style='color:darkblue; font-size: small'>"+items[i].TITLE+"</h3>"+
				"<p><strong style='color:orangered; font-size: small'>"+items[i].SUBTITLE+"</strong></p>"+
				"<p><strong style='color:darkblue;'>"+(items[i].DGBFN_NAME || '')+"</strong></p>"+
				"</div>"+
				"<div class='ui-block-b' style='float:right; text-align: right; padding-right: 16px; padding-top: 3px;'> " +
				"<h3 style='color:#373737; font-size: 12px;'> "+ user + "</h3>"+
				"<p><strong style='color:#373737;'>"+items[i].REGISTERDATE+"</strong></p>"+
				( items[i].SEALMOUNT != "" ? "<p><strong style='color:darkblue;'>("+items[i].SEALMOUNT+")</strong></p>":"")+
				"</div>"+
				"</a>"+
				"</li>";
			listItems[i] = html;
		}

		if( pageCount == 0 ) {
			_layout.resetLayout();
			listView.html(listItems.join(''));
		} else {
			listView.append(listItems.join(''));
		}
		listView.listview( "refresh" );

		//리스트클릭 이벤트
		++pageCount;
		/* 페이징 */
		if (items.length/pageCount == _pageSize) {
			if (pageCount*_pageSize == _totalCount) { // 마지막페이지
				$this.find('#grst01pullUp').hide();
				_iscrollEnd = true;
			} else {
				$this.find('#grst01pullUp').show();
				startNum += _pageSize;
				endNum += _pageSize;
			}
		} else {
			_iscrollEnd = true;
			$this.find('#grst01pullUp').hide();
		}

		_layout.refreshLayout();
		dgbLoading(false);

		listView.find('li a.wink001List').off('vclick').on('vclick',function(){
			var index = $(this).attr('data-index');
			DGB.Page.triggerPage("#EMWK004", "selectmenu", [ { menuId : _menuId, item : items[index] } ]);
			DGB.Page.changePage('#EMWK004');
			return false;
		});
	}

	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	function _pageshow() {
		DGB.Common.backPage();
		var isReceive = (_menuId == 'EM0503');
		$this.find("#page_title").text(isReceive ? "받은윙크톡" : "보낸윙크톡");
		procedureName = isReceive ? 'GW_WINK0002' : 'GW_WINK0003';
		// procedureName = isReceive ? 'WINK0002' : 'WINK0003';
		if(!preScenMode){
			preScenMode = isReceive ? 1 : 2;
		} else if((preScenMode==1 && isReceive) || (preScenMode==2 && !isReceive)){// 이전접근 모드 와 현재접근 모드 같음
			if( $this.data('refresh') ) {
				$this.data('refresh', false);
				initData();
				_layout.resetLayout(); 		// 스크롤위치 초기화
			}
		} else { //이전 접근 모드 현재 접근모드 틀림.
			initData();
		}

		if( items.length == 0) {
			request();
		}
	}

	function initData(){
		_iscrollEnd = false;
		preScenMode = (_menuId == 'EM0503') ? 1 : 2;
		pageCount = 0;
		items = [];
		startNum = 1;
		endNum = _pageSize;
	}

	$(document).on({
		pageinit: _pageinit,
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			if(_totalCount && param.totalCnt != _totalCount){
				initData();
			}
			_totalCount = param.totalCnt;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				request();
			}
		},
		pulldownrefresh : function() {
			initData();
			request();
		},
		orientationchange : function() {
			DGB.Common.refreshLayout(_layout);
			return false;
		}
	}, '#EMWK003');
})();
