(function() {
	var $this;
    var _layout;
	var _menuId;
	var _msgReciever = [];
	var _20msg = []; //20명씩 나눠서 전송.
	var _sendSize = 20;
	var _startNum = 0;
	var _endNum=20;
	var _pushCn = ""; //전송메시지
	var _rcv_names = "";
	var _issms = false;
	var addflag = false;
	
	var pageinit = function(instance) {
		$this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		
		$this.find('#emst06MsgSendBtn').off('vclick').on('vclick', function() {
            clickSendPush();
			return false;
		});

		
		//직원 추가 버튼
		$this.find('#emst06Addreciever').off('vclick').on('vclick', function() {
			addflag = true;

            DGB.Common.hideKeyboard();
            $this.find('#emst06MsgSendBtn').focus();

            var args = {
                menuId : _menuId,
                msgReciever : _msgReciever
            };
            DGB.Page.triggerPage("#EMST007", "parentpage", [args]);
            setTimeout(function () {
                DGB.Page.changePage('#EMST007');
            },400);
			return false;
		});

        //뒤로가기 버튼
        $this.find('#emst06backbtn').off('vclick').on('vclick', function(){
            changPage();
            return false;
        });

        function clickSendPush() {
            var msgSMSMaxLan = 80; //byte로 계산 한글 40자, 영문 80자
            var msgPushMaxLan = 4000;  //byte로 계산 한글 2000자, 영문 4000자

            //키보드 내리기
            DGB.Common.hideKeyboard();
            $this.find('#emst06MsgSendBtn').focus();
            _pushCn = $("#emst06MsgInput").val();
            if (_pushCn == "") {
                showAlert(Messages.msg053);
                return false;
            }

            var srccount = getMsgLength(_pushCn);
            if(_issms){
                if( srccount > msgSMSMaxLan){
                    showAlert(Messages.msg122);
                    return;
                }
            } else {
                if( srccount > msgPushMaxLan){
                    showAlert(Messages.msg121);
                    return;
                }
            }

            var checked = $this.find('#ckbMessUseYn').prop('checked');
            if( _msgReciever.length > 1 ) {
                var title = Messages.msg124 + '\n전송 : ' + _msgReciever[0].NAME + ' 외 ' + (_msgReciever.length - 1) + '명';
                showConfirm(function(btn){
                    if (btn == '1') {
                        dgbLoading(true);
                        sendPushMsg(_pushCn, checked ? 'Y' : 'N');
                    }
                },  title);
            } else {
                dgbLoading(true);
                sendPushMsg(_pushCn, checked ? 'Y' : 'N');
            }
        };
		
		function sendPushMsg(pushCn, MESS_USE_YN){
			// 푸쉬 전송 처리
			var param = _msgReciever;	// 메시지 받을 사람 배열 파라미터
			var rcvEnobs = "";	        // 받을사람행번
			var rcvNames = "";	        // 받을사람이름

			if(_msgReciever.length <= _sendSize){
				$.each(param, function(index, value) {
					if (index == 0) {
                        rcvEnobs = value.SABUN;
                        rcvNames = value.NAME;
					} else {
                        rcvEnobs += ("," + value.SABUN);
                        rcvNames += ("," + value.NAME);
                    }
				});
			}
			else{
				_20msg = param.slice(_startNum,_endNum);
				$.each(_20msg, function(index, value) {
					if (index == 0) {
                        rcvEnobs = value.SABUN;
                        rcvNames = value.NAME;
					} else {
                        rcvEnobs += ("," + value.SABUN);
                        rcvNames += ("," + value.NAME);
					}
				});
			}
			
			var invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00007',
					parameters : [{CS_ID :_menuId,
								   SYS_ID : SYS_ID, 
								   DSPT_ENOB : USER_INFO.ENOB,
								   DSPT_COMP_DVCD : USER_INFO.ENTER_CD,
								   RCV_ENOBS : rcvEnobs,
								   RCV_NAMES : rcvNames,
								   PUSH_CN :pushCn,
								   D_SENDER :USER_INFO.HP,
								   ORG_CD :USER_INFO.ORG_CD,
								   CS_MMT_YN :"N",	//메시지함 화면 이동여부
								   PSNM : USER_INFO.FSNM,
                                   MESS_USE_YN: MESS_USE_YN
								  }]
				};
			
			var options = {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {},
					timeout : 120000
			};
			callProcedure(invocationData, options);
			
		}

		function displayResult(data) {
			var result = data.invocationResult;
			if (result.count == 0) {
				dgbLoading(false);
				showAlert(Messages.msg010);	//메시지전송 실패하였습니다.
				$('#emst06MsgSendBtn .ui-btn-text').text("메시지재전송");
			}else if(_msgReciever.length == 1 && result.count == 1) {	// 1명인 경우

				dgbLoading(false);
				showAlert(Messages.msg008+"\n전송 : "+result.RCV_NAMES);
                initData();
			}
			else {
				
				var s_data = result.RCV_NAMES;
				var arr_data = s_data.split(",");
				var first_name = arr_data[0];
				var sendcount = result.count -1;
				
				if(_msgReciever.length <= _sendSize){
				
					dgbLoading(false);
					showAlert(Messages.msg008+"\n전송 : "+first_name + " 외 "+ sendcount +"명" );
                    initData();
				} else {

					if( (_startNum >= _sendSize) && (result.RCV_NAMES.charAt(0) != ",") ){
						_rcv_names += ","+result.RCV_NAMES;
					} else {
						_rcv_names += result.RCV_NAMES;
					}
					
					if(_msgReciever.length <= _endNum){ //_msgReciever.length 크기보다 마지막값이 크면 종료
						
						var foo = _rcv_names.split(',');
						foo.join();
						var first_name = foo[0];
						var sendcount = foo.length -1;
						
						dgbLoading(false);
						showAlert(Messages.msg008+"\n전송 : "+first_name + " 외 "+ sendcount +"명" );
                        initData();
					} else {
                        var checked = $this.find('#ckbMessUseYn').prop('checked');
						_startNum += _sendSize;
						_endNum += _sendSize;
						sendPushMsg(_pushCn, checked ? 'Y' : 'N');
					} 
						
				}
			}
		}

		function displayError() {
			dgbLoading(false);
			showAlert(Messages.msg010);
		}
	};

    function initData(page) {
        if( !page ) {
            page = $.mobile.activePage;
        }

        if( !addflag ) {
            page.find('#emst06MsgInput').val('');
            page.find('#emst06MsgInput').css("height", "80px");
            page.find('#ckbMessUseYn').prop('checked', false).checkboxradio('refresh');
        }
        page.find('#emst06MsgSendBtn .ui-btn-text').text("메시지전송");

        _startNum = 0;
        _endNum = 20;
        _pushCn= "";
        _rcv_names = "";
    };
	
	function setContents() {
		var receiverName = "";
		_msgReciever.forEach(function(elem) {
            receiverName += elem.NAME + ", ";
		});
		
		var last = receiverName.lastIndexOf(',');
		receiverName = receiverName.substr(0,last);
		$this.find('#emst06Reciever').text(receiverName);

		$.each(_msgReciever, function(index, value) {
			if(value.ISPUSH == "false") {
				_issms = true;
				return false;
			}
		});

		if(_issms){
			showAlert(Messages.msg123);
			return;
		}
	}
	
	function changPage(){
        showConfirm(function(button){
            if (button == '1') {
                if (DGB.isAndroid()) {
                    setTimeout(function () {
                        DGB.Page.changePage('#EMST005');
                    }, 300);
                } else{
                    DGB.Page.changePage('#EMST005');
                }
            }
        }, Messages.msg076);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
            WL.App.overrideBackButton(changPage);
			setContents();
            _layout.refreshLayout();
		},
		pagebeforehide: function(e) {
            initData($(e.target));
            $('#EMST006 .initContents').text("");
			_issms = false;
			addflag = false;
		},
		parentpage :function(evt, param) {
			_msgReciever = param.msgReciever;
			_menuId = param.menuId;
			dgbLoading(false);
		},
		orientationchange : function() {
            _layout.refreshLayout();
            return false;
		}
	}, '#EMST006');
})();
