(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;
	var _mgstype = undefined;
    var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	function setContents() {
        _layout.resetLayout();

        DGB.Common.backPage();

		var title = "";
		if (_item.CS_NM == undefined || _item.CS_NM == "") {
			title = "알림 메시지";
		} else {
			title = _item.CS_NM + "에서 보냄";
		}
		
		$('#co03CSNM').text(title);
		$('#co03FWDtti').text(_item.FW_DTTI);

		if(_mgstype == "rece"){
            // A로 시작하는 행번일때 답장하기 버튼 숨김.
            if(_item.DSPT_ENOB.charAt(0) == 'A')
            {
                $('#co03MsgSendBtn').addClass("displayNone");
            }
			$('#co03DsptNm').text(_item.DSPT_NM);
			$('#co03MsgSendBtn .ui-btn-text').text("답장하기");

            $('#co03DsptMess').addClass("displayNone");
		}else{
			$('#co03DsptNm').text(_item.RCV_NAME);
			$('#co03MsgSendBtn .ui-btn-text').text("새로답장하기");

            if( _item.MESS_USE_YN == 'Y' ) {
                $('#co03DsptMess').removeClass("displayNone");
            } else {
                $('#co03DsptMess').addClass("displayNone");
            }
		}

		_item.PUSH_CN = _item.PUSH_CN.replace(/</gi, '&lt;');
		_item.PUSH_CN = _item.PUSH_CN.replace(/>/gi, '&gt;');
		_item.PUSH_CN = _item.PUSH_CN.replace(/\n/g,'<br />');
		var pushCnhtml = "<p class='pushCnDiv co03PushCn w100'>"+_item.PUSH_CN.autoLink({ class: "pushCnMsg" })+"</p>";
		$("#co03divpushCn").html(pushCnhtml);

        _layout.refreshLayout(100);

		//url 링크
		$this.find('.pushCnMsg').off('vclick').on('vclick',function(e){
			var href = $(this).attr("href");
			WL.App.openURL(href, "_blank", "location=1");
			e.preventDefault();
			return false;
		});
		
		if (_item.LINK_URL != undefined && _item.LINK_URL != "" ) {
			$('#co03Attach').css("display","");
			
			var elem = "첨부파일";
			var html = "<li><a href='#' class='ui-link noTitle' data-url="+_item.LINK_URL+"><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
			$('#co03Attach').append(html);
			
			$('#co03Attach').find('li a').off('vclick').on('vclick',function(){
				var linkUrl = $(this).attr('data-url');

				var attachURL =  DOWN_URL+linkUrl;
				var fileType = (linkUrl.split('.'))[1];	//첨부파일확장자
				
				//이미지일때
				if (fileType.indexOf('jpg') != -1 || fileType.indexOf('png') != -1 || fileType.indexOf('bmp') != -1 || fileType.indexOf('gif') != -1) {
					window.open(encodeURI(attachURL), "_blank", "EnableViewPortScale=yes,location=no");
				} else {//이미지 아닐때 뷰어로 실행..하기위해서 로컬에 저장
					var downPath = DGB.fileRoot() + "message/";
					var file = {"url" :attachURL, "title":"data", "downPath":downPath};//url, 파일명, 경로
					downloadFile(file);
				}
				return false;
			});
		}
		
		//답장하기
		$('#co03MsgSendBtn').off('vclick').on('vclick',function(){
			var args = {
                item : _item,
                menuId : _menuId,
                mgstype : _mgstype
            };
            DGB.Page.triggerPage("#CO00009", "parentpage", [args]);
            DGB.Page.changePage('#CO00009');
            return false;
		});
	}

	$(document).on({
		pageinit: function() {
            $this = $(this);
            _layout = new DGB.layout($this, _headerHeight);

		},
		pageshow: function() {
			setContents();
		},
		pagebeforehide: function() {
			$('#co03Attach').empty();
			$('#co03Attach').css("display","none");
			$('#co03PushCn').val("");
			$('#co03PushCn').css("height","100px");
            $("#co03MsgSendBtn").removeClass("displayNone");
		},
		parentpage :function (e, param) {
            // $(e.target).find('.initContents').text("");

			_item = JSON.parse(param.item);
			_menuId = param.menuId;
			_mgstype =param.msgselect;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#CO00003');
})();
