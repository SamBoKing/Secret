(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
    var _layout = undefined;
	var directpmsg = null;
	var _pushnum = undefined; //푸시 고유번호
    var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

        _layout = new DGB.layout($this, _headerHeight);
		
		directpmsg = {
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},
				call : function() {
					dgbLoading(true); 

					invocationData = {
						adapter : 'DBTransactionAdapter',
						procedure : 'TCO00006_2',
						parameters : [ {
							CS_ID:"CO0101",
							PUSH_FW_SEQ : _pushnum //푸시 고유번호
						} ]
					};
					
					callProcedure(invocationData, this.options);
				}
			};
		
		function displayResult(data) {
			_item = data.invocationResult.resultSet[0];
			
			dgbLoading(false);
			if(_item == undefined){
				showAlert(Messages.msg059);
			}
			else{
				$('#copu01FWDtti').text(_item.FW_DTTI);
				$('#copu01DsptNm').text(_item.DSPT_NM);

				if(_item.DSPT_ENOB.charAt(0) == 'A')
	            {
	                $('#copu01MsgSendBtn').addClass("displayNone");
	            }
				
				_item.PUSH_CN = _item.PUSH_CN.replace(/\n/g,'<br/>');
				
				var pushCnhtml = "<div class='pushCnDiv co03PushCn w100'>"+_item.PUSH_CN.autoLink({ class: "pushCnMsg" })+"</div>";
				$("#copu01Pushdiv").html(pushCnhtml);

				//$('#copu01PushCn').val(_item.PUSH_CN);
				
				//url 링크
				$this.find('.pushCnMsg').off('vclick').on('vclick',function(e){
					var href = $(this).attr("href");
					WL.App.openURL(href, "_blank", "location=1");
					e.preventDefault();
					return false;
				});
				
				if (_item.LINK_URL != undefined && _item.LINK_URL != "" ) {
					$('#copu01Attach').css("display","");
					
					var elem = "첨부파일";
					var html = "<li><a href='#' class='ui-link noTitle' data-url="+_item.LINK_URL+"><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
					$('#copu01Attach').append(html);
					
					//첨부파일 클릭 이벤트
					$('#copu01Attach').find('li a').off('vclick').on('vclick',function(){
						var linkUrl = $(this).attr('data-url');

						var attachURL =  DOWN_URL+linkUrl;
						var fileType = (linkUrl.split('.'))[1];	//첨부파일확장자
						
						//이미지일때
						if (fileType.indexOf('jpg') != -1 || fileType.indexOf('png') != -1 || fileType.indexOf('bmp') != -1 || fileType.indexOf('gif') != -1) {
							window.open(encodeURI(attachURL), "_blank", "EnableViewPortScale=yes,location=no");
						}else {//이미지 아닐때 뷰어로 실행..하기위해서 로컬에 저장
							var downPath = DGB.fileRoot() + "message/";
							downloadFile({"url" :attachURL, "title":"data", "downPath":downPath});
						}
						return false;
					});
				}

                DGB.Common.backMenu();
                _layout.refreshLayout(100);
			}
			
		}
		function displayError(){
            DGB.Log.e('[SRW_COPU002] ====>> Display Error!');
		}
		
		//답장하기
		$('#copu01MsgSendBtn').off('vclick').on('vclick',function(){
			var args = {
                item : JSON.stringify(_item),
                menuId : _menuId
            };
            DGB.Page.triggerPage('#COPU002', 'parentpage', [args]);
            DGB.Page.changePage('#COPU002');
		});
		
	};
	
	function setContents() {
        _layout.resetLayout();
		directpmsg.call();
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
			setContents();
		},
		pagebeforehide: function() {
            $("#copu01MsgSendBtn").removeClass("displayNone");
		},
		parentpage :function (evt, param) {
            _item = {};
            _pushnum = param.payload;

			$('#COPU001 .initContents').text("");
			$('#copu01Attach').empty();
			$('#copu01Attach').css("display","none");
			$('#copu01PushCn').val("");
			$('#copu01PushCn').css("height","100px");

			if($('.ui-page-active').attr('id') == 'COPU001') {
				setContents();
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#COPU001');
})();