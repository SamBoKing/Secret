(function() {
	var $this, _menuId, _layout;
	var linkMap =  new DGB.HashMap();

	var pageinit = function() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        // 수정 : msg119, msg120, msg125, msg130, msg131 -> 타이틀로 변경
        // 수정 : url029, url031 -> 마켓 url로 변경
        // 추가 : msg133 -> [앱] 설치 화면으로 이동하시겠습니까?
		linkMap.put('dgbp', { android : Messages.url023, iphone : Messages.url024, title : JSON.parse(Messages.msg119.replace(/'/g, '\"')) || {} });
		linkMap.put('dgbm', { android : Messages.url025, iphone : Messages.url026, title : JSON.parse(Messages.msg120.replace(/'/g, '\"')) || {} });
		linkMap.put('dgbfium', { android : Messages.url027, iphone : Messages.url028, title : JSON.parse(Messages.msg125.replace(/'/g, '\"')) || {} });
		linkMap.put('dgbrn', { android : Messages.url029, iphone : Messages.url030, title : JSON.parse(Messages.msg130.replace(/'/g, '\"')) || {} });

		var keys = linkMap.keys();
		for(var i in keys) {
            var link = linkMap.get(keys[i]);
            var app = $this.find('#' + keys[i]);
			var img = $this.find('#img_' + keys[i]);
			img.on('vclick', goLink);
            app.find('appcaption').html( getTitle(link).replace(/(\n)/g, '<br/>') );
		}
	};

    function getTitle(link) {
        var title = DGB.isIPhone() ? link.title.iphone : link.title.android;
        return title || '';
    }

	function goLink() {
		var key = $(this).attr('id').replace('img_', '');
		var link = linkMap.get(key);
		if( !link ) {
			showAlert('Link object is null');
			return false;
		}

        var confirm = getTitle(link).replace(/(\n)/g, '') + Messages.msg133;
		if( (DGB.isAndroid() && link.android) || DGB.isDebug() ) {
			showConfirm(function(btn){
				if (btn == '1') {
					if( link.android.indexOf('market://') > -1 )
						$(location).attr('href', link.android);
					else {
						var file = {"url" :link.android, "title":key, "downPath": DGB.fileRoot() + 'apps/'};
						downloadFile(file);
					}
				}
			}, confirm);
		} else if( DGB.isIPhone() && link.iphone ) {
			showConfirm(function(btn){
				if (btn == '1') {
					window.open(link.iphone, "_system");
				}
			}, confirm );
		} else {
			showAlert(Messages.msg132);
		}
		return false;
	}

	$(document).on({
        pageinit : pageinit,
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow : function() {
			_layout.refreshLayout(100);
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#CO00010');
})();
