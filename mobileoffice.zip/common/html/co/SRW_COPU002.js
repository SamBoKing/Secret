(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _rcvEnob = undefined;
	var _name = undefined;
	var _item = {};
	
	var pageinit = function(instance) {
		$this = instance;

		$this.find('#copu02MsgSendBtn').off('vclick').on('vclick', function() {
			var msgPushMaxLan = 4000; //byte로 계산 한글 2000자, 영문 4000자

            DGB.Common.hideKeyboard();
            $this.find('#copu02MsgSendBtn').focus();

			var pushCn = $("#copu02MsgInput").val();
			if (pushCn == "") {
				showAlert(Messages.msg053);
				return false;
			}
			
			//2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
			pushCn = pushCn.replace( /(\')/g,'\"');
			
			var srccount = getMsgLength(pushCn);
            if( srccount > msgPushMaxLan){
                showAlert(Messages.msg121);
                return;
            }

            var checked = $this.find('#ckbMessUseYn').prop('checked');

			dgbLoading(true);
			var invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TEM00005_1',
					parameters : [{CS_ID :"EM0103", //메시지보내기로 설정
								   SYS_ID : SYS_ID, 
								   DSPT_ENOB : _item.RCV_ENOB,  // 보내는사람 행번
								   ENOB : _item.RCV_ENOB,       // 행번
								   DSPT_COMP_DVCD : "DGB",
								   RCV_ENOB : _rcvEnob,         // 받는사람 행번
								   PUSH_CN :pushCn,             // 푸시메시지
								   ORG_CD :"906",
								   CS_MMT_YN :"N",	            // 메시지함 화면 이동여부
								   PSNM : _item.RCV_NAME,       // 보내는사람 이름
                                   MESS_USE_YN : checked ? 'Y' : 'N'
								   }]
				};
			
			var options = {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
			};
			
			callProcedure(invocationData, options);
			return false;
		});
		
		function displayResult(data) {
            dgbLoading(false);
			if (data.invocationResult.result == "1") {	//data 성공 :1, 실패 0
                initData();
				showAlert(Messages.msg008);
			}else {
				showAlert(Messages.msg010);
				$('#copu02MsgSendBtn .ui-btn-text').text("메시지재전송");
			}
		}

		function displayError() {
			dgbLoading(false);
			showAlert(Messages.msg010);
		}
	};
	
	function setContents() {
        DGB.Common.backPage();
		$this.find('#copu02Reciever').text(_name);
	}

    function initData(page) {
        if( !page ) {
            page = $.mobile.activePage;
        }
        page.find('#copu02MsgInput').val("");
        page.find('#copu02MsgInput').css("height","80px");
        page.find('#copu02MsgSendBtn .ui-btn-text').text("메시지전송");
    }
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
			setContents();
		},
        pagebeforehide: function(e) {
            initData($(e.target));
            $(e.target).find('.initContents').text("");
        },
		parentpage :function(e, param) {
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
			_name =_item.DSPT_NM;
			_rcvEnob = _item.DSPT_ENOB;
		},
		orientationchange : function() {
            return false;
		}
	}, '#COPU002');
})();