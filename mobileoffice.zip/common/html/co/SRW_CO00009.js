(function() {
	var _rcvEnob = undefined;
	var _name = undefined;

	$(document).on({
		pageinit: function() {
            $(this).find('#co09MsgSendBtn').off('vclick').on('vclick', function() {
                onSelectPushType();
                return false;
            });
		},
		pageshow: function() {
            $('#co09Reciever').text(_name);
		},
		pagebeforehide: function(e) {
            initData($(e.target));
			$('#CO00009 .initContents').text("");

		},
		parentpage :function(evt, param) {
            _name = (param.mgstype == "rece") ? param.item.DSPT_NM : param.item.RCV_NAME;
            _rcvEnob = (param.mgstype == "rece") ? param.item.DSPT_ENOB : param.item.RCV_ENOB;
		},
		orientationchange : function() {
            return false;
		}
	}, '#CO00009');

    function initData(page) {
        if( !page ) {
            page = $.mobile.activePage;
        }
        page.find('#ckbMessUseYn').prop('checked', false).checkboxradio('refresh');
        page.find('#co09MsgInput').val("");
        page.find('#co09MsgInput').css("height","80px");
        page.find('#co09MsgSendBtn .ui-btn-text').text("메시지전송");
    };


    function onSelectPushType() {
        var page = $.mobile.activePage;
        page.find('#co09MsgSendBtn').focus();

        //키보드 내리기
        DGB.Common.hideKeyboard();

        var msgPushMaxLan = 4000;   //byte로 계산 한글 2000자, 영문 4000자
        var pushCn = page.find("#co09MsgInput").val();
        if (pushCn == "") {
            showAlert(Messages.msg053);
            return;
        }

        //2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
        pushCn = pushCn.replace( /(\')/g,'\"');
        pushCn = pushCn.replace(/(<|<\;)br\s*\/*(>|>\;)/g, "\n");
        if( getMsgLength(pushCn) > msgPushMaxLan){
            showAlert(Messages.msg121);
            return;
        }

        var checked = page.find('#ckbMessUseYn').prop('checked');
        dgbLoading(true);
        onSendPush(pushCn, checked ? 'Y' : 'N');
    };

    function onSendPush(PUSH_CN, MESS_USE_YN) {
        dgbLoading(true);
        var invocationData = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TEM00005',
            parameters : [{CS_ID :"EM0103",
                SYS_ID : SYS_ID,
                DSPT_ENOB : USER_INFO.ENOB,
                DSPT_COMP_DVCD : USER_INFO.ENTER_CD,
                RCV_ENOB : _rcvEnob,
                PUSH_CN :PUSH_CN,
                ORG_CD :USER_INFO.ORG_CD,
                D_SENDER :USER_INFO.HP,
                CS_MMT_YN :"N",	                // 메시지함 화면 이동여부
                PSNM : USER_INFO.FSNM,
                MESS_USE_YN : MESS_USE_YN       // 메신저 전송 추가시 사용
            }]
        };

        var options = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };
        callProcedure(invocationData, options);
    };

    function onSuccess(data) {
        dgbLoading(false);
        if (data.invocationResult.result == "1") {
            initData();
            showAlert(Messages.msg008);
        }else {
            showAlert(Messages.msg010);
            $('#co09MsgSendBtn .ui-btn-text').text("메시지재전송");
        }
    }

    function onFailure() {
        dgbLoading(false);
        showAlert(Messages.msg010);
    }
})();

