(function() {
    var _page,
        _layout,
        _input_id,
        _input_pass,
        _save_id,
        _rd_login,
        _rd_bio,
        _rd_nfc,
        _tab_id,
        _init_fido,
        _help1,
        _help2,
        _sms_help,
        _sms_ymd,
        _sms_count,
        _sms_request,
        _sms_auth,
        _sms_ok,
        _nfc_help,
        _nfc_state,
        _nfc_img,
        _nfc_auth,
        _nfc_ok,
        _nfc_setting,
        _div_id,
        _div_pass,
        _div_sso,
        _div_sms,
        _div_sms_wait;

    var isOneClick;
    var BACK_GLOBAL = {};

    var NFC_STATE = { ERR : '-1', OFF : '0', ON : '1' };

    var HELP_STATE = {
        ID : ['· 행번인증이 필요합니다.', '· 행번 7자리를 입력하여 주십시오.'],
        PASS : ['· SSO 인증이 필요합니다.', '· 행번과 SKY 비밀번호는 당행 내부업무시스템에 접속하는 SKY 로그인 행번과 비밀번호입니다.'],
        SMS : ['· SMS 인증이 필요합니다.', '· 생년월일 6자리를 입력하여 SMS 인증번호를 요청하시기 바랍니다.']
    };

    function _pageinit(e) {
        _page = $(e.target);
        _layout = new DGB.layout(_page, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
        _input_id = _page.find('#loginId');
        _input_pass = _page.find('#loginPw');
        _save_id = _page.find('#ckb_save_id');
        _div_sso = _page.find('#div_sso');
        _div_sms = _page.find('#div_sms');
        _div_id = _page.find('#div_id');
        _div_pass = _page.find('#div_pass');
        _div_sms_wait = _page.find('#div_sms_wait');

        _help1 = _page.find('#login_help1');
        _help2 = _page.find('#login_help2');
        _sms_help = _page.find('#sms_help');
        _sms_ymd = _page.find('#sms_ymd');
        _sms_count = _page.find('#sms_count');
        _sms_request = _page.find('#sms_request');
        _sms_auth = _page.find('#sms_auth');
        _sms_ok = _page.find('#sms_ok');
        _nfc_img = _page.find('#nfc_img');
        _nfc_help = _page.find('#nfc_help');
        _nfc_state = _page.find('#nfc_state');
        _nfc_auth = _page.find('#nfc_auth');
        _nfc_ok = _page.find('#nfc_ok');
        _nfc_setting = _page.find('#nfc_setting');
        _rd_login = _page.find('#rd_login');
        _rd_bio = _page.find('#rd_bio');
        _rd_nfc = _page.find('#rd_nfc');

        // IPhone NFC 사용안됨
        if( DGB.isIPhone() ) {
            // 사용을 안할시
            _page.find('.login_view_tab .ui-radio').addClass('ios');

            // 입력으로 사용시
            _nfc_img.hide();
            _nfc_setting.hide();
            _nfc_help.text('사원증번호를 입력해 주세요.');

            _nfc_auth.attr('readonly', '');
        } else {
            onNfcStateChange(NFC_STATE.OFF);
            _nfc_auth.attr('readonly', 'readonly');
            _nfc_auth.on('vclick', function() {
                showAlert(_nfc_help.text());
                return false;
            });
        }

        _input_id.on({
            focusin: function() {
                _input_pass.attr('readonly', false);
                if( !_input_id.attr('readonly') ) {
                    if(_page.find(".my-toggle").css('display') == 'none') {
                        _page.find(".my-toggle").css('display', 'block');
                    }
                }
                return false;
            },
            keyup: function() {
                //행번 7자리만 입력
                var text = $(this).val();
                var maxlength = $(this).data('maxlength');
                if(maxlength > 0) {
                    $(this).val(text.substr(0, maxlength));
                }
            },
            keydown : function(e) {
                if ( DGB.isAndroid() ) {
                    if(e.keyCode == 9){
                        _input_pass.focus();
                        return false;
                    }
                }
            },
            blur: function() {
                _input_pass.attr('readonly',true);
                return false;
            }
        });

        _input_pass.attr('readonly',true);
        _input_pass.on({
            vclick : function() { showKeyPad(); return false; },
            focusin: function(){ showKeyPad(); return false; },
            blur: function(){ _input_pass.attr('readonly',false); _input_id.focus(); return false; }
        });

        // IPAD1 에서 input 박스에 ',' 문자 자동을 붙는거 해결
        if( DGB.isIPhone() ) {
            _input_id.on('passwordVisibilityChange', function () {
                _input_id.attr("pattern", "[0-9]*");
                _input_id[0].type = "text";
            });
        }

        // 행번 자동저장 부분추가
        _save_id.prop('checked', nmf.Store.get('SAVE_ID')).checkboxradio('refresh');
        _save_id.on('change', function() {
            nmf.Store.set('SAVE_ID', $(this).prop('checked'));
        });

        _page.find('#rd_tab').on('change', onClickTab);
        _page.find('#bioInsert').on('vclick', onBioInsert);
        _page.find('#bioDelete').on('vclick', onBioDelete);
        _page.find('.bioMenu').on('vclick', onBioSelect);
        _page.find('#loginBtn').on('vclick', onLogin);
        _sms_request.on('vclick', onSmsRequest);
        _sms_ymd.on('keydown', onKeySmsRequest);
        _sms_ymd.on('keyup', function() {
            var me =  $(this);
            me.val(me.val().substr(0, me.data('maxlength')));
        });
        _sms_ok.on('vclick', onSmsAuth);
        _sms_auth.on('keydown', onKeySmsAuth);
        _sms_auth.on('keyup', function() {
            var me =  $(this);
            me.val(me.val().substr(0, me.data('maxlength')));
        });

        _nfc_img.on('vclick', function() { if( DGB.isAndroid() ) { DGB.Nfc.setting(); } });
        _nfc_ok.on('vclick', onNfcAuth);
        _nfc_setting.on('vclick', function() { DGB.Nfc.setting(); });
        _nfc_auth.on('keydown', onKeyNfcAuth);
        _nfc_auth.on('keyup', function() {
            var me =  $(this);
            me.val(me.val().substr(0, me.data('maxlength')));
        });
    }

    function _pageshow() {
        DGB.Common.backMenu();
        var fido_start = false;
        if( !_init_fido && DGB.Fido.get(DGB.Fido.BIO_LOGIN) && DGB.Fido.check() ) {
            fido_start = true;
        }
        _init_fido = true;

        _tab_id = 'tab_login';
        if ( fido_start ) {
            _tab_id = 'tab_bio';
        }

        _page.find(".my-toggle").css('display','none');
        _input_id.hidePassword('focus', {
            toggle : { className: 'my-toggle' },
            style : { display:'block' }
        });

        // 자동저장에 따른 아이디 설정
        if( !_input_id.val() && DGB.Sms.get() && _save_id.prop('checked') ) {
            _input_id.val(DGB.Sms.get());
            _input_id.showPassword();
        }

        // IPAD1 에서 input 박스에 ',' 문자 자동을 붙는거 해결
        if( DGB.isIPhone() ) {
            _input_id.attr("pattern","[0-9]*");
            _input_id[0].type="text";
            _sms_ymd.attr("pattern","[0-9]*");
            _sms_ymd[0].type="text";
            _sms_auth.attr("pattern","[0-9]*");
            _sms_auth[0].type="text";
        }

        // NFC 상태확인
        if( DGB.isAndroid() ) {
            DGB.Nfc.is(onNfcStateChange);
        }
        _updateTab();

        if( fido_start ) {
            DGB.Fido.auth(DGB.Fido.type(),
                function() {
                    GLOBAL.ENOB = DGB.Fido.id(true);
                    GLOBAL.STAT = DGB.Auth.Level.Bio;
                    GLOBAL.TEMP_STAT = GLOBAL.STAT;
                    GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
                    authProcess();
                }
            );
        }
    }

    function _pagehide() {
        _sms_help.text('');
        _sms_ymd.val('');
        _sms_auth.val('');
        _div_sms_wait.hide();
    }

    function onNfcStateChange(state) {
        if( state == NFC_STATE.OFF ) {
            _nfc_help.text('NFC를 활성화 해주세요.');
            _nfc_img.attr('class', 'nfc_off');
        } else if( state == NFC_STATE.ON) {
            _nfc_help.text('사원증을 뒷면에 태깅해 주세요.');
            _nfc_img.attr('class', 'nfc_on');
        } else {
            _nfc_help.text('NFC를 지원하지 않는 단말입니다.');
            _nfc_img.attr('class', 'nfc_off');
        }
    }

    function _updateLayout() {
        var help = [];
        _input_pass.val('');

        switch (GLOBAL.STAT) {
            default:
            case DGB.Auth.Level.ID:
                help = HELP_STATE.ID;
                _div_sso.show();
                _div_sms.hide();
                _div_id.show();
                _div_pass.hide();
                break;
            case DGB.Auth.Level.Pass:
                help = HELP_STATE.PASS;
                if( GLOBAL.ENOB ) {
                    _input_id.val(GLOBAL.ENOB);
                }

                if(window.regAuthState == DGB.Auth.Level.ID) {
                    _input_id.attr("readonly", true);
                }
                _div_sso.show();
                _div_sms.hide();
                _div_id.show();
                _div_pass.show();
                break;
            case DGB.Auth.Level.Sms:
                if( !window.regAuthState ) {
                    help = HELP_STATE.PASS;
                    _div_sso.show();
                    _div_sms.hide();
                    _div_id.show();
                    _div_pass.show();
                } else if( window.regAuthState == DGB.Auth.Level.ID ) {
                    help = HELP_STATE.PASS;
                    if( GLOBAL.ENOB ) {
                        _input_id.val(GLOBAL.ENOB);
                    }
                    _input_id.attr("readonly", true);
                    _div_sso.show();
                    _div_sms.hide();
                    _div_id.show();
                    _div_pass.show();
                } else {
                    help = HELP_STATE.SMS;
                    _div_sso.hide();
                    _div_sms.show();
                    _sms_request.focus();
                    setTimeout(function() { _sms_ymd.focus(); }, 200);
                }
                break;
            case DGB.Auth.Level.Nfc:
                _rd_nfc.click();
                break;
        }

        if( help && help.length == 2 ) {
            _help1.html(help[0]);
            _help2.html(help[1]);
        }
    }

    function showKeyPad(){
        if(isOneClick) {
            _input_pass.blur();
           return;
        }
        isOneClick = true;
        setTimeout(function(){ isOneClick = false; }, 2000);

        if(_input_id.val().length < 4 || _input_id.val().length > 7 ) {
            _input_id.focus();
            showAlert(Messages.msg004);
            return false;
        }
        _page.find('#loginBtn').focus();
        onE2K('eng','loginPw', '8', '15', 'Sky 비밀번호', '1');
    }

    function onLogin() {
        if( isOneClick ) return;

        isOneClick = true;
        setTimeout(function() { isOneClick = false; }, 1000);

        if( !GLOBAL.STAT ) {
            GLOBAL.STAT = DGB.Auth.Level.ID;
        }

        switch (GLOBAL.STAT) {
            case DGB.Auth.Level.ID:      // 행번인증
                // id pw 전역 저장
                _input_id.blur();
                GLOBAL.ENOB = _input_id.val();
                break;
            case DGB.Auth.Level.Pass:    // SSO 인증
                GLOBAL.ENOB = _input_id.val();
                GLOBAL.PSWD = _input_pass.attr('data-enc');
                break;
        }

        if(window.regAuthState != DGB.Auth.Level.Pass) {
            if(GLOBAL.ENOB == undefined || GLOBAL.ENOB.length < 4 || GLOBAL.ENOB.length > 7) {
                showAlert(Messages.msg004);
                return false;
            }

            if(GLOBAL.STAT != DGB.Auth.Level.ID){
                if(GLOBAL.PSWD == undefined || GLOBAL.PSWD.length < 1) {
                    showAlert(Messages.msg034);
                    return false;
                }
            }
        }
        authProcess();
        return false;
    }

    function _updateTab() {
        _rd_login.prop("checked", _tab_id == 'tab_login');
        _rd_login.checkboxradio("refresh");
        _rd_bio.prop("checked", _tab_id == 'tab_bio');
        _rd_bio.checkboxradio("refresh");
        _rd_nfc.prop("checked", _tab_id == 'tab_nfc');
        _rd_nfc.checkboxradio("refresh");

        var tab_login = _page.find('#tab_login');
        var tab_bio = _page.find('#tab_bio');
        var tab_nfc = _page.find('#tab_nfc');
        if( tab_login && tab_bio && tab_nfc ) {
            if( _tab_id == 'tab_login' ) {
                tab_login.show();
                tab_bio.hide();
                tab_nfc.hide();
            } else if( _tab_id == 'tab_bio' )  {
                tab_login.hide();
                tab_bio.show();
                tab_nfc.hide();
            } else if( _tab_id == 'tab_nfc' ) {
                tab_login.hide();
                tab_bio.hide();
                tab_nfc.show();
            }
        }
        _layout.refreshLayout(500);
    }

    function onClickTab(e) {
        // 상태복원
        GLOBAL.STAT = BACK_GLOBAL.STAT;
        GLOBAL.PAGEID = BACK_GLOBAL.PAGEID;
        GLOBAL.TEMP_STAT = BACK_GLOBAL.TEMP_STAT;
        GLOBAL.TEMP_PAGEID = BACK_GLOBAL.TEMP_PAGEID;

        if( e.target.id == 'rd_login' ) {
            _tab_id = 'tab_login';
        } else if( e.target.id == 'rd_bio' ) {
            _tab_id = 'tab_bio';
        } else if( e.target.id == 'rd_nfc' ) {
            _tab_id = 'tab_nfc';
        }


        if( !DGB.isDebug() ) {
            if( _tab_id != 'tab_login' && !DGB.Sms.get() ) {
                showAlert('통합인증 및 SMS 인증 후 사용하실 수 있습니다.');
                _tab_id = 'tab_login';
            }
        }

        _updateTab();
        // 키패드 닫히는 시간이후 업데이트
        setTimeout(function() { _updateTab(); }, 300);
        return false;
    }

    function onKeySmsRequest(e) {
        if ( (DGB.isAndroid() && e.keyCode == 9) || (!DGB.isAndroid() && e.keyCode == 13) ) {
            DGB.Common.hideKeyboard();
            _sms_request.focus();
            setTimeout(onSmsRequest, 300);
            return false;
        }
    }

    function onSmsRequest() {
        var ymd = _sms_ymd.val() || '';
        if( !ymd || ymd.length != 6 ) {
            showAlert('생년월일이 올바르지 않습니다!');
            _sms_ymd.focus();
            return false;
        }

        _sms_auth.val('');
        _sms_request.focus();
        DGB.Common.hideKeyboard();
        DGB.Sms.req(GLOBAL.ENOB, ymd, function(success, message) {
            if( success ) {
                _sms_help.text(message);
                _div_sms_wait.show();
                _sms_count.text(DGB.Sms.count() + '초');
                setTimeout(function() { _sms_auth.focus(); }, 400);
                DGB.Sms.start(function(count) {
                    _sms_count.text(count + '초');
                }, function() {
                    DGB.Common.hideKeyboard();
                    _sms_help.text('');
                    _sms_auth.val('');
                    _div_sms_wait.hide();
                    showAlert('입력시간이 경과되었습니다!\n다시 시도해 주세요.');
                });
            } else {
                _sms_request.focus();
                _div_sms_wait.hide();
                showAlert(message);
            }
        });
        return false;
    }

    function onKeySmsAuth(e) {
        if ( (DGB.isAndroid() && e.keyCode == 9) || (!DGB.isAndroid() && e.keyCode == 13) ) {
            DGB.Common.hideKeyboard();
            _sms_ok.focus();
            setTimeout(onSmsAuth, 300);
            return false;
        }
    }

    function onSmsAuth() {
        var auth = _sms_auth.val() || '';
        if( !auth || auth.length != 6 ) {
            showAlert('인증번호가 올바르지 않습니다!');
            setTimeout(function() { _sms_auth.focus(); }, 400);
            return false;
        }

        DGB.Sms.auth(GLOBAL.ENOB, auth, function(success, message) {
            if( success ) {
                DGB.Sms.end();
                DGB.Sms.set(GLOBAL.ENOB);
                DGB.Fido.setEnob(GLOBAL.ENOB);
                DGB.Auth.Sms.isLogin = true;
                DGB.Auth.Step.use();
            } else {
                _sms_ok.focus();
                showAlert(message);
            }
        });
        return false;
    }

    function onKeyNfcAuth(e) {
        if ( (DGB.isAndroid() && e.keyCode == 9) || (!DGB.isAndroid() && e.keyCode == 13) ) {
            DGB.Common.hideKeyboard();
            _nfc_ok.focus();
            setTimeout(onNfcAuth, 300);
            return false;
        }
    }

    function onNfcAuth() {
        var auth = _nfc_auth.val() || '';
        if( !auth || auth.length != 10 ) {
            showAlert('사원증번호가 올바르지 않습니다!');
            setTimeout(function() { _nfc_auth.focus(); }, 400);
            return false;
        }
        DGB.Nfc.auth(auth);
        return false;
    }

    function onBioSelect() {
        var id = DGB.Fido.id();
        if( !id ) {
            showAlert('등록된 바이오 정보가 없습니다. 바이오 정보를 등록 후 사용해 주시기 바랍니다.');
            return false;
        }

        var check = DGB.Fido.check();
        if( !check ) {
            showAlert('사용자정보와 바이오정보가 일치하지 않습니다. 기존 사용자로 SSO 로그인 또는 바이오 재등록 후 사용해 주시기 바랍니다.');
            return false;
        }

        var type = $(this).data('type');
        DGB.Fido.auth(type,
            function() {
                GLOBAL.STAT = DGB.Auth.Level.Bio;
                GLOBAL.TEMP_STAT = GLOBAL.STAT;
                GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;

                // 로그인시 실제 행번을 추출
                GLOBAL.ENOB = DGB.Fido.id(true);
                authProcess();
            }
        );
        return false;
    }

    function onBioInsert() {
        var id = DGB.Fido.id();
        if( id ) {
            showConfirm(function(btn) {
                if( btn == '1' ) {
                    if( window.regAuthState != DGB.Auth.Level.Sms && window.regAuthState != DGB.Auth.Level.Bio ) {
                        GLOBAL.STAT = DGB.Auth.Level.Sms;
                        GLOBAL.PAGEID = 'BIO0001';
                        GLOBAL.TEMP_STAT = GLOBAL.STAT;
                        GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
                        _tab_id = 'tab_login';
                        _updateLayout();
                        _updateTab();
                    } else {
                        DGB.Page.changePage('#BIO0001');
                    }
                }
            }, '이미 등록된 바이오 정보가 있습니다. 바이오 정보를 재등록 하시겠습니까?');
        } else {
            if( window.regAuthState != DGB.Auth.Level.Sms && window.regAuthState != DGB.Auth.Level.Bio ) {
                GLOBAL.STAT = DGB.Auth.Level.Sms;
                GLOBAL.PAGEID = 'BIO0001';
                GLOBAL.TEMP_STAT = GLOBAL.STAT;
                GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
                _tab_id = 'tab_login';
                _updateLayout();
                _updateTab();
            } else {
                DGB.Page.changePage('#BIO0001');
            }
        }
        return false;
    }

    function onBioDelete() {
        var id = DGB.Fido.id();
        if( !id ) {
            showAlert('삭제할 바이오 정보가 없습니다.');
            return false;
        }

        if( window.regAuthState != DGB.Auth.Level.Sms && window.regAuthState != DGB.Auth.Level.Bio ) {
            GLOBAL.STAT = DGB.Auth.Level.Sms;
            GLOBAL.PAGEID = 'BIO0003';
            GLOBAL.TEMP_STAT = GLOBAL.STAT;
            GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
            _tab_id = 'tab_login';
            _updateLayout();
            _updateTab();
        } else {
            DGB.Page.changePage('#BIO0003');
        }
        return false;
    }

	$(document).on({
        pageinit : _pageinit,
		pageshow : _pageshow,
        pagehide : _pagehide,
		parentpage : function() {
            BACK_GLOBAL.STAT = GLOBAL.STAT;
            BACK_GLOBAL.PAGEID = GLOBAL.PAGEID;
            BACK_GLOBAL.TEMP_STAT = GLOBAL.TEMP_STAT;
            BACK_GLOBAL.TEMP_PAGEID = GLOBAL.TEMP_PAGEID;
            _updateLayout();

        },
        nfcstatechange : function(e, state) {
            onNfcStateChange(state);
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#login');

})();

