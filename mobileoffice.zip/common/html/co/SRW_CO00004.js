(function() {

	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
    var pushKey = DGB.Setting.Keys.PushVibration;

	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, _headerHeight);
        initSelectTheme();

        if(DGB.isAndroid()){
            $("#pushVibeBox").removeClass("displayNone");
            //push 진동횟수 설정 - 안드로이드만 사용.
            var vibObj = DGB.Setting.get(pushKey);
			$this.find('#co04pushnum').val(vibObj.loop);
			$this.find('#co04pushnum').selectmenu("refresh");
        }

		//이메일 ID,PW 전송
		$this.find("#co04EmailSubmit").on('vclick',function() {
			if( !USER_INFO.ENOB ) {
				showAlert('로그인 후 이메일을 등록해 주시기 바랍니다.');
				DGB.Menu.trigger('leftPanel','updateAuth',{ menuId: 'CO0102', auth : DGB.Auth.Level.Pass });
				return false;
			}

			$this.find("#co04EmailSubmit").focus();
			var emailId = $this.find("#co04emailId").val();
			var emailPw = $this.find("#co04emailPw").val();
			if ( ($this.find("#co04emailId").val() == "") || ($this.find("#co04emailPw").val() == "") ) {
				showAlert(Messages.msg015);
				return false;
			}

			//@dgb.co.kr 입력시 삭제 후 id만 전송
			if(emailId.indexOf('@dgb.co.kr') != -1) {
				emailId = emailId.replace("@dgb.co.kr","");
			}

			addingEmailIdPw(emailId.split("@")[0],  emailPw);
			return false;
		});

		$this.find("#co04ViewAccept").on('vclick',function() {
            DGB.Page.triggerPage("#CO00007", "parentpage");
            DGB.Page.changePage('#CO00007');
			return false;
		});

        // 푸쉬진동 횟수 설정 - 안드로이드만 사용.
        if(DGB.isAndroid()) {
            $('#co04pushnum').on('change', function(){
                var vibeNum = $this.find('#co04pushnum:visible option:selected').val();
                var vibObj = DGB.Setting.get(pushKey);

                vibObj.loop =  parseInt(vibeNum);
                DGB.Setting.set(pushKey,vibObj);
                AndroidNative.pushVibratorSet( vibObj.loop, vibObj.vibe,vibObj.stop );
            });
        }
	};

	function addingEmailIdPw(id, pw) {
		dgbLoading(true);
		var inv = {
			adapter : 'DBTransactionAdapter',
			procedure : 'TCO00003',
			parameters : [{
				ENOB : USER_INFO.ENOB,
				MAIL_ID: id,
				'MAIL_PW.ENC': pw,
				DEVC_NATV_NO :nmf.Store.get(MAC_ADDRESS),
				CS_ID:_menuId
			}]
		};

		var opt = {
			onSuccess : addingResult,
			onFailure : addingError,
			invocationContext : {}
		};
		callProcedure(inv, opt);
	}

	function addingResult(data) {
		dgbLoading(false);
		var email_id = $this.find("#co04emailId");
		var email_pw = $this.find("#co04emailPw");
		email_id.val('');
		email_pw.val('');

		var result = data.invocationResult;
		if( result.status < 0 ) {
			showAlert((result.status == -2) ? Messages.msg017 : Messages.msg019);
			_layout.refreshLayout(400);
			return;
		}

		nmf.Store.set(EMAIL_KEY_ID, result.updateStatementResult.__PRIVATE_KEY__);
		email_id.attr("placeholder", "****");
		email_pw.attr("placeholder", "****");
		showCusConfirm(
			function(button){
				if (button == '1') {
					DGB.Menu.open('leftPanel');
					setTimeout(function () {
						DGB.Menu.trigger('leftPanel', 'click', 'GR0100'); // 메일 메뉴 ID
					}, 400);
				}
			}, "알림", Messages.msg016, '확인'
		);
		_layout.refreshLayout(400);
	}

	function addingError() {
		dgbLoading(false);
		showAlert(Messages.msg017);
	}

	function _pageshow() {
		if ( nmf.Store.get(EMAIL_KEY_ID) != undefined) {
			$this.find("#co04emailId").attr("placeholder", "****");
			$this.find("#co04emailPw").attr("placeholder", "****");
		}
		$('#appVersion').text(WL.Client.getAppProperty(WL.AppProperty.APP_VERSION));
		_layout.refreshLayout(100);
	}

    function initSelectTheme() {
        var select_theme = $this.find('#config_theme');
        var themes = DGB.Theme.getThems();
        for(var i in themes ) {
            select_theme.append(
                "<option value='" + themes[i].id + "'>" + themes[i].name + "</option>"
            );
        }
        select_theme.val( DGB.Theme.getTheme() );
        select_theme.selectmenu('refresh');
        select_theme.on('change', function() {
            DGB.Theme.use($(this).val());
            DGB.Menu.open('leftPanel');
            return false;
        });
    }

	$(document).on({
        pageinit: function(){
            pageinit($(this));
        },
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: _pageshow,
		pagebeforehide: function() {
			$this.find("#co04emailId").val("");
			$this.find("#co04emailPw").val("");
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
				$this.find("#co04EmailSubmit").focus();
            }
            return false;
		}
	}, '#CO00004');
})();
