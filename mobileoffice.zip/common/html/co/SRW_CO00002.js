(function() {
    var MIN_PAGE_SIZE = 1,
        MAX_PAGE_SIZE = 20;

    var MODE_RECV = 'rece',
        MODE_SEND = 'send';

    var $this, _menuId, _layout;
    var _iscrollEnd = false;        // 마지막 페이지

    var _mode = MODE_SEND;
    var _startNum = MIN_PAGE_SIZE;
    var _endNum = MAX_PAGE_SIZE;

    var _firstPageshow = false;

    var _menuItem = undefined;

    var pageinit = function(instance) {
        $this = instance;
        _layout = new DGB.layout($this,
            COMMON_PAGE_HEADER_HEIGHT,
            COMMON_EDIT_HEIGHT + COMMON_NAVBAR_HEIGHT);

        setTabEvent();
        setMenuBoxEvent();
    };

    function _pageshow() {

        _firstPageshow = true;

        DGB.Menu.callback("leftPanel","panelopen",function(){
            $this.find('#write_msg').hide();
        });
        DGB.Menu.callback("leftPanel","panelclose",function(){
            $this.find('#write_msg').show();
        });
        onTabToggle();
    };

    var initControl = function() {
        _iscrollEnd = false;
        _startNum = MIN_PAGE_SIZE;
        _endNum = MAX_PAGE_SIZE;

        $this.find("#send_msg").addClass("displayNone");
        $this.find("#recv_msg").addClass("displayNone");
        $this.find("#listview").empty();
        _layout.resetLayout();

        $this.find('#pullUp').css("display", "none");

        $this.find('#write_msg').show();

        if(_menuId == 'CO0101') {
            $this.find('#tab_navbar').show();
            $this.find('#tab_navbar_work').hide();
        }else {
            $this.find('#tab_navbar_work').show();
            $this.find('#tab_navbar').hide();
        }

    };

    var onTabToggle = function() {
        initControl();

        var $empty= $this.find('div.menu-box button[data-menu="edit"]').closest('.ui-btn');
        var $edit_btn = $this.find('#edit_btn');
        if( $this.find('.ui-state-persist').attr('id') == 'tab_recv' ) {
            _mode = MODE_RECV;
            $edit_btn.prop('disabled',false);
            $empty.removeClass('buttonDisabled');
        } else {
            _mode = MODE_SEND;
            $edit_btn.prop('disabled',true);
            $empty.addClass('buttonDisabled');
            showEditMode(false);
        }
        execSerach();
    };

    var execSerach = function() {
        var procedure;
        if(_menuId == 'CO0101') {
            procedure = (_mode == MODE_RECV) ? 'TCO00001' : 'TCO00005';
        }
        else {
            procedure = 'TCO00008';
        }
        var opts = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : procedure,
            parameters : [ {
                CS_ID:_menuId,
                ENOB : USER_INFO.ENOB,
                TRS_DV_CD:'PUSH',
                DEVC_NATV_NO : nmf.Store.get(MAC_ADDRESS),
                START_NUM : _startNum,
                END_NUM : _endNum
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opts);
    };

    var execUpdate = function(seq) {
        if( _mode != MODE_RECV )
            return;

        var options = {
                onSuccess : function() {
                    DGB.Menu.trigger('leftPanel', 'updateBadge', {});
                },
                onFailure : onFailure,
                invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TCO00002',
            parameters : [{
                CS_ID :_menuId,
                PUSH_FW_SEQ : seq
            }]
        };
        callProcedure(inv, options);
    };

    var execDelete = function(seq) {
        if( _mode != MODE_RECV )
            return;

        var options = {
                onSuccess : function() {
                    initControl();
                    showEditMode(false);
                    execSerach();
                },
                onFailure : onFailure,
                invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TCO00007',
            parameters : [{
                CS_ID :_menuId,
                PUSH_FW_SEQ : seq
            }]
        };
        callProcedure(inv, options);
    };

    var onSuccess = function(data) {
        var result = data.invocationResult;
        if( _menuId != 'CO0101' ) {
            var isSuccess = result.PASS_VALIDATION;
            if( !isSuccess ) {
                dgbLoading(false);
                showAlert(Messages[result.MSG_CD]);
                if( result.MSG_CD == 'msg00C' ) {
                    var args = {};
                    GLOBAL.STAT = "PasswordPass";
                    GLOBAL.PAGEID = "freeSv";
                    GLOBAL.ARGS = args;
                    GLOBAL.TEMP_STAT = GLOBAL.STAT;
                    GLOBAL.TEMP_PAGEID = GLOBAL.PAGEID;
                    DGB.Page.triggerPage('#login', 'parentpage', [args]);
                    DGB.Page.changePage('#login');
                }
                return;
            }
        }

        var item = result.resultSet;
        if (item.length === 0) {
            var className = ( _mode == MODE_RECV ) ? 'recv' : 'send';
            $this.find("#" + className + "_msg").removeClass("displayNone");
            dgbLoading(false);

            // 안읽은메시지 동기화, 뱃지 카운트 업데이트
            if (_mode == MODE_RECV ){
                if( _menuId == 'CO0101') {
                    USER_INFO.MSG_COUNT = 0;
                }else if(  _menuId == 'CO0105' ) {
                    USER_INFO.MSG_COUNT2 = 0;
                }
                DGB.Menu.trigger('leftPanel', 'updateBadge', {});
            }
        } else {
            var html = "";
            var listItems = [];
            for ( var i = 0; i < item.length; i++) {
                item[i].PUSH_CN = item[i].PUSH_CN.replace( /(\')/g,'\"');
                html  = "<li>"+
                    "<a href='#' class='list-item downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
                    "<div class='image'>";
                if(item[i].TRS_DV_CD == "SMS"){
                    html += "<img class='img_sms_msg' src='images/icn_sms.png'>";
                }else{ //PUSH
                    if(item[i].MSG_VD_YN == "Y") // 읽음Y, 안읽음N
                    {
                        html += "<img class='img_msg_r' src='images/mail_icon_open.png'>";
                    }
                    else
                    {
                        html += "<img class='img_msg' src='images/mail_icon_colse.png'>";
                    }
                }
                html +=		"</div>" +
                        "<div style='margin-left: 30px;'>"+
                    "<h3><font color=darkblue>";

                var name = (_mode == MODE_RECV) ? item[i].DSPT_NM : item[i].RCV_NAME;
                var cs_nm = item[i].CS_NM || "알림 메시지";
                html += name +"</font> / <font style='font-size: 13px;'>"+ cs_nm + " (" +item[i].FW_DTTI+")"+"</font></h3>";

                var push_cn = item[i].PUSH_CN || '';
                push_cn = push_cn.replace(/</gi, '&lt;');
                push_cn = push_cn.replace(/>/gi, '&gt;');
                html += "<p class='paddingright15'><strong>"+push_cn+"</strong></p></div></a></li>";
                listItems[i] = html;
            }

            /* 페이징 */
            if (item.length == MAX_PAGE_SIZE) {
                if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
                    $this.find('#pullUp').css("display", "none");
                    _iscrollEnd = true;
                } else {
                    $this.find('#pullUp').css("display", "block");
                    _startNum += MAX_PAGE_SIZE;
                    _endNum += MAX_PAGE_SIZE;
                }
            } else {
                _iscrollEnd = true;
                $this.find('#pullUp').css("display", "none");
            }
            /* //페이징 */

            // 안읽은메시지 동기화, 뱃지 카운트 업데이트
            if (_mode == MODE_RECV ){
                if( _menuId == 'CO0101') {
                    USER_INFO.MSG_COUNT = item[0].MSG_COUNT;
                }else if(  _menuId == 'CO0105' ) {
                    USER_INFO.MSG_COUNT2 = item[0].MSG_COUNT;
                }
                DGB.Menu.trigger('leftPanel', 'updateBadge', {});
            }

            $this.find("#listview").append(listItems.join(''));
            $this.find("#listview").listview("refresh");
            $this.find("#listview").trigger("updatelayout");
        }
        dgbLoading(false);
        setListViewEvent();
        _layout.refreshLayout(500);
    };

    var onFailure = function() {
        dgbLoading(false);
        showAlert(Messages.err001);
    };

    // 리스트클릭 이벤트
    var setListViewEvent = function() {
        $('#listview').find('li a.list-item').off('vclick').on('vclick',function() {
            var item = $(this).attr('data-item');
            var detailId = "CO00003";
            var args = {};
            var $mail = $(this);

            // Check it is under the edit mode.
            if ($this.find('div.mail-list').hasClass('editMode')) {
                $mail.toggleClass('oncheck');
                return false;
            }

            var _item = JSON.parse(item);
            if ( _item.CS_MMT_YN == 'Y') {
                args.activePage = false;
                args.menuId = _item.CS_ID;
                showConfirm(function(button){
                    if (button == '1') {
                        if (_item.MSG_VD_YN == "N") {
                            execUpdate(_item.PUSH_FW_SEQ);
                        }

                        var param = {
                            id : _item.CS_ID,
                            event : 'selectmenu',
                            args : args
                        };
                        DGB.Menu.trigger('leftPanel', 'location', param);
                    }
                }, Messages.msg113);
            }else {
                if (_item.MSG_VD_YN == "N") {
                    execUpdate(_item.PUSH_FW_SEQ);
                }
                args.item = item;
                args.menuId = _menuId;
                args.msgselect = _mode;
                DGB.Page.triggerPage("#" + detailId, "parentpage", args);
                setTimeout(function () {
                    DGB.Page.changePage('#'+detailId);
                },400);
            }
            return false;
        });
    };

    var setTabEvent = function() {
        $this.find('#tab_navbar').on('vclick','a', function () {
            if( $(this).text() == '수신' ) {
                $this.find('#tab_recv').addClass("ui-state-persist");
                $this.find("#tab_send").removeClass("ui-state-persist");
            } else {
                $this.find('#tab_recv').removeClass("ui-state-persist");
                $this.find("#tab_send").addClass("ui-state-persist");
            }
            onTabToggle();
        });
    };

    // Menu Box Event Handler
    var setMenuBoxEvent = function() {
        $this.find('div.menu-box').find('button').off('vclick').on('vclick', function(){
            switch( $(this).attr("data-menu") ) {
                case 'edit' :
                    if( _mode != MODE_RECV )
                        return;

                    showEditMode(true);
                    return false;
                case 'cancel' :
                    showEditMode(false);
                    return false;
                case 'selectAll':
                    $this.find('#listview').find('li a.list-item').addClass('oncheck');
                    return false;
                case 'delete':
                    itemDeleteMode();
                    return false;
            }
        });
    };

    var showEditMode = function(isEdit) {
        var main = $this.find('div.menu-box .main-menu');
        var edit = $this.find('div.menu-box .edit-menu');
        var list = $this.find('div.mail-list');
        if( isEdit ) {
            main.removeClass('block');
            edit.addClass('block');
            list.addClass('editMode');

            main.addClass('displayNone');
            edit.removeClass('displayNone');
            list.addClass('editMode');
        } else {
            main.addClass('block');
            edit.removeClass('block');
            list.removeClass('editMode');

            $this.find('#listview').find('li a.list-item').removeClass('oncheck');
            main.removeClass('displayNone');
            edit.addClass('displayNone');
        }
    };

    var itemDeleteMode = function(){
        var items = getSelectList();
        if (items.length == 0) {
            showAlert(Messages.msg078);
            return;
        }

        showConfirm(function(btn){
            if (btn == '1') {
                var push_fw_seq= [];
                $.each(items, function(index, value) {

                    push_fw_seq.push(value.PUSH_FW_SEQ);
                });
                execDelete(push_fw_seq.join(','));
            }
        }, Messages.msg079);
    };

    var getSelectList = function() {
        var items = [];
        $this.find('#listview a.oncheck').each(function() {
            items.push(JSON.parse($(this).attr('data-item')));
        });
        return items;
    };

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();

			// 메세지보내기로 이동
			$this.find('#write_msg').off('vclick').on('vclick', function() {
                DGB.Page.changePage('#EMST005');
                return false;
            });
		},
		pageshow: _pageshow,
		pagehide: function() {
            showEditMode(false);
            initControl();
            _firstPageshow = false;
        },
		selectmenu :function(evt, param) {
            if(_menuId != param.menuId) {
                _menuId = param.menuId;
                _menuItem = param.menuItem;

                $('#tab_recv').addClass("ui-state-persist");
                $("#tab_send").removeClass("ui-state-persist");
                if( _menuId == 'CO0101') {
                    $('#CO00002').find('[data-role="navbar"] a').removeClass("ui-btn-active");
                    $('#CO00002').find('[data-role="navbar"] #li_tab_recv a:first').addClass("ui-btn-active");
                }
                else {
                    $('#CO00002').find('[data-role="navbar"] a').removeClass("ui-btn-active");
                    $('#CO00002').find('[data-role="navbar"] #li_work_recv a:first').addClass("ui-btn-active");
                }
                showEditMode(false);
                if( _firstPageshow ) {
                    _pageshow();
                }
            }

		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		parentpage :function(evt, param) {
			_menuId = param.menuId;
			$('#tab_recv').addClass("ui-state-persist");
			$("#tab_send").removeClass("ui-state-persist");
			if(param.messageRefresh) {
                if( _menuId == 'CO0101') {
                    $('#CO00002').find('#tab_navbar [data-role="navbar"] a').removeClass("ui-btn-active");
                    $('#CO00002').find('#tab_navbar [data-role="navbar"] #li_tab_recv a:first').addClass("ui-btn-active");
                }
				_pageshow();
			}
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
                execSerach();
			}
		}
	}, '#CO00002');
})();