(function () {
    var $this, _layout;
    var is_agree = true;

    var pageinit = function (instance) {
        $this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        $this.find('#btn_yes').on('vclick', function () {
            request();
            return false;
        });

        $this.find('#btn_no').on('vclick', function () {
            noAgreeAlert();
            return false;
        });
    };

    function request() {
        var opt = {
            onSuccess: function() { dgbLoading(true); DGB.Auth.Step.use(); },
            onFailure: function() { },
            invocationContext: {}
        };

        var inv = {
            adapter: 'DBTransactionAdapter',
            procedure: 'TCO00004',
            parameters: [{
                CS_ID: 'CO0001',
                LT_AG_DTHR: getTimeStamp(),
                ENOB: GLOBAL.ENOB,
                GMNO: nmf.utils.UUID.get(),
                TRNS_CD: "TCO00004"
            }]
        };
        callProcedure(inv, opt);
    }

    function noAgreeAlert() {
        showCusConfirm(
            function (btn) {
                if (btn == '1') {
                    DGB.Common.appExit();
                }
            }, "DGB오피스 확인", "동의하지 않으시면 DGB오피스를 사용하실 수 없습니다.\n\n앱을 [종료] 하시겠습니까?"
        );
    }

    // 날짜 계산
    function getTimeStamp() {
        var d = new Date();
        return pad(d.getFullYear(), 4) +
            pad(d.getMonth() + 1, 2) +
            pad(d.getDate(), 2) +
            pad(d.getHours(), 2) +
            pad(d.getMinutes(), 2);
    }

    function pad(n, digits) {
        var zero = '', n = n + '';
        if (n.length < digits) {
            for (var i = 0; i < digits - n.length; i++)
                zero += '0';
        }
        return zero + n;
    }

    $(document).on({
        pageinit: function () {
            pageinit($(this));
        },
        pagebeforeshow: function () {
            if( is_agree ) {
                WL.App.overrideBackButton(noAgreeAlert);
                $this.find('#btn_back').hide();
                $this.find('.agree').show();
            } else {
                DGB.Common.backPage();
                $this.find('#btn_back').show();
                $this.find('.agree').hide();
            }
        },
        pageshow: function () {
            _layout.refreshLayout();
        },
        pagehide: function () {
            is_agree = true;
        },
        parentpage: function () {
            is_agree = false;
        },
        orientationchange: function () {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#CO00007');

})();
