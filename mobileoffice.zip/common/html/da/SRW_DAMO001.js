(function() {
    var $this, _type, _menuId, _selct_title, _popup_file;
    var _config, _list, _layout;

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT + 19);
        _type = $this.find('#type');
        _list = $this.find('#list');
        _popup_file = $this.find('#popupFile');
        $this.find('#submit').on('vclick', request);
        $.Mustache.add('DAMO001_tmpl-list', $this.find('#tmpl_list').html());
    }

    function _pageshow() {
        DGB.Common.backMenu();
        if( _config ){
            request();
        } else {
            config();
        }
    }

    function config() {
        var opt = {
            onSuccess : onSuccessConfig,
            onFailure : onFailureConfig,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DamoaAdapter',
            procedure : 'DAMO001',
            parameters : [{
                CS_ID : _menuId
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessConfig(data) {
        var result = data.invocationResult || {};
        _config = result.config || {};
        $.each(_config.MEET_VAL, function(i, e) {
            var selected = e.SELECTED ? ' selected="selected"' : '';
            _type.append('<option value="' + e.VALUE + '"' + selected + '>' + e.TEXT + '</option>');
        });
        _type.selectmenu('refresh');
        request();

        _type.change(function() {
            request();
            return false;
        });
    }

    function onFailureConfig(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function request() {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DamoaAdapter',
            procedure : 'DAMO002',
            parameters : [{
                CS_ID : _menuId,
                ENOB : GLOBAL.ENOB,
                DVCD : _type.val(),
                BRNO : USER_INFO.WORKORG_CD
            }]
        };

        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var obj = data.invocationResult || {};
        if( !obj.success ) {
            dgbLoading(false);
            showAlert(obj.msg);
            return;
        }

        _list.empty().mustache('DAMO001_tmpl-list', obj);
        _layout.resetLayout();
        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function requestFile(id) {
        var opt = {
            onSuccess : onSuccessFile,
            onFailure : onFailureFile,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DamoaAdapter',
            procedure : 'DAMO003',
            parameters : [{
                CS_ID : _menuId,
                ID : id
            }]
        };

        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessFile(data) {
        var obj = data.invocationResult || {};
        dgbLoading(false);
        daView(obj.titles || [], obj.urls || []);
    }

    function onFailureFile(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function daView(titles, urls){
        switch( titles.length ) {
            case 0:
                showAlert(Messages.msg02L);
                break;
            case 1:
                callDaview({url : urls[0]}, titles[0]);
                break;
            default:
                DGB.Common.selectList( _selct_title, titles,
                    function(index) {
                        callDaview({url : urls[index]}, titles[index]);
                    },
                    function(err) {
                        DGB.Log.e('[SRW_DAMO001] ====>> Error : ' + err);
                    }
                );
                break;
        }
    }

    function onClickItem(){
        var id = $(this).data('id');
        _selct_title = $(this).data('title');
        requestFile(id);
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        pagebeforeshow: function() {
            DGB.Alive.start();
        },
        pagebeforehide: function() {
            DGB.Alive.end();
        },
        selectmenu : function(evt, param) {
            _menuId = param.menuId;
        },
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#DAMO001');

    $(document).on('vclick', '#DAMO001 .inner_list', onClickItem);
})();