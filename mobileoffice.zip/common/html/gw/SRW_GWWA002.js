(function() {
	var $this, _menuId, _layout, _pass, _attach, _menuTitle, _pageTitle;
	var _item, _prevPage;
	var _isRequestAttach;
	var _titles = [], _list = [];
	var _contents, _comment, _isReject = false;

	function _pageinit() {
		$this = $(this);
		// _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		_pass = $this.find('#gwwa002_pw');
		_attach = $this.find('#btn_attach');
		_pageTitle = $this.find('#pageTitle');

		$.Mustache.add('tmpl-contents', $this.find('#tmpl-contents').html());
		_contents = $this.find('#contents');
		// _layout.refreshLayout(function() {});

		$this.find('#btn_detail').on('vclick', function() {
			request(_item.link, _item.guid+".mht", true);
		});

		_pass.on({
			'touchstart' : function() { $this.blur(); },
			'vclick' : function() {
				if( !_pass.attr("disabled") ) {
					onE2K('eng','gwwa002_pw', '8', '16', '결재비밀번호', '1');
				}
				return false;
			}
		});

		_attach.on('vclick', function() {
			if( _isRequestAttach ) {
				showAttach();
			} else {
				requestAttach();
			}
		});

		$this.find('#btn_decision').on('vclick', function() {
			_isReject = false;
			if( _pass.val() ) {
				requestDecision();
			} else {
				showAlert('결재비밀번호를 입력해 주세요');
			}
			return false;
		});
		$this.find('#btn_cancel').on('vclick', function() {
			_isReject = true;
			_comment ='';
			if( !_pass.val() ){
				showAlert('결재비밀번호를 입력해 주세요');
				return false;
			}
			navigator.notification.prompt(
				'반송사유를 입력해 주세요',  // message
				function(obj) {
					if( obj.buttonIndex == 1 ) {
						if( !obj.input1.length || obj.input1 == ' ' ) {

							showAlert("반송사유를 입력해 주세요.");
							return;
						}
						_comment = obj.input1;
						requestDecision();
					}
				},                 // callback to invoke
				'반송사유입력',       // title
				['확 인','닫 기'],     // buttonLabels
				' '                // defaultText
			);
			return false;
		});
	}

	function _pageshow() {
		_pageTitle.text(_menuTitle + "상세");

		_titles = [];
		_list = [];
		_isRequestAttach = false;

		var count = parseInt((_item || {}).attachcnt || 0);
		_prevPage = $('#GWWA001');
		_pass.val('');
		if( count > 0 ) {
			_attach.removeAttr('disabled');
			_attach.text('첨부파일(' + count + '건)');

		} else {
			_attach.attr('disabled', 'disabled');
			_attach.text('첨부파일 없음');
		}
		_attach.button('refresh');

		var data = { contents : [
			{ title : '문서제목', content : _item.title || '제목없음' },
			{ title : '문서상태', content : (_item.apprstatustext + '('+_item.guid+')' ) || '상태없음' },
			{ title : '기안자', content : _item.drafter || '없음' },
			{ title : '기안일시', content : _item.draftDate || '' },
			{ title : '시행종류', content : _item.drafttypetext || '' }
		]};
		_contents.empty().mustache('tmpl-contents', data);

		// 메뉴별 컨트롤 활성화 여부
		switch( _menuId ) {
			case 'GW0100':	// 결재대기
				_pass.attr("disabled", false);
				$this.find('#footer').show();
				break;
			case 'GW0101':	// 결재진행
				_pass.attr("disabled", true);
				$this.find('#footer').hide();
				break;
			default:
				_pass.attr("disabled", false);
				$this.find('#footer').show();
				break;
		}
		DGB.Common.backPage();
		request(_item.link, _item.guid+".mht", true);
		// _layout.refreshLayout();
		// _layout.resetLayout();
	}

	function requestAttach() {
		var opt = {
			onSuccess : onSuccessAttach,
			onFailure : onFailureAttach,
			invocationContext : {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GWWA0002',
			parameters : [{
				GUID : _item.guid || '',
				ENOB : USER_INFO.ENOB
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessAttach(data) {
		dgbLoading(false);
		try {
			_isRequestAttach = true;
			_titles = [];
			_list = [];
			var items = data.invocationResult.items || [];
			for(var i = 0; i < items.length; i++) {
				var item = items[i];
				if(item.type == 'attach') {
					_titles.push(item.filename + ' (' + filesize(item.size) + ')');
					_list.push(item);
				}
			}
			showAttach();
		} catch(err) {
			showAlert(Messages.err001 + "\n\nError : " + err.message);
		}
	}

	function showAttach() {
		if( _list.length == 0 ) {
			_isRequestAttach = false;
			showAlert(Messages.err001);
		} else {
			DGB.Common.selectList("첨부파일 목록",
				_titles,
				function (index) {
					showAlert(_list[index].link);
					request(_list[index].link, _list[index].filename, false);
				},
				function () { }
			);
		}
	}

	function onFailureAttach(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function request(docLink, filename, isApprovalDoc) {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'ServletAdapter',
			procedure : isApprovalDoc? 'SVLT0001' : 'SVLT0002',
			parameters : [{
				APPRID : _item.guid || '',
				URL : docLink,
				FILENAME : filename,
				ENOB : USER_INFO.ENOB
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}
	function onSuccess(data) {
		dgbLoading(false);
		try {

			var items = data.invocationResult|| [];
			//showAlert("callURL : " + items.path);
			callDaview({url:items.path});

		} catch(err) {
			showAlert(Messages.err001 + "\n\nError : " + err.message);
		}
	}



	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	//결재하기
	function requestDecision() {
		var opt = {
			onSuccess : onSuccessDecesion,
			onFailure : onFailureDecision,
			invocationContext : {}
		};

		var inv = {
			adapter : 'DaServerAdapter',
			procedure : (_isReject?'DASV0002':'DASV0001'),
			parameters : [{
				APPRID : _item.guid || '',
				USERNAME : USER_INFO.FSNM,
				COMMENT : _comment || '',
				ENOB : USER_INFO.ENOB,
				PASSWD : _pass.attr('data-enc'),
				ENCODE_NUM : "PASSWD"
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessDecesion(data) {
		dgbLoading(false);
		try {

			var item = data.invocationResult|| [];
			if(item.success){
				showAlert("결재하기 성공 : "+item.info);
				_prevPage.data('refresh', true);
				DGB.Page.backPage();

				//navigator.notification.alert(
				//	'결재되었습니다!',
				//	function() { DGB.Page.backPage(); },
				//	'결재성공',
				//	'확인'
				//);
			}else{
				showAlert("결재하기 실패 : "+item.error);
			}

		} catch(err) {
			showAlert(Messages.err001 + "\n\nError : " + err.message);
		}
	}



	function onFailureDecision(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		parentpage :function (evt, param) {
			_item = param.item || {};
			_menuTitle = param.menuTitle;
			_menuId = param.menuId;
		},
		orientationchange : function() {
            // DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GWWA002');
})();
