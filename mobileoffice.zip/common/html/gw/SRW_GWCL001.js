(function() {
    var $this, $calendar, _menuId, _layout;
    var _date = new Date();
    var _calendar;
    var calendar_select,
        calendar_menu,
        calendar_layout1,
        calendar_layout2,
        calendar_color,
        calendar_title;

    var _pageinit = function() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        initCalendar();
    };

    var _pageshow = function() {
        $calendar.trigger('refresh', _date);
        _layout.refreshLayout();
    };

    var _pagebeforeshow = function() {
        DGB.Common.backMenu();

        if( !_calendar ) {
            requestCalendar();
        } else {
            //initData();
        }
        DGB.Menu.callback("leftPanel","panelopen",function(){
            $this.find('#moveCalBtn').hide();
        });
        DGB.Menu.callback("leftPanel","panelclose",function(){
            $this.find('#moveCalBtn').show();
        });
    };
    var bindChange = function() {
        $calendar.bind('change', function(event, date) {
            _date = date;
            initControl();

            DGB.Calendar_Alios.load(date, function(success) {
                if( success )
                    $calendar.trigger('refresh');
                else
                    showAlert(Messages.err001);
            });

            DGB.Common.refreshLayout(_layout);
        });
    };
    var initData = function() {

        resetSelect();
    };
    var initCalendar = function() {
        calendar_layout1 = $this.find('#calendar_layout1');
        calendar_layout2 = $this.find('#calendar_layout2');
        calendar_select = $this.find('#calendar_select');
        calendar_menu = $this.find('#calendar_select-menu');
        calendar_color = $this.find('#calendar_color');
        calendar_title = $this.find('#calendar_title');
        // calendar_layout1.show();

        calendar_select.on('change', updateSelect);

        $calendar = $this.find('#calendar');
        $calendar.jqmCalendar({
            events : DGB.Calendar_Alios.events(),
            startOfWeek : 0,
            weeksInMonth : 6
        });

        DGB.Calendar_Alios.load(_date, function(success) {
            bindChange();

            if( success )
                $calendar.trigger('refresh');
            else
                showAlert(Messages.err001);
        });
    };


    var initSelect = function() {
        // calendar_select.empty();
        $.each(_calendar, function(index, item) {
            var opt = "<option data-default='" + item['default'] + "' data-color='" + item.color + "' data-description='" + item.description + "' value='" + item.id + "'>" + item.title + "</option>";
            calendar_select.append(opt);
        });
        calendar_select.selectmenu('refresh');
        updateSelect();
    };


    var resetSelect = function() {
        // calendar_layout1.show();
        calendar_layout2.hide();
        calendar_select.find('option').each(function() {
            var opt = $(this);
            opt.attr('selected', 'selected');
        });
        calendar_select.selectmenu('refresh', true);
        updateSelect();

    };

    var updateSelect = function() {
        calendar_select.find('option').each(function(){
            try {
                var index = $(this).index();
                var color = $(this).attr('data-color') || '#ffffff';
                var option = calendar_menu.find('[data-option-index=' + index + ']').find(".ui-btn-text");
                if( option.length ) {
                    option.before('<span class="state_box" style="background-color: ' + color + '"></span>');
                }
            } catch(e) { }
        });
        var list = getCalendarIds().join(";");
        $calendar.trigger('update',list);
        $calendar.trigger('refresh');
        return false;
    };
    var getCalendarIds = function() {
        var list = calendar_select.val() || [];

        var idx = list.indexOf("달력을 선택해주세요.");
        if( idx > -1 ) {
            list.splice(idx, 1);
        }
        return list;
    };
    var requestCalendar = function() {
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                _calendar = data.invocationResult.calendarlist;
                initSelect();
                initData();
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'GroupWareAdapter',
            procedure : 'GWCL0002',
            parameters : [{
                CS_ID : 'GWCL003',
                Enob : USER_INFO.ENOB
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };
    var initControl = function() {
        $this.find('.ui-listview li').off('vclick').on('vclick',function() {
            var event = JSON.parse($(this).attr('data-item'));
            DGB.Page.triggerPage("#GWCL002", "parentpage", [{
                menuId : _menuId,
                date : _date,
                event : event,
                calendar : _calendar
            }]);
            DGB.Page.changePage('#GWCL002');
            return false;
        });

        $this.find('#moveCalBtn').off('vclick').on('vclick', function() {
            DGB.Page.triggerPage("#GWCL002", "parentpage", [{
                menuId : _menuId,
                date : _date,
                calendar : _calendar
            }]);
            DGB.Page.changePage('#GWCL002');
            return false;
        });
    };

	$(document).on({
        pageinit : _pageinit,
        pagebeforeshow: _pagebeforeshow,
        pageshow: _pageshow,
        selectmenu : function(evt, param) {
            _menuId = param.menuId;
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GWCL001');

})();