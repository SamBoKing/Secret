(function() {
    // Object
    var _this,
        _layout,
        _menuId,
        _event,
        _date,
        _calendar;

    // Control
    var page_title,
        btn_edit,
        btn_delete,
        calendar_select,
        calendar_menu,
        calendar_layout1,
        calendar_layout2,
        calendar_color,
        calendar_title;

    // Input
    var title,
        start_time,
        end_time,
        start_date,
        end_date,
        start_picker,
        end_picker,
        description;

    var _pageinit = function() {
        _this = $(this);
        _layout = new DGB.layout(_this, COMMON_PAGE_HEADER_HEIGHT);
        initControl();
        initInput();
    };

    var initControl = function() {
        page_title = _this.find('#page_title');
        btn_edit = _this.find('#btn_edit');
        btn_delete = _this.find('#btn_delete');
        calendar_select = _this.find('#calendar_select');
        calendar_menu = _this.find('#calendar_select-menu');
        calendar_layout1 = _this.find('#calendar_layout1');
        calendar_layout2 = _this.find('#calendar_layout2');
        calendar_color = _this.find('#calendar_color');
        calendar_title = _this.find('#calendar_title');
        start_date = _this.find('#start_date');
        end_date = _this.find('#end_date');

        start_picker = _this.find('#datePicker1');
        end_picker = _this.find('#datePicker2');

        btn_edit.off('vclick').on('vclick', onClickEdit);
        btn_delete.off('vclick').on('vclick', onClickDelete);
        calendar_select.on('change', updateSelect);
    };

    var initSelect = function() {
         calendar_select.empty();
        $.each(_calendar, function(index, item) {
            if(item['write_auth'] == true){
                var opt = "<option data-default='" + item['default'] + "' data-color='" + item.color + "' data-description='" + item.description + "' value='" + item.id + "'>" + item.title + "</option>";
                calendar_select.append(opt);
            }

        });
        calendar_select.selectmenu('refresh');
        updateSelect();
    };

    var resetSelect = function(event) {
        if( !event ) {
            calendar_layout1.show();
            calendar_layout2.hide();
            calendar_select.find('option').each(function() {
                var opt = $(this);
                if( opt.attr('data-default') == 'true' ) {
                    opt.attr('selected', 'selected');
                } else {
                    opt.removeAttr('selected');
                }
            });
            calendar_select.selectmenu('refresh', true);
            updateSelect();
        } else if( !event.ReadOnly ) {
            calendar_layout1.show();
            calendar_layout2.hide();
            var cids = DGB.Calendar_Alios.getCIds(event.ID);
            calendar_select.find('option').each(function() {
                var opt = $(this);
                if( cids.indexOf(opt.val()) > -1 ) {
                    opt.attr('selected', 'selected');
                } else {
                    opt.removeAttr('selected');
                }
            });
            calendar_select.selectmenu('refresh', true);
            updateSelect();
        } else {
            calendar_color.css('background-color', event.Color);
            calendar_title.text(event.CTitle + ' - 작성자 : ' + event.Name);
            calendar_layout1.hide();
            calendar_layout2.show();
        }
    };

    var updateSelect = function() {
        calendar_select.find('option').each(function(){
            var option = $(this);
            var index = option.index();
            var color = option.attr('data-color') || '#ffffff';
            var option = calendar_menu.find('[data-option-index=' + index + ']').find(".ui-btn-text");
            option.before('<span class="state_box" style="background-color: ' + color + '"></span>');
        });
        return false;
    };

    var initInput = function() {
        title = _this.find('#title');
        start_time = _this.find('#start_time');
        end_time = _this.find('#end_time');
        description = _this.find('#description');

        if( DGB.isAndroid() ) {
            start_time.removeAttr("type");
            end_time.removeAttr("type");

            start_time.attr("readonly",true);
            end_time.attr("readonly",true);
            start_time.off('vclick').on('vclick', function() {
                title.blur();
                description.blur();
                start_time.clockpicker('show');
                end_time.clockpicker('hide');
                return false;
            });

            end_time.off('vclick').on('vclick', function() {
                title.blur();
                description.blur();
                start_time.clockpicker('hide');
                end_time.clockpicker('show');
                return false;
            });
            start_time.clockpicker({
                placement: 'bottom',
                align: 'left',
                autoclose: true,
                'default': '09:00'
            });

            end_time.clockpicker({
                placement: 'bottom',
                align: 'left',
                autoclose: true,
                'default': '10:00'
            });
        }
    };

    var onClickEdit = function() {
        DGB.Common.hideKeyboard();
        title.blur();
        description.blur();

        if( !valueCheck() )
            return false;

        var message = ( _event ) ? Messages.msg601 : Messages.msg600;
        var success = ( _event ) ? "일정이 [변경]되었습니다." : "일정이 [등록]되었습니다.";
        var failure = ( _event ) ? "일정이 [변경]에 실패하였습니다." : "일정이 [등록]에 실패하였습니다.";
        showConfirm(function(btn){
            if (btn == '1') {
                _event = _event || {};

                var start =  start_time.val().split(':');
                var end = end_time.val().split(':');
                var date = DGB.Calendar_Alios.formatDate(_date);

                _event.Title = title.val();
                _event.Description = description.val();
                //_event.StartDate = _event.begin? DGB.Calendar_Alios.formatDate(new Date(_event.begin)) : date;
                _event.StartDate = start_picker.val();
                _event.StartHour = start[0];
                _event.StartMinute = start[1];
                //_event.EndDate = _event.end? DGB.Calendar_Alios.formatDate(new Date(_event.end)) : date;
                _event.EndDate = end_picker.val();
                _event.EndHour = end[0];
                _event.EndMinute = end[1];
                _event.CalendarIds = getCalendarIds().join(";");
                DGB.Calendar_Alios.save(_event, function(isSuccess) {
                    showAlert(isSuccess ? success : failure);
                    DGB.Page.changePage('#GWCL001');
                });
            }
        }, message);
        return false;
    };

    var valueCheck = function() {
        if( !title.val() ){
             showAlert(Messages.msg603);
             return false;
        }

        if( !start_time.val() ){
            showAlert(Messages.msg604);
            return false;
        }

        if ( !end_time.val() ){
            showAlert(Messages.msg605);
            return false;
        }

        var start_hour =  start_time.val().split(":");
        var end_hour = end_time.val().split(":");

        if(!start_picker.val() || !end_picker.val()) {
            showAlert("시작/종료 날짜를 선택해 주세요.");
            return false;
        }
        var start = start_picker.val().split("-");
        var end = end_picker.val().split("-");

        var startDate = new Date(start[0],start[1],start[2],start_hour[0],start_hour[1]);
        var endDate = new Date(end[0],end[1],end[2],end_hour[0],end_hour[1]);

        if(startDate >  endDate){
            showAlert(Messages.msg606);
            return false;
        }

        var list = getCalendarIds();
        if( !list || !list.length ) {
            showAlert("달력을 선택해 주세요.");
            return false;
        }
        return true;
    };

    var getCalendarIds = function() {
        var list = calendar_select.val() || [];
        var idx = list.indexOf("달력을 선택해주세요.");
        if( idx > -1 ) {
            list.splice(idx, 1);
        }
        return list;
    };

    var onClickDelete = function() {
        DGB.Common.hideKeyboard();
        title.blur();
        description.blur();

        showConfirm(function(btn){
            if (btn == '1') {
                DGB.Calendar_Alios.remove(_event.ID, function(isSuccess) {
                    showAlert(isSuccess ? "일정이 [삭제]되었습니다" : "일정 [삭제]에 실패하였습니다.");
                    DGB.Page.changePage('#GWCL001');
                });
            }
        }, Messages.msg602);
        return false;
    };

    var requestCalendar = function() {
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                _calendar = data.invocationResult.calendarlist;
                initSelect();
                initData();
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'GroupWareAdapter',
            procedure : 'GWCL0002',
            parameters : [{
                CS_ID : 'GWCL003',
                Enob : USER_INFO.ENOB
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    var initData = function() {
        if( _event ) {
            // 수정여부
            if( _event.ReadOnly ) {
                page_title.text("일정보기");
                btn_edit.hide();
                btn_delete.hide();
            } else {
                page_title.text("일정편집");
                btn_edit.show();
                btn_delete.show();
            }
            start_date.text("("+_event.StartDate+")");
            end_date.text("("+_event.EndDate+")");
            start_picker.val(_event.StartDate);
            end_picker.val(_event.EndDate);

            title.val(_event.Title);

            start_time.val(_event.StartHour + ':' + _event.StartMinute);
            end_time.val(_event.EndHour + ':' + _event.EndMinute);
            description.height('150px').val(_event.Description);
        } else {
            page_title.text("일정추가");
            btn_edit.show();
            btn_delete.hide();

            var date = DGB.Calendar_Alios.formatDate(_date);
            title.val('');
            start_date.text('');
            end_date.text('');
            start_picker.val(date);
            end_picker.val(date);
            start_time.val('09:00');
            end_time.val('10:00');
            description.height('150px').val('');
        }
        resetSelect(_event);
    };

    var _pagebeforeshow = function() {
        DGB.Common.backPage();
        if( !_calendar ) {
            requestCalendar();
        } else {
            initSelect();
            initData();
        }
    };

	$(document).on({
        pageinit : _pageinit,
        pagebeforeshow : _pagebeforeshow,
        pageshow : function() {
            _layout.refreshLayout();
        },
        parentpage : function(evt, param) {
            _date = param.date;
            _event = param.event;
            _menuId = param.menuId;
            _calendar = param.calendar;
        },
		orientationchange : function() {
            _layout.refreshLayout();
            return false;
		}
	}, '#GWCL002');
})();