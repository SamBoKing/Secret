(function() {
	var $this, _menuId, _menuItem, _layout, _list;
	var _refresh;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		$.Mustache.add('tmpl-list', $this.find('#tmpl-list').html());
		_list = $this.find('#list');
		_list.mustache('tmpl-list', { items : [] });
		_layout.refreshLayout(function() {});

		if( DGB.isDebug() ) { _menuId = 'GW0100'; _refresh = true; }
	}

	function _pageshow() {
		DGB.Common.backMenu();

		var page = $('#GWWA001');
		var title = _menuItem ? _menuItem.data('title') : '결재목록';
		page.find('#pageTitle').text(title);

		if( $this.data('refresh') || _refresh ) {
			_refresh = false;
			$this.data('refresh', false);
			request();
		}
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'GroupWareAdapter',
			procedure : 'GWWA0001',
			parameters : [{
				CS_ID : _menuId,
				ENOB : USER_INFO.ENOB
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var list = { 'items' : data.invocationResult.items || [] };
		for(var i = 0; i < list.items.length; i++) {
			list.items[i].index = i;
			if( list.items[i].attachcnt && list.items[i].attachcnt != "0" ) {
				list.items[i].attach = true;
			}
		}

		_list.empty()
			.mustache('tmpl-list', list)
			.listview('refresh')
			.trigger('updatelayout');

		_list.find('li a').off('vclick').on('vclick',function() {
			var _item = list.items[$(this).attr('data-item')];
			if( !_item ) {
				showAlert(Messages.err001);
				return false;
			}
			var param = [{ menuId : _menuId, item : _item, menuTitle : _menuItem ? _menuItem.data('title') : '결재목록'}];
			DGB.Page.triggerPage("#GWWA002", "parentpage", param);
			DGB.Page.changePage('#GWWA002');
			return false;
		});

		_layout.resetLayout();
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			_menuItem = param.menuItem;
			_refresh = true;
			if (param.activePage) {	// pageshow와 동일한동작
				_pageshow();
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulldownrefresh : function() {
			request();
		}
	}, '#GWWA001');
})();
