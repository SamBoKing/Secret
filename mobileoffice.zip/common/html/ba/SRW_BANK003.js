(function() {
	var $this, _menuId, _layout, _list, _refresh, _config, _result;
	var _sdt, _edt, _group, _state;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, (COMMON_SEARCH_HEIGHT * 2) - 6);
		_list = $this.find('#list');
		_sdt = $this.find('#sdt');
		_edt = $this.find('#edt');
		_group = $this.find('#group');
		_state = $this.find('#state');
		$this.find('.move_top').on('vclick', onMoveTop);
		$this.find('#search').on('vclick', request);

		$.Mustache.add('BANK003_tmpl-list', $this.find('#tmpl-list').html());
		_list.mustache('BANK003_tmpl-list', { list : [] });
		_layout.refreshLayout();
	}

	function _pageshow() {
		DGB.Common.backMenu();
		if( _config ) {
			var refresh = $this.data('refresh');
			if( _refresh || refresh ) {
				_refresh = false;
				$this.data('refresh', false);
				request();
			}
		} else {
			_refresh = false;
			config();
		}
	}

	function config() {
		var opt = {
			onSuccess : onSuccessConfig,
			onFailure : onFailureConfig,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BankingAdapter',
			procedure : 'BANK0005',
			parameters : [{
				CS_ID : _menuId
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessConfig(data) {
		var result = data.invocationResult || {};
		if( !result.success ) {
			dgbLoading(false);
			showAlert(result.msg);
			return;
		}
		_config = result.config || {};
		_sdt.val(_config.SDT);
		_edt.val(_config.EDT);
		$.each(_config.GROUP_CODE, function(i, e) {
			var selected = e.SELECTED ? ' selected="selected"' : '';
			_group.append('<option value="' + e.VALUE + '"' + selected + '>' + e.TEXT + '</option>');
		});
		_group.selectmenu('refresh');
		$.each(_config.STATE_CODE, function(i, e) {
			var selected = e.SELECTED ? ' selected="selected"' : '';
			_state.append('<option value="' + e.VALUE + '"' + selected + '>' + e.TEXT + '</option>');
		});
		_state.selectmenu('refresh');

		request();
	}

	function onFailureConfig(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function request() {
		var sdt = _sdt.val();
		var edt = _edt.val();
		if( !sdt || !edt ) {
			showAlert('날짜입력이 잘못되었습니다!');
			return;
		}

		var int_sdt = parseInt(sdt.replace(/-/g, ''));
		var int_edt = parseInt(edt.replace(/-/g, ''));
		if( int_sdt > int_edt ) {
			showAlert('시작날짜와 종료날짜가 잘못되었습니다!');
			return;
		}

		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BankingAdapter',
			procedure : 'BANK0006',
			parameters : [{
				CS_ID : _menuId,
				SDT : _sdt.val(),
				EDT : _edt.val(),
				MBL_BRCH_GRPCD : _group.val(),
				INSYS_SANCTN_DLNG_STC : _state.val(),
				IS_ADMIN : _config.IS_ADMIN
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		_result = data.invocationResult || {};
		if( !_result.success ) {
			dgbLoading(false);
			showAlert(_result.msg);
			return;
		}

		_list.empty().mustache('BANK003_tmpl-list', _result);
		_layout.resetLayout();
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function onClickItem() {
		var index = $(this).data('index');
		var detail = _result.list[index].DETAIL;
		if( !detail ) {
			showAlert(Messages.err001);
			return false;
		}

		var param = [{ menuId : _menuId, detail : detail }];
		DGB.Page.triggerPage("#BANK004", "parentpage", param);
		DGB.Page.changePage('#BANK004');
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			_refresh = !param.activePage;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BANK003');

	$(document).on('vclick', '#BANK003 .book_item', onClickItem);
})();
