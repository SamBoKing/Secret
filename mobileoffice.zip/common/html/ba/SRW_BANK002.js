(function() {
	var $this, _menuId, _layout, _view, _id = 'IJ', _result;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
		_view = $this.find('#view');
		$.Mustache.add('BANK002_tmpl-view', $this.find('#tmpl-view').html());
		_view.mustache('BANK002_tmpl-view', {});
		_layout.refreshLayout();

		$this.find('.move_top').on('vclick', onMoveTop);
		$this.find('#btn_yes').on('vclick', onClickYes);
		$this.find('#btn_no').on('vclick', onClickNo);
	}

	function _pageshow() {
		DGB.Common.backPage();
		_view.empty().mustache('BANK002_tmpl-view', {});
		request();
	}

	function _parentpage(evt, param) {
		_menuId = param.menuId;
		_id = param.id;
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BankingAdapter',
			procedure : 'BANK0002',
			parameters : [{
				CS_ID : _menuId,
				CYB_DVCD : _id
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		_result = data.invocationResult || {};
		if( !_result.success ) {
			dgbLoading(false);
			showAlert(_result.msg);
			return;
		}
		_view.empty().mustache('BANK002_tmpl-view', _result.detail);

		if( _result.detail.DISABLE_YES ) {
			$this.find('#btn_yes').addClass('btn_disable');
		} else {
			$this.find('#btn_yes').removeClass('btn_disable');
		}

		if( _result.detail.DISABLE_NO ) {
			$this.find('#btn_no').addClass('btn_disable');
		} else {
			$this.find('#btn_no').removeClass('btn_disable');
		}

		$this.find('#tit_nm').attr('readonly', _result.detail.READONLY);
		$this.find('#smr_cn1').attr('readonly', _result.detail.READONLY);



		_layout.resetLayout();
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function requestState(yes) {
		var opt = {
			onSuccess : onSuccessState,
			onFailure : onFailureState,
			invocationContext : {}
		};

		var param = {
			CS_ID : _menuId,
			CYB_DVCD : _id
		};

		if( yes ) {
			param.TIT_NM = $this.find('#tit_nm').val();
			param.SMR_CN1 = $this.find('#smr_cn1').val();
		} else {
			param.APL_DT = _result.detail.APL_DT;
			param.APL_SEQ = _result.detail.APL_SEQ;
		}

		var inv = {
			adapter : 'BankingAdapter',
			procedure : yes ? 'BANK0003' : 'BANK0004',
			parameters : [param]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessState(data) {
		var result = data.invocationResult || {};
		dgbLoading(false);
		showAlert(result.msg);

		if( result.success ) {
			$('#BANK001').data('refresh', true);
			request();
		}
	}

	function onFailureState(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function onClickYes() {
		if( !_result.detail ) {
			showAlert(Messages.err001);
			return false;
		}

		if( _result.detail.DISABLE_YES ) {
			return false;
		}

		var tit_nm = $this.find('#tit_nm').val();
		var smr_cn1 = $this.find('#smr_cn1').val();
		if( _result.detail && tit_nm == _result.detail.TIT_NM && smr_cn1 == _result.detail.SMR_CN1 ) {
			showAlert('수정된 내용이 없습니다! 수정 후 요청해 주시기 바랍니다.');
			return false;
		}

		showConfirm(function(btn) {
			if (btn == '1') {
				DGB.Common.hideKeyboard();
				setTimeout(function() {
					requestState(true);
				}, 300);
			}
		}, "승인요청을 하시겠습니까?");
		return false;
	}

	function onClickNo() {
		if( !_result.detail ) {
			showAlert(Messages.err001);
			return false;
		}

		if( _result.detail.DISABLE_NO ) {
			return false;
		}

		showConfirm(function(btn) {
			if (btn == '1') { requestState(false); }
		}, "요청취소을 하시겠습니까?");
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		parentpage : _parentpage,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BANK002');
})();

