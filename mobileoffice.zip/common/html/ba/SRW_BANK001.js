(function() {
	var $this, _menuId, _layout, _list, _move_top, _btn_refresh, _refresh = true;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT + 2);
		_list = $this.find('#list');
		_btn_refresh = $this.find('#btn_refresh');
		_move_top = $this.find('.move_top');

		$.Mustache.add('BANK001_tmpl-list', $this.find('#tmpl-list').html());
		_list.mustache('BANK001_tmpl-list', { list : [] });
		_layout.refreshLayout();

		_move_top.on('vclick', onMoveTop);
		_btn_refresh.on('vclick', request);
	}

	function _pageshow() {
		DGB.Common.backMenu();
		var refresh = $this.data('refresh');
		if( _refresh || refresh ) {
			_refresh = false;
			$this.data('refresh', false);
			request();
		}
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BankingAdapter',
			procedure : 'BANK0001',
			parameters : [{
				CS_ID : _menuId
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var result = data.invocationResult || {};
		if( !result.success ) {
			dgbLoading(false);
			showAlert(result.msg);
			return;
		}
		_list.empty().mustache('BANK001_tmpl-list', result);
		_layout.resetLayout();
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function onClickItem() {
		var id = $(this).data('id');
		if( !id ) {
			showAlert(Messages.err001);
			return false;
		}
		var param = [{ menuId : _menuId, id : id }];
		DGB.Page.triggerPage("#BANK002", "parentpage", param);
		DGB.Page.changePage('#BANK002');
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			_refresh = !param.activePage;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BANK001');

	$(document).on('vclick', '#BANK001 .book_item', onClickItem);
})();
