(function() {
	var $this, _menuId, _layout, _view, _detail = {};

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
		_view = $this.find('#view');
		$.Mustache.add('BANK004_tmpl-view', $this.find('#tmpl-view').html());
		_view.mustache('BANK004_tmpl-view', {});
		_layout.refreshLayout();

		$this.find('.move_top').on('vclick', onMoveTop);
		$this.find('#btn_yes').on('vclick', onClickYes);
		$this.find('#btn_no').on('vclick', onClickNo);
	}

	function _pageshow() {
		DGB.Common.backPage();
		_view.empty().mustache('BANK004_tmpl-view', _detail);
		if( _detail.DISABLE ) {
			$this.find('#btn_yes').addClass('btn_disable');
			$this.find('#btn_no').addClass('btn_disable');
		} else {
			$this.find('#btn_yes').removeClass('btn_disable');
			$this.find('#btn_no').removeClass('btn_disable');
		}
		_layout.resetLayout();
		_layout.refreshLayout();
	}

	function _parentpage(evt, param) {
		_menuId = param.menuId;
		_detail = param.detail;
	}

	function request(yes) {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};


		var parameters = _detail;
		parameters.CS_ID = _menuId;
		// 승인 : 30, 반려 : 25
		parameters.INSYS_SANCTN_DLNG_STC = yes ? '30' : '25';
		parameters.INFO = '';

		var inv = {
			adapter : 'BankingAdapter',
			procedure : 'BANK0007',
			parameters : [parameters]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var result = data.invocationResult || {};
		if( !result.success ) {
			dgbLoading(false);
			showAlert(result.msg);
			return;
		}

		dgbLoading(false);
		$('#BANK003').data('refresh', true);
		showAlert("알림", result.msg, function() {
			DGB.Page.backPage();
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function onClickYes() {
		if( !_detail ) {
			showAlert(Messages.err001);
			return false;
		}

		if( _detail.DISABLE ) {
			return false;
		}

		showConfirm(function(btn) {
			if (btn == '1') { request(true); }
		}, "[승인] 하시겠습니까?");
		return false;
	}

	function onClickNo() {
		if( !_detail ) {
			showAlert(Messages.err001);
			return false;
		}

		if( _detail.DISABLE ) {
			return false;
		}

		showConfirm(function(btn) {
			if (btn == '1') { request(false); }
		}, "[반려] 하시겠습니까?");
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		parentpage : _parentpage,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BANK004');
})();

