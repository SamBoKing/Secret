(function() {
    var _page, _layout, _bio_id, _menuId;
    _pageinit = function() {
        _page = $(this);
        _layout = new DGB.layout(_page, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT);

        _page.find('#btn_add').on('vclick', onAdd);
        _page.find('.bioMenu').on('vclick', onTab);
        DGB.Common.refreshLayout(_layout);
    };

    _pageshow = function() {
        DGB.Common.backPage();
        onInit();
    };

    onInit = function() {
        _bio_id = '';
        // _page.find('.bioMenu').css('background-color', '#fff');
        // _page.find('.bio_tab').hide();
        // _page.find('#bio_select').text('사용할 바이오 정보를 선택하세요.');
        _page.find('#div_finger').trigger('vclick');
    };

    onAdd = function() {
        if( !_bio_id ) {
            showAlert('사용할 바이오 정보를 선택하세요!');
            return false;
        }

        DGB.Fido.regist(_bio_id,
            function() {
                DGB.Page.changePage('#freeSv');
            }
        );
        return false;
    };

    onTab = function() {
        // 바이오 메뉴 색상변경
        _page.find('.bioMenu').css('background-color', '#fff');
        $(this).css('background-color', '#bfd8e0');

        // 바이오 설명탭 활성화
        _bio_id = $(this).data('type');
        _page.find('.bio_tab').hide();
        _page.find('#bio_tab_' + _bio_id).show();
        DGB.Common.refreshLayout(_layout);

        // 선택된 바이오 텍스트
        var text = '선택된 바이오 정보 : ' + $(this).find('span').text();
        _page.find('#bio_select').text(text);
        return false;
    };

	$(document).on({
        pageinit : _pageinit,
		pageshow : _pageshow,
        selectmenu : function(evt, param) {
            _menuId = param.menuId;
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BIO0002');
})();