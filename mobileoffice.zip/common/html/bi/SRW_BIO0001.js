(function() {
    var _page, _layout;
    _pageinit = function() {
        _page = $(this);
        _layout = new DGB.layout(_page, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT);

        _page.find('#btn_yes').on('vclick', function() {
            DGB.Page.changePage('#BIO0002');
            return false;
        });

        _page.find('#btn_no').on('vclick', function() {
            DGB.Page.changePage('#freeSv');
            return false;
        });
        DGB.Common.refreshLayout(_layout);
    };
    _pageshow = function() {
        WL.App.overrideBackButton(function() {
            dgbLoading(false);
            DGB.Page.changePage('#freeSv');
        });

        _page.find('.jqm-back-link').off('vclick').on('vclick', function(){
            DGB.Page.changePage('#freeSv');
            return false;
        });
    };

	$(document).on({
        pageinit : _pageinit,
		pageshow : _pageshow,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BIO0001');
})();