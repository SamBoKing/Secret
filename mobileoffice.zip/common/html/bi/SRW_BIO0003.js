(function() {
    var _page, _layout, _list, _title;
    var _pageinit = function() {
        _page = $(this);
        _layout = new DGB.layout(_page, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT);

        _page.find('#btn_yes').on('vclick', function() {
            showList();
            return false;
        });
        DGB.Common.refreshLayout(_layout);
    };

    var _pageshow = function() {
        // 뒤로가기 버튼 클릭
        WL.App.overrideBackButton(function() {
            dgbLoading(false);
            DGB.Page.changePage('#freeSv');
        });

        _page.find('.jqm-back-link').off('vclick').on('vclick', function(){
            DGB.Page.changePage('#freeSv');
            return false;
        });

        request();
    };

    var request = function() {
        var opt = {
            onSuccess: function (response) {
                dgbLoading(false);
                var result = response.invocationResult || {};
                _title = result.title;
                _list = result.list;
            },
            onFailure : function(response) {
                dgbLoading(false);
                showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(response));
            },
            invocationContext : { }
        };

        var inv = {
            adapter : 'FidoAdapter',
            procedure : 'FIAUTH0003',
            parameters : [{
                FIDO_ENOB : DGB.Fido.getEnob()
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    var remove = function(rp_usr_id, dvc_id, is_this, index) {
        var opt = {
            onSuccess: function (response) {
                dgbLoading(false);
                var result = response.invocationResult || {};
                if( result.success && _list.length > 0 ) {
                    _list.splice(index, 1);
                    if( is_this ) {
                        DGB.Fido.set('', '');
                        DGB.Fido.login(false);
                    }
                }
                showAlert(result.message || '');
            },
            onFailure : function(response) {
                dgbLoading(false);
                showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(response));
            },
            invocationContext : { }
        };

        var inv = {
            adapter : 'FidoAdapter',
            procedure : 'FIAUTH0004',
            parameters : [{
                RP_USR_ID : rp_usr_id,
                DVC_ID : dvc_id
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

    var showList = function() {
        if( !_list || !_list.length ) {
            showConfirm(function(btn) {
                if( btn == '1' ) {
                    DGB.Page.changePage('#freeSv');
                }
            }, '삭제할 바이오 정보가 없습니다.');
            return;
        }

        var texts = [];
        for(var i in _list){
            texts.push(_list[i].TEXT);
        }
        DGB.Common.selectList(_title, texts, function (index) {
            var item = _list[index];
            showConfirm(function(btn) {
                if( btn == '1' ) {
                    remove(item.RP_USR_ID, item.DVC_ID, item.THIS, index);
                }
            }, item.TEXT + '\n\n바이오정보를 정말 삭제 하시겠습니까?');
        }, function () { } );
    };

	$(document).on({
        pageinit : _pageinit,
		pageshow : _pageshow,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BIO0003');
})();