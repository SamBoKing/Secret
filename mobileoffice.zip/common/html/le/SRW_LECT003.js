(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;

	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$this.find('#lect03Btn').off('vclick').on('vclick', function() {
			lect03search();
		});

		
		$this.find('#lect03Search').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('#lect03Btn').focus();
				lect03search();
				return false;
			}
		});
		
		function lect03search(){
			var param = $('#lect03Search').val();
			if (param == "") {
				showAlert(Messages.msg021);
				return;
			}
			_layout.resetLayout(); //스크롤위치 초기화
			_iscrollEnd = false;
			$("#lect03Noresult").addClass("displayNone");
			$("#videoTrainingListview").empty();
			$('#lect03pullUp').css("display", "none");
			
			//키보드 내리기
			if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
				AndroidNative.hideKeyboard();	
			}
			
			setTimeout(function () {
				listSearch.call(param);
			}, 300);
			
			return false;
		
		}
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#lect03StNum').val(param2), $('#lect03EdNum').val(param3);
						/* //페이징 */
					}

					invocationData = {
						adapter : 'SocketTransactionAdapter',
						procedure : 'TLE00003',
						parameters : [ {
							CS_ID : _menuId,
							TITLE : param1,
							START_NUM : param2,
							END_NUM : param3,
							TELLER_NUM : USER_INFO.ENOB
						} ]
					};

					callProcedure(invocationData, this.options);
				}


			};
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet;
			if(item.length === 0)
			{
				$("#lect03Noresult").removeClass("displayNone");
				$("#lect03InputText").text($('#lect03Search').val());
			
			}
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") break;
				html  = "<li>"+
							"<a href='#' class='lect003List downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
								"<h3>"+item[i].TITLE+"</h3>"+
								"<p><strong style='color:darkblue;'>"+item[i].CREATE_DATE+" / " + item[i].TEACHER_NAME + "</strong></p>"+
							"</a>"+
						"</li>";
				listItems[i] = html;
			}
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#lect03pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#lect03pullUp').css("display", "block");
					$('#lect03StNum').val(
							parseInt($('#lect03StNum').val()) + _pageSize);
					$('#lect03EdNum').val(
							parseInt($('#lect03EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#lect03pullUp').css("display", "none");
			}
			/* //페이징 */
			$("#videoTrainingListview").append(listItems.join(''));
//			$("#videoTrainingListview").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#videoTrainingListview").listview( "refresh" );
			$("#videoTrainingListview").trigger("updatelayout");
			
			$('#videoTrainingListview').find('li a.lect003List').off('vclick').on('vclick',function(){
				
				var item = $(this).attr('data-item');
				var detailId ="LECT004"; 
				var args={};
				args.menuId = _menuId;
				args.item = item;
				
				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}

		function displayError() {
			dgbLoading(false);
		}
		//videoTrainingSearch();
	};
	
	function _pageshow() {
		
		_layout.refreshLayout();
		$('#lect03pullUp').css("display", "none");
		listSearch.call("");
		//android back 버튼 동작
		DGB.Common.backMenu();
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#lect03Search').val(),
			param2 = $('#lect03StNum').val(),
			param3 = $('#lect03EdNum').val();

		listSearch.call(param1, param2, param3);
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagebeforehide: function(evt, ui) {
			//화면 초기화
			$("#videoTrainingListview").empty();
			$('#lect03Search').val("");
			$("#lect03Noresult").addClass("displayNone");
			$('#lect03pullUp').css("display", "none");
			_iscrollEnd = false;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#lect03Btn").focus();
            }
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#LECT003');
})();
