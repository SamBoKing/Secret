(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var listSearch = null;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight);
        $this.find('#monSelectBox').on('change',function(){
            listSearch.call();
            return false;
        });
	};

    listSearch = {
        options : {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        },

        call : function() {
            var firstday = firstDay().replace(/(\-)/g,'');
            var endday = endMonth(firstDay());

            dgbLoading(true);

            var inv = {
                adapter : 'SocketTransactionAdapter',
                procedure : "TDU00001",
                parameters : [{
                    CS_ID : _menuId,
                    EDU_S : firstday,
                    EDU_E : endday
                }]
            };
            callProcedure(inv, this.options);
        }
    };

    function displayResult(data) {
        var item = data.invocationResult.resultSet;
        $this.find("#eduScheduleT").text("");
        var html = "";
        var listItems = [];
        
        if(item.length < 2) {
            $this.find("#ledu01Noresult_1").removeClass("displayNone");
            $this.find("#ledu01Table_1").addClass("displayNone");
        }else{
            $this.find("#ledu01Noresult_1").addClass("displayNone");
            $this.find("#ledu01Table_1").removeClass("displayNone");
        	
            for ( var i = 0; i < item.length; i++) {
                 html  =   "<tr>"
                           +    "<td>"+ item[i].EDU_COURSE_NM + "</td>"
                           +    "<td>"+ dateFormat( item[i].EDU_S_YMD )  + "</td>"
                           +    "<td>"+ dateFormat( item[i].EDU_E_YMD ) + "</td>"
                           +    "<td>"+ parseFloat( item[i].COMPLETE_POINT )  + "</td>  "
                           + "</tr>" ;

                listItems.push(html);
            }

            $this.find("#eduScheduleT").append(listItems.join(''));
        }

        listItems = null;
        html = "";
        item = null;

        _layout.refreshLayout(function(){
            dgbLoading(false);
        }, 500);
    }

    function displayError() {
        dgbLoading(false);
        showAlert(Messages.msg030);
    }

    function insertSelectBox(){
        var months = ["","1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
        var html = "";
        var listItems = [];
        if(months.length != 0) {
            for(var i=1; i<months.length; i++) {
                if(setNowMonth() == i)
                {
                    html =	"<option value='"+[i]+"' selected='selected'>" + months[i]+"</option>";

                }else {
                    html =	"<option value='" +[i]+"'>" + months[i]+"</option>";
                }
                listItems[i] = html;
            }
            $this.find('#monSelectBox').append(listItems.join(''));
            $this.find('#monSelectBox').selectmenu('refresh');

            listItems = null;
        }
    }

    function startDay(){
        var d = new Date();

        d.setDate(1);
        var year = d.getFullYear();
        var month = pad(d.getMonth()+1);
        var date = pad(d.getDate());

        return year+month+date;
    }

    function endMonth(dt){

        var d = new Date(dt);
        d.setMonth(d.getMonth() + 1);
        d.setDate(0);
        var year = d.getFullYear();
        var month = pad(d.getMonth()+1);
        var date = pad(d.getDate());

        return year+month+date;
    }

    function setNowYear(){
        var dt = new Date();
        return  dt.getFullYear() + '년';
    }

    function setNowMonth(){
        var dt = new Date();
        return  dt.getMonth() +1;
    }

    function firstDay(){
        var dt = new Date();
        return dt.getFullYear() + "-" +  pad($this.find('#monSelectBox option:selected').val()) + "-" + "01";
    }

    function dateFormat(date) {
        var val = [];
        if(date.length == 8)
        {
            val.push(date.substr(4,2)+'월');
            val.push(date.substr(6,2)+'일');
        }

        return val.join("");
    }

    $(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
            $this.find('#thisYear').text(setNowYear());
            insertSelectBox();
		    listSearch.call();
		},
		pagebeforehide: function(evt, ui) {
            $this.find("#eduScheduleT").text("");
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#LEDU001');
})();