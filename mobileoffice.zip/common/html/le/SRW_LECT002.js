(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;


		_layout = new DGB.layout($this, _headerHeight);
		
	};
	
	function setContents() {
		$('#lectCourseTitle').text(_item.TITLE);				// 제목
		$('#lectCourseDt').text(_item.UPDATE_DATE);			// 연수일자
		$('#lectInstName').text(_item.REGISTER_NAME);			// 강사
//		$('#lectContent').text(_item.CONTENT);					// 내용
		var attachFiles = _item.ATTACH.split(",");
		var html = "";
		attachFiles.forEach(function(elem) {
			var daviewUrl = new Object();
			daviewUrl.url = _item.URL+"/"+elem;
	
			html += "<li><a href='#' class='lect002DocList ui-link noTitle' data-callDaview='"+JSON.stringify(daviewUrl)+"'><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
			//html += "<li><a href='#' class='ui-link noTitle' onclick='callDaview("+JSON.stringify(daviewUrl)+")'><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
//			html += "<li><a href='#' class='ui-link' onclick='callDaview("+JSON.stringify(daviewUrl)+")'><div class='story'><span class='contentName'>파일 보기</span> <b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
			
		});
		
		$("#lectBuListview:last").html(html);
		//$("#lectBuListview").listview( "refresh" );
//		$('#lectHeduFileNm').text(param1.ATTACH);				// 파일명(ATTACH)
			
		
		//문서리스트 클릭 이벤트
		$('#lectBuListview').find('li a.lect002DocList').off('vclick').on('vclick',function(){
			var daviewUrls ={};
			var dataDaview = $(this).attr('data-callDaview');
			daviewUrls = JSON.parse(dataDaview);
			callDaview(daviewUrls);
			return false;
		});
		
		//android back 버튼 동작
		DGB.Common.backPage();
		
		_layout.refreshLayout(100);
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			setContents();
		},
		parentpage :function (evt, param) {
			$('#LECT002 .initContents').text("");
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#LECT002');

})();
