(function() {
	var $this = undefined;
	var _item = {};
	var videoAndroid = "";
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight);
	};
	
	function setContents() {
		$('#lectTitle').text(_item.TITLE);						// 제목
		$('#lectCreateDate').text(_item.CREATE_DATE);			// 연수일자
		$('#lectTeacherName').text(_item.TEACHER_NAME);		// 강사
		$('#lect04Thumb').attr("src","HTTP://"+ _item.THUMB);	// 썸네일이미지
		
		videoAndroid = "http://"+_item.ANDROID; //안드로이드 동영상파일 경로
		$('#lect04SIos').attr("src","http://"+_item.IPHONE);	//IPHONE 동영상파일 경로
		
		var src = '<source id="lect04SIos" src="'+"http://"+_item.IPHONE+'" type="video/mp4" />';
		$('#lectPlayIos video').append(src);
		
		$('.lectFilename').text(_item.VIDEOSIZE + " / " + _item.DURATION);	// 파일명

		//$('#lectFilename').text(param1.FILENAME+ " " + param1.VIDEOSIZE + " " + param1.DURATION);	// 파일명
		
		if (WL.Client.getEnvironment() == WL.Environment.ANDROID) { // android
			$("#lectPlayAndroid").removeClass("displayNone");
			$("#lectPlayIos").addClass("displayNone");
		}
		else{ //ios
			
			$("#lectPlayIos").removeClass("displayNone");
			$("#lectPlayAndroid").addClass("displayNone");
			
		}

		$this.find('#lect04Thumb').off('vclick').on('vclick', function() {
			window.plugins.videoPlayer.play(videoAndroid);	
			return false;
		});
		
		//android back 버튼 동작
		DGB.Common.backPage();
		
		_layout.refreshLayout(100);
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			setContents();
		},
		pagehide: function(evt, ui) {
			$('#LECT004 .initContents').text("");
			$this.find('.lect04VideoIos')[0].pause();
			$('#lectPlayIos video').empty();
		},
		parentpage :function (evt, param) {
			$('#LECT004 .initContents').text("");
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#LECT004');
})();



//@ sourceURL=le/LECT004.js
