(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$this.find('#lect01Btn').off('vclick').on('vclick', function() {	
			lect01search();
		});
		
		$this.find('#lect01Search').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('#lect01Btn').focus();
				lect01search();
				return false;
			}
		});
		
		function lect01search(){
			var param = $('#lect01Search').val();
			
			if (param == "") {
				showAlert(Messages.msg021);
				return;
			}
			_layout.resetLayout(); //스크롤위치 초기화
			_iscrollEnd = false;
			$("#lect01Noresult").addClass("displayNone");
			$("#buTrainingListview").empty();
			$('#lect01pullUp').css("display", "none");
		
			//키보드 내리기
			if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
				AndroidNative.hideKeyboard();	
			}
			
			setTimeout(function () {
				listSearch.call(param);
			}, 300);
			
			return false;
		}
		
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#lect01StNum').val(param2), $('#lect01EdNum').val(param3);
						/* //페이징 */
					}

					invocationData = {
						adapter : 'SocketTransactionAdapter',
						procedure : 'TLE00001',
						parameters : [ {
							CS_ID : _menuId,
							TITLE : param1,
							START_NUM : param2,
							END_NUM : param3,
							TELLER_NUM : USER_INFO.ENOB
						} ]
					};

					callProcedure(invocationData, this.options);
				}
				
				
			};
				
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet;
			
			if(item.length === 0)
			{
				$("#lect01Noresult").removeClass("displayNone");
				$("#lect01InputText").text($('#lect01Search').val());
			
			}
			
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") break;
				html  = "<li>"+
						"<a href='#' class='lect001List downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
						"<h3>"+item[i].TITLE+"</h3>"+
//						"<p><strong style='color:darkblue;'>"+item[i].UPDATE_DATE+" / " + item[i].REGISTER_NAME + "</strong></p>"+
						"<p><strong style='color:darkblue;'>"+item[i].UPDATE_DATE+"</strong></p>"+
						"</a>"+
						"</li>";
				listItems[i] = html;
			}
			
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#lect01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#lect01pullUp').css("display", "block");
					$('#lect01StNum').val(
							parseInt($('#lect01StNum').val()) + _pageSize);
					$('#lect01EdNum').val(
							parseInt($('#lect01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#lect01pullUp').css("display", "none");
			}
			/* //페이징 */
					
			$("#buTrainingListview").append(listItems.join(''));
//			$("#buTrainingListview").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#buTrainingListview").listview( "refresh" );
			$("#buTrainingListview").trigger("updatelayout");
			
			
			//리스트클릭 이벤트
			$('#buTrainingListview').find('li a.lect001List').off('vclick').on('vclick',function(){
				
				var item = $(this).attr('data-item');
				var detailId ="LECT002"; 
				var args={};
				args.menuId = _menuId;
				args.item = item;
				
				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				
				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}

		function displayError() {
			dgbLoading(false);
		}
		//learningSearch();
	};
	
	function _pageshow() {
		
		_layout.refreshLayout();
		
		$('#lect01pullUp').css("display", "none");
		listSearch.call("");
		//android back 버튼 동작
		DGB.Common.backMenu();
		
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#lect01Search').val(),
		    param2 = $('#lect01StNum').val(),
		    param3 = $('#lect01EdNum').val();

		listSearch.call(param1, param2, param3);
	}

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagebeforehide: function(evt, ui) {
			//화면 초기화
			$("#buTrainingListview").empty();
			$('#lect01Search').val("");
			$("#lect01Noresult").addClass("displayNone");
			$('#lect01pullUp').css("display", "none");
			_iscrollEnd = false;
		},
		pagehide: function(evt, ui) {
			$("#buTrainingListview").empty();
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#lect01Btn").focus();
            }
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#LECT001');
})();
