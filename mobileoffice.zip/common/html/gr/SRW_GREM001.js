(function() {
	var $this = undefined;
	
	var _default = {
		'menuId': undefined,
		'boxId': undefined,
		'mailId': undefined,
		'rowId': undefined,
		'redraw': true,
		'forward': false,
		
		// Mail Form
		'TO':undefined,
		'CC':undefined,
		'BCC':undefined,
		'SUBJECT':undefined,
		'DATA':undefined,	// body data
		'ISATTACHMENTS':false,
		'attachments':undefined
	};
	
	var _Camera = undefined; // Cordova Camera Plugin
	
	var _context = $.extend({}, _default);

	var _textarea = undefined;
	var _textareaHeight = undefined;
	var _j = 0;
	
	// The iscroll was not applied in GREM001 email writer.
	// Because the iscroll didn't work correctly when I made it to be expanded by typing the Enter key.
	
	var pageinit = function(instance) {
		$this = instance;
		
		// Initialize Cordova Camera Plugin
		_Camera = navigator.camera;

		if (typeof _Camera === 'undefined') {
			if(WL.Client.getEnvironment() != WL.Environment.PREVIEW) {
				showAlert(Messages.msg900);
				return;
			}
			_Camera = {
				'getPicture':function(success, failure, options){
					// For testing
					__attachFileCallback({
						name: 'test.ext'+(_j++),
						size: 100402+_j*100,
						type: '',
						fullPath:'/filestore/path/filename.ext'
					}, true);
			
				},
			       	'DestinationType':{
					'FILE_URI':'FILE_URI',
				},
				'PictureSourceType':{
					'PHOTOLIBRARY':'PHOTOLIBRARY',
				},
			};
		}
		
		// Get the template for mail writer
		var _tmpl = $this.find('div[data-name="tmpl-emailwriter"]');
		$.Mustache.add('tmpl-emailwriter', _tmpl.html());
		$.Mustache.add('tmpl-emailwriter-attachitem', _tmpl.find('span.attach-list li')[0].outerHTML);
		
		// Button Event		// Menu Box Event Handler
		var $menuBox = $this.find('div.menu-box');
		$menuBox.find('button').off('vclick').on('vclick', function(){

            _textarea.blur();
			var menu = $(this).attr("data-menu");
			
			if (menu == 'send') {
				showConfirm(function(button){
					if (button == '1') {
						// Send the mail
						var $headerArea = $this.find('div.mailHeaderArea');
						var $to = $headerArea.find('tr[data-rowId="to"] input');
						var $subject = $headerArea.find('tr[data-rowId="subject"] input');
						
						var to = $to.val();
						var cc = $headerArea.find('tr[data-rowId="cc"] input').val();
//						var cc = $headerArea.find('tr[data-rowId="cc"] input').attr('data-val');
						var bcc = $headerArea.find('tr[data-rowId="bcc"] input').val();
//						var bcc = $headerArea.find('tr[data-rowId="bcc"] input').attr('data-val');
						var subject = $subject.val();
						var body = _textarea.val();
						
						//엔터를 <br>태그로 변경
						body=body.replace(/\n/g,"<br/>");
						
						//편지쓰기메뉴로 접근하지 않고 답장,전체답장,전달로 접근시 추가
						if (_context.boxId != undefined) {
							body +=_emailBodyMove;
							_emailBodyMove = '';
						}
						
						if (typeof to === 'undefined' || to == "") {
							$to.addClass('missing').focus();
							showAlert(Messages.msg022);
							return;
						}
						$to.removeClass('missing');
						
						if (typeof subject === 'undefined' || subject == "") {
							$subject.addClass('missing').focus();
							showAlert(Messages.msg022);
							return;
						}
						$subject.removeClass('missing');
						
						var mailId = undefined;
						if (_context.forward) mailId = _context.mailId;
						dgbLoading(true);

						// Read files as attachment
						var attachments = [];
						var promises = [];

						for (var idx in _context.attachments) {
							var att = _context.attachments[idx];
							var file = att.FILE;
							promises.push(DGB.filectrl.getFileAsDataURL(file, idx).done(function(b64){
								
								var __idx = b64.substring(0, b64.indexOf(';'));
								b64 =  b64.substring(b64.indexOf(';')+1);
								
								var __att = _context.attachments[__idx].FILE;
								
								if (typeof b64 === 'undefined') {
									// on testing
									attachments.push({
										'NAME':att.NAME,
										'TYPE':att.TYPE,
										'SIZE':att.SIZE,
										'DATA': att.DATA,
									});
								} else {
									attachments.push({
										'NAME':__att.name,
										'TYPE':__att.type,
										'SIZE':__att.size,
										'DATA': b64
									});
								}
							}).fail(function(err){
							}));
						}
						$.when.apply($, promises).done(function(){
							DGB.email.sendMail(_context.menuId, to, cc, bcc, subject, body, attachments, mailId, 
								function(){
									// Success
									dgbLoading(false);
									$("#GREM003").trigger("pagerefresh",[]);
									DGB.menuctrl.triggerLocMails(_context.menuId);
								},
								function(err){
									// Failure
									dgbLoading(false);
									__emailErrorHandler(err);
								});
						});
						
					}else if (button == '2') {
						return;
					}
					
				}, Messages.msg023);
				return false;
			}
			if (menu == 'save') {
				showAlert(Messages.msg900);
				return false;
			}
			if (menu == 'attach') {
				
				var options = {
					quality: 50,
					allowEdit: true,
					//sourceType: _Camera.PictureSourceType.CAMERA,
					sourceType: _Camera.PictureSourceType.PHOTOLIBRARY,
					//sourceType: _Camera.PictureSourceType.SAVEDPHOTOALBUM,
					//destinationType: _Camera.DestinationType.DATA_URL,
					destinationType: _Camera.DestinationType.FILE_URI,
				};
				_Camera.getPicture(function(photo){
					// Success
					DGB.filectrl.getLocalFileURI(photo, __attachFileCallback , function(errMsg){
					});
				}, function(errMsg){
					// Error
					showAlert(Messages.msg02E+':\n'+errMsg);
				}, options);
				
				return false;
			}
			if (menu == 'cancel') {
				showConfirm(function(button){
					if (button == '1') {
						// Switch to previous page
						//$("#GREM003").trigger("pagerefresh",[]);
						//DGB.Common.backPage();;
						DGB.menuctrl.triggerLocMails(_context.menuId);
						
					}else if (button == '2') {
						return;
					}
					
				}, Messages.msg025);
				return false;
			}
			
			return false;
		});
		
		// TextArea
		_textarea = $this.find('.mailBodyArea textarea');
		_textareaHeight = _textarea.innerHeight();
		_textarea.on({
			'blur': function(evt) {
				/*
				if (evt.target.scrollHeight > $(this).innerHeight()) {
					$(this).height(evt.target.scrollHeight);
				}*/
				return false;
			},
			'keyup': function(evt) {
				if(evt.target.scrollHeight >= _textareaHeight) {
					$(this).height(evt.target.scrollHeight);
				}
				return false;
			}
		});
	};

	var __emailErrorHandler = function(err) {
		// show error
		var errmsg = getErrorInfo(err.errorCode);
		if(err.errorCode == 'MOSE0101') {
			showAlert(Messages.msg020+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0105') {
			showAlert(Messages.msg024+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0201') {
            var $headerArea = $this.find('div.mailHeaderArea');
            var $to = $headerArea.find('tr[data-rowId="to"] input');
            $to.addClass('missing').focus();
			showAlert(Messages.msg02H);
		} else {
			showAlert(Messages.msg104);
			DGB.menuctrl.triggerMenuItem('CO0102');
			return true; // Handle page switching outside
		}
	};

	var __attachFileCallback = function(file, test){
		// Get total file size
		var total = 0;
		_context.attachments.map(function(item){
			total += item.SIZE;
		});
		
		if (total + file.size > SENDMAIL_ATTACHMENTS_SIZE_LIMIT) {
			showAlert(Messages.msg02E);
			return;
		}

		if (test) {
			_context.attachments.push({
				'NAME':file.name,
				'TYPE':file.type,
				'SIZE':28,
				'FSIZE':formattedFilesize(file.size),
				'DATA': 'L2ZpbGVzdG9yZS9wYXRoL2ZpbGVuYW1lLmV4dA=='
				// -> /filestore/path/filename.ext
			});
			
			// Refresh
			__updateAttachments();
			return;
		}

		_context.attachments.push({
			'NAME':file.name,
			'TYPE':file.type,
			'SIZE':file.size,
			'FSIZE':formattedFilesize(file.size),
			'FILE':file // to read it when the mail is sending
		});
		
		// Refresh
		__updateAttachments();
	};
	
	var __updateAttachments = function() {
		var $attach = $this.find('[data-rowId="attachments"]');
		var $attachList = $attach.find('.attach-list ul').empty();

		if (typeof _context.attachments === 'undefined' || _context.attachments.length == 0) {
			// clear list
			
			// hide attachments
			$attach.hide();
			return;
		}
		
		// Update Mail Attachments
		var noshow = true;
		for (var idx in _context.attachments) {
			noshow = false;
			var att = _context.attachments[idx];
			att.INDEX = idx;
			$attachList.mustache('tmpl-emailwriter-attachitem', att);
		}

		if (noshow) {
			// hide attachments
			$attach.hide();
			return;
		}
		
		// Event listener
		$attachList.find('li').off('vclick').on('vclick', function(){
			delete _context.attachments[$(this).attr('data-idx')];
			__updateAttachments();
			return false;
		});
		
		$attach.show();
	};
	
	var __setHeaderEventHandler = function() {
		var $headerArea = $this.find('div.mailHeaderArea');
		$headerArea.find('tr[data-rowId="to"] input').on('keyup', function(evt){
			if (evt.target.value.length !== 0) $(this).removeClass('missing');
			else $(this).addClass('missing');
		});
		$headerArea.find('tr[data-rowId="subject"] input').on('keyup', function(evt){
			if (evt.target.value.length !== 0) $(this).removeClass('missing');
			else $(this).addClass('missing');
		});

		$headerArea.find('label.addBtn').off('vclick').on('vclick', function(){
			_context.rowId = $(this).parents('tr').attr('data-rowId');

            /*
			$('#EMST004').trigger('selectmenu', [{
				menuId:_context.menuId,
			}]);
			*/

            DGB.Page.triggerPage('#EMST004', "selectmenu", [{
                menuId:_context.menuId
            }]);

			setTimeout(function () {
				DGB.Page.changePage('#EMST004');
			},400);
			return false;
		});
	};
	
	var __pageshow = function(forced) {
		if (!forced && !_context.redraw) return;
		_context.redraw = false;
		
		// Get email content from the mail box
		if (typeof _context.boxId !== 'undefined' && typeof _context.mailId !== 'undefined' && typeof _context.forward === 'undefined') {
			dgbLoading(true);
			DGB.email.getMailContent(_context.menuId, _context.boxId, _context.mailId, 
				function(mailDetail){
					// Success
					dgbLoading(false);
					_context.reload = false;
					
					// Update Mail Header
					$this.find('div.mailHeaderArea').empty()
						.mustache('tmpl-emailwriter', mailDetail.mail);
					
					_textarea.val(mailDetail.mail.DATA);
					
					__setHeaderEventHandler();
				}, function(err) {
					// Failure
					dgbLoading(false);
					__emailErrorHandler(err);
				});
		} else {
			// Clean up
			$this.find('div.mailHeaderArea').empty()
				.mustache('tmpl-emailwriter', _context);
			_textarea.val(_context.DATA);
			
			__setHeaderEventHandler();
		}
	};
	
	var __insertMailAddress = function(rowId, usermail) {
		var $tf = $this.find('.mailHeaderArea [data-rowId="'+rowId+'"] input');
        var ez = $tf.val();
        if (ez !== '') ez = ', '+ez;
        $tf.val(usermail+ez);
	};
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function() {
			__pageshow();
		},
		selectmenu :function(evt, params) {
			_context = $.extend({}, _default, params);
			_context.attachments = [];
		},
		writemail: function(evt, params) {
			// reply or forward
			_context = $.extend({}, _default, params);
			_context.attachments = [];
			
			//DGB.Page.changePage('#GREM001');
		},
		editmail: function(evt, params) {
			// Editing email is not supported currently.
			showAlert(Messages.msg900);

			if (_default.attachments instanceof Array) {
				// Deep copy
				_context = $.extend(true, {}, _default, params);
			} else {
				_context = $.extend({}, _default, params);
			}
		},
		response: function(evt, params) {
			// select person or write to the person
			if (typeof params.usermail != 'undefined') {
				__insertMailAddress(_context.rowId, params.usermail);
			}
		},
		orientationchange : function(evt) {
            return false;
		}
	}, '#GREM001');
})();
