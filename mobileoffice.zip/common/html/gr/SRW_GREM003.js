(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _boxId = undefined;
	var _mailId = undefined;
	var _layout = undefined;
	
	// control context
	var _context = {
		refresh : false
	};
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _menuHeight = COMMON_MENUBAR_HEIGHT;
	
	var __menuBoxEventHandler = function() {
		var menu = $(this).attr("data-menu");
		
		if (menu == 'delete') {
			showConfirm(function(button){
				if (button == '1') {
					// Delete the selected mails
					dgbLoading(true);
					DGB.email.deleteMails(_menuId, _boxId, _mailId, 
						function(isSuccess){
							// Success
							dgbLoading(false);
							// it makes the prev page be refreshed
                            //DGB.Page.triggerPage("#GREM002", "pulldownrefresh", []);
							//DGB.Common.backPage();;
                            mailBackRefresh();
						},
						function(err){
							// Failure
							dgbLoading(false);
							if (__emailErrorHandler(err)) {
								// refresh result
								__refresh(true);
							}
						});
				}else if (button == '2') {
					return;
				}
			}, Messages.msg027);
			return false;
		}
		if (menu == 'move') {
			showConfirm(function(button){
				if (button == '1') {
					
					__mailboxItemMove(_mailId);
					
					// Show the mailbox list as a dialog
//					$("#GREM004").trigger("movemails",[{
//						menuId: _menuId,
//						boxId: _boxId,
//						mailIds: _mailId
//					}]);
				}else if (button == '2') {
					return;
				}
				
			}, Messages.msg029);
			return false;
		}
		
		// Use text() instead of html()
		var $detailView = $this.find('div.mailHeaderArea .detailView');
		var sender = $detailView.find('span.senderText').text();
		var to = $detailView.find('span.toText').text();
		var cc = $detailView.find('span.ccText').text();
		var time = $detailView.find('span.sentTime').text();
		var subject = $detailView.find('span.subjectText').text();
		var body = $this.find('div.mailBodyArea').html();
		
		var arr = [];
		arr.push('\n\n\n');
		arr.push(Messages.msg02F);
		arr.push('>발신 : '+sender);
		arr.push('>수신 : '+to);
		if (typeof cc !== 'undefined' && cc != '') arr.push('>참조 : '+cc);
		arr.push('>시간 : '+time);
		
		var atts = [];
		$detailView.find('li.attachText label').each(function(idx, item){
			atts.push($(item).text());
		});
		if (atts.length > 0) arr.push('>첨부 : '+atts.join(', '));
		
		arr.push('>제목 : '+subject);
		
		//content부분은 reply,replyAll,forward시 textarea에는 출력되지 않고 전송시에 append시켜서 보냄
		// Put the body content
		_emailBodyMove = '';
		_emailBodyMove = "<br/>"+body.replace(/\n/g,"<br/>");
		
		// Check if it's forwarding
		if (menu == 'forward') {
			// Show the mail writer
            DGB.Page.triggerPage("#GREM001", "writemail", [{
				menuId: _menuId,
				boxId: _boxId,
				forward: true,
				mailId: _mailId,
				SUBJECT: 'Fw: '+subject,
				DATA: arr.join('\n'),
            }]);
            DGB.Page.changePage('#GREM001');				
			return false;
		}
		
		if (menu == 'reply') {
			// Show the mail writer
            DGB.Page.triggerPage("#GREM001", "writemail", [{
                menuId: _menuId,
                boxId: _boxId,
                TO: sender,
                SUBJECT: 'Re: '+subject,
                DATA: arr.join('\n'),
            }]);
            DGB.Page.changePage('#GREM001');

			return false;
		}
		if (menu == 'replyAll') {
			// Show the mail writer
            DGB.Page.triggerPage("#GREM001", "writemail", [{
				menuId: _menuId,
				boxId: _boxId,
				TO: sender,
				CC: cc,
				SUBJECT: 'Re: '+subject,
				DATA: arr.join('\n'),
            }]);
            DGB.Page.changePage('#GREM001');			
			return false;
		}
		
		return false;
	};
	
	var pageinit = function(instance) {
		$this = instance;
		
		// Get the template for mail header
		var _tmpl = $this.find('script[data-name="tmpl-emailheader"]');
		$.Mustache.add('tmpl-emailheader', _tmpl.html());
		

		_layout = new DGB.layout($this, _headerHeight, _menuHeight, {zoom:true});

//		// Header Button Event Handler
		$this.find("#grem003Back").off('vclick').on('vclick',function() {
			
			mailBack();
			return false;
		});
		
		// Menu Box Event Handler
		var $menuBox = $this.find('div.menu-box');
		$menuBox.find('button').off('vclick').on('vclick', __menuBoxEventHandler);
		
		var $viewType = $this.find('span.viewType span');
		$viewType.off('vclick').on('vclick', function(){
			if ($viewType.hasClass('ui-icon-plus')) {
				// Expand
				$viewType.removeClass('ui-icon-plus').addClass('ui-icon-minus');
				
				$this.find('.mailHeaderArea div.simpleView').hide();
				$this.find('.mailHeaderArea div.detailView').show();
			} else {
				// Collapse
				$viewType.removeClass('ui-icon-minus').addClass('ui-icon-plus');
				
				$this.find('.mailHeaderArea div.detailView').hide();
				$this.find('.mailHeaderArea div.simpleView').show();
			}
			_layout.refreshLayout(600);
			return false;
		});
	};

	
	//메일 이동
	var __mailboxItemMove = function(selectMail) {
		
		if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
			var numberlist = [ "이동할 메일함선택" ];
		}
		else{
			var numberlist = [ "취소" ];
		}
			var thelist = [];
			var mailbox_name=[];
			// Get email box list
			dgbLoading(true);
			DGB.email.getMailBoxList(_menuId, 
				function(mailboxInfo){
					
					// list up the mail box
					// Remove current box
					var boxes = mailboxInfo.boxes.filter(function(box){
						return box.MAILBOX_NAME != _boxId;
					});
					
					for (var i= 0; i < boxes.length; i++){
						numberlist[i+1]=boxes[i].MAILBOX_NAME_DECODE;
						//thelist[i+1]=boxes[i].MAILBOX_NAME_DECODE;
						mailbox_name[i+1] = boxes[i].MAILBOX_NAME;
					}
					dgbLoading(false);
					
					thelist = numberlist;
				 if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
						cordova.exec(
	
								function(listitem) {
									DGB.email.moveMails(_menuId, _boxId, selectMail, mailbox_name[listitem], 
											function(){
												// Success
												//dgbLoading(false);
												// $this.dialog('close');
												//DGB.menuctrl.triggerMoveMails(_menuId);
												//DGB.Common.backPage();;
                                                showAlert(Messages.msg02I);
                                                mailBackRefresh();

											},
											function(err){
												// Failure
												//dgbLoading(false);
												__emailErrorHandler(err);
											});
	
								}, function(error) {
								}, "AlertList", "alertlist",thelist);
						
					}else{
						// After device ready, create a local alias
						var actionSheet = window.plugins.actionSheet;
	
						// Complex
						actionSheet.create({
							title : '이동할 메일함선택',
							items : numberlist,
							//destructiveButtonIndex : 1,
							cancelButtonIndex : 0
						}, function(buttonValue, buttonIndex) {
						
							DGB.email.moveMails(_menuId, _boxId, selectMail, mailbox_name[buttonIndex], 
									function(){
										// Success
										//dgbLoading(false);
										// $this.dialog('close');
										//DGB.menuctrl.triggerMoveMails(_menuId);
										//DGB.Common.backPage();;
                                        showAlert(Messages.msg02I);
                                        mailBackRefresh();
									},
									function(err){
										// Failure
										//dgbLoading(false);
										__emailErrorHandler(err);
									});
						
						});
					}
				}, function(err){
					// Failure
					dgbLoading(false);
					if (__emailErrorHandler(err)) {
						DGB.Common.backPage();;
					}
				});
		
		return false;
	};
	
	var __emailErrorHandler = function(err) {
		// show error
		var errmsg = getErrorInfo(err.errorCode);

		if(err.errorCode == 'MOSE0101') {
			showAlert(Messages.msg020+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0105') {
			showAlert(Messages.msg024+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0000'){
			showAlert(Messages.msg072);	//메일서버에서 응답이 없습니다.다시조회하시기바랍니다.
			return true; // Handle page switching outside
		}else {
			//showAlert(Messages.msg104+':'+errmsg);
			showAlert(Messages.msg104);
			DGB.menuctrl.triggerMenuItem('CO0102');
			return true; // Handle page switching outside
		}
	};
	
	/*
	var fit = function() {
		if (iscroll) iscroll.destroy();
		
		iscroll = new iScroll($wrapper[0],{zoom:true, zoomMin:0.5, zoomMax:6});
	};
	*/
	
	var __refresh = function(forced) {
		
		if (!_context.refresh && !forced) return;
		_context.refresh = false;

		dgbLoading(true);

		// Reset layout for zoom
		_layout.resetLayout();

		// Get email content
		DGB.email.getMailContent(_menuId, _boxId, _mailId, 
			function(mailDetail){
				// Reset view type
				var $viewType = $this.find('span.viewType span');
				$viewType.removeClass('ui-icon-minus').addClass('ui-icon-plus');
				
				if (mailDetail.mail.ISATTACHMENTS) {
					mailDetail.mail.attachments.map(function(item){
						item.FSIZE = formattedFilesize(item.SIZE);
					});
				}
				
				// Get & Empy Mail Header & Body
				var $headerArea = $this.find('div.mailHeaderArea').empty();
				var $bodyArea = $this.find('div.mailBodyArea').empty();
				var $nobody = $this.find('div.mailNobody').show();

				// Update Mail Header
				$headerArea.mustache('tmpl-emailheader', mailDetail.mail);

				// Update Mail Body
				if (typeof mailDetail.mail.DATA !== 'undefined') {
					// Hide nobody
					$nobody.hide();

					// Wrap the body text with x-body element
					var $body = $('<x-body>'+mailDetail.mail.DATA+'</x-body>');
					
					// Remove script tags for security
					$body.find('script').remove();
					$body.find('embed').remove();
					$body.find('iframe').remove();
					$body.find('style').remove();
					$body.find('[target]').removeAttr('target');
					$body.find('[onclick]').removeAttr('onclick');
					$body.find('[onload]').removeAttr('onload');
					$body.find('[onerror]').removeAttr('onerror');

					$body.appendTo($bodyArea);
					
					//메일내용에 a태그 url 링크
					$('.mailBodyArea x-body').find('[href]').off('vclick').on('vclick',function(e){
						e.preventDefault();
						var mLink = $(this).attr("href");
						window.open(mLink, "_system", "location=no");
						return false;
					});
					
					
					//이미지 불러오는것 계산(imagesloaded 사용)
					$this.find('div.mailBodyArea').imagesLoaded()
					  .always( function( instance ) {
					    _layout.refreshLayout(300);
					  })
					  .done( function( instance ) {
					    _layout.refreshLayout(300);
					  })
					  .fail( function() {
					    _layout.refreshLayout(300);
					  })
					  .progress( function( instance, image ) {
					    var result = image.isLoaded ? 'loaded' : 'broken';
					  });
					
				}
				
				// Attachment click event
				$this.find('div.mailHeaderArea li.attachText').off('vclick').on('vclick', function(){
					// show the contents with content viewer
					var fileName = $(this).attr('data-fileName');
					var type = $(this).attr('data-type');
					var uid = $(this).attr('data-uid');
					var bodyPeek = $(this).attr('data-bodyPeek');
					
					var boxId = _boxId.indexOf('&') != -1 ? "B:"+_boxId.substr(1, _boxId.length) : _boxId;
					
					var param = "/emailattach?parameters={'__PRIVATE_KEY__':'"	+ nmf.Store.get(EMAIL_KEY_ID)
														+"','ENOB':'"			+ USER_INFO.ENOB
														+"','DEVC_NATV_NO':'"	+ nmf.Store.get(MAC_ADDRESS)
														+"','UID':'"			+ uid
														+"','BODY_PEEK':'"		+ bodyPeek
														+"','MAILBOX_NAME':'"	+ boxId
														+"','NAME':'"			+ fileName + "'}";
					
					if (fileName.indexOf('.') != -1) {
						fileType = (fileName.split('.'))[1];	//첨부파일확장자
						
						if (EMAIL_NOT_VIEW.indexOf(fileType.toLowerCase()) != -1) {
							showAlert(Messages.msg026);	//모바일에서볼수없는파일입니다 PC에서이용해주십시오
							return false;
						}
						if (WL.Client.getEnvironment() != WL.Environment.ANDROID) {
							//IOS만 제외
							if ("text".indexOf(fileType.toLowerCase()) != -1) {
								showAlert(Messages.msg026);	//모바일에서볼수없는파일입니다 PC에서이용해주십시오
								return false;
							}
						}
					}else {
						showAlert(Messages.msg026);	//모바일에서볼수없는파일입니다 PC에서이용해주십시오
						return false;
					}
					
					dgbLoading(true);
					$.ajax({
						url:  DOWN_URL+ param
					}).done(function(data){
						dgbLoading(false);
						
						var jsonData = JSON.parse(data);
/*
						//첨부파일 다뷰호출시..
						var callHost =jsonData.HOST.split('/');
						var callURL ="http://"+ callHost[0]+":9080/"+callHost[1] + jsonData.URL;	//was url
						callDaview({url:callURL});
*/
						
						var attachURL = DOWN_URL+jsonData.URL;
						//20140204 - 이미지파일도 다운로드 되도록 수정.
						//이미지일때
						//if (fileType.indexOf('jpg') != -1 || fileType.indexOf('png') != -1 || fileType.indexOf('bmp') != -1 || fileType.indexOf('gif') != -1) {
							//window.open(encodeURI(attachURL), "_blank", "EnableViewPortScale=yes,location=no");
			
						//}else {//이미지 아닐때 뷰어로 실행..하기위해서 로컬에 저장
							var downPath = DGB.fileRoot() + "email/";
							downloadFile({"url" :attachURL, "title":(fileName.split('.'))[0], "downPath":downPath});
						//}
					}).fail(function(jqXHR,textStatus){
						showAlert(Messages.msg069);	//첨부파일 열기가 실패하였습니다.PC에서 이용해주십시오
						dgbLoading(false);
					});
					return false;
				});
				_layout.refreshLayout(1000);
				dgbLoading(false);
			},
			function(err){
				// Failure
				dgbLoading(false);
				if (__emailErrorHandler(err)) {
					DGB.Common.backPage();
				}
			});
	};
	
	function mailBack() {

        DGB.Page.triggerPage("#GREM002", "detailpageread", [_mailId]);
        DGB.Page.changePage("#GREM002");
		//setTimeout(function(){
			//DGB.Common.backPage();;
		//},300);
	}
    //메일읽기에서 삭제, 이동 후 자동 back동작.
    function mailBackRefresh(){

        DGB.Page.triggerPage("#GREM002", "pulldownrefresh", []);
        DGB.Page.changePage("#GREM002");
    }
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pagebeforeshow: function(evt, ui) {
			_context.refresh = true;
			
			__refresh();

			//android back 버튼 동작
			WL.App.overrideBackButton(mailBack);
		},
		pagehide: function(evt, ui) {
			// remove body elements, it will remove inline CSS of email content
			$this.find('div.mailBodyArea').empty();
		},
		pagerefresh: function(evt, ui) {
			_context.refresh = true;
		},
		showmail: function(evt, params) {
			_menuId = params.menuId;
			_boxId = params.boxId;
			_mailId = params.mailId;

			// Initialize context 
			_context = {
				refresh : true
			};
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GREM003');
})();
