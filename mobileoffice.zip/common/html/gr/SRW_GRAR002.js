(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight);
		
	};
	
	function setContents() {
		$('#grarTitle').text(_item.TITLE);				// 제목
		
		var zzzuser00 = _item.ZZZUSER00.split("/");
		var html = "";
		var dummyName = "";
		if($.trim(zzzuser00) != "") {
			zzzuser00.forEach(function(elem) {
	//			html += "<label for='textarea2'>"+elem+"</label>";
				var indexNumber = elem.indexOf("0");
				var callName = elem.substring(0, indexNumber);
				if($.trim(callName) == "") {
					callName = dummyName;
				}
				var callNumber = elem.substring(indexNumber, elem.length);
				// 무조건 전화걸기로
//				var smsYn = callName.indexOf("SMS") == -1 ? "no" : "yes";
//				var callIcon = smsYn == "no" ? "images/call.png" : "images/message.png";
				var smsYn = "no";
				var callIcon = "images/call.png";
				
				html += "<li><a href='#' class='grar002List' data-smsYn='"+smsYn+"' data-callNumber='"+callNumber+"'>"+
							"<div class='story'>"+
								"<span class='contentName'>"+callName+"</span> <b class='metadata initContents'>"+callNumber+"</b><br></div>"+
							"<div class='storyIcon'>"+
							"<img src='"+callIcon+"' class='action-icon'></div>"+
						"</a></li>";
				dummyName = callName;
			});
			
			$('#grarZzzuser00').append(html);
		}
		
		html = "";
		var attachFiles = _item.ATTACH.split(",");
		attachFiles.forEach(function(elem) {
			var daviewUrl = new Object();
			daviewUrl["url"] = _item.URL+"/"+elem;
			html += "<li><a href='#' class='grar002DocList ui-link noTitle' data-callDaview='"+JSON.stringify(daviewUrl)+"'><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
//			html += "<li><a href='#' class='ui-link noTitle' onclick='callDaview("+JSON.stringify(daviewUrl)+")'><div class='story'><b class='metadata'>"+elem+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
		});
		$('#grarAttachFiles').append(html);
//		$('#lectHeduFileNm').text(param1.ATTACH);				// 파일명(ATTACH)
//		$("#grarZzzuser00").listview( "refresh" );
//		$("#grarZzzuser00").trigger("updatelayout");
		_layout.refreshLayout();
		
		//리스트클릭 이벤트
		$('#grarZzzuser00').find('li a.grar002List').off('vclick').on('vclick',function(){
			
			var callNumber = $(this).attr('data-callNumber');
			var sms = $(this).attr('data-smsYn');
			if(sms === "yes") {
				if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
					AndroidNative.sendSms(callNumber.replace(/-/g,''));
				} else {
                    location.href = "sms:"+ callNumber.replace(/-/g,'');
				}
			} else {
				location.href = "tel:"+ callNumber.replace(/-/g,'');
			}
			return false;
		});
		
		//문서리스트 클릭 이벤트
		$('#grarAttachFiles').find('li a.grar002DocList').off('vclick').on('vclick',function(){
			var daviewUrls ={};
			var dataDaview = $(this).attr('data-callDaview');
			daviewUrls = JSON.parse(dataDaview);
			callDaview(daviewUrls);
			return false;
		});
		
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			setContents();

			DGB.Common.backPage();
		},
		pagehide: function(evt, ui) {
			$("#grarZzzuser00").empty();
			$("#grarAttachFiles").empty();
		},
		parentpage :function (evt, param) {
			$('#GRAR002 .initContents').text("");
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRAR002');
})();
