(function() {
	var $this = undefined;
	var _layout = undefined;
    var _localUrl = undefined;
    var _activePage = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, _headerHeight);
	};
	
	function setContents() {

        if(_activePage == 'GRMA002'){
            $('#grma03title').text('마케팅 상세');
        }else if(_activePage == 'GRYL002'){
            $('#grma03title').text('윤리경영 상세');
        }

        $('#grma03SIos').attr("src",_localUrl);	//IPHONE 동영상파일 경로
		var src = '<source id="grma03SIos" src="'+_localUrl+'" type="video/mp4" />';
		$('#grmaPlayIos video').append(src);
		$("#grmaPlayIos").removeClass("displayNone");
		_layout.refreshLayout(100);
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			setContents();
		},
		pagehide: function(evt, ui) {
			$('#GRMA003 .initContents').text("");
			$this.find('.lect04VideoIos')[0].pause();
			$('#grmaPlayIos video').empty();
		},
		parentpage :function (evt, param) {
			$('#GRMA003 .initContents').text("");

            _localUrl = param.localUrl;
            _activePage = param.activePage
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRMA003');
})();