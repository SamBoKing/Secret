(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight);
		
	};
	
	//Hit 업데이트
	function plusHit() {
		var writNo = _item.PUTUP_WRIT_NO;

		var invocationData = {
				adapter : 'DBTransactionAdapter',
				procedure : 'TGR00002',
				parameters : [{WRIT_NO : writNo, CS_ID:_menuId}]
			};
			
			var options = {
				onSuccess : plusResult,
				onFailure : plusError,
				invocationContext : {}
			};
			
			callProcedure(invocationData, options);
	}
	
	function plusResult(data) {

		if(data.invocationResult.updateStatementResult.updateCount == 1)
		{
			setContents();
		}

	}

	function plusError() {
	}

	function setContents() {

		$('.grbo02Title').text(_item.TIT);				// 제목
		$('#grbo02Date').text(_item.REG_DTTI);			// 날짜
		$('#grbo02Hit').text(_item.INQ_CNT);			// hit 수
		
		$('#grbo02MainArea').append("");
		$('#grbo02MainArea').append(_item.PUTUPWRIT_CN);					// 내용

		DGB.Common.backPage();
		
		_layout.refreshLayout(100);
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			$('#GRBO002 .initContents').text("");
			plusHit();
		},
		parentpage :function (evt, param) {
			$('#GRBO002 .initContents').text("");
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRBO002');
})();
