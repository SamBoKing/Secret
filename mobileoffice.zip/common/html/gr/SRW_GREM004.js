(function() {
	var $this = undefined;
	
	var _menuId = undefined;
	var _mailIds = undefined;
	var _layout = undefined;
	
	// Fixed height
	var _headerHeight = COMMON_DIALOG_HEADER_HEIGHT;
	var _layoutCalibration = COMMON_DIALOG_POSITION_OFFSET*2;
	
	// This page doesn't have the menu controls.
	
	var pageinit = function(instance) {
		$this = instance;
		
		// Get the template for mail writer
		var _tmpl = $this.find('div[data-name="tmpl-emailboxselect"]').html();
		$.Mustache.add('tmpl-emailboxselect', _tmpl);
		

		_layout = new DGB.layout($this, _headerHeight+_layoutCalibration);
		
	};
	
	var __emailErrorHandler = function(err) {
		// show error
		var errmsg = getErrorInfo(err.errorCode);
		if(err.errorCode == 'MOSE0101') {
			showAlert(Messages.msg020+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0105') {
			showAlert(Messages.msg024+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else {
			showAlert(Messages.msg104+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
			return true; // Handle page switching outside
		}
	};
	var __mailboxItemEventHandler = function() {
		var $mailbox = $(this);
		var boxId = $mailbox.attr('data-boxid');
		
		//
		//dgbLoading(true);
		DGB.email.moveMails(_menuId, _boxId, _mailIds, boxId, 
			function(){
				// Success
				//dgbLoading(false);
				// $this.dialog('close');
				DGB.menuctrl.triggerMoveMails(_menuId);
				//DGB.Common.backPage();;
			},
			function(err){
				// Failure
				//dgbLoading(false);
				__emailErrorHandler(err);
			});
		
		return false;
	};
	
	var __refreshMailboxItemHandler = function() {
		// rebind menu item event handler
		$this.find('.mailBoxSelect a')
		.off('vclick', __mailboxItemEventHandler)
		.on('vclick', __mailboxItemEventHandler);
	};
	
	var _refresh = function(forced) {
		var cached = DGB.email.getCachedMailBoxInfo(); 
		if (typeof cached !== 'undefined' && !forced) {
			var boxes = cached.boxes.filter(function(box){
				return box.MAILBOX_NAME != _boxId;
			});
			$this.find('div.mailBoxSelect').empty()
				.mustache('tmpl-emailboxselect', {'boxes':boxes});
			__refreshMailboxItemHandler();
			_layout.refreshLayout();
			return;
		}

		// Get email box list
		dgbLoading(true);
		DGB.email.getMailBoxList(_menuId, 
			function(mailboxInfo){
				dgbLoading(false);
				// list up the mail box
				// Remove current box
				var boxes = mailboxInfo.boxes.filter(function(box){
					return box.MAILBOX_NAME != _boxId;
				});
				$this.find('div.mailBoxSelect').empty()
					.mustache('tmpl-emailboxselect', {'boxes':boxes});
				__refreshMailboxItemHandler();
				_layout.refreshLayout();
			}, function(err){
				// Failure
				dgbLoading(false);
				if (__emailErrorHandler(err)) {
					DGB.Common.backPage();;
				}
			});
	};
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pagebeforeshow: function(evt, ui) {
			_refresh();
			DGB.Common.backPage();
		},
		movemails: function(evt, params) {
			_menuId = params.menuId;
			_boxId = params.boxId;
			_mailIds = params.mailIds;

			setTimeout(function () {
                DGB.Page.changePage('#GREM004');
			}, 400);
			
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GREM004');
})();
