(function() {
	var $this, _menuId, _layout;
	var _item = {}, _title, _content, _file;
	var TOKEN = '<BR>', TOKEN_MIN = 3, TOKEN_MAX = 6;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		_title = $this.find('#grst02Title');
		_content = $this.find('#grst02contents');
		_file = $this.find('#grst02AttachFiles');
	}

	function getContent(val) {
		var token = '';
		for(var i = 0; i < TOKEN_MAX; i++) {
			token += TOKEN;
		}

		for(var j = 0; j < (TOKEN_MAX - TOKEN_MIN + 1); j++) {
			var index = val.indexOf(token);
			if( index > -1 ) {
				return val.substr(index + token.length);
			}
			token = token.replace(TOKEN, '');
		}
		return val || '';
	}
	
	function setContents() {
		_title.text(_item.TITLE);
		_content.append("");
		_content.append(getContent(_item.CONTENT));

		var files = _item.ATTACH.split(',');
		var html = [];
		for(var i in files) {
			if( files[i] ) {
				html.push(
					"<li>" +
					"<a href='#' class='grst02DocList ui-link noTitle' data-file='" + files[i] + "'>" +
					"<div class='story'><b class='metadata'>" + files[i] + "</b><br></div>" +
					"<div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div>" +
					"</a><br>" +
					"</li>"
				);
			}
		}
		if( html.length > 0 ) {
			$this.find('.files').show();
			_file.append(html.join(''));
		} else {
			$this.find('.files').hide();
		}
		_layout.refreshLayout();

		_file.find('li a.grst02DocList').off('vclick').on('vclick',function() {
			var file = $(this).attr('data-file');
			callDaview({ url :  DGB.skyHost() + '/STORAGES/ATTACH/0/2904/' + _item.OID + '/' + file });
			return false;
		});
	}
	
	$(document).on({
		pageinit: _pageinit,
		pageshow: function() {
            DGB.Common.backPage();
			setContents();
		},
		pagehide: function() {
			_content.empty();
			_file.empty();
		},
		parentpage :function (evt, param) {
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRST002');
})();
