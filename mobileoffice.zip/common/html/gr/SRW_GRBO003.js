(function() {
	var $this = undefined;
	var _pageSize = 20;		//한페이지 갯수
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	var _iscrollEnd = false; //마지막 페이지
	var _pullDownFlag = ""; //down ,up 구분
	var listDelete = null; //freetalk 삭제
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;


		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
 				
		//로컬스토리지의 좋아요선택 초기화
		dgInit();

		listSearch = {
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},
				call : function(param1, param2) {
					
					dgbLoading(true);
					if (arguments.length != 2) {
						param1 = 1;			//START_NUM 기본값
						param2 = _pageSize;	//EDD_NUM	기본값
						/* 페이징 */
						$('#grbo03StNum').val(param1),
						$('#grbo03EdNum').val(param2);
						/*//페이징 */
					}
					
					var invocationData = {
							adapter : 'DBTransactionAdapter',
							procedure : 'TGR00003',
							parameters : [{CS_ID:_menuId,  START_NUM:param1, END_NUM:param2}]
					};
					
					callProcedure(invocationData, this.options);
				}
			};
		
		

		listDelete = {
				options : {
					onSuccess : deleteResult,
					onFailure : deleteError,
					invocationContext : {}
				},
				call : function(param) {
					
					dgbLoading(true);

					var invocationData = {
							adapter : 'DBTransactionAdapter',
							procedure : 'TGR00007',
							parameters : [{CS_ID:_menuId,  FREET_NM:param}]
					};
					
					callProcedure(invocationData, this.options);
				}
			};
		
		function deleteResult()
		{
			dgbLoading(false);
			_pullDownFlag = "down";
			
			_iscrollEnd = false;
			listSearch.call("");	
		}
		
		function deleteError() {
			dgbLoading(false);
		}
		
		function displayResult(data) {
			var item = data.invocationResult.resultSet;
			var html = "";	
			var listItems = [];
			var freet_cn = '';
			   for (var i=0; i<item.length; i++) {
				   freet_cn = item[i].FREET_CN;
				   freet_cn = freet_cn.replace(/</gi, '&lt;');
				   freet_cn = freet_cn.replace(/>/gi, '&gt;');
				   freet_cn = freet_cn.autoLink({ class: "grboFreeCntMsg" });

				html  ="<article class='freeTalk' id='"+item[i].FREET_NO+"' data-item='"+JSON.stringify(item[i])+"'>" +
			      "<div class='freeTtitle'> " +
				      "<img id='grboTimg' class='freeTimg' width='45' height='58' src="+DOWN_URL+"/download?parameters={'URL':'" + USER_PHOTO_URL + item[i].PHOTO_URL+"'}>" +
				      "<div class='freeTdetail'>" +
				         "<h3 class='voiceTitle'>" ;//+
							//나의 free톡 표시
							if(USER_INFO.ENOB == item[i].ENOB )
					    	{
					     		html += "<strong class='grboOrg_nm colordarkblue'>"+item[i].ORG_NM+"</strong>&nbsp;<strong class='grboName colordarkblue'>"+item[i].NAME+"</strong><strong class='grboEnob' style='display:none'>"+item[i].ENOB+"</strong>";
					    	}
					    	else 
					    	{
					    		html += "<strong class='grboOrg_nm'>"+item[i].ORG_NM+"</strong>&nbsp;<strong class='grboName'>"+item[i].NAME+"</strong><strong class='grboEnob' style='display:none'>"+item[i].ENOB+"</strong>";
					    	}
				           
				 html += "</h3>" +
				          "<div class='actions'>" +
				             "<span class='grboTime'>"+item[i].REG_DTTI+"</span>" +
				          "</div>" +
				      "</div>" +
				      "<div class='like_thumb_container'>" +
				         "<img  data-freeNo='"+item[i].FREET_NO+"' ";
				 		if(item[i].GD > 9 && item[i].GD < 20)
				     	//if(item[i].GD > 9 && item[i].GD < 50)
				    	{
				     		html += "class='img_like img_like_10'";
				    	}
				 		else if(item[i].GD > 19 && item[i].GD < 30)
//				    	else if(item[i].GD > 49 && item[i].GD < 100)
				    	{
				    		html += "class='img_like img_like_50'";
				    	}
				 		else if(item[i].GD > 29)
//				    	else if(item[i].GD > 99)
				    	{
				    		html += "class='img_like img_like_100'";
				    	}
				    	else
				    	{
				    		html += "class='img_like'";
				    	}		
				   html += ">" +
				         "<strong class='grboLikeNm'>"+item[i].GD+"</strong>" +
				      "</div>" +
				    "</div>" +
				 "<div class='freeTmsg'>" +
			    "<span class='grboFreeMsg'>"+freet_cn+"</span>" +
				
				 "</div>" +
				"</article>";
				   listItems[i] = html;
			}

			// 내려서 새로고침   
			if (_pullDownFlag == "down") {
				
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지

					$('#grbo03pullDown').css("display", "block");
					$('#grbo03pullUp').css("display", "none");
					_iscrollEnd = true;
					$(".freeTalkArea").html(listItems.join(''));

				} else {

					$('#grbo03pullDown').css("display", "block");
					$('#grbo03pullUp').css("display", "block");
					$('#grbo03StNum').val(parseInt($('#grbo03StNum').val()) + _pageSize);
					$('#grbo03EdNum').val(parseInt($('#grbo03EdNum').val()) + _pageSize);
					$(".freeTalkArea").html(listItems.join(''));
				}
			}   
			else if (_pullDownFlag == "up") {// 당겨서 더보기

				$(".freeTalkArea").append(listItems.join(''));

				/* 페이징 */
				if (item.length == _pageSize) {
					if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
						$('#grbo03pullUp').css("display", "none");
						_iscrollEnd = true;

					} else {
						$('#grbo03pullUp').css("display", "block");
						$('#grbo03StNum').val(parseInt($('#grbo03StNum').val()) + _pageSize);
						$('#grbo03EdNum').val(parseInt($('#grbo03EdNum').val()) + _pageSize);
					}
				} else {
					_iscrollEnd = true;
					$('#grbo03pullUp').css("display", "none");
				}
				/* //페이징 */

			} else {
				
				if (item.length >= _pageSize) {
					if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
						$('#grbo03pullDown').css("display", "block");
						$('#grbo03pullUp').css("display", "none");
						_iscrollEnd = true;
						$(".freeTalkArea").html(listItems.join(''));

					} else {
						$('#grbo03pullDown').css("display", "block");
						$('#grbo03pullUp').css("display", "block");
	
						$('#grbo03StNum').val(parseInt($('#grbo03StNum').val()) + _pageSize);
						$('#grbo03EdNum').val(parseInt($('#grbo03EdNum').val()) + _pageSize);
						$(".freeTalkArea").html(listItems.join(''));
					}
				} else {
					$('#grbo03pullDown').css("display", "block");
					$('#grbo03pullUp').css("display", "none");
					_iscrollEnd = true;
					$(".freeTalkArea").html(listItems.join(''));
				}
			}

			listItems = null;
            item = null;
            html = "";
			//수정삭제 팝업
			$(".freeTalk").off('taphold').on('taphold',function(){	
				var freet_no = $(this).attr("id") ; 
				var item = $(this).attr('data-item');
				var detailId ="GRBO004"; 
				var args={};
				
				if(USER_INFO.ENOB == $('#'+freet_no+' .grboEnob').text() )
					{
						if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
							var numberlist = [ "선택하세요", // this is the title
											"수정하기", "삭제하기" ];
											
							thelist = numberlist;			
							cordova.exec(

								function(listitem) {

									if (thelist[listitem] == numberlist[1]) {
						
										args.menuId = _menuId;
										args.item = item;
										// $("#"+detailId).trigger("parentpage",[args]);
                                        DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
							
										
										setTimeout(function () {
											DGB.Page.changePage('#'+detailId);
										},400);
									} else {

										listDelete.call(freet_no);
									}

								}, function(error) {
								}, "AlertList", "alertlist",thelist);
						} else if(WL.Client.getEnvironment() == WL.Environment.IPHONE){ // iphone
							// After device ready, create a local alias
							var actionSheet = window.plugins.actionSheet;

							// Complex
							actionSheet.create({
								title : '선택하세요',
								items : [ '수정하기', '삭제하기', '취소' ],
								destructiveButtonIndex : 1,
								cancelButtonIndex : 2
							}, function(buttonValue, buttonIndex) {
								switch (buttonIndex) {
                                    case 0:
                                        args.menuId = _menuId;
                                        args.item = item;

                                        // $("#"+detailId).trigger("parentpage",[args]);
                                        DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);

                                        setTimeout(function () {
                                            DGB.Page.changePage('#'+detailId);
                                        },400);

                                        break;
                                    case 1:
                                        listDelete.call(freet_no);
                                        break;
                                    default:
                                        break;
								}
							
							});
						} else {
                            showAlert('스마트폰에서만 가능한 기능입니다.수정하기, 삭제하기');
						}
					}
				return false;
			 });
			
			$('.img_like').off('vclick').on('vclick',function(){
				  var freeTid =  $(this).attr('data-freeNo');
				   
				  var likeNm = 0;
					//좋아요 본인글 체크
				    if(USER_INFO.ENOB == $('#'+freeTid+' .grboEnob').text() )
					{
						showAlert("본인의 글에는 '좋아요'를 할수 없습니다.");
						return;
					}

					//좋아요 중복체크
					if( gdPressCheck(freeTid) )
					{
						return;
					}
					function plusFreeTalkGood() {
						
						dgbLoading(true);
						var invocationData = {
								adapter : 'DBTransactionAdapter',
								procedure : 'TGR00006',
								parameters : [{FREET_NM : freeTid, CS_ID:_menuId}]
							};
							
							var options = {
								onSuccess : plusResult,
								onFailure : plusError,
								invocationContext : {}
							};
							
							callProcedure(invocationData, options);
					}
					
					function plusResult(data) {

						likeNm = $('#'+freeTid+' .grboLikeNm').text();	

						likeNm++;

						changeLikeImg(freeTid,likeNm);
						
						$('#'+freeTid+' .grboLikeNm').text(likeNm);	
						
						dgbLoading(false);
						
					}

					function plusError() {
						dgbLoading(false);
					}
					
					plusFreeTalkGood();
                    return false;
            });
			
			//url 링크
			$('.grboFreeCntMsg').off('vclick').on('vclick',function(e){
				var href = $(this).attr("href");
				WL.App.openURL(href, "_blank", "location=1");
				e.preventDefault();
				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}
		function displayError() {
            dgbLoading(false);
		}

	};

	function _pageshow() {
		//initMenu(true,false);
		dgbLoading(false);
		
		_layout.refreshLayout();
		
		$('#grbo03pullDown').css("display","none");
		$('#grbo03pullUp').css("display","none");
		
	//android back 버튼 동작
		DGB.Common.backMenu();
		
		listSearch.call("");
		_pullDownFlag = "";
	}
	//내려서 새로고침
	function pullDownAdd()
	{

		_pullDownFlag = "down";
		
		_iscrollEnd = false;
		listSearch.call("");	
	}
	
	//당겨서 추가
	function pullUpAdd()
	{

		var param1  = $('#grbo03StNum').val(),
		param2 = $('#grbo03EdNum').val();
	
		_pullDownFlag = "up";
		
		listSearch.call(param1, param2);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			$this.find('#grboInputbox').off('vclick').on('vclick', function() {
				DGB.Page.changePage('#GRBO004');
                return false;
			});
		},
		pageshow: _pageshow,
		pagebeforehide: function() {
			_iscrollEnd = false;
			$(".freeTalkArea").html('');
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh :function(){
			if( !_iscrollEnd )
			{
				pullUpAdd();
			}
			
		},
        pulldownrefresh :function(){
            pullDownAdd();
        }


	}, '#GRBO003');

	//종아요 선택수 초기화(localstorage)
	function dgInit() {   	
	 	     	 	  
		var gdArray = nmf.Store.get(FREET_GD_CHECK);
		if ( ! gdArray  ) {
			gdArray = [];  // 빈 배열
			
			nmf.Store.set(FREET_GD_CHECK, JSON.stringify(gdArray) );  // 배열을 문자열로
		}
		else {
			gdArray = JSON.parse( gdArray );  // 문자열을 배열로
		}     

	}
	
})();

//좋아요 버튼  10 20 30일때 이미지 교체 // 기존10 50 100
function changeLikeImg(freeTid,likeNm)
{
	if(likeNm > 9 && likeNm < 20)
	//if(likeNm > 9 && likeNm < 50)
	{
		$('#'+freeTid+' .img_like').css("background-position","-137px -206px");
	}
	else if(likeNm > 19 && likeNm < 30)
	//else if(likeNm > 49 && likeNm < 100)
	{
		$('#'+freeTid+' .img_like').css("background-position","-71px -206px");
	}
	else if(likeNm > 29)
	//else if(likeNm > 99)
	{
		$('#'+freeTid+' .img_like').css("background-position","-104px -206px");
	}
	else
	{
		$('#'+freeTid+' .img_like').css("background-position","-38px -206px");
	}
}

//좋아요 버튼 중복체크(localstorage)
function gdPressCheck(freeTid) {

	var gdArray = nmf.Store.get(FREET_GD_CHECK);
	if ( ! gdArray  ) {
		gdArray = [];  // 빈 배열
		
		nmf.Store.set(FREET_GD_CHECK, JSON.stringify(gdArray)); // 배열을 문자열로
	}
	else {
		gdArray = JSON.parse( gdArray );  // 문자열을 배열로
	}                        
	
	//등록된 좋아요인경우
	if ((gdArray).toString().indexOf(freeTid) != -1) {
		showAlert( Messages.msg011);
		return true;
	}
	//좋아요100번 이상한경우 100번전꺼부터 삭제.
	if(gdArray.length > 100)
	{
		gdArray.shift(); //배열의첫번째요소 삭제
	}	
	gdArray.push( freeTid );  // 새로운 키를 배열에 추가
	nmf.Store.set(FREET_GD_CHECK, JSON.stringify(gdArray));
	return false;
}