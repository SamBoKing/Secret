(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;


		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$this.find('#grar01Btn').off('vclick').on('vclick', function() {
			grar01search();
		});
		
		$this.find('#grar01Search').on('keypress',function(e){

			if(e.keyCode ==13)
			{
				$this.find('#grar01Btn').focus();
				grar01search();
				return false;
			}
		});
		
		
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#grar01StNum').val(param2), $('#grar01EdNum').val(param3);
						/* //페이징 */
					}

					invocationData = {
						adapter : 'SocketTransactionAdapter',
						procedure : 'TGR00005',
						parameters : [ {
							CS_ID : _menuId,
							TITLE : param1,
							START_NUM : param2,
							END_NUM : param3,
							TELLER_NUM : USER_INFO.ENOB
						} ]
					};
					callProcedure(invocationData, this.options);
				}
			};

		
		function grar01search(){
			var param = $('#grar01Search').val();
			if (param == "") {
				showAlert(Messages.msg021);
				return;
			}
			
			_layout.resetLayout(); //스크롤위치 초기화
			_iscrollEnd = false;
			$("#grar01Noresult").addClass("displayNone");
			$("#welfareListview").empty();
			$('#grar01pullUp').css("display", "none");
			
			//키보드 내리기
			DGB.Common.hideKeyboard();

			setTimeout(function () { listSearch.call(param); }, 300);
			return false;
		}
		
		
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet;
			if(item.length === 0) {
				$("#grar01Noresult").removeClass("displayNone");
				$("#grar01InputText").text($('#grar01Search').val());
			
			}
			
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") break;
				html  = "<li>"+
							"<a href='#' class='grar001List downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
								"<h3 class='paddingright15'>"+item[i].TITLE+"</h3>";
								if(item[i].ZZZUSER00 ==""){
				html +=				"<p><strong>&nbsp;</strong></p>";
								}
								else
								{
				html +=				"<p class='paddingright15'><strong style='color:darkblue;'>"+item[i].ZZZUSER00+ "</strong></p>";
								}
				html +=			"</a>"+
						"</li>";
				listItems[i] = html;
			}
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#grar01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#grar01pullUp').css("display", "block");
					$('#grar01StNum').val(
							parseInt($('#grar01StNum').val()) + _pageSize);
					$('#grar01EdNum').val(
							parseInt($('#grar01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#grar01pullUp').css("display", "none");
			}
			/* //페이징 */
			$("#welfareListview").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#welfareListview").listview( "refresh" );
			$("#welfareListview").trigger("updatelayout");
//			$('#welfareListview').iscrollview('refresh');
			
			dgbLoading(false);
			
			
			//$this.find('.grar001List').off('vclick').on('vclick', function() {
			
			$('#welfareListview').find('li a.grar001List').off('vclick').on('vclick',function(){
				
				var item = $(this).attr('data-item');
				var detailId ="GRAR002"; 
				var args={};
				args.menuId = _menuId;
				args.item = item;
				
				// $("#"+detailId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				return false;
			});
			
	
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
			
		}

		function displayError() {
			dgbLoading(false);
		}
	};
	
	function _pageshow() {
		_layout.refreshLayout(400);
		
	
		$('#grar01pullUp').css("display", "none");
		listSearch.call("");

		DGB.Common.backMenu();
		
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#grar01Search').val(),
			param2 = $('#grar01StNum').val(),
			param3 = $('#grar01EdNum').val();

		listSearch.call(param1, param2, param3);
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow:_pageshow,
		pagebeforehide: function(evt, ui) {
			//화면 초기화
			$("#welfareListview").empty();
			$('#grar01Search').val("");
			$("#grar01Noresult").addClass("displayNone");
			$('#grar01pullUp').css("display", "none");
			_iscrollEnd = false;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#grar01Btn").focus();
            }
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd )
			{
				pullUpAdd();
			}
		}
	}, '#GRAR001');
})();
