(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight);
		
		//내가본 DGB프로매너
		$this.find('li a.grpm01Loc').off('vclick').on('vclick',function(){
			locDetailview = true;
			var detailId ="GRPM002"; 
			setTimeout(function () {
				DGB.Page.changePage('#'+detailId);
			},400);
			return false;
		});
		
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#grpm01StNum').val(param2), $('#grpm01EdNum').val(param3);
						/* //페이징 */
					}

					var invocationData = {
						adapter : 'SocketTransactionAdapter',
						procedure : 'TGR00009',
						parameters : [ {
							CS_ID : _menuId,
							TITLE : param1,
							START_NUM : param2,
							END_NUM : param3,
							CABINET_ID : "2890",
							TELLER_NUM : USER_INFO.ENOB
						} ]
					};

					callProcedure(invocationData, this.options);
				}
			};
				
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet;
			
			if(item.length === 0)
			{
				$("#grpm01Noresult").removeClass("displayNone");
			}
			
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") break;
				html  = "<li>"+
						"<a href='#' class='grpm001List downHeight' data-item='"+item[i].ATTACH+"'  data-oid='"+item[i].OID+"' >"+
						"<h3>"+item[i].TITLE+"</h3>"+
						"<p><strong style='color:darkblue;'>"+item[i].UPDATE_DATE+"</strong></p>"+
						"</a>"+
						"</li>";
				listItems[i] = html;
			}
			
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#grpm01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#grpm01pullUp').css("display", "block");
					$('#grpm01StNum').val(
							parseInt($('#grpm01StNum').val()) + _pageSize);
					$('#grpm01EdNum').val(
							parseInt($('#grpm01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#grpm01pullUp').css("display", "none");
			}
			/* //페이징 */
					
			$("#grpm01Listview").append(listItems.join(''));
			//$("#grpm01Listview").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#grpm01Listview").listview( "refresh" );
			$("#grpm01Listview").trigger("updatelayout");
			
			
			$('#grpm01Listview').find('li a.grpm001List').off('vclick').on('vclick', function() {
				var item = $(this).attr('data-item');
				var title = $(this).find('h3').text();
                var oid = $(this).attr('data-oid');
                var items = item.split(',');
                switch( items.length ) {
                    case 0:
                        showAlert(Messages.msg02L);
                        break;
                    case 1:
                        if( items[0].length == 0 ) {
                            showAlert(Messages.msg02L);
                        } else {
                            onFileDownload(oid, items[0]);
                        }
                        break;
                    default:
                        DGB.Common.selectList(title, items,
                            function(index) {
                                // 파일이 여러개 일때 파일명을 실제 파일명으로 등록해야함
                                onFileDownload(oid, items[index]);
                            },
                            function(err) {
                                DGB.Log.e('[SRW_GRPM001] ====>> Error : ' + err);
                            }
                        )
                        break;
                }
				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}

        function onFileDownload(oid, name) {
            // Test
            // name = 'POST.gif';
            // var serverPath = '/KP4Resources/Images/DGB/KWindows/Post/Kor/' + encodeURI(name);
            var serverPath = '/Storages/Attach/0/2890/' + oid + '/' + encodeURI(name);
            var isImage = DGB.isImage(name);
            var downPath = DGB.fileRoot() + "promanner/";
            var link = DGB.skyHost() + serverPath;
            var url = DGB.homeDown() + "/download?parameters={'URL':'" + link + "','SAVE': '" + (isImage ? "true" : "false") + "'}";
            var params = {
                url : url,
                name : name,
                // 다른곳에서 Title 만 쓰기 때문에 여기서 가공을 해야함.
                title : name.replace(DGB.getFileExt(name), ''),   // 실제파일로 등록
                downPath : downPath,
                attach : DGB.homeAttach() + serverPath
            };
            downloadFile(params);
        }

		function displayError() {
			dgbLoading(false);
            showAlert(Messages.err001);
		}
	};
	
	function _pageshow() {
		
		if(locDetailview == false) {
            //화면 초기화
            $("#grpm01Listview").empty();
			$("#grpm01Noresult").addClass("displayNone");
			$('#grpm01pullUp').css("display", "none");
			_iscrollEnd = false;
			
			listSearch.call("");
		}
		locDetailview = false;
		
		_layout.refreshLayout();
	
		//android back 버튼 동작
		DGB.Common.backMenu();
		
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = "",//$('#grpm01input').val(),
		    param2 = $('#grpm01StNum').val(),
		    param3 = $('#grpm01EdNum').val();

		listSearch.call(param1, param2, param3);
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
        pagehide: function(){
        },
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#GRPM001');
})();
