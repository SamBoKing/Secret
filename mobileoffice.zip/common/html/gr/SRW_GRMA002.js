(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, _headerHeight);
		
	};

    function search(param1, param2, param3) {
        dgbLoading(true);
        if (arguments.length != 3 ) {
            param2 = 1; // START_NUM 기본값
            param3 = _pageSize; // EDD_NUM 기본값
            $('#grma02StNum').val(param2);
            $('#grma02EdNum').val(param3);
        }

        var opts = {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        };
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TGR00011',
            parameters : [ {
                CS_ID : _menuId,
                TITLE : param1,
                START_NUM : param2,
                END_NUM : param3,
                CABINET_ID : "2892",
                ZZZUSER00 :_item.CMN_CD,
                TELLER_NUM : USER_INFO.ENOB
            } ]
        };

        callProcedure(inv, opts);
    }

    function displayResult(data) {
        if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
            dgbLoading(false);
            eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
            return false;
        }

        var item = data.invocationResult.resultSet;
        if(item.length === 0) {
            $("#grma02Noresult").removeClass("displayNone");
            $("#grma02InputText").text(_item.CMN_CD);
        }

        var html = "";
        var listItems = [];
        for (var i=0; i<item.length; i++) {
        	
            if(item[i].TITLE == "") break;
            var fDate = (item[i].UPDATE_DATE.substring(0,19)).replace(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/,"$1-$2-$3 $4:$5:$6");
            
            html  = "<li>"+
                "<a href='#' class='grma002List downHeight' data-item='" + JSON.stringify(item[i]) + "'>" +
                "<h3>"+item[i].TITLE+"</h3>"+
                "<p><strong style='color:darkblue;'>"+fDate+"</strong></p>"+
                "</a>"+
                "</li>";
            listItems[i] = html;
        }
        /* 페이징 */
        if (item.length == _pageSize) {
            if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
                $('#grma02pullUp').css("display", "none");
                _iscrollEnd = true;

            } else {
                $('#grma02pullUp').css("display", "block");
                $('#grma02StNum').val(
                    parseInt($('#grma02StNum').val()) + _pageSize);
                $('#grma02EdNum').val(
                    parseInt($('#grma02EdNum').val()) + _pageSize);
            }
        } else {
            _iscrollEnd = true;
            $('#grma02pullUp').css("display", "none");
        }
        /* //페이징 */

        $("#grma02Listview").append(listItems.join(''));
        listItems = null;
        item = null;
        html = "";
        $("#grma02Listview").listview( "refresh" );
        $("#grma02Listview").trigger("updatelayout");

        //리스트클릭 이벤트
        $('#grma02Listview').find('li a.grma002List').off('vclick').on('vclick',function(){
            var item = JSON.parse($(this).attr('data-item'));
            var files = item.ATTACH.split(',');
            switch( files.length ) {
                case 0:
                    showAlert(Messages.msg02L);
                    break;
                case 1:
                    if( files[0].length == 0 ) {
                        showAlert(Messages.msg02L);
                    } else {
                        onFileopen(item.OID, item.ATTACH);
                    }
                    break;
                default:
                    DGB.Common.selectList(item.TITLE, files,
                        function(index) {
                            onFileopen(item.OID, files[index]);
                        },
                        function(err) {
                            DGB.Log.e('[SRW_GRMA002] ====>> Error : ' + err);
                        }
                    )
                    break;
            }
            return false;
        });

        _layout.refreshLayout(function(){
            dgbLoading(false);
        }, 500);
    }

    function displayError() {
        dgbLoading(false);
        showAlert(Messages.err001);
    }

    function onFileDownload(oid, name) {
        // Test
        // name = 'POST.gif';
        // var serverPath = '/KP4Resources/Images/DGB/KWindows/Post/Kor/' + encodeURI(name);
        var serverPath = '/STORAGES/ATTACH/0/2892/' + oid + '/' + encodeURI(name);
        var downPath = DGB.fileRoot() + "marketing/";
        var link = DGB.skyHost() + serverPath;
        var url = DGB.homeDown() + "/download?parameters={'URL':'" + link + "'}";
        var params = {
            url : url,
            name : name,
            // 다른곳에서 Title 만 쓰기 때문에 여기서 가공을 해야함.
            title : name.replace(DGB.getFileExt(name), ''),   // 실제파일로 등록
            downPath : downPath,
            attach : DGB.homeAttach() + serverPath
        };
        downloadFile(params);
    }

    function onFileopen(oid, name) {

        if(DGB.isImage(name)) {
            showAlert(Messages.msg400);
        }else if(DGB.isSound(name) || DGB.isMovie(name)){
            if(DGB.isAndroid()){
                if(DGB.isMovieAVI(name)){
                    showAlert(Messages.msg401);
                }else{
                    onFileDownload(oid, name);
                }
            }else{
                if(DGB.isMovieAVI(name) || DGB.isMovieWMV(name)){
                    showAlert(Messages.msg401);
               }else{
                    onFileDownload(oid, name);
                }
            }
        }
        else{
            var dataView = {
                url : DGB.skyHost() + "/STORAGES/ATTACH/0/2892/" + oid + "/" + name
            }
            callDaview(dataView);
        }
    }

	function _pageshow() {
        //android back 버튼 동작
        //DGB.Common.backMenu();
		DGB.Common.backPage();
		if(locDetailview == false) {
			//화면 초기화
			$("#grma02Listview").empty();
			$("#grma02Noresult").addClass("displayNone");
			$('#grma02pullUp').css("display", "none");
			_iscrollEnd = false;
            search('');
		}
		locDetailview = false;
		_layout.refreshLayout();
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = "",
		    param2 = $('#grma02StNum').val(),
		    param3 = $('#grma02EdNum').val();
		search(param1, param2, param3);
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagehide: function(evt, ui) {
		},
		parentpage :function (evt, param) {
			_item = JSON.parse(param.item);
			_menuId = param.menuId;
			$('#grma002_title').text("마케팅자료실("+_item.CD_EPL+")");
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
        pulluprefresh : function() {
            if( !_iscrollEnd ) {
                pullUpAdd();
            }
        }
	}, '#GRMA002');

})();
