(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;

		//_layout = new DGB.layout($this, _headerHeight);
	};

	function _pageshow() {
		
		//프리톡 수정인 경우
		if(_item.FREET_CN != undefined)
		{
			var freetTxt = _item.FREET_CN;
			freetTxt = freetTxt.replace(/<br>/gi,"\n");
			$('textarea#grbo04TextArea').val(freetTxt);
		}			
		
		//_layout.refreshLayout();

		//입력 카운터 display-보류
		//$('#grbo04TextArea').on("vclick, keypress, keyup", $.MessageSlice);
		
		//android back 버튼 동작
		DGB.Common.backPage();

	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pagebeforeshow: function(evt, ui) {
			$this.find('#grbo04SendBtn').off('vclick').on('vclick', function() {			

				var grboOrg_cd;		// 부서
				var grboSabun;		// 사번
				var grboFreeMsg = $('#grbo04TextArea').val();	//메인텍스트
				var freetMaxLan = 140; //byte로 계산 한글 70자, 영문 140자
				//---------로그인한 user----------
				grboOrg_cd = USER_INFO.ORG_CD;// USER_INFO.ORG_NM;
				grboSabun = USER_INFO.ENOB;
				//-------------------------------
					
				if (grboFreeMsg == "") {
					showAlert("Free톡 내용을 입력하세요");
					return;
				}
				
				//2013.11.08 '를 "로 변환. '이 있으면 에러발생함.
				grboFreeMsg = grboFreeMsg.replace( /(\')/g,'\"');
				
				var srccount = getMsgLength(grboFreeMsg);
				if( srccount > freetMaxLan){
					showAlert("한글 70자,영문 140" +Messages.msg116);
					return;
				}

				function addingFreeTalk() {

					dgbLoading(true);
					var invocationData = {
							adapter : 'DBTransactionAdapter',
							procedure : 'TGR00004',
							parameters : [{SABUN : grboSabun, ORG_CD: grboOrg_cd, FREET_TXT: grboFreeMsg, FREET_NUM: _item.FREET_NO, CS_ID:_menuId}]
						};
						
						var options = {
							onSuccess : addingResult,
							onFailure : addingError,
							invocationContext : {}
						};
						
						callProcedure(invocationData, options);
				}
				
				function addingResult(data) {
					dgbLoading(false);
					DGB.Page.changePage('#GRBO003');

				}

				function addingError() {
				}

				//키보드 내리기
				if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
					AndroidNative.hideKeyboard();	
				}
				
				setTimeout(function () {
					addingFreeTalk();
				}, 300);
				
			return false;

			});
			
		},
		pageshow: _pageshow,
		pagehide: function(evt, ui) {
			//초기화
			_item={};
			$('#grbo04TextArea').val("");
			$('#grbo04TextArea').css("height","100px");
		},
		parentpage :function (evt, param) {
			_menuId = param.menuId;
			_item = JSON.parse(param.item);
		},
		orientationchange : function(evt) {
            return false;
		}

	}, '#GRBO004');

	//입력 카운터 display-보류
	$.MessageSlice = function(){
		var k, tmp;
		var srccount = 0;
		var msgObj = $('#grbo04TextArea');
		var msgLenObj = $("#msgLen");

		var limitlen = 140;
		
		if(msgObj.text().length == 0)
		{
			msgLenObj.text(140); 
		}
		
		str = new String(msgObj.val());
		srccount = getMsgLength(str);

		if(srccount > limitlen) {
	
			tmp = getMsgPosition(str,limitlen);
			count = tmp.split("^")[0];
			k = parseInt(tmp.split("^")[1]);
			msgObj.val(str.substring(0,k));
			srccount = getMsgLength(msgObj.val());
		}
		
		msgLenObj.text(limitlen-srccount); 
	};
})();
