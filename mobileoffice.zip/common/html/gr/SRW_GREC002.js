
var a;
(function() {
	var $this;
	var _item = {};
	var _menuId;
	var _layout;
	var _title;
	var _contents;
	var _attach_files;
	var _attach_text;
	var _attach_list;

	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		_title = $this.find('#title');
		_contents = $this.find('#contents');
		_attach_files = $this.find('#attach_files');
		_attach_text = $this.find('#attach_text');
		_attach_list = $this.find('#attachlist');
	};
	
	function setContents() {
		_title.text(_item.TITLE);

		var data = htmlToData(_item.CONTENT);
		_contents.html(data.content);

		_attach_list.empty();
		var listItems = [];
		for (var i = 0; i < _item.ATTACH.length; i++) {
			listItems[i] = "<li data-icon='false'>"+
				"<a href='#' id='attach_link' class='ui-link noTitle' data-num='" + i + "'>" +
				"<h3 style='margin: .2em .10em 0 0;color:#0061FF'  class='metadata' id='attach_text'>" +
				"<div class='icon_attach' style='margin-top: 2px; float: left'></div>&nbsp;"+ _item.ATTACH[i] +"</h3>" +
				"</a></li>"
		}
		_attach_list.append(listItems.join(''));
		_attach_list.listview( "refresh" );
		_attach_list.trigger("updatelayout");
		_attach_list.find('li a').off('vclick').on('vclick',function(e){
			e.preventDefault(); // href이벤트 막기
			var num = $(this).attr('data-num');
			var path = DGB.fileRoot() + "economicnews/";
			var url = DOWN_URL+"/download?encoding=true&parameters={'URL':'" + (_item.URL[num] || '')  + "'}";
			var file = { url : url, title : _item.ATTACH[num], downPath : path };
			
			showConfirm(function(btn) {
				if ( btn == '1' ) {
					downloadFile(file);
				}
			}, Messages.msg077);

			return false;
		});

		_layout.refreshLayout();
	}

	function htmlToData(html) {
		var board = $('<div></div>').append(html);
		var temp = board.text().split("\n");
		var values = [];
		for(var i in temp) {
			if( temp[i] ) {
				var value = temp[i].trim();
				if( value ) {
					values.push(value);
				}
			}
		}

		var contents = [];
		for(var i in values) {
			if( i >= 24 ) {
				contents.push(values[i]);
			}
		}

		var options = [];
		var express = board.find("#BBSEXPRESS").prop("checked");
		var announce = board.find("#BBSANNOUNCE").prop("checked");
		if( express ) options.push("긴급");
		if( announce ) options.push("공지");
		return {
			num : values[1],
			search : values[3],
			yes : values[5],
			no : values[7],
			reply : values[9],
			auth : values[11],
			title : values[13],
			sender : values[15],
			board : values[17],
			start_date : values[19],
			option : options.join("/"),
			end_date : values[23],
			content : contents.join("<br/>")
		}
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
			DGB.Common.backPage();
			setContents();
		},
		pagehide: function() {
			_contents.empty();
		},
		parentpage :function (evt, param) {
			_item = param.item;
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GREC002');
})();
