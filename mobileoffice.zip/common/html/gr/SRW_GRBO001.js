(function() {
	var $this = undefined;
	var listSearch = null;
	var _pageSize = 20; // 한페이지 갯수
	var _menuId = undefined;	
	var _layout = undefined;

	var _iscrollEnd = false; //마지막 페이지
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;

	var pageinit = function(instance) {


		$this = instance;
		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$this.find('#grbo01Btn').off('vclick').on('vclick', function() {
			grbo01search();
		});

		$this.find('#grbo01Search').on('keypress',function(e){
			if(e.keyCode ==13)
			{
				$this.find('#grbo01Btn').focus();
				grbo01search();
				return false;
			}
		});
		
		listSearch = {
			options : {
				onSuccess : displayResult,
				onFailure : displayError,
				invocationContext : {}
			},
			call : function(param1, param2, param3) {
				dgbLoading(true);
				if (arguments.length != 3) {
					param2 = 1; // START_NUM 기본값
					param3 = _pageSize; // EDD_NUM 기본값
					/* 페이징 */
					$('#grbo01StNum').val(param2), $('#grbo01EdNum').val(param3);
					/* //페이징 */
				}

				invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : 'TGR00001',
					parameters : [ {
						CS_ID:_menuId,
						TITLE : param1,
						START_NUM : param2,
						END_NUM : param3
					} ]
				};

				callProcedure(invocationData, this.options);
			}
		};

		function grbo01search(){

			var param = $('#grbo01Search').val();

			if (param == "") {
				showAlert("검색할 내용을 입력하세요");
				return;
			}
			
			_layout.resetLayout(); //스크롤위치 초기화
			_iscrollEnd = false;
			$("#grbo01Noresult").addClass("displayNone");
			$("#grbo01Listview").empty();
			$('#grbo01pullUp').css("display", "none");
			
			//키보드 내리기
			if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
				AndroidNative.hideKeyboard();	
			}
			
			setTimeout(function () {
				listSearch.call(param);
			}, 300);
			
			return false;
		}
		
		function displayResult(data) {
			var item = data.invocationResult.resultSet;
			if (item.length === 0) {
				$("#grbo01Noresult").removeClass("displayNone");
				$("#grbo01InputText").text($('#grbo01Search').val());
			}

			var html = "";
			var listItems = [];
			for ( var i = 0; i < item.length; i++) {
				
				html  = "<li>" 
						+ "<a href='#' class='grbo001List downHeight' data-item='"+ JSON.stringify(item[i]) + "' >"						
							+ "<h3>"+ item[i].TIT + "</h3>" 
							+ "<p><strong style='color:darkblue;'>"+ item[i].REG_DTTI + "</strong></p>"
						+ "</a>" 
						+ "</li>";
				listItems[i] = html;
			}

			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#grbo01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#grbo01pullUp').css("display", "block");
					$('#grbo01StNum').val(
							parseInt($('#grbo01StNum').val()) + _pageSize);
					$('#grbo01EdNum').val(
							parseInt($('#grbo01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#grbo01pullUp').css("display", "none");
			}
			/* //페이징 */

			$("#grbo01Listview").append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#grbo01Listview").listview("refresh");
			$("#grbo01Listview").trigger("updatelayout");

			// 리스트클릭 이벤트
			$('#grbo01Listview').find('li a.grbo001List').off('vclick').on('vclick',
					function() {

						var item = $(this).attr('data-item');
						var detailId = "GRBO002";
						var args = {};
						args.menuId = _menuId;
						args.item = item;

						// $("#" + detailId).trigger("parentpage", [args]);
                        DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
						
						setTimeout(function () {
							DGB.Page.changePage('#'+detailId);
						},400);
						
						return false;
			});
			
		
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);

		}

		function displayError() {
			dgbLoading(false);
		}

	};

	function _pageshow() {
		_layout.refreshLayout();
		
		$('#grbo01pullUp').css("display", "none");
		listSearch.call('');

		DGB.Common.backMenu();
	}

	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#grbo01Search').val(), param2 = $('#grbo01StNum').val(), param3 = $(
				'#grbo01EdNum').val();

		listSearch.call(param1, param2, param3);
	}

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow : _pageshow,
		pagebeforehide : function(evt, ui) {

			// 화면 초기화
			$("#grbo01Listview").empty();
			$('#grbo01Search').val("");
			$("#grbo01Noresult").addClass("displayNone");
			$('#grbo01pullUp').css("display", "none");
			_iscrollEnd = false;
		},
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#grbo01Btn").focus();
            }
            return false;
		}
		,
		pulluprefresh : function() {
			if( !_iscrollEnd )
			{
				pullUpAdd();
			}
			
			
		}

	}, '#GRBO001');
})();
