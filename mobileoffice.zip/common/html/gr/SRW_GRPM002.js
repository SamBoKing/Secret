
(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var _grpm02Root = "" //주요경제기사 폴더 경로
	var _fileSystem = null; 
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight);
		
		//파일 삭제 버튼
		$this.find('#grpm02FileEdit').on('vclick', function(){
			$this.find('div.prpmFile-list').addClass('editMode');
			$("#grpm02delDiv").removeClass("displayNone");
			$("#grpm02noDiv").removeClass("displayNone");
		});
		
		//삭제
		$this.find('#grpm02DelBtn').off('vclick').on('vclick', function(){
			
			var ids = __selectedFiles();
			if (ids.length == 0) {
				showAlert(Messages.msg071);
				return false;
			}
			
			showConfirm(function(button){
				if (button == '1') {
					// Delete the selected files
					dgbLoading(true);
					
					for(var i =0; i < ids.length; i++){
						__removeFiles(ids[i]);
					}
					
					getfileList();
					
					// Clear checked
					$this.find('.prpmFile-list a').removeClass('oncheck');
					
					$this.find('div.prpmFile-list').removeClass('editMode');

					$("#grpm02delDiv").addClass("displayNone");
					$("#grpm02noDiv").addClass("displayNone");
				
					showAlert(Messages.msg02G);
				}
			}, Messages.msg070);
			return false;
		
		});
		//삭제취소버튼
		$this.find('#grpm02NoBtn').off('vclick').on('vclick', function(){
			
			setTimeout(function () {
				// Clear checked
				$this.find('.prpmFile-list a').removeClass('oncheck');
				
				$this.find('div.prpmFile-list').removeClass('editMode');

				$("#grpm02delDiv").addClass("displayNone");
				$("#grpm02noDiv").addClass("displayNone");
			},300);
			

		});
	};
	
	//체크박스 선태된 파일
	var __selectedFiles = function() {
		var ids = [];
		$this.find('.prpmFile-list a.oncheck').each(function(){
			var $li = $(this);
			ids.push($li.find('h3').attr('data-fileName'));
		});
		
		return ids;
	};
	
	var __removeFiles = function(name){
		var filepath = _grpm02Root+name;
		
		_fileSystem.root.getFile(filepath, {create:false},
				function(file){ // success find file
					file.remove(function(){
					    dgbLoading(false);
					}, function(error){
						dgbLoading(false);
						showAlert(Messages.msg02C);
					});
				},
				function(error){ // error find file
					dgbLoading(false);
				}
			);
	};
	
	function getfileList(){
        if( DGB.isDebug() ) {
            DGB.Log.w("[DGB.Debug] ====>> File List Success!");
            return;
        }
		
		var sPath = DGB.fileRoot() + "promanner/";
		var filepath = "";

		// Get File System
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs){
            filepath = fs.root.fullPath + "/" +sPath;
			_fileSystem = fs;
			_grpm02Root = sPath;
		
			fs.root.getDirectory(sPath, {create: true},function(directory){
				var directoryReader = directory.createReader();
				directoryReader.readEntries(function(entries){
					
					$("#grpm02Noresult").addClass("displayNone");
						
					var html = "";
					var listItems = [];
					for (var i=0; i<entries.length; i++) {
						html  = "<li>"+
									"<a href='' data-href='"+filepath +entries[i].name+"' target='_blank' class='downHeight'>"+
										"<h3 data-fileName='"+entries[i].name+"'>"+entries[i].name+"</h3>"+
										//"<p><strong>"+myPMList[i].date+"</strong></p>"+
									"</a>"+
								"</li>";
						listItems[i] = html;
					}
						
					$("#grpm02Listview").html(listItems.join(''));
					listItems = null;
                    html = "";
					$("#grpm02Listview").listview( "refresh" );
					$("#grpm02Listview").trigger("updatelayout");
			
					_layout.refreshLayout(100);
						
					$('#grpm02Listview').find('li a').off('vclick').on("vclick", function() {
						var $grpm02File = $(this);
							
						// Check it is under the edit mode.
						if ($this.find('div.prpmFile-list').hasClass('editMode')) {
							$grpm02File.toggleClass('oncheck');
							return false;
						}
							
						var url = $(this).attr("data-href");
						showLink(url);
                        return false;
					});
						
					if(entries.length == 0){
						$("#grpm02Noresult").removeClass("displayNone");
						_layout.refreshLayout(1000);
					}
					
				},function(err) {
                    DGB.Log.e('[SRW_GRPM002] ====>> Error : ' + err);
				});
			});

		}, function(evt){
		});
	}
	
	function _pageshow() {
		// Get File System
		getfileList();
		
		//android back 버튼 동작
		DGB.Common.backPage();
		
	}

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagehide: function(evt, ui) {
			// Clear checked
			$this.find('.prpmFile-list a').removeClass('oncheck');
			$this.find('div.prpmFile-list').removeClass('editMode');

			$("#grpm02delDiv").addClass("displayNone");
			$("#grpm02noDiv").addClass("displayNone");
		},
		parentpage :function(evt, param) {
            _menuId = param.menuId;

		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRPM002');
})();
