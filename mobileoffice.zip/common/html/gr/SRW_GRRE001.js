(function() {
    var _this, _layout, _menuId;
    var title, description, rd_name, rd_noname;

    var _pageinit = function() {
        _this = $(this);
        _layout = new DGB.layout(_this, COMMON_PAGE_HEADER_HEIGHT);
        initControl();
    };

    var initControl = function() {
        title = _this.find('#title');
        description = _this.find('#description');
        rd_name = _this.find('#rd_name');
        rd_noname = _this.find('#rd_Noname');

        _this.find('#btn_send').off('vclick').on('vclick', onClickSend);
        _this.find('#radioField').on('change', onClickRadio);

        // 기본값 셋팅
        setNameRadio(false);
    };

    var _pageshow = function() {
        DGB.Common.backMenu();
        title.val('');
        description.height('150px').val('');
        if( !DGB.Auth.Sso.isSso ) {
            setNameRadio(false);
        }
        _layout.refreshLayout();
    };

    var setNameRadio = function(is_name) {
        rd_name.prop("checked", is_name).checkboxradio("refresh");
        rd_noname.prop("checked", !is_name).checkboxradio("refresh");
    };

    var onClickSend = function() {
        window.open(Messages.url036, "_system");

        /*
        DGB.Common.hideKeyboard();
        title.blur();
        description.blur();

        if( !valueCheck() )
            return false;

        var type = (_this.find('input:radio[name=radio-choice]:checked').val() == '1');
        showConfirm(function(btn){
            if (btn == '1') {
                dgbLoading(true);
                // 익명 : true, 실명 : false
                sendMail(title.val(), description.val(), type ? 'false' : 'true');
            }
        }, type ? Messages.msg608 : Messages.msg609);
        */
        return false;
    };

    var valueCheck = function() {
        if( !title.val() ){
             showAlert(Messages.msg603);
             return false;
        }
        if( !description.val() ){
            showAlert(Messages.msg610);
            return false;
        }
        return true;
    };

    var onClickRadio = function(event) {
        DGB.Common.hideKeyboard();
        if( !DGB.Auth.Sso.isSso && event.target.id == 'rd_name') {
            showConfirm(function(btn){
                if (btn == '1') {
                    DGB.Menu.trigger('leftPanel','updateAuth',{ menuId: _menuId, auth : DGB.Auth.Level.Pass });
                } else {
                    setNameRadio(false);
                }
            }, Messages.msg607);
        }
        return false;
    };

    var sendMail = function(subject, body, isSecret){
        DGB.email.sendSecretMail(_menuId, subject, body, isSecret,
            function(){
                // Success
                dgbLoading(false);
                title.val('');
                description.val('');
                showAlert(Messages.msg02G);
            },
            function(err){
                dgbLoading(false);
                emailErrorHandler(err);
            });
    };

    var emailErrorHandler = function(err) {
        // show error
        var errmsg = getErrorInfo(err.errorCode);
        if(err.errorCode == 'MOSE0101') {
            showAlert(Messages.msg020+':'+errmsg);
            DGB.menuctrl.triggerMenuItem('CO0102');
        } else if(err.errorCode == 'MOSE0105') {
            showAlert(Messages.msg024+':'+errmsg);
            DGB.menuctrl.triggerMenuItem('CO0102');
        } else {
            showAlert(Messages.msg104);
            DGB.menuctrl.triggerMenuItem('CO0102');
            return true;
        }
    };

	$(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        parentpage : function(evt, param) {
            _menuId = param.menuId;
        },
        selectmenu : function(evt, param) {
            _menuId = param.menuId;
        },
		orientationchange : function() {
            _layout.refreshLayout();
            return false;
		}
	}, '#GRRE001');
})();