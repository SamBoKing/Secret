(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _menuItem = undefined;
	var _boxId = undefined;
	var _layout = undefined;
	var _needMenuUpdate = false;
	
	// List control context
	var _context = {
		lastMailId : -1,
		keyword : undefined,
		refresh : false
	};
	
	var searchbtnFlag = false;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;

		// Get the template for mail list
		var _tmpl = $this.find('ul[data-name="tmpl-emaillist"]').html();
		$.Mustache.add('tmpl-emaillist', _tmpl);


		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		// Menu Box Event Handler
		var $menuBox = $this.find('div.menu-box');
		$menuBox.find('button').off('vclick').on('vclick', function(){
			if ($(this).closest('.ui-btn').hasClass('buttonDisabled')) {
				return false;
			}
			var menu = $(this).attr("data-menu");
			
			if (menu == 'search') {
				$this.find('.menu-box .search-box input').val('');
				__showSearchingBox();
				return false;
			}
			
			if (menu == 'delete') {
				// Get Select Items
				var ids = __selectedMails();
				if (ids.length == 0) {
					showAlert(Messages.msg02A);
					return false;
				}
				showConfirm(function(button){
					if (button == '1') {
						// Delete the selected mails
						dgbLoading(true);
						DGB.email.deleteMails(_menuId, _boxId, ids.join(','), 
							function(){
								// Success
								dgbLoading(false);
								//showAlert(Messages.msg02G);
								// refresh result
								__refresh(true);
							},
							function(err){
								// Failure
								dgbLoading(false);
								if (__emailErrorHandler(err)) {
									// refresh result
									__refresh(true);
								}
							});
					}else if (button == '2') {
						return;
					}
				}, Messages.msg027);
				return false;
			}
			if (menu == 'move') {
				// Get Select Items
				var ids = __selectedMails();
				if (ids.length == 0) {
					showAlert(Messages.msg02A);
					return false;
				}
				showConfirm(function(button){
					if (button == '1') {
						
						__mailboxItemMove(ids);
						
						// Show the mailbox list as a dialog
//						$("#GREM004").trigger("movemails",[{
//							menuId: _menuId,
//							boxId: _boxId,
//							mailIds: ids.join(',')
//						}]);
						// set flag to refresh when it returns
						_context.refresh = true;
					}else if (button == '2') {
						return;
					}
					  
				}, Messages.msg029);
				return false;
			}
			
			// Clear checked
			$this.find('.mail-list a').removeClass('oncheck');
			
			if (menu == 'edit') {
				__showEditingButtons();
				return false;
			}

			if (menu == 'normal') {
				__showMainButtons();
				return false;
			}
			
			if (menu == 'cancel') {
				$(this).focus();
				__showMainButtons();
				if (typeof _context.keyword !== 'undefined' && _context.keyword != '') {
					// reset keyword & search result
					$this.find('.menu-box .search-box input').val('');
					__reset();
				}
				return false;
			}
			
			if (menu == 'empty') {
				showConfirm(function(button){
					if (button == '1') {
						// Empty the mail box
						dgbLoading(true);
						DGB.email.emptyMailBox(_menuId, _boxId, 
							function(){
								// Success
								dgbLoading(false);
								//showAlert(Messages.msg02G);
								__refresh(true);
							},
							function(err){
								// Failure
								dgbLoading(false);
								if (__emailErrorHandler(err)) {
									// refresh result
									__refresh(true);
								}
							});
					}else if (button == '2') {
						return;
					}
					
				}, Messages.msg028);
				return false;
			}

			if (menu == 'refresh') {
				__reset();
				return false;
			}
			
			if (menu == 'find') {
				$(this).focus();
				__searchBoxEventHandler();
				return false;
			}
			return false;
		});
	};
	
	//메일 이동
	var __mailboxItemMove = function(selectMail) {

		var numberlist = DGB.isAndroid() ? [ "이동할 메일함선택" ] : [ "취소" ];

			var thelist = [];
			var mailbox_name=[];
			// Get email box list
			dgbLoading(true);
			DGB.email.getMailBoxList(_menuId,
				function(mailboxInfo){
					
					// list up the mail box
					// Remove current box
					var boxes = mailboxInfo.boxes.filter(function(box){
						return box.MAILBOX_NAME != _boxId;
					});
					
					for (var i= 0; i < boxes.length; i++){
						numberlist[i+1]=boxes[i].MAILBOX_NAME_DECODE;
						//thelist[i+1]=boxes[i].MAILBOX_NAME_DECODE;
						mailbox_name[i+1] = boxes[i].MAILBOX_NAME;
					}
					dgbLoading(false);
					
					thelist = numberlist;
					
					if (WL.Client.getEnvironment() == WL.Environment.ANDROID) {
						cordova.exec(

								function(listitem) {
									DGB.email.moveMails(_menuId, _boxId, selectMail.join(','), mailbox_name[listitem], 
											function(){
												// Success
												DGB.menuctrl.triggerMoveMails(_menuId);
											},
											function(err){
												// Failure
												__emailErrorHandler(err);
											});

								}, function(error) {
								}, "AlertList", "alertlist",thelist);
					}else{
						// After device ready, create a local alias
						var actionSheet = window.plugins.actionSheet;

						// Complex
						actionSheet.create({
							title : '이동할 메일함선택',
							items : numberlist,
							//destructiveButtonIndex : 1,
							cancelButtonIndex : 0
						}, function(buttonValue, buttonIndex) {
						
							DGB.email.moveMails(_menuId, _boxId, selectMail.join(','), mailbox_name[buttonIndex], 
									function(){
										// Success
										//dgbLoading(false);
										// $this.dialog('close');
										DGB.menuctrl.triggerMoveMails(_menuId);
										//DGB.Common.backPage();;
									},
									function(err){
										// Failure
										//dgbLoading(false);
										__emailErrorHandler(err);
									});
						
						});
					}
					
				}, function(err){
					// Failure
					dgbLoading(false);
					if (__emailErrorHandler(err)) {
						DGB.Common.backPage();
					}
				});
		
		return false;
	};
	
	var __emailErrorHandler = function(err) {
		// show error
		var errmsg = getErrorInfo(err.errorCode);

		if(err.errorCode == 'MOSE0101') {
			showAlert(Messages.msg020+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0105') {
			showAlert(Messages.msg024+':'+errmsg);
			DGB.menuctrl.triggerMenuItem('CO0102');
		} else if(err.errorCode == 'MOSE0000'){
			showAlert(Messages.msg072);	//메일서버에서 응답이 없습니다.다시조회하시기바랍니다.
			return true; // Handle page switching outside
		}else {
			//showAlert(Messages.msg104+':'+errmsg);
			showAlert(Messages.msg104);
			DGB.menuctrl.triggerMenuItem('CO0102');
			return true; // Handle page switching outside
		}
	};
	
	var __searchBoxEventHandler = function() {
		var keyword = $this.find('.menu-box .search-box input').val();
		if (keyword == "") {
			showAlert(Messages.msg021);
			return false;
		}
		
		searchbtnFlag = true;
		_context.keyword = keyword;
		__refresh(true);
	};
	
	var __showEditingButtons = function() {
		// Hide main menu
		$this.find('div.menu-box .main-menu').removeClass('block');
		
		// Show edit menu
		$this.find('div.menu-box .edit-menu').addClass('block');
		
		// Set the editing mode
		$this.find('div.mail-list').addClass('editMode');
	};
	
	var __showMainButtons = function() {
		// Show main menu
		$this.find('div.menu-box .main-menu').addClass('block');
		
		// Hide edit menu
		$this.find('div.menu-box .edit-menu').removeClass('block');
		
		// Hide search box
		$this.find('div.menu-box .search-box').removeClass('block');
		
		// Reset the editing mode
		$this.find('div.mail-list').removeClass('editMode');
	};
	
	var __showSearchingBox = function(searching) {
		// Hide main menu
		$this.find('div.menu-box .main-menu').removeClass('block');
		
		// Show search box
		$this.find('div.menu-box .search-box').addClass('block');
		
	};
	
	var __selectedMails = function() {
		var ids = [];
		$this.find('.mail-list a.oncheck').each(function(){
			ids.push($(this).attr('data-mailId'));
		});
		
		return ids;
	};
	
	var __mailItemEventHandler = function() {
		var $mail = $(this);

		// Check it is under the edit mode.
		if ($this.find('div.mail-list').hasClass('editMode')) {
			$mail.toggleClass('oncheck');
			return false;
		}
		
		// Get Box ID & Mail ID
		var mailId = $mail.attr('data-mailid');
		
		var args = {
			menuId: _menuId,
			boxId: _boxId,
			mailId: mailId
		};

		// Trigger & switch page
		// Edit mail is not support currently
		//if (_boxId == 'Drafts') {
		//	$("#GREM001").trigger("editmail",[args]);
		//} else {
		//	$("#GREM003").trigger("showmail",[args]);
		//}
		//$("#GREM003").trigger("showmail",[args]);
        DGB.Page.triggerPage("#GREM003", "showmail", [args]);
        setTimeout(function () {
            DGB.Page.changePage('#GREM003');
        },400);
		return false;
	};
	
	var __refreshMailItemHandler = function() {
		// rebind menu item event handler
		$('ul#emailListView li a')
		.off('vclick', __mailItemEventHandler)
		.on('vclick', __mailItemEventHandler);
	};

	function __reset() {
		_context.lastMailId = -1;
		_context.keyword = undefined;
		_context.refresh = true;

		__refresh();
	};

	function __refresh(forced) {
		if (!_context.refresh && !forced) return;
		_context.refresh = false;
		
		// Get current box ID
        if(!_boxId){
            _boxId = $this.find('[data-id=' + _menuId + ']').data('boxid');
            if (_boxId == undefined) {_boxId = 'Inbox';}
        }

		dgbLoading(true);
		// Get email list
		DGB.email.searchMails(_menuId, _boxId, -1, DEFAULT_NUMBER_OF_LIST_ITEMS, _context.keyword, 
			function(mailboxDetail){

				// Update Title
				$this.find('div[data-role="header"] > h1').html(DGB.email.getMailBoxName(mailboxDetail.box.MAILBOX_NAME));
								
				// Enable or disable empty
				var $empty= $this.find('div.menu-box button[data-menu="empty"]').closest('.ui-btn');
				if (_boxId === 'Junk' || _boxId === 'Trash' || _boxId === 'Spam') $empty.removeClass('buttonDisabled');
				else $empty.addClass('buttonDisabled');

				// Update Email ListView
				$('#emailListView').empty()
					.mustache('tmpl-emaillist', mailboxDetail)
					.listview('refresh').trigger('updatelayout');
				__refreshMailItemHandler();
				_layout.refreshLayout(function(){
					dgbLoading(false);
				});
				
				// Get Last Mail ID
				var mails = mailboxDetail.mails;
				if (typeof mails === 'undefined' || mails.length == 0) {
					_context.lastMailId = -1;
					$this.find('#grem02emptyTxt').text(searchbtnFlag ? "검색 결과가 없습니다." : "메일함이 비어 있습니다.");
					searchbtnFlag = false;
				} else {
					_context.lastMailId = mails.length;
				}

				if( !GLOBAL.IS_EMAIL ) {
					DGB.Menu.trigger('leftPanel', 'EMail.update');
				}
			},
			function(err){
				// Failure
				dgbLoading(false);
				__emailErrorHandler(err);
			});
	}

	function __moreshow() {
		
		if (_context.lastMailId != -1) {
			//화면에 보여지는 메일갯수를 보냄
			_context.lastMailId = $("#emailListView li").length;
		}
		dgbLoading(true);
		
		// Get email list
		DGB.email.searchMails(_menuId, _boxId, _context.lastMailId, DEFAULT_NUMBER_OF_LIST_ITEMS, _context.keyword, 
			function(mailboxDetail){
				if (mailboxDetail.mails.length == 0 && $('#emailListView div.noResult').length != 0) {
					_layout.refreshLayout(function(){
						dgbLoading(false);
						$('#grem02emptyTxt').text("검색 결과가 없습니다.");
					});
					return;
				}
				
				// Update Email ListView
				$('#emailListView')
					.mustache('tmpl-emaillist', mailboxDetail)
					.listview('refresh').trigger('updatelayout');
				__refreshMailItemHandler();
				_layout.refreshLayout(function(){
					dgbLoading(false);
				});
				
//				// Get Last Mail ID
//				var mails = mailboxDetail.mails;
//				if (typeof mails !== 'undefined' && mails.length != 0) {
//					//_context.lastMailId = mails[mails.length -1].ID;
//					
//				}
				
			},
			function(err){
				// Failure
				dgbLoading(false);
				__emailErrorHandler(err);
			});
		
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			__refresh();
			DGB.Common.backMenu();
		},
		pageshow: function() {
			_layout.refreshLayout();
		},
		pagebeforehide: function() {
			__showMainButtons();
		},
		pagehide: function() {
			$('#grem02emptyTxt').text("메일함이 비어 있습니다.");
		},
		selectmenu :function(evt, param) {
			// Update Menu ID
			_menuId = param.menuId;
            _boxId = param.boxId;
			_menuItem = param.menuItem;

			if(param.needMenuUpdate){
				_needMenuUpdate = true;
			}
	
			// init menu bar area  
			if (typeof $this !== 'undefined') __showMainButtons();
			
			// Initialize context 
			_context = {
				lastMailId : -1,
				keyword : undefined,
				refresh : true
			};
			
			// It's true if the page is already shown.
			if (param.activePage) {
				// Redraw it forced
				__refresh(true);
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulldownrefresh: function() {
			__refresh(true);
		}, 
		pulluprefresh: function() {
			// Get more mails
			__moreshow();
		},
		detailpageread: function(evt, mailId) {
			$(this).find('ul li a[data-mailId='+mailId+']').parent().parent().parent().removeClass('new');
		}
	}, '#GREM002');
})();
