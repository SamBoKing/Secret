/**
 *  SKY 지식함 공통(Security ON)
 */
(function() {
	var $this = undefined;
	var listSearch = null;
	var _menuId = undefined;
	var _layout = undefined;
	var _menuItem = undefined;

	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		
		_layout = new DGB.layout($this, _headerHeight);

        //내가 본 파일
        $this.find('li a.grco01Loc').off('vclick').on('vclick',function(){
            locDetailview = true;
            var title = "내가 본 " + _menuItem.text().replace('·  ', '');

            DGB.Page.triggerPage("#GRCO003", "parentpage", [{path:getLocalPath(), title :title}]);
            setTimeout(function () {
                DGB.Page.changePage('#GRCO003');
            },400);
            return false;
        });

		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#grco01StNum').val(param2), $('#grco01EdNum').val(param3);
						/* //페이징 */
					}

					var invocationData = {
						adapter : 'SocketTransactionAdapter',
                        procedure :  _menuItem.attr('procedure_name'),
						parameters : [ {
							CS_ID : _menuId,
							TITLE : param1,
							START_NUM : param2,
							END_NUM : param3,
							CABINET_ID : _menuItem.attr('cabinet_id'),
							TELLER_NUM : USER_INFO.ENOB
						} ]
					};

					callProcedure(invocationData, this.options);
				}
			};
				
		function displayResult(data) {
			if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
				dgbLoading(false);
				eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
				return false;
			}
			
			var item = data.invocationResult.resultSet;
			
			if(item.length === 0)
			{
				$("#grco01Noresult").removeClass("displayNone");
			}
			
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") break;

                // 글자에 "<- 있다면 JSON.parse시 SyntaxError 발생을 방지
                if( item[i].CONTENT ) {
                    item[i].CONTENT = item[i].CONTENT.replace( /&quot;/g, "\"");
                }

				html  = "<li>"+
						"<a href='#' class='grco01List downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
						"<h3>"+item[i].TITLE+"</h3>"+
						"<p><strong style='color:darkblue;'>"+item[i].UPDATE_DATE+"</strong></p>"+
						"</a>"+
						"</li>";

				listItems[i] = html;
			}
			
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#grco01pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#grco01pullUp').css("display", "block");
					$('#grco01StNum').val(
							parseInt($('#grco01StNum').val()) + _pageSize);
					$('#grco01EdNum').val(
							parseInt($('#grco01EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#grco01pullUp').css("display", "none");
			}
			/* //페이징 */
					
			$("#grco01Listview").append(listItems.join(''));
			//$("#grco01Listview").html(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#grco01Listview").listview( "refresh" );
			$("#grco01Listview").trigger("updatelayout");


			$('#grco01Listview').find('li a.grco01List').off('vclick').on('vclick', function() {
				var item = JSON.parse($(this).attr('data-item'));
                if( item.CONTENT ){
                    contentDetail(item);
				} else {
                    daviewAndDownload(item);
				}

				return false;
			});
			
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 500);
		}

		function displayError() {
			dgbLoading(false);
            showAlert(Messages.err001);
		}


        function contentDetail(item){
            // 페이지 이동후 다시 왔을때 리로드 안하기 위해
            locDetailview = true;

            var args={
                menuId : _menuId,
                item : item,
                menuItem : _menuItem
            };
            DGB.Page.triggerPage("#GRCO002", "parentpage", [args]);
            setTimeout(function () {
                DGB.Page.changePage('#GRCO002');
            },400);
        }

        function daviewAndDownload(item){
            var title = item.TITLE;
            var oid = item.OID;
            var items = item.ATTACH.split(',');

            switch( items.length ) {
                case 0:
                    showAlert(Messages.msg02L);
                    break;
                case 1:
                    if( items[0].length == 0 ) {
                        showAlert(Messages.msg02L);
                    } else {
                        onFileopen(oid, items[0]);
                    }
                    break;
                default:
                    DGB.Common.selectList(title, items,
                        function(index) {
                            // 파일이 여러개 일때 파일명을 실제 파일명으로 등록해야함
                            onFileopen(oid, items[index]);
                        },
                        function(err) {
                            DGB.Log.e('[SRW_GRCO001] ====>> Error : ' + err);
                        }
                    )
                    break;
            }
        }

        function onFileopen(oid, name) {

            if(DGB.isImage(name)) {
                showAlert(Messages.msg400);
            }else if(DGB.isSound(name) || DGB.isMovie(name)){
                if(DGB.isAndroid()){
                    if(DGB.isMovieAVI(name)){
                        showAlert(Messages.msg401);
                    }else{
                        onFileDownload(oid, name);
                    }
                }else{
                    if(DGB.isMovieAVI(name) || DGB.isMovieWMV(name)){
                        showAlert(Messages.msg401);
                    }else{
                        onFileDownload(oid, name);
                    }
                }
            }
            else{
                var dataView = {
                    url : DGB.skyHost() +  getServerPath(oid,name)
                };
                callDaview(dataView);
            }
        }

        function onFileDownload(oid, name) {
            var serverPath = getServerPath(oid,name);
            var downPath = getLocalPath();

            var link = DGB.skyHost() + serverPath;
            var url = DGB.homeDown() + "/download?parameters={'URL':'" + link + "'}";
            var params = {
                url : url,
                name : name,
                // 다른곳에서 Title 만 쓰기 때문에 여기서 가공을 해야함.
                title : name.replace(DGB.getFileExt(name), ''),   // 실제파일로 등록
                downPath : downPath,
                attach : DGB.homeAttach() + serverPath
            };
            downloadFile(params);
        }

        function getServerPath(oid,name){
            var cabinet_id = _menuItem.attr('cabinet_id');
            // return  '/STORAGES/ATTACH/0/'+ cabinet_id +'/' + oid + '/' + encodeURI(name);
			return  '/STORAGES/ATTACH/0/'+ cabinet_id +'/' + oid + '/' + name;
        }

        function getLocalPath(){
            var  folder =  DGB.isAndroid() ? _menuItem.data('title') : _menuItem.data('id');
            return DGB.fileRoot() + folder;
        }
	};

	function _pageshow() {
        var page = $('#GRCO001');
        var title = _menuItem.data('title');
        page.find('#pageTitle').text(title);

        var myfiles_btn = page.find('#MyFiles');
        var myfiles_text = page.find('li a.grco01Loc');
        myfiles_text.text("내가 본 " + title);


        if(_menuItem.attr('my_files') == 'true' && !DGB.isIPhone()){
            myfiles_btn.show();
        }else{
            myfiles_btn.hide();
        }

		if(locDetailview == false) {
            //화면 초기화
            $("#grco01Listview").empty();
			$("#grco01Noresult").addClass("displayNone");
			$('#grco01pullUp').css("display", "none");
			_iscrollEnd = false;
			
			listSearch.call("");
		}
		locDetailview = false;
		
		_layout.refreshLayout();
	
		//android back 버튼 동작
		DGB.Common.backMenu();
		
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = "",//$('#grco01input').val(),
		    param2 = $('#grco01StNum').val(),
		    param3 = $('#grco01EdNum').val();

		listSearch.call(param1, param2, param3);
	}
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Alive.start();
		},
		pagebeforehide: function() {
			DGB.Alive.end();
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			_menuItem = param.menuItem;
            if (param.activePage) {//pageshow와 동일한동작
                _pageshow();
            }
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#GRCO001');
})();