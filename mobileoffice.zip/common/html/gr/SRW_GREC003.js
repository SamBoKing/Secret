
(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var _grec03Root = "" //주요경제기사 폴더 경로
	var _fileSystem = null; 
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight);
		
		//파일 삭제 버튼
		$this.find('#grec03FileEdit').on('vclick', function(){
			$this.find('div.prpmFile-list').addClass('editMode');
			$("#grec03delDiv").removeClass("displayNone");
			$("#grec03noDiv").removeClass("displayNone");
		});
		
		//삭제
		$this.find('#grec03DelBtn').off('vclick').on('vclick', function(){
			var ids = __selectedFiles();
			if (ids.length == 0) {
				showAlert(Messages.msg071);
				return false;
			}
			
			showConfirm(function(button){
				if (button == '1') {
					dgbLoading(true);
					
					for(var i =0; i < ids.length; i++){
						__removeFiles(ids[i]);
					}
					
					getfileList();
					
					// Clear checked
					$this.find('.prpmFile-list a').removeClass('oncheck');
					$this.find('div.prpmFile-list').removeClass('editMode');

					$("#grec03delDiv").addClass("displayNone");
					$("#grec03noDiv").addClass("displayNone");
				
					showAlert(Messages.msg02G);
				}
			}, Messages.msg070);
			return false;
		});

		//삭제취소버튼
		$this.find('#grec03NoBtn').off('vclick').on('vclick', function(){
			setTimeout(function () {
				// Clear checked
				$this.find('.prpmFile-list a').removeClass('oncheck');
				$this.find('div.prpmFile-list').removeClass('editMode');
				$("#grec03delDiv").addClass("displayNone");
				$("#grec03noDiv").addClass("displayNone");
			},300);
            return false;
		});
	};
	
	//체크박스 선태된 파일
	var __selectedFiles = function() {
		var ids = [];
		$this.find('.prpmFile-list a.oncheck').each(function(){
			var $li = $(this);
			ids.push($li.find('h3').attr('data-fileName'));
		});
		return ids;
	};
	
	var __removeFiles = function(name){
		var filepath = _grec03Root+name;
		_fileSystem.root.getFile(
            filepath,
            { create:false },
            function(file){ // success find file
                file.remove(function(){
                    dgbLoading(false);
                }, function(error){
                    dgbLoading(false);
                    showAlert(Messages.msg02C);
                });
            },
            function(error){ // error find file
                dgbLoading(false);
                showAlert(error);
            }
        );
	};
	
	function getfileList() {
        if( DGB.isDebug() ) {
            DGB.debugMessage();
            return;
        }

		var sPath = DGB.fileRoot() + "economicnews/";

		// Get File System
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs){
            var filepath = fs.root.fullPath + "/" +sPath;
			_fileSystem = fs;
			_grec03Root = sPath;
		
			fs.root.getDirectory(sPath, {create: true},function(directory){
				var directoryReader = directory.createReader();
				directoryReader.readEntries(function(entries){
					
					$("#grec03Noresult").addClass("displayNone");
						
					var html = "";
					var listItems = [];
					for (var i=0; i<entries.length; i++) {
						html  = "<li>"+
									"<a href='' data-href='"+filepath +entries[i].name+"' target='_blank' class='downHeight'>"+
										"<h3 data-fileName='"+entries[i].name+"'>"+entries[i].name+"</h3>"+
										//"<p><strong>"+myPMList[i].date+"</strong></p>"+
									"</a>"+
								"</li>";
						listItems[i] = html;
					}
						
					$("#grec03Listview").html(listItems.join(''));
					listItems = null;
                    html = "";
					$("#grec03Listview").listview( "refresh" );
					$("#grec03Listview").trigger("updatelayout");
			
					_layout.refreshLayout(100);
						
					$('#grec03Listview').find('li a').off('vclick').on("vclick", function() {
                        var $grec03File = $(this);

						// Check it is under the edit mode.
						if ($this.find('div.prpmFile-list').hasClass('editMode')) {
							$grec03File.toggleClass('oncheck');
							return false;
						}
						showLink($(this).attr("data-href"));
                        return false;
					});
						
					if(entries.length == 0){
						$("#grec03Noresult").removeClass("displayNone");
						_layout.refreshLayout(1000);
					}
				},function(err){
                    DGB.Log.e('[SRW_GREC003] ====>> Error : ' + err);
				});
			});

		}, function(){} );
	}
	
	function _pageshow() {
        DGB.Common.backPage();
		getfileList();
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: _pageshow,
		pagebeforehide: function() {
			$("#grec03Listview").empty();
		},
		pagehide: function() {
			// Clear checked
			$this.find('.prpmFile-list a').removeClass('oncheck');
			$this.find('div.prpmFile-list').removeClass('editMode');

			$("#grec03delDiv").addClass("displayNone");
			$("#grec03noDiv").addClass("displayNone");
		},
		parentpage :function(evt, param) {
            _menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GREC003');
})();
