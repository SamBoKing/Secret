(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight);

	};

    function search(param1, param2, param3) {
        dgbLoading(true);

        if (arguments.length != 3 ) {
            param2 = 1; // START_NUM 기본값
            param3 = _pageSize; // EDD_NUM 기본값
            $('#grma01StNum').val(param2);
            $('#grma01EdNum').val(param3);
        }

        var opts = {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TGR00011',
            parameters : [ {
            	DV_CD : '021', // 모바일관리자에 등록된 코드.
            	CS_ID : _menuId
            } ]
        };

        callProcedure(inv, opts);
    }

    function displayResult(data) {
        var item = data.invocationResult.resultSet;
        if(item.length === 0) {
            $("#grma01Noresult").removeClass("displayNone");
            $("#grma01InputText").text("마케팅자료실");
        }

		var html = "";
		var listItems = [];
		for ( var i = 0; i < item.length; i++) {
            html = "<li class='menuitem'>"
                    + "<div class='freeMenu' data-item='"+ JSON.stringify(item[i]) + "'>"
                    + "<table>"
                    +    "<tr>"
                    +        "<td>"
                    +            "<img src='images/mark_list0"+parseInt(i+1)+".png' alt=''>"
                    +            "<span>"+ item[i].CD_EPL + "</span>"
                    +        "</td>"
                    +    "</tr>"
                    +"</table>"
                +"</div>"
            +"</li>";

			listItems[i] = html;
		}
		
        $("#grma01Listview").append(listItems.join(''));
        listItems = null;
        item = null;
        html = "";
        $("#grma01Listview").trigger("updatelayout");

        $('#grma01Listview').find('li div.freeMenu').off('vclick').on('vclick',function(e){
            locDetailview = true;
            var item = $(this).attr('data-item');
            var detailId ="GRMA002";
            var args={};
            args.menuId = _menuId;
            args.item = item;

            // $("#"+detailId).trigger("parentpage",[args]);
            DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);

            setTimeout(function () {
                DGB.Page.changePage('#'+detailId);
            },400);

            return false;
        });
        

        _layout.refreshLayout(function(){
            dgbLoading(false);
        }, 500);
    }

    function displayError() {
        dgbLoading(false);
        showAlert(Messages.err001);
    }

	function _pageshow() {
        //android back 버튼 동작
        DGB.Common.backMenu();

		if(locDetailview == false) {
			//화면 초기화
			$("#grma01Listview").empty();
			$("#grma01Noresult").addClass("displayNone");
			_iscrollEnd = false;
            search('');
		}

		locDetailview = false;
		_layout.refreshLayout();

        // 안드로이드 버튼 활성화 표시(hover)
        $(this).find('.menuitem').off('touchstart').on('touchstart' ,function(){
            $(this).addClass('mainfocus');
        }).on('touchend', function(){
            $(this).removeClass('mainfocus');
        }).on("touchcancel", function() {
            $(this).removeClass('mainfocus');
        });

	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = "",
		    param2 = $('#grma01StNum').val(),
		    param3 = $('#grma01EdNum').val();

		search(param1, param2, param3);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#GRMA001');
})();
