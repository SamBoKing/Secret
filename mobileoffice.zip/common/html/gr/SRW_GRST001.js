(function() {
	var PAGE_SIZE = 10;
	var $this, _layout, _menuId;
	var _start, _end, _refresh = true;
	var _list, _pull;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		_list = $this.find('#list');
		_pull = $this.find('.pullUp');
		_start = 1;
		_end = PAGE_SIZE;
	}
	
	function _pageshow() {
        DGB.Common.backMenu();

		if( _refresh ) {
			_start = 1;
			_end = PAGE_SIZE;
			request();
		}
		_refresh = false;
	}

	function request() {
		var opt = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};

		var inv = {
			adapter : 'SocketTransactionAdapter',
			procedure : 'TGR00012',
			parameters : [{
				CS_ID : _menuId,
				TITLE : '',
				ZZZUSER00 :"전체",
				START_NUM : _start,
				END_NUM : _end,
				TELLER_NUM : USER_INFO.ENOB
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function displayResult(data) {
		var result = data.invocationResult;
		if( result.PRCS_RSLT_DVCD == "9" ) {
			dgbLoading(false);
			eaiSocketErrorDisplay(result.STD_GRAM_ERRC);
			return false;
		}

		var item = result.resultSet;
		if(item.length == 0) {
			$("#grst01Noresult").show();
			dgbLoading(false);
			_layout.refreshLayout();
		} else{
			$("#grst01Noresult").hide();

			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				if(item[i].TITLE == "") continue;

				var fDate = (item[i].UPDATE_DATE.substring(0,19)).replace(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/,"$1-$2-$3 $4:$5:$6");
				html = "<li>"+
					"<a href='#' class='grst001List downHeight' data-item='"+JSON.stringify(item[i])+"' >"+
					"<h3>"+item[i].TITLE+"</h3>"+
					"<p><strong style='color:darkblue;'>"+fDate+"</strong></p>"+
					"</a>"+
					"</li>";
				listItems.push(html);
			}

			/* 페이징 */
			if (item.length == PAGE_SIZE) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) {
					_pull.hide();
				} else {
					_pull.show();
					_start = _start + PAGE_SIZE;
					_end = _end + PAGE_SIZE;
				}
			} else {
				_pull.hide();
			}

			_list.append(listItems.join('')).listview("refresh");
			_list.trigger("updatelayout");
			_list.find('li a.grst001List').off('vclick').on('vclick',function() {
				var item = $(this).attr('data-item');
				DGB.Page.triggerPage('#GRST002', 'parentpage', [{ menuId : _menuId, item : item }]);
				setTimeout(function () {
					DGB.Page.changePage('#GRST002');
				}, 200);
				return false;
			});

			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 300);
		}
	}

	function displayError() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	$(document).on({
		pageinit: _pageinit,
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( _pull.is(':visible') ) {
				request();
			}
		}
	}, '#GRST001');
})();
