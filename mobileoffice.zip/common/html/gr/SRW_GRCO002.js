(function() {
	var $this = undefined;
	var _item = {};
	var _menuId = undefined;
	var _layout = undefined;
    var _menuItem =  undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, _headerHeight);
		
	};
	
	function setContents() {
        //header 타이틀
        $this.find('h1').text(_menuItem.data('title') + '상세');

		$('#grco02Title').text(_item.TITLE);				// 제목
		
		var html = "";
		
		var content =_item.CONTENT;

        content = delnbsp(content);
        content = content.replace("<BR><BR><BR>Untitled<BR>p{ line-height:20px;}<BR><BR><BR><BR>","");
        content = content.replace("<BR><BR><BR><BR><BR><BR><BR><BR>","");

		$('#grco02contents').append("");
		$('#grco02contents').append(content);					// 내용
		
		html += "<li><a href='#' class='grco02DocList ui-link noTitle' ><div class='story'><b class='metadata'>"+ _item.ATTACH+"</b><br></div><div class='storyIcon'><img src='images/icn_filedown.png' class='action-icon'></div></a><br></li>";
		$('#grco02AttachFiles').append(html);
		_layout.refreshLayout();
		
		//문서리스트 클릭 이벤트
		$('#grco02AttachFiles').find('li a.grco02DocList').off('vclick').on('vclick',function(e){
			e.preventDefault();//href이벤트 막기

            daviewAndDownload(_item);
			return false;
		});
		
	}

    function daviewAndDownload(item){
        var title = item.TITLE;
        var oid = item.OID;
        var items = item.ATTACH.split(',');

        switch( items.length ) {
            case 0:
                showAlert(Messages.msg02L);
                break;
            case 1:
                if( items[0].length == 0 ) {
                    showAlert(Messages.msg02L);
                } else {
                    onFileopen(oid, items[0]);
                }
                break;
            default:
                DGB.Common.selectList(title, items,
                    function(index) {
                        // 파일이 여러개 일때 파일명을 실제 파일명으로 등록해야함
                        onFileopen(oid, items[index]);
                    },
                    function(err) {
                        DGB.Log.e('[SRW_GRCO002] ====>> Error : ' + err);
                    }
                )
                break;
        }
    }

    function onFileopen(oid, name) {

        if(DGB.isImage(name)) {
            showAlert(Messages.msg400);
        }
        else if(DGB.isSound(name) || DGB.isMovie(name)){
            if(DGB.isAndroid()){
                if(DGB.isMovieAVI(name)){
                    showAlert(Messages.msg401);
                }else{
                    onFileDownload(oid, name);
                }
            }else{
                if(DGB.isMovieAVI(name) || DGB.isMovieWMV(name)){
                    showAlert(Messages.msg401);
                }else{
                    onFileDownload(oid, name);
                }
            }
        }
        else{
            var dataView = {
                url : DGB.skyHost() +  getServerPath(oid,name)
            }
            callDaview(dataView);
        }
    }

    function onFileDownload(oid, name) {
        var serverPath = getServerPath(oid,name);
        var downPath = getLocalPath();

        var link = DGB.skyHost() + serverPath;
        var url = DGB.homeDown() + "/download?parameters={'URL':'" + link + "'}";
        var params = {
            url : url,
            name : name,
            // 다른곳에서 Title 만 쓰기 때문에 여기서 가공을 해야함.
            title : name.replace(DGB.getFileExt(name), ''),   // 실제파일로 등록
            downPath : downPath,
            attach : DGB.homeAttach() + serverPath
        };
        downloadFile(params);
    }

    function getServerPath(oid,name){
        var cabinet_id = _menuItem.attr('cabinet_id');
        return  '/STORAGES/ATTACH/0/'+ cabinet_id +'/' + oid + '/' + encodeURI(name);

    }

    function getLocalPath(){
        var  folder =  DGB.isAndroid() ? _menuItem.data('title') : _menuItem.data('id');
        return DGB.fileRoot() + folder;
    }

    function delnbsp(content){
        var str = "";
        for(var i=0;i<content.length;i++){
            if(content.charCodeAt(i) != 160)
                     str += content.charAt(i);
        }
        return str;
    }
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			setContents();
			DGB.Common.backPage();
		},
		pagehide: function(evt, ui) {
//            _item = {};
			$("#grco02contents").empty();
			$("#grco02AttachFiles").empty();
		},
		parentpage :function (evt, param) {
			_item = param.item;
			_menuId = param.menuId;
            _menuItem =  param.menuItem;

		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#GRCO002');
})();