(function() {
	var PAGE_SIZE = 10; // 한페이지 갯수

	var $this;
	var _menuId;
	var _layout;
	var _items = [];

	var _list, _result, _pull_up;
	var isScroll, isDetail;
	var start = 1, end = PAGE_SIZE;

	var _pageinit = function() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		_list = $this.find("#list");
		_result = $this.find("#result");
		_pull_up = $this.find("#pull_up");

		$this.find('#my_list').off('vclick').on('vclick',function(){
			isDetail = true;
			DGB.Page.changePage('#GREC003');
			return false;
		});
	};

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv =  {
			adapter : 'GroupWareAdapter',
			procedure : 'GWEX0001',
			parameters : [ {
				CS_ID : _menuId,
				START_NUM : start,
				END_NUM : end,
				ENOB : USER_INFO.ENOB
			} ]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		dgbLoading(false);
		if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
			eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
			return false;
		}

		var total = data.invocationResult.TOTAL_COUNT;
		var last_num = data.invocationResult.LAST_NUM;
		var items = data.invocationResult.resultSet;
		if( items.length === 0 ) {
			_result.removeClass("displayNone");
			_pull_up.css("display", "none");
			return;
		}

		_result.addClass("displayNone");
		var listItems = [];
		for (var i = 0; i < items.length; i++) {
			_items.push(items[i]);

			listItems[i] = "<li>"+
				"<a href='#' class='item downHeight' data-num='" + items[i].RNUM + "'>"+
				"<h3>"+items[i].TITLE+"</h3>"+
				"<p><strong style='color:darkblue;'>" + items[i].DATE + "</strong></p>"+
				"</a></li>";
		}

		_list.append(listItems.join(''));
		_list.listview( "refresh" );
		_list.trigger("updatelayout");
		_list.find('.item').off('vclick').on('vclick',function(e) {
			isDetail = true;
			var num = $(this).attr('data-num');
			var obj = {};
			for(var i in _items) {
				if( _items[i].RNUM == num ) {
					obj = _items[i];
					break;
				}
			}

			var detailId = "GREC002";
			DGB.Page.triggerPage("#"+detailId, "parentpage", [{ menuId : _menuId, item : obj }]);
			DGB.Page.changePage('#'+detailId);
			return false;
		});

		if ( last_num == total ) {
			_pull_up.css("display", "none");
			isScroll = true;
		} else {
			_pull_up.css("display", "block");
			start += PAGE_SIZE;
			end += PAGE_SIZE;
		}
		_layout.refreshLayout();
	}

	function onFailure() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}
	
	function _pageshow() {
		DGB.Common.backMenu();

		if( !isDetail ) {
            if( _items.length == 0 ) {
				request();
			}
		}
		isDetail = false;
		_layout.refreshLayout();
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulldownrefresh : function() {
			_items = [];
			_list.empty();
			start = 1;
			end = PAGE_SIZE;
			_layout.refreshLayout();
			request();
		},
		pulluprefresh : function() {
			if( !isScroll ) {
				request();
			}
		}
	}, '#GREC001');
})();
