(function() {
    var $this, _layout, _view, _menuId, _row = {};

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _view = $this.find('#view');
        $.Mustache.add('ITMS002_tmpl-view', $this.find('#tmpl_list').html());
    }

    function _pageshow() {
        DGB.Common.backPage();

        _view.empty().mustache('ITMS002_tmpl-view', _row);
        _layout.resetLayout();
        _layout.refreshLayout();
    }

    function _parentpage(evt, param) {
        _menuId = param.menuId;
        _row = param.row || {};
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        parentpage : _parentpage,
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }

    }, '#ITMS002');

})();