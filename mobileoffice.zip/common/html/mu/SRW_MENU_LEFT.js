var SRW_MENU_LEFT = {};
(function() {
    function getMenuClass() {
        var step_class = 'menu_step' + this.STEP + '_title';

        var arraw_class = this.ID ? 'menu_step_arrow' : '';
        // 메시지함 예외 처리
        if( this.ID == 'CO0100' || this.SKIP ) {
            arraw_class = '';
        }
        var line_class = this.LINE ? 'menu_step_line' : '';
        var hide_class = this.HIDE ? 'menu_step_hide' : '';
        return [step_class, arraw_class, line_class, hide_class].join(' ');
    }

    function getMenuComma() {
        return this.STEP == 3 ? '·  ' : '';
    }

    function setMenuData(panel, selecter, menu) {
        var item = panel.find(selecter + menu.INDEX);
        if( !item ) { return; }

        if( menu.ID ) { item.attr('data-id', menu.ID); }
        if( menu.PAGE ) { item.attr('data-page', menu.PAGE); }
        if( menu.STATE ) { item.attr('data-state', menu.STATE); }
        if( menu.HIDE ) { item.attr('data-hide', menu.HIDE); }
        for(var k in menu.ETC_DATA) {
            var etc = menu.ETC_DATA[k];
            item.attr(etc.KEY, etc.VALUE);
        }
    }

    var INIT_MENI = false;
    var MENU = { STEP1: [
        {
            TITLE: 'My DGB',
            MENU: [
                { TITLE: '보수명세표', STEP : 2, ID : 'EHR001', PAGE : 'EHR0001', STATE : DGB.Auth.Level.Sms },
                { TITLE: '쪽지함', STEP : 2, ID : 'CO0100', BADGE : 'BadgeMain' },
                { TITLE: '개인', STEP : 3, ID : 'CO0101', PAGE : 'CO00002', STATE : DGB.Auth.Level.ID, BADGE : 'Badge1' },
                { TITLE: '업무', STEP : 3, ID : 'CO0105', PAGE : 'CO00002', BADGE : 'Badge2' },
                { TITLE: '쪽지보내기', STEP : 2, ID : 'EM0103', PAGE : 'EMST005', STATE : DGB.Auth.Level.Pass },
                { TITLE: '윙크톡',  STEP : 2, ID : 'EM0501', PAGE : 'EMWK001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE : '메일',
            MENU : [
                { TITLE: '메일', STEP : 2, ID : 'GR0100', STATE : DGB.Auth.Level.Pass },
                { TITLE: '받은메일함', STEP : 3, ID : 'GR0102', PAGE : 'GREM002', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '일정/경조사',
            MENU : [
                { TITLE: '일정관리', STEP : 2, ID : 'GW0200', PAGE : 'GWCL001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '경조사', STEP : 2, ID : 'EM0201', PAGE : 'EMSO001' },
                { TITLE: 'Happy Days', STEP : 2, ID : 'EM0301', PAGE : 'EMHD001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '직원조회',
            MENU : [
                { TITLE: '직원통합조회', STEP : 2, ID : 'EM0101', PAGE : 'EMST001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '직원전화번호조회', STEP : 2, ID : 'EM0102', PAGE : 'EMST001' },
                { TITLE: '영업점담당조회', STEP : 2, ID : 'EM0401', PAGE : 'EMTK001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '마케팅',
            MENU : [
                { TITLE: '신규업무', STEP : 2 },
                { TITLE: '예금', STEP : 3, ID : 'RE0301', PAGE : 'RESU001', STATE : DGB.Auth.Level.Sms },
                {
                    TITLE: '인터넷뱅킹', STEP : 3, ID : 'RE0701', PAGE : 'REFN001', STATE : DGB.Auth.Level.Sms,
                    ETC_DATA : [ { KEY : 'data-biz_dvcd', VALUE : 'EF1' } ]
                },
                {
                    TITLE: '폰뱅킹', STEP : 3, ID : 'RE0801', PAGE : 'REFN001', STATE : DGB.Auth.Level.Sms,
                    ETC_DATA : [ { KEY : 'data-biz_dvcd', VALUE : 'EF2' } ]
                },
                { TITLE: '카드', STEP : 3, ID : 'RE0901', PAGE : 'RECD001', STATE : DGB.Auth.Level.Sms },
                { TITLE: '금리조회', STEP : 2, ID : 'PR0200', SKIP : true },
                { TITLE: '예금금리조회', STEP : 3, ID : 'PR0202', PAGE : 'PRDE002' },
                { TITLE: '적금금리조회', STEP : 3, ID : 'PR0203', PAGE : 'PRDE003' },
                { TITLE: '대출금리조회', STEP : 3, ID : 'PR0204', PAGE : 'PRDE004' },
                { TITLE: '외환', STEP : 2, ID : 'PR0300', SKIP : true },
                { TITLE: '환율/주가 조회', STEP : 3, ID : 'PR0205', PAGE : 'PRDE005' },
                { TITLE: '환가요율조회', STEP : 3, ID : 'PR0301', PAGE : 'PR0301' },
                {
                    TITLE: '외환업무별유의사항', STEP : 3, ID : 'PR0302', PAGE : 'GRCO001',
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2956' }, { KEY : 'procedure_name', VALUE : 'SKYNonUN' } ]
                },
                { TITLE: '아파트시세조회', STEP : 2, ID : 'PR0104', PAGE : 'PRAP001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '부동산시세(네이버)', STEP : 2, ID : 'PR0102' },
                { TITLE: '주식정보(네이버)', STEP : 2, ID : 'PR0103' },
                { TITLE: '상품관', STEP : 2, ID : 'PR0101', PAGE : 'PRPM001' },
                { TITLE: '프로매너/감성자료', STEP : 2, ID : 'GR0501', PAGE : 'GRPM001' }
            ]
        }, {
            TITLE: '스마트워크',
            MENU : [
                { TITLE: '거액이동명세', STEP : 2, ID : 'RE0401', PAGE : 'REBM001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '영업계수', STEP : 2, ID : 'RE0101', PAGE : 'RESI001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '영업점현황', STEP : 2, ID : 'RE0102', PAGE : 'RESI004', STATE : DGB.Auth.Level.Pass },
                { TITLE: '영업점실적', STEP : 2, ID : 'RE0103', PAGE : 'RESI005', STATE : DGB.Auth.Level.Pass },
                { TITLE: 'M-배치작업관리', STEP : 2, ID : 'RE0501', STATE : DGB.Auth.Level.Sms },
                { TITLE: '지점알리미 수정', STEP : 2, ID : 'BA0001', PAGE : 'BANK001', STATE : DGB.Auth.Level.ID },
                { TITLE: '지점알리미 현황', STEP : 2, ID : 'BA0003', PAGE : 'BANK003', STATE : DGB.Auth.Level.ID },
                { TITLE: '형상관리 긴급이행', STEP : 2, ID : 'RE0601', PAGE : 'REIT001', STATE : DGB.Auth.Level.Sms, HIDE : true }
            ]
        }, {
            TITLE: '규정정보',
            MENU : [
                { TITLE: '규정정보', STEP : 2, ID : 'LI0001', PAGE : 'LIS0001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '도서실',
            MENU : [
                { TITLE: '소장도서검색', STEP : 2, ID : 'BO0101', PAGE : 'BOOK101', STATE : DGB.Auth.Level.ID },
                { TITLE: '대출현황/연기 조회', STEP : 2, ID : 'BO0201', PAGE : 'BOOK201', STATE : DGB.Auth.Level.ID },
                { TITLE: '대출신청/예약 조회', STEP : 2, ID : 'BO0301', PAGE : 'BOOK301', STATE : DGB.Auth.Level.ID }
            ]
        }, {
            TITLE: 'DGB맛집',
            MENU : [
                { TITLE: '맛집 조회', STEP : 2, ID : 'FD0001', PAGE : 'FOOD001', STATE : DGB.Auth.Level.ID },
                { TITLE: '구내식단표', STEP : 2, ID : 'FD0002', PAGE : 'FOOD002' }
            ]
        }, {
            TITLE: '자료실',
            MENU : [
                { TITLE: '복지길잡이', STEP : 2, ID : 'GR0301', PAGE : 'GRAR001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '마케팅자료실', STEP : 2, ID : 'GR0601', PAGE : 'GRMA001', STATE : DGB.Auth.Level.Pass },
                { TITLE: '부점혁신의날', STEP : 2, ID : 'GR0701', PAGE : 'GRST001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '회의자료',
            MENU : [
                { TITLE: '임원회의', STEP : 2, ID : 'RE0201', PAGE : 'REME001', STATE : DGB.Auth.Level.Pass },
                // {
                //     TITLE: 'IT NPC', STEP : 2, ID : 'RE0202', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                //     ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '3204' }, { KEY : 'procedure_name', VALUE : 'SKYNonUN' } ]
                // },
                { TITLE: '스마트회의', STEP : 2, ID : 'DA0001', PAGE : 'DAMO001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '본부부서',
            MENU : [
                { TITLE: '장애대비 비상연락처', SUBTITLE : '(IT본부)', STEP : 2, ID : 'ITMS001', PAGE : 'ITMS001', STATE : DGB.Auth.Level.ID },
                { TITLE: '본부금리승인', STEP : 2, ID : 'BPR0001', PAGE : 'BPR0001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '연수',
            MENU : [
                { TITLE: '사이버연수', STEP : 2 },
                { TITLE: '부점자체연수', STEP : 3, ID : 'LE0101', PAGE : 'LECT001', STATE : DGB.Auth.Level.ID },
                // { TITLE: '동영상연수', STEP : 3, ID : 'LE0102', PAGE : 'LECT003', STATE : DGB.Auth.Level.ID },
                { TITLE: 'ACT', STEP : 2, ID : 'LE0200', SKIP : true },
                {
                    TITLE: 'ACT-수신', STEP : 3, ID : 'LE0201', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2436' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-여신일반', STEP : 3, ID : 'LE0202', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2437' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-여신운용지침', STEP : 3, ID : 'LE0203', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2438' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-외국환', STEP : 3, ID : 'LE0204', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2439' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-실무법률', STEP : 3, ID : 'LE0205', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2440' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-기출문제', STEP : 3, ID : 'LE0206', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2433' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: 'ACT-공지사항', STEP : 3, ID : 'LE0207', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2434' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                {
                    TITLE: '주요자격증일정', STEP : 2, ID : 'LE0302', PAGE : 'GRCO001', STATE : DGB.Auth.Level.Pass,
                    ETC_DATA : [ { KEY : 'cabinet_id', VALUE : '2948' }, { KEY : 'procedure_name', VALUE : 'SKYNon' } ]
                },
                { TITLE: '주요연수일정', STEP : 2 },
                { TITLE: '통신연수', STEP : 3, ID : 'LE0301', PAGE : 'LEDU001', STATE : DGB.Auth.Level.Pass }
            ]
        }, {
            TITLE: '설정 및 기타',
            MENU : [
                { TITLE: 'DGB바른소리', STEP : 2, ID : 'GR0900', PAGE : 'GRRE001' },
                { TITLE: '바이오인증', STEP : 2 },
                { TITLE: '바이오인증 등록', STEP : 3, ID : 'BI0001', PAGE : 'BIO0001', STATE : DGB.Auth.Level.Sms },
                { TITLE: '바이오인증 해지', STEP : 3, ID : 'BI0003', PAGE : 'BIO0003', STATE : DGB.Auth.Level.Sms },
                { TITLE: '환경설정', STEP : 2, ID : 'CO0102', PAGE : 'CO00004' },
                { TITLE: 'DGB APP설치', STEP : 2, ID : 'CO0104', PAGE : 'CO00010' },
                { TITLE: 'iM챗봇', STEP : 2, ID : 'CHAT01', STATE : DGB.Auth.Level.Pass, HIDE : true }
            ]
        }
    ]};


    // 신규메뉴 표시
    var new_menu = [];
    if( Messages.opt002 ) {
        var opt = JSON.parse(Messages.opt002.replace(/'/g, '\"')) || {};
        // menu new icon
        if (opt && opt.new_menu.length > 0) {
            new_menu = opt.new_menu;
        }
    }

    // 기본값 설정
    var menu_index = 0;
    for(var i in MENU.STEP1) {
        MENU.STEP1[i].INDEX = i;
        var index = parseInt(i) + 1;
        MENU.STEP1[i].ICON = 'menu_icon_' + ( index > 9 ? index : '0' + index);
        for(var j in MENU.STEP1[i].MENU ){
            MENU.STEP1[i].MENU[j].INDEX = menu_index++;
            MENU.STEP1[i].MENU[j].COMMA = getMenuComma;
            MENU.STEP1[i].MENU[j].CLASS = getMenuClass;

            var idx = parseInt(j);
            if( MENU.STEP1[i].MENU[idx].STEP == 3 && (!MENU.STEP1[i].MENU[idx + 1] || MENU.STEP1[i].MENU[idx + 1].STEP != 3 ) ) {
                MENU.STEP1[i].MENU[idx].LINE = true;
            }

            var menu_id =  MENU.STEP1[i].MENU[j].ID;
            if( menu_id && new_menu && new_menu.length ) {
                if( new_menu.indexOf(menu_id) > -1 ) {
                    MENU.STEP1[i].MENU[j].NEW = true;
                }
            }
        }
    }

    var permissionMap = new DGB.HashMap();      // 사용자별 메뉴권한정보.(key:#pageId, value:menuId)
    var skipMenuMap =  new DGB.HashMap();       // 예외 페이지 처리

    this.initSkipMenu = function() {
        // 메인화면
        skipMenuMap.put('CO0002', { log : false, url : '' });
        // 부동산시세(네이버)
        skipMenuMap.put('PR0102', { log : true,  url : Messages.url001 });
        // 주식정보(네이버)
        skipMenuMap.put('PR0103', { log : true,  url : Messages.url002 });
        // M-배치작업관리
        skipMenuMap.put('RE0501', { log : true,  url : Messages.url003 });
        // 환가요율조회
        skipMenuMap.put('PR0301', { log : true,  url : Messages.url004 });
        // 설정,메뉴얼,인증서설치
        skipMenuMap.put('CO0102', { log : true,  url : '' });
        // 유용한 모바일 사이트
        skipMenuMap.put('CO0103', { log : true,  url : '' });
        // 대구은행 App 설치
        skipMenuMap.put('CO0104', { log : true,  url : '' });
        // DGB CARD소개
        skipMenuMap.put('CD0200', { log : true,  url : Messages.url005 });
        // BC EVENT
        skipMenuMap.put('CD0201', { log : true,  url : Messages.url006 });
        // 당행 EVENT
        skipMenuMap.put('CD0202', { log : true,  url : Messages.url007 });
        // 상품관
        skipMenuMap.put('PR0101', { log : true,  url : Messages.url033 });
        // 챗봇
        skipMenuMap.put('CHAT01', { log : true,  url : true });
    };

    this.isSkipMenu = function(menu_id) {
        return skipMenuMap.containsKey(menu_id);
    };

    this.execSkipMenu = function(menu_id) {
        var me = this;
        var skip = skipMenuMap.get(menu_id);
        if( !skip ) return false;

        // 화면 로그 남기기
        if( skip.log ) DGB.Common.log(menu_id);

        // 링크페이지 처리
        if( skip.url ) {
            switch( menu_id ) {
                case 'RE0501':  // M-배치관리
                    if(USER_INFO.ORG_CD != "906" && USER_INFO.ORG_CD != "951" && USER_INFO.ORG_CD != "969") {
                        showAlert(Messages.msg065);
                        return true;
                    }
                    me.connectEzJob();
                    break;
                case 'CHAT01':  // 챗봇
                    DGB.Common.openChatBot();
                    DGB.Menu.close('leftPanel');
                    break;
                default:
                    window.open(skip.url, DGB.isIPhone() ? "_system" : "_blank", "location=yes,EnableViewPortScale=yes");
                    break;

            }
            return true;
        }
        return false;
    };

	this.init = function(panel) {
        // dgb_menu click event
        var me = this;

        if( !INIT_MENI ) {
            INIT_MENI = true;
            $.Mustache.add('tmpl-menu_step1', panel.find('#tmpl-menu_step1').html());
            $.Mustache.add('tmpl-menu_step2', panel.find('#tmpl-menu_step2').html());
            $.Mustache.add('tmpl-menu_email', panel.find('#tmpl-menu_email').html());

            panel.find('#menu_step1').empty().mustache('tmpl-menu_step1', MENU);
            panel.find('#menu_step2').empty().mustache('tmpl-menu_step2', MENU);

            // data, attr 셋팅
            for(var i in MENU.STEP1) {
                for(var j in MENU.STEP1[i].MENU) {
                    var menu = MENU.STEP1[i].MENU[j];
                    setMenuData(panel, '#menu_step_item_', menu);
                }
            }

            // Skip Menu Init
            me.initSkipMenu();

            // 이메일 관련 초기화
            me.EMail.init(panel);

            // 챗봇아이콘 숨김
            if( !Messages.url038 ) {
                panel.find('#menu_chat').hide();
            }
        }

        panel.find('.menu_step1_item').off('vclick').on("vclick", function() {
            var me = $(this);
            if( !me.hasClass('on') ) {
                panel.find('.menu_step1_item.on').removeClass('on');
                me.addClass('on');
            }

            var section = me.data('section');
            DGB.Menu.scrollTo('leftPanel', $('#' + section));
            return false;
        });

        panel.find('.menu_step2_item').off('vclick').on("vclick", function() {
            me.clickMenu(panel, $(this));
            return false;
    	});

        panel.find('#menu_chat').off('vclick').on("vclick", function () {
            // 챗봇은 하드코딩;;
            me.click(panel, 'CHAT01');
            return false;
        });

        panel.find('#menu_close').off('vclick').on("vclick", function () {
            DGB.Menu.close('leftPanel');
            return false;
        });
	};

    // 외부에서 호출을 하기 때문에 this 를 쓰면안됨
    this.click = function(panel, id) {
        var menu = panel.find('[data-id=' + id  +']');
        var section_id = menu.parent('section').attr('id');
        var section = panel.find('[data-section=' + section_id + ']');
        if( menu.length ) {
            // 숨겨진 메뉴는 이동을 안함.
            if( !menu.data('hide') ) {
                section.trigger('vclick');
            }
            SRW_MENU_LEFT.clickMenu(panel, menu, true);
        } else {
            showAlert('해당 메뉴에 대한 권한이 없습니다.\n메뉴 ID : ' + id);
        }
    };

    this.clickPopup = function(panel, id) {
        var menu = panel.find('[data-id=' + id + ']');
        if( !menu.length ) {
            showAlert('해당 메뉴에 대한 권한이 없습니다.\n메뉴 ID : ' + id);
            return;
        }

        var title = menu.data('title');
        var items = [];
        while(true) {
            menu = menu.next();
            if( menu.hasClass('menu_step3_title') ) {
                var menu_id = menu.data('id');
                var menu_page = menu.data('page');
                var menu_text = menu.data('title');
                var menu_badge = menu.find('.menu_step_badge').text();
                items.push( { ID : menu_id, PAGE : menu_page, TEXT : menu_text, BADGE : menu_badge } );
            } else {
                break;
            }
        }

        // 메시지함
        if( id == 'CO0100' && items.length == 2 ) {
            var cnt1 = USER_INFO.MSG_COUNT || 0;
            var cnt2 = USER_INFO.MSG_COUNT2 || 0;
            if( cnt1 > 0 && cnt2 == 0 ) {
                SRW_MENU_LEFT.click(panel, items[0].ID);
            } else if(cnt1 == 0 && cnt2 > 0) {
                SRW_MENU_LEFT.click(panel, items[1].ID);
            } else {
                title = title + ' (' + (cnt1 + cnt2) + ')';
                var title1 = items[0].TEXT + ' (' + cnt1 + ')';
                var title2 = items[1].TEXT + ' (' + cnt2 + ')';
                DGB.Common.selectList(title, [title1, title2], function (index) {
                    SRW_MENU_LEFT.click(panel, items[index].ID);
                }, function () { } );
            }
        } else {
            var titleList = [];
            for(var i in items){
                var text = items[i].TEXT;
                if( items[i].BADGE ) {
                    text += ' (' + items[i].BADGE + ')';
                }
                titleList.push(text);
            }
            DGB.Common.selectList(title, titleList, function (index) {
                SRW_MENU_LEFT.click(panel, items[index].ID);
            }, function () { } );
        }
    };

	this.clickMenu = function(panel, item, etc) {
		var _menu_id = item.data('id');
		var _page_id = item.data('page');
        var _state = item.data('state');
        SRW_MENU_LEFT.clickEvent(panel, item, _menu_id, _page_id, _state, etc);
	};

    // 이메일 클래스
    this.EMail = {
        item : {},
        menu : {},
        init: function(panel) {
            this.item = panel.find('#menu_section_1');
            this.menu = panel.find('[data-id="GR0100"]');
        },
        list: function(data) {
            var used = Math.round(data.quota.USED / 1024);
            var maxmin = Math.round(data.quota.MAXIMUM / 1024);
            var text = used + ' / ' + maxmin + ' MB';

            var EMAIL = { TITLE : '메일', MENU : [] };
            EMAIL.MENU.push(
                { TITLE: '메일 ' + text, STEP : 2, ID : 'GR0100', COMMA : getMenuComma, CLASS : getMenuClass, STATE : DGB.Auth.Level.Pass },
                { TITLE: '편지쓰기', STEP : 3, ID : 'GR0101', PAGE : 'GREM001', COMMA : getMenuComma, CLASS : getMenuClass, STATE : DGB.Auth.Level.Pass }
            );
            for(var i in data.boxes) {
                var box =  data.boxes[i];
                var isLine = data.boxes.length == (i + 1);
                EMAIL.MENU.push(
                    {
                        TITLE : box.MAILBOX_NAME_DECODE,
                        STEP : 3,
                        ID : box.menuId,
                        PAGE : box.pageId,
                        ETC_DATA : [{ KEY : 'data-boxid', VALUE : box.MAILBOX_NAME }],
                        LINE : isLine,
                        BADGE : box.UNREAD,
                        COMMA : getMenuComma,
                        CLASS : getMenuClass,
                        STATE : DGB.Auth.Level.Pass
                    }
                )
            }

            for(var i in EMAIL.MENU) {
                EMAIL.MENU[i].INDEX = i;
            }

            this.item.empty().mustache('tmpl-menu_email', EMAIL);

            for(var i in EMAIL.MENU) {
                var menu = EMAIL.MENU[i];
                setMenuData(this.item, '#menu_step_email_item_', menu);
            }
        },
        event: function(panel) {
            this.item.find('.menu_step2_item').off('vclick').on("vclick", function() {
                SRW_MENU_LEFT.clickMenu(panel, $(this));
            });
        },
        update: function(panel, id) {
            if( id ) { dgbLoading(true); }

            DGB.email.getMailBoxList('GR0100',
                function(info) {
                    dgbLoading(false);
                    SRW_MENU_LEFT.EMail.list(info);
                    SRW_MENU_LEFT.EMail.event(info);
                    GLOBAL.IS_EMAIL = true;
                    if( id ) {
                        SRW_MENU_LEFT.clickPopup(panel, id);
                    }

                    var section_id = SRW_MENU_LEFT.EMail.item.attr('id');
                    var section = panel.find('[data-section=' + section_id + ']');
                    if( section.length ) {
                        section.trigger('vclick');
                    }
                },
                function(err) { SRW_MENU_LEFT.EMail.error(err); dgbLoading(false); });
        },
        error: function(err) {
            // show error
            var errmsg = getErrorInfo(err.errorCode);
            if(err.errorCode == 'MOSE0101') {
                showAlert(Messages.msg020+':'+errmsg);
                DGB.menuctrl.triggerMenuItem('CO0102');
            } else if(err.errorCode == 'MOSE0105') {
                showAlert(Messages.msg024+':'+errmsg);
                DGB.menuctrl.triggerMenuItem('CO0102');
            } else if(err.errorCode == 'MOSE0000'){
                showAlert(Messages.msg072);
            } else if (err.errorCode == 'MOSE0104'){
                showAlert(Messages.msg073);
                DGB.menuctrl.triggerMenuItem('CO0102');
            } else {
                showAlert(Messages.msg104);
                DGB.menuctrl.triggerMenuItem('CO0102');
            }
        }
    };

    // @ 중요 @ 여기에서 패널에 대한 이벤트를 정의할때 조심할것! 페이지에 패널이 안붙음.
    this.clickEvent = function(panel, _item, _menu_id, _page_id, _state, _etc) {
        var me = this;
        var page_id = $.mobile.activePage.attr('id');
        var activePage = (page_id == _page_id);

        if( !DGB.isDebug() ) {
            // 기기가 등록이 안되어 있다면 강제 SSO 로그인
            if( !DGB.Auth.Sso.isSso && USER_INFO.LEVEL == 0 && (!_state || _state == DGB.Auth.Level.ID) ) {
                // SSO 인증 없는 메뉴 체크
                if( !me.isSkipMenu(_menu_id) ) {
                    showAlert(Messages.msg00C);
                    _state = DGB.Auth.Level.Pass;
                }
            }

            if( _state ) {
                // 세션종료시 이전 상태로 복구를 위해 상태 저장
                GLOBAL.TEMP_STAT = _state;
                GLOBAL.TEMP_PAGEID = _page_id;
                var returnAuthState = authState.stateCompare(_state);
                if(returnAuthState != "AUTH_PASSED") {
                    // EzJOBs, 챗봇 연결 - 로그인후 freeSv 페이지로이동.
                    if(_menu_id == 'RE0501' || _menu_id == 'CHAT01' )
                        _page_id = 'freeSv';

                    var args = {
                        menuId: _menu_id,
                        menuItem : _item
                    };
                    GLOBAL.STAT = returnAuthState;
                    GLOBAL.PAGEID = _page_id || 'freeSv';
                    GLOBAL.ARGS = args;
                    DGB.Page.triggerPage("#login", "parentpage", [args]);
                    DGB.Page.changePage('#login');
                    return false;
                }
            }
        }

        if( _menu_id == 'GR0100' || _item.hasClass('emailmenu') ) {
            // 이메일등록 체크
            if ( !DGB.email.getKey() ) {
                showConfirm(function(btn){
                    if (btn == '1') {
                        DGB.Page.changePage("#CO00004");
                    }
                }, Messages.msg020+ "\n"+ Messages.msg02K);
                return;
            }

            // 이메일 메뉴 클릭시 메뉴 확장
            if( _menu_id == 'GR0100' ) {
                dgbLoading(true);
                DGB.email.getMailBoxList('GR0100', function(info){
                        // Success
                        dgbLoading(false);
                        me.EMail.list(info);
                        me.EMail.event(panel);
                        DGB.Menu.refresh();
                }, function(err){
                        dgbLoading(false);
                        me.EMail.error(err);
                });
                return;
            }

            // 이메일 확장된 메뉴 클릭시
            var boxId = _item.data('boxid');
            if ( !boxId ) {
                // Get mailbox info
                dgbLoading(true);
                DGB.email.getMailBoxList('GR0100',
                    function(mailbox){
                        // Success
                        dgbLoading(false);
                        // draw them
                        me.EMail.list(mailbox);
                        me.EMail.event(panel);
                        DGB.Menu.refresh();
                        // Change page
                        DGB.Page.triggerPage("#"+_page_id, "selectmenu", [{
                            menuId : _menu_id,
                            activePage : activePage,
                            menuItem : _item
                        }]);
                        DGB.Page.changePage('#'+_page_id);
                    },
                    function(err){
                        dgbLoading(false);
                        me.EMail.error(err);
                    });
                return;
            }
        }

        // 로그 및 링크 공통 함수
        if( me.execSkipMenu(_menu_id) )
            return;

        var args = {
            menuId :_menu_id,
            activePage : activePage,
            menuItem : _item
        };

        //메일 메세지함 선택시 _boxId정보 넘김.
        if (_item.hasClass('emailmenu')) {
            args.boxId = _item.data('boxid');
        }

        DGB.Page.triggerPage('#' + _page_id, 'selectmenu', [args]);
        DGB.Page.changePage('#' + _page_id);
    };

    this.updateProfile = function(panel) {
        if( USER_INFO.PHOTO_URL ) {
            var image = panel.find('#menu_user_img');
            image.attr('src', DOWN_URL+"/download?parameters={'URL':'" + USER_INFO.PHOTO_URL+"'}");

            // 이미지 불러오는것 계산(ImagesLoaded 사용)
            image.imagesLoaded()
                .always( function( ) { })
                .done( function( ) { })
                .fail( function() {
                    image.attr('src', "images/unknownUser.jpg");
                })
                .progress( function( instance, img ) {
                    var result = img.isLoaded ? 'loaded' : 'broken';
                    DGB.Log.d('[SRW_MENU_LEFT] ====>> image is ' + result + ' for ' + img.img.src );
                });
        }
        panel.find('.menu_header_logout').hide();
        panel.find('.menu_header_login').show();
        panel.find('.menu_header_text').text(USER_INFO.FSNM);
        panel.find('.menu_header_sub').text(USER_INFO.RSB_NM);
        panel.find('.BadgeMain').text(parseInt(USER_INFO.MSG_COUNT) + parseInt(USER_INFO.MSG_COUNT2));
        panel.find('.Badge1').text(USER_INFO.MSG_COUNT);
        panel.find('.Badge2').text(USER_INFO.MSG_COUNT2);

        panel.find('.menu_step2_item').each(function() {
            var item = $(this);
            if( isRejectedMenu(item.data("id")) ) {
                permissionMap.put('#' + item.data("page"), item.data("id"));
               item.remove();
            }
        });
    };

    // 메뉴 아이디로 페이지 이동
    this.location = function(panel, data) {
        var id = data.id;
        var menu = panel.find('[data-id=' + id + ']');
        if( !menu.length ) {
            showAlert('해당 메뉴에 대한 권한이 없습니다.\n메뉴 ID : ' + id);
            return;
        }

        var page = menu.data("page");
        if( !page ) {
            showAlert('해당 페이지를 찾을수 없습니다.\n메뉴 ID : ' + id);
            return;
        }

        var event = data.event || '';
        var args = data.args || {};
        DGB.Page.triggerPage('#', event, args);
        DGB.Page.changePage('#' + page);
    };

    // 권한 수정 후
    this.updateAuth = function(panel, args) {
        var menu = panel.find('[data-id=' + args.menuId + ']');
        menu.attr('data-state', args.auth);
        menu.trigger('vclick');

        // 권한 삭제
        setTimeout(function() {
            menu.removeAttr('data-state');
        }, 2000);
    };

    //페이지 아이디로 권한이 없는 메뉴아이디 찾기.
    this.getRejectedMenuId = function(panel, page_id){
        return permissionMap.get(page_id);
    };

    // 뱃지 업데이트
    this.updateBadge = function(panel) {
        panel.find('.BadgeMain').html(parseInt(USER_INFO.MSG_COUNT) + parseInt(USER_INFO.MSG_COUNT2));
        panel.find('.Badge1').html(USER_INFO.MSG_COUNT);
        panel.find('.Badge2').html(USER_INFO.MSG_COUNT2);
    };

    this.hideMenu = function(panel, menu_data) {
        var success = false;
        var menus = (menu_data || '').split(',');
        for(var i in menus) {
            var menu = panel.find('[data-id=' + menus[i] + ']');
            if( menu && menu.length ) {
                menu.removeClass('menu_step_hide');
                success = true;
            }
        }

        if( success ) {
            DGB.Menu.refresh();
        }
    };

    // ezJob(배치작업관리)연결.
    this.connectEzJob = function(){
        showConfirm(function(button){
            var theText = USER_INFO.ENOB;
            if (button == '1') {
                var output   = "";
                var Temp    = [];
                var Temp2   = [];
                var TextSize  = theText.length;
                for (var i = 0; i < TextSize; i++) {
                    var rnd    = Math.round(Math.random() * 122) + 68;
                    Temp[i]  = theText.charCodeAt(i) + rnd;
                    Temp2[i]  = rnd;
                }

                for (i = 0; i < TextSize; i++) {
                    output += String.fromCharCode(Temp[i], Temp2[i]);
                }

                var url = Messages.url003;
                url += encodeURI(USER_INFO.ENOB);
                url += "&session_id=" + USER_INFO.SESSION_ID + "&user_nm=" + encodeURI(USER_INFO.FSNM);
                window.open(url, "_blank", "location=yes");
            }
        }, Messages.msg207);
    };

}).apply( SRW_MENU_LEFT );