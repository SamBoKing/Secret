(function() {
	var $this, _menuId, _layout, _view, _reserve_view, _mast_id = '63563';
	var _rd_view, _rd_list, _move_top, _is_view, _reset_scroll, _book_me, _book_id;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
		_view = $this.find('#view');
		$.Mustache.add('BOOK102_tmpl-view', $this.find('#tmpl-view').html());

		_reserve_view = $this.find('#reserve_view');
		$.Mustache.add('BOOK102_tmpl-reserve_view', $this.find('#tmpl-reserve_view').html());

		_move_top = $this.find('.move_top');
		_move_top.on('vclick', onMoveTop);

		$this.find('#rd_tab').on('change', onClickTab);
		_rd_view = $this.find('#rd_view');
		_rd_list = $this.find('#rd_list');
	}

	function _pageshow() {
		DGB.Common.backPage();

		_reset_scroll = true;
		_is_view = true;
		setTab();
		_view.empty().mustache('BOOK102_tmpl-view', {});
		request();
	}

	function _parentpage(evt, param) {
		_menuId = param.menuId;
		_mast_id = param.mast_id;
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : 'BOOK0002',
			parameters : [{
				CS_ID : _menuId,
				mast_id : _mast_id + ''
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var obj = data.invocationResult || {};
		obj.view = [];
		obj.list = [];
		for(var key in obj.result) {
			obj.view.push(obj.result[key]);
		}

		for(var key in obj.row) {
			var color = '#3f3fCA';
			var state = obj.row[key].L_STATE_TEXT;
			if( state == '대출중' ) {
				color = '#f00';
			} else if( state == '대출신청중' ) {
				color = '#000';
			}
			obj.row[key].L_STATE_COLOR = color;

			var btn_class = '';
			var button = obj.row[key].L_BUTTON_TEXT;
			if( button == '예약취소' ) {
				btn_class = 'book_btn_red';
			} else if( button == '예약신청' ) {
				btn_class = 'book_btn_green';
			} else if( button == '대출신청' ){
				btn_class = 'book_btn_blue';
			}
			obj.row[key].L_BUTTON_CLASS = btn_class;
		}

		_view.empty().mustache('BOOK102_tmpl-view', obj);
		setTab();

		if( _reset_scroll ) {
			_reset_scroll = false;
			_layout.resetLayout();
		}
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function setTab() {
		_rd_view.prop("checked", _is_view);
		_rd_view.checkboxradio("refresh");
		_rd_list.prop("checked", !_is_view);
		_rd_list.checkboxradio("refresh");

		var tab_view = $this.find('#tab_view');
		var tab_list = $this.find('#tab_list');
		if( tab_view && tab_list ) {
			if( _is_view ) {
				tab_view.show();
				tab_list.hide();
			} else {
				tab_view.hide();
				tab_list.show();
			}
		}
	}

	function onClickTab(e) {
		_is_view = e.target.id == 'rd_view';
		setTab();
		_layout.scrollTo(0, 0);
		_layout.resetLayout();
		_layout.refreshLayout();
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}

	function onClickBook() {
		_book_me = $(this);
		_book_id = _book_me.data('book_id');
		switch( _book_me.text() ) {
			case '대출신청':
				showConfirm(function(btn) {
					if (btn == '1') {
						requestBook('BOOK0006');
					}
				}, "대출신청을 하시겠습니까?");
				break;
			case '예약신청':
				onBookReserve();
				break;
			case '예약하기':
				showConfirm(function(btn) {
					if (btn == '1') {
						requestBook('BOOK0004');
					}
				}, "예약신청을 하시겠습니까?");
				break;
			case '예약취소':
				showConfirm(function(btn) {
					if (btn == '1') {
						requestBook('BOOK0005');
					}
				}, "예약취소를 하시겠습니까?");
				break;
		}
		return false;
	}

	function onBookReserve() {
		var is_selected = _book_me.hasClass('selected');
		$this.find('.book_btn_green').removeClass('selected');
		$this.find('.tr_reserve').hide();

		if( is_selected ) {
			_layout.refreshLayout();
			return;
		}

		_book_me.addClass('selected');
		requestBook('BOOK0003');
	}

	function requestBook(procedure) {
		var opt = {
			onSuccess : (procedure == 'BOOK0003') ? onSuccessBookList : onSuccessBook,
			onFailure : onFailureBook,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : procedure,
			parameters : [{
				CS_ID : _menuId,
				mast_id : _mast_id + '',
				book_id : _book_id + ''
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessBook(data) {
		dgbLoading(false);
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			showAlert("알림", Messages.msg110, function(){ DGB.Common.appExit(); });
		} else {
			showAlert('알림', obj.msg, obj.success ? function() { request(); } : null);
		}
	}

	function onSuccessBookList(data) {
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			dgbLoading(false);
			showAlert("알림", Messages.msg110, function(){ DGB.Common.appExit(); });
			return;
		}

		if( !obj.success ) {
			dgbLoading(false);
			_book_me.removeClass('selected');
			showAlert(obj.msg);
			return;
		}

		var index = 1;
		for(var i in obj.items) {
			obj.items[i].L_INDEX = index++;
		}
		_reserve_view.empty().mustache('BOOK102_tmpl-reserve_view', { items : obj.items, L_REALREG : _book_id });
		$this.find('#div_' + _book_id).html(_reserve_view.html());
		$this.find('#tr_' + _book_id).show(300);
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailureBook(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		parentpage : _parentpage,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BOOK102');

	$(document).on('vclick', '#BOOK102 .book_button', onClickBook);
})();

