(function() {
	var PAGE_COUNT = 10;
	var $this, _menuId, _layout, _list, _is_lend, _refresh = true, _rd_lend, _rd_reserve;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
		_list = $this.find('#list');
		$this.find('#rd_tab').on('change', onClickTab);
		_rd_lend = $this.find('#rd_lend');
		_rd_reserve = $this.find('#rd_reserve');

		$.Mustache.add('BOOK301_tmpl-list', $this.find('#tmpl-list').html());
		_list.mustache('BOOK301_tmpl-list', { row : [] });
		_layout.refreshLayout(function() {});
	}

	function _pageshow() {
		DGB.Common.backMenu();
		if( _refresh ) {
			_refresh = false;
			_is_lend = true;
			setTab();
			request();
		}
	}

	function setTab() {
		_rd_lend.prop("checked", _is_lend).checkboxradio("refresh");
		_rd_reserve.prop("checked", !_is_lend).checkboxradio("refresh");
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : _is_lend ? 'BOOK0009' : 'BOOK0010',
			parameters : [{
				CS_ID : _menuId
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			dgbLoading(false);
			showAlert("알림", Messages.msg110, function () { DGB.Common.appExit(); });
			return;
		}

		_list.empty().mustache('BOOK301_tmpl-list', { row : obj.row } );
		_layout.scrollTo(0, 0);
		_layout.resetLayout();
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function requestBook(book_id) {
		var opt = {
			onSuccess : onSuccessBook,
			onFailure : onFailureBook,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : _is_lend ? 'BOOK0011' : 'BOOK0005',
			parameters : [{
				CS_ID : _menuId,
				book_id : book_id
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessBook(data) {
		dgbLoading(false);
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			showAlert("알림", Messages.msg110, function () { DGB.Common.appExit(); });
		} else {
			showAlert('알림', obj.msg, obj.success ? function() { request(); } : null);
		}
	}

	function onFailureBook(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}


	function onClickItem() {
		var mast_id = $(this).data('mast_id');
		if( !mast_id ) {
			showAlert(Messages.err001);
			return false;
		}
		var param = [{ menuId : _menuId, mast_id : mast_id }];
		DGB.Page.triggerPage("#BOOK102", "parentpage", param);
		DGB.Page.changePage('#BOOK102');
		return false;
	}

	function onClickCancel() {
		var book_id = $(this).data('book_id');
		var msg = _is_lend ? '대출신청을 취소하시겠습니까?' : '예약신청을 취소하시겠습니까?';
		showConfirm(function(btn) {
			if (btn == '1') {
				requestBook(book_id);
			}
		}, msg);
		return false;
	}

	function onClickTab(e) {
		_is_lend = (e.target.id == 'rd_lend');
		request();
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			if( !param.activePage ) {
				_refresh = true;
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BOOK301');

	$(document).on('vclick', '#BOOK301 .book_item', onClickItem);
	$(document).on('vclick', '#BOOK301 .book_btn_cancel', onClickCancel);
})();
