(function() {
	var PAGE_COUNT = 10;
	var $this, _menuId, _layout, _list, _pullUp, _current, _page, _refresh = true, _rd_current, _rd_all;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT + COMMON_SEARCH_HEIGHT + 12);
		_list = $this.find('#list');
		_pullUp = $this.find('.pullUp');
		$this.find('#rd_tab').on('change', onClickTab);
		_rd_current = $this.find('#rd_current');
		_rd_all = $this.find('#rd_all');

		$.Mustache.add('BOOK201_tmpl-list', $this.find('#tmpl-list').html());
		_list.mustache('BOOK201_tmpl-list', { row : [] });
		_layout.refreshLayout(function() {});
	}

	function _pageshow() {
		DGB.Common.backMenu();
		if( _refresh ) {
			_refresh = false;
			_current = 'Y';
			_page = 1;
			setTab();
			request();
		}
	}

	function setTab() {
		_rd_current.prop("checked", _current == 'Y').checkboxradio("refresh");
		_rd_all.prop("checked", _current == '').checkboxradio("refresh");
	}

	function _pulluprefresh() {
		if ( _pullUp.is(':visible') ) {
			_page++;
			request();
		}
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : 'BOOK0007',
			parameters : [{
				CS_ID : _menuId,
				page : _page + '',
				current : _current
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			dgbLoading(false);
			showAlert("알림", Messages.msg110, function(){ DGB.Common.appExit(); });
			return;
		}

		for(var i in obj.row) {
			if( obj.row[i].L_DELAY_REG == '연기불가' ) {
				obj.row[i].L_DELAY_CLASS = 'book_btn_delay_red';
			} else  {
				obj.row[i].L_DELAY_CLASS = 'book_btn_delay_blue';
			}

			if( obj.row[i].L_STATUS == '연체중' ) {
				obj.row[i].L_STATUS_CLASS = 'book_info_delay_state';
			} else  {
				obj.row[i].L_STATUS_CLASS = '';
			}
		}

		if( obj.row.length < PAGE_COUNT ) {
			_pullUp.hide();
		} else {
			_pullUp.show();
		}

		if( _page == 1 ) {
			_list.empty().mustache('BOOK201_tmpl-list', { row : obj.row } );
			_layout.scrollTo(0, 0);
			_layout.resetLayout();
		} else if( obj.row.length > 0 ) {
			_list.mustache('BOOK201_tmpl-list', {row: obj.row});
		}
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function requestBook(book_id) {
		var opt = {
			onSuccess : onSuccessBook,
			onFailure : onFailureBook,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : 'BOOK0008',
			parameters : [{
				CS_ID : _menuId,
				book_id : book_id
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccessBook(data) {
		dgbLoading(false);
		var obj = data.invocationResult || {};
		if( obj.session_error ) {
			showAlert("알림", Messages.msg110, function () { DGB.Common.appExit(); });
		} else {
			showAlert('알림', obj.msg, obj.success ? function() { request(); } : null);
		}
	}

	function onFailureBook(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}


	function onClickItem() {
		var mast_id = $(this).data('mast_id');
		if( !mast_id ) {
			showAlert(Messages.err001);
			return false;
		}
		var param = [{ menuId : _menuId, mast_id : mast_id }];
		DGB.Page.triggerPage("#BOOK102", "parentpage", param);
		DGB.Page.changePage('#BOOK102');
		return false;
	}

	function onClickDelay() {
		var text = $(this).text();
		if( text == '연기불가' ) {
			showAlert('연기불가 상태입니다!');
		} else {
			var book_id = $(this).data('book_id');
			showConfirm(function(btn) {
				if (btn == '1') {
					requestBook(book_id);
				}
			}, "연기신청을 하시겠습니까?");
		}
		return false;
	}

	function onClickTab(e) {
		_page = 1;
		_current = (e.target.id == 'rd_current') ? 'Y' : '';
		request();
		return false;
	}

	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			if( !param.activePage ) {
				_refresh = true;
			}
		},
		pulluprefresh : _pulluprefresh,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BOOK201');

	$(document).on('vclick', '#BOOK201 .book_item', onClickItem);
	$(document).on('vclick', '#BOOK201 .book_btn_delay', onClickDelay);
})();
