(function() {
	var MODE = { SEARCH : 0, LIST : 1 };
	var PAGE_COUNT = 10;

	var $this, _menuId, _layout, _list, _items_search, _items_list, _mode, _page, _record_type, _search;
	var _search_input, _search_button, _pullUp, _move_top, _reset_data;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT + 12);
		_list = $this.find('#list');
		_search_input = $this.find('#search_input');
		_search_button = $this.find('#btn_search');
		_pullUp = $this.find('.pullUp');
		_move_top = $this.find('.move_top');

		setMode(MODE.SEARCH, 1, '', '');
		_items_search = { items : [] };
		_items_list = { items : [] };

		$.Mustache.add('BOOK101_tmpl-list', $this.find('#tmpl-list').html());
		_list.mustache('BOOK101_tmpl-list', _items_search);
		_layout.refreshLayout(function() {});

		_move_top.on('vclick', onMoveTop);
		_search_input.on('keypress', onKeypressSearch);
		_search_button.on('vclick', onClickSearch);
	}

	function resetData() {
		_items_search.items = [];
		_search_input.focus();
		_search_input.val('');
		setMode(MODE.SEARCH, 1, '', '');
		_list.empty().mustache('BOOK101_tmpl-list', _items_search);
		$this.find('.book_prev').hide();
		_layout.resetLayout();
		_layout.refreshLayout();
	}

	function _pageshow() {
		DGB.Common.backMenu();
		if( _reset_data ) {
			_reset_data = false;
			resetData();
		}
	}

	function _pulluprefresh() {
		if ( _pullUp.is(':visible') ) {
			_page++;
			request();
		}
	}

	function valueCheck() {
		var text = _search_input.val() || '';
		if( text.length < 1 ){
			showAlert("검색어를 입력해 주세요.");
			return false;
		}
		return true;
	}

	function setMode(mode, page, type, search) {
		if( mode == MODE.SEARCH ) {
			_pullUp.hide();
		}
		_mode = mode;
		_page = page;
		_record_type = type;
		_search = search;
	}

	function request() {
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		var inv = {
			adapter : 'BookAdapter',
			procedure : 'BOOK0001',
			parameters : [{
				CS_ID : _menuId,
				record_type : _record_type,
				search : _search,
				page : _page + ''
			}]
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	function onSuccess(data) {
		if( data.invocationResult.session_error ) {
			dgbLoading(false);
			showAlert("알림", Messages.msg110, function(){ DGB.Common.appExit(); });
			return;
		}

		var list = data.invocationResult.list || {};
		if( _mode == MODE.SEARCH ) {
			_items_search.items = [];
			for(var key in list) {
				var obj = list[key];
				if( obj.count > 0 ) {
					_items_search.items.push(list[key]);
				}
			}
			_list.empty().mustache('BOOK101_tmpl-list', _items_search);
			$this.find('.book_prev').hide();
			_layout.resetLayout();
		} else {
			var add_count = 0;
			for(var key in list) {
				if( _page == 1 ) {
					_items_list.items = [];
					_items_list.items.push(list[key]);
					add_count = _items_list.items[0].row.length;
				} else {
					for(var i in list[key].row) {
						_items_list.items[0].row.push(list[key].row[i]);
						add_count++;
					}
				}
			}

			if( add_count < PAGE_COUNT ) {
				_pullUp.hide();
			} else {
				_pullUp.show();
			}
			_list.empty().mustache('BOOK101_tmpl-list', _items_list );

			$this.find('.book_prev').show();
			if( _page == 1 ) {
				_layout.resetLayout();
			}
		}
		_layout.refreshLayout(function() {
			dgbLoading(false);
		});
	}

	function onFailure(data) {
		dgbLoading(false);
		showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
	}

	function onRefreshPrev() {
		setMode(MODE.SEARCH, 1, '', _search);
		_list.empty().mustache('BOOK101_tmpl-list', _items_search);
		_layout.resetLayout();
		_layout.refreshLayout();
		return false;
	}

	function onKeypressSearch(e) {
		if( e.keyCode == 13 ) {
			if( valueCheck() ){
				DGB.Common.hideKeyboard();
				_search_button.focus();
				setMode(MODE.SEARCH, 1, '', _search_input.val());
				setTimeout(request, 300);
			}
			return false;
		}
	}

	function onClickSearch() {
		if( valueCheck() ) {
			_search_button.focus();
			setMode(MODE.SEARCH, 1, '', _search_input.val());
			request();
		}
		return false;
	}

	function onClickItem() {
		var mast_id = $(this).data('mast_id');
		if( !mast_id ) {
			showAlert(Messages.err001);
			return false;
		}
		var param = [{ menuId : _menuId, mast_id : mast_id }];
		DGB.Page.triggerPage("#BOOK102", "parentpage", param);
		DGB.Page.changePage('#BOOK102');
		return false;
	}

	function onClickRecord() {
		var record_type = $(this).data("record_type");
		var is_append = $(this).data("is_append");
		if( _mode == MODE.SEARCH && is_append ) {
			setMode(MODE.LIST, 1, record_type, _search);
			request();
		}
		return false;
	}

	function onMoveTop() {
		_layout.scrollTo(0, 0, 300);
		return false;
	}


	$(document).on({
		pageinit : _pageinit,
		pageshow : _pageshow,
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
			_reset_data = !param.activePage;
		},
		pulluprefresh : _pulluprefresh,
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#BOOK101');

	$(document).on('vclick', '#BOOK101 .book_item', onClickItem);
	$(document).on('vclick', '#BOOK101 .record_title, #BOOK101 .book_more', onClickRecord);
	$(document).on('vclick', '#BOOK101 .book_prev', onRefreshPrev);
})();
