(function() {
	var $this,_layout;

	var pageinit = function() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		_layout.refreshLayout();

		$this.find('#email_set').on('vclick', function() {});
	};

	function _pageshow() { }

	$(document).on({
        pageinit : pageinit,
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: _pageshow,
		selectmenu : function() {},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
			return false;
		}
	}, '#SP00001');
})();
