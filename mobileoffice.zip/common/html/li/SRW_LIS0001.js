(function() {
    var $this, _search_input, _search_button, _menuId, _scroll_y = {};
    var  _list, _layout, _lis_list, _parent_title, _btn_back, _btn_chat;
    var all_list = {};
    var file_list = [];
    var map_list = new DGB.HashMap();
    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT + 60);

        _list = $this.find('#list');
        _search_input = $this.find('#search_input');
        _search_button = $this.find('#btn_search');
        _parent_title = $this.find('#parent_title');
        _btn_back = $this.find('#btn_back');
        _btn_chat = $this.find('#btn_chat');
        _search_input.on('keypress', onKeypressSearch);
        _search_button.click( onClickSearch );
        _btn_chat.on('vclick', function() { _btn_chat.hide(); DGB.Common.openChatBot(); return false; });
        $this.find('#btn_back').click( onClickBack );
        $this.find('#btn_root').click( onClickRoot );

        $.Mustache.add('LIS0001_tmpl-list', $this.find('#tmpl_list').html());
    }

    function _pageshow() {
        DGB.Common.backMenu();
        _btn_chat.hide();

        if( !_lis_list ){
            request();
        } else {
            callChatBot();
        }
    }

    function callChatBot() {
        if( GLOBAL.CHATBOT && GLOBAL.CHATBOT.search ) {
            _search_input.val(GLOBAL.CHATBOT.search);
            onClickSearch();
            GLOBAL.CHATBOT = null;
            _btn_chat.show();
        }
    }

    function request() {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'LISAdapter',
            procedure : 'LIS0001',
            parameters : [{
                CS_ID : _menuId,
                ENOB : GLOBAL.ENOB
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var obj = data.invocationResult || {};
        if( !obj.success ) {
            dgbLoading(false);
            showAlert(obj.msg);
            return;
        }

        var row = obj.row;
        var depth_list = {};
        for( var i in row ) {
            row[i].DEPTH = parseInt(row[i].DEPTH) + '';
            row[i].SEQ = parseInt(row[i].SEQ) + '';
            row[i].ID = parseInt(row[i].ID) + '';
            row[i].PID = parseInt(row[i].PID) + '';
            if( row[i].FOLDER == 'N' ){
                row[i].URL = row[i].URL + row[i].SEQ;
            }
            
            if( !depth_list[row[i].DEPTH] ) {
                depth_list[row[i].DEPTH] = [];
            }
            depth_list[row[i].DEPTH].push(row[i]);
            map_list.put(row[i].ID, row[i]);
        }

        make(all_list, depth_list, 0);
        all_list.TITLE = "규정 정보";
        all_list.SUBTITLE = "규정 정보";

        _lis_list = all_list;
        drawList();

        // 챗봇요청
        callChatBot();
    }

    function drawList(){
        _lis_list.ID ? _btn_back.show() : _btn_back.hide();
        _parent_title.text(_lis_list.TITLE);

        _list.empty().mustache('LIS0001_tmpl-list', _lis_list);
        _layout.resetLayout();
        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function make( parent, child, depth ) {
        if( !parent.CHILDS ) {
            parent.CHILDS = [];
        }
        var childs = child[depth];
        for( var i in childs ) {
            var item = childs[i];
            if( depth == 0 || parent.ID == item.PID ) {
                item.SUBTITLE = parent.SUBTITLE ? parent.SUBTITLE + ' > ' + parent.TITLE : parent.TITLE;
                item.ICON = (item.FOLDER == 'N') ? 'icon_file' : 'icon_folder';
                    parent.CHILDS.push(item);
                if( item.URL ) {
                    file_list.push(item);
                }
                make(item, child, depth + 1);
            }
        }
    }

    function onKeypressSearch(e) {
        if( e.keyCode == 13 ) {
            DGB.Common.hideKeyboard();
            _search_button.focus();
            onClickSearch();
            return false;
        }
    }

    function onClickSearch() {
        var text = _search_input.val();
        if( !text ) {
            showAlert("검색어를 입력해 주세요!");
            _search_input.focus();
            return false;
        }

        // 공백제거 ( 다중검색 )
        var temp = text.split(' ');
        var words = [];
        for(var j in temp) {
            if( temp[j] ) {
                words.push(temp[j]);
            }
        }

        _scroll_y = {};                 // 스크롤 위치 초기화
        _lis_list = { CHILDS : [] };
        _lis_list.TITLE = "검색 : " + words.join(', ');
        for(var i in file_list) {
            for(var j in words) {
                var word = words[j];
                if(file_list[i].TITLE.indexOf(word) > -1 || file_list[i].SEQ.indexOf(word) > -1) {
                    _lis_list.CHILDS.push(file_list[i]);
                }
            }
        }

        dgbLoading(true);
        setTimeout(function() { drawList(); }, 300);
        return false;
    }

    function onClickRoot() {
        _scroll_y = {};         // 스크롤 위치 초기화
        _search_input.val('');  // 검색어 초기화
        _lis_list = all_list;
        drawList();
        return false;
    }

    function onClickItem() {
        var url = $(this).data('url');
        var title = $(this).data('title');
        var file = $(this).data('doc');
        if( url ) {
            callDaview({ url : url }, title, file);
        } else {
            // 이전화면[텝스로 관리] 스크롤 위치 저장
            _scroll_y[_lis_list.DEPTH || 'ROOT'] = _layout.getScroller().y || 0;

            var index = $this.find(".lis_list").index(this);
            _lis_list = _lis_list.CHILDS[index];
            drawList();
        }
        return false;
    }

    function onClickBack() {
        if(_lis_list.PID) {
            _lis_list = _lis_list.PID == '0' ? all_list : map_list.get(_lis_list.PID);
            drawList();

            // 이전위치로 이동
            var y = _scroll_y[_lis_list.DEPTH || 'ROOT'] || 0;
            if( y < 0 ) {
                _layout.getScroller().scrollTo(0, y);
            }
        }
        return false;
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        selectmenu : function(e, p) {
            if ( _lis_list && p.activePage ) {
                callChatBot();
            }
        },
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#LIS0001');

    $(document).on('vclick', '#LIS0001 .lis_list', onClickItem);
})();