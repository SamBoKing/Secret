(function() {
	var $this;
	var brachNum = "";
	var _menuId;
	var _layout;
    var _buttonText;
	var locDetailview = false;
    var tableCard, tableBanka, tableTrust, tableFundP,tableFundB, tableFx;
	var divFundP, divFundB;
    var baseDate;
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _buttonText = $this.find('#resiOrgNm').prev('span').find('.ui-btn-text');

        tableCard = $this.find('#cardRecordTable tbody');
        tableBanka = $this.find('#bankaRecordTable tbody');
        tableTrust = $this.find('#trustRecordTable tbody');
        tableFx = $this.find('#fxRecordTable tbody');
        tableFundP = $this.find('#fundPRecordTable tbody');
        tableFundB = $this.find('#fundBRecordTable tbody');
        divFundP = $this.find('#fundPRecordDiv');
        divFundB = $this.find('#fundBRecordDiv');

        // 모점, 자점 리스트 초기화
        USER_INFO.BRBAS = USER_INFO.BRBAS || [];

		if( DGB.isIPhone() ) {  // 폰트사이즈 조정
            $this.find('table').css('font-size', '12px');
            $this.find('.ui-grid-a div > h3').css('fontSize', '14px');
		}

        // 영업점변경
        $this.find('#resiOrgNm').off('vclick').on('vclick', function() {
            clickGroup();
            return false;
        });

        // 은행전체로 다시 조회
        $this.find('#bankInfoBtn').off('vclick').on('vclick', function() {
            searchBranch = "999";
            searchBranchName = "영업점변경";
            setContents();
            return false;
        });

        // 영업계수 조회
        $this.find('#businessFigureBtn').off('vclick').on('vclick', function() {
            DGB.Page.triggerPage("#RESI001", "selectbutton", {'menuId':"RE0101"});
            DGB.Page.changePage('#RESI001');
            return false;
        });

        // 영업점현황 조회
        $this.find('#branchInfoBtn').off('vclick').on('vclick', function() {
            DGB.Page.triggerPage("#RESI004", "selectbutton", {'menuId':"RE0102"});
            DGB.Page.changePage('#RESI004');
            return false;
        });

        // 소속직원보기
        $this.find('#branchStaffBtn').off('vclick').on('vclick', function() {
            if(brachNum === "999") {		// 은행전체인 경우에는 소속직원 보기 안됨
                showAlert(Messages.msg051);
                return false;
            }
            locDetailview = true;
            DGB.Page.triggerPage("#RESI003", "selectmenu", {'menuId':"EM0101", options:{'type':'3', 'keyword':brachNum}});
            DGB.Page.changePage('#RESI003');
            return false;
        });

        var toDay = new Date();
        toDay.setDate(toDay.getDate()-1);
        baseDate = nmf.utils.DateFormat.format(toDay, 'yymmdd');
        $('#RESI005 #rebmDate').val(baseDate);
	};

    function clickGroup() {
        if( DGB.Common.isAdminMember() ) {
            var args = {
                menuId : _menuId,
                parentId : "RESI005"
            };
            DGB.Page.triggerPage("#RESI002", "parentpage", [args]);
            setTimeout(function () { DGB.Page.changePage('#RESI002'); }, 200);

        } else if(USER_INFO.GROUP_ID == "G003" && USER_INFO.BRBAS.length > 1 ) {
            var BRNames = [];
            for(var i=0; i<USER_INFO.BRBAS.length; i++){
                BRNames.push(USER_INFO.BRBAS[i].BRC_NM);
            }

            DGB.Common.selectList("지점 선택", BRNames,
                function(index) {
                    searchBranch = USER_INFO.BRBAS[index].BRNO;
                    searchBranchName = USER_INFO.BRBAS[index].BRC_NM;
                    setContents();
                },
                function(err) { }
            );
        } else {
            showAlert(Messages.msg009);
        }
    }
	
	function setContents() {
        if( DGB.Common.isAdminMember() ) {
            brachNum = searchBranch || "999";
            _buttonText.text(brachNum == "999" ? "영업점변경" : searchBranchName);
        } else if(USER_INFO.GROUP_ID != "G003" && Number(USER_INFO.ORG_CD) > 900) {
            brachNum = "999";
            _buttonText.text("은행전체");
        } else {
            // 일반 영업점 직원의 경우 영업점현황, 소속직원보기 가능, 조회영업점변경 불가능
            brachNum = searchBranch || USER_INFO.WORKORG_CD;
            _buttonText.text(searchBranchName || USER_INFO.WORKORG_NM);
            $this.find('#bankInfoBtn').button('disable');
        }

        // 본부직원이면서 임원이 아닌 경우엔 [소속직원보기], [영업점현황] 조회 권한 없음
        if(Number(USER_INFO.ORG_CD) > 900 && !DGB.Common.isAdminMember() ) {
            //$this.find('.optionFunc').hide();
            showAlert('영업점현황 조회 권한이 없습니다.');
            DGB.Page.changePage('#freeSv');
            return;
        }

        baseDate = $('#RESI005 #rebmDate').val();
        if(baseDate.length != 8) {
            showAlert(Messages.msg05B);
            return false;
        }

		_layout.refreshLayout();

        var callProcedureId = brachNum == "999" ? 'TRE00111' : 'TRE00112';
        var invocationData = {
            adapter : 'SocketTransactionAdapter',
            procedure : callProcedureId,
            parameters : [{
                SEARCH_BRANCH : brachNum,
                ORG_CD : USER_INFO.ORG_CD,
                TELLER_NUM : USER_INFO.ENOB,
                VS_BASIS_YMD : baseDate,
                CS_ID:_menuId
            }]
        };

        var options = {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        };

        if( !locDetailview ) {
            dgbLoading(true);
            callProcedure(invocationData, options);
        }
        locDetailview = false;
	}

	function displayResult(data) {
        $('#RESI005 #foreignExchangeRecordTable tbody').html('');

        _layout.resetLayout();

        var item = data.invocationResult;
        var card = item.cardRecord;
        var banka = item.bankaRecord;
        var trust = item.trustRecord;
        var fx = item.foreignExchangeRecord;
        var fundP = item.fundPRecord;
        var fundB = item.fundBRecord;

        if(card) {
            $this.find('#cardAmtUnit').text("신용카드 실적(단위 : "+ card.AMT_UNIT+")");
            // 카드 실적
            tableCard.find('#WK_CARD_Q_MOK').text(commaNum(card.TRGAMT?card.TRGAMT:'0'));
            tableCard.find('#WK_BANG_Q_PREM').text(commaNum(card.ARAMT?card.ARAMT:'0'));
            tableCard.find('#WK_BANG_Q_RATE').text(numberWithComma(card.ATTARATE?card.ATTARATE:'0'));
        }
        if(banka) {
            $this.find('#bankaAmtUnit').text("방카 실적(단위 : "+ banka.AMT_UNIT+")");
            // 방카 실적
            tableBanka.find('#WK_BANG_YEAR_MOK').text(commaNum(banka.TRGAMT ? banka.TRGAMT : '0'));
            tableBanka.find('#WK_BANG_YEAR_PREM').text(commaNum(banka.ARAMT ? banka.ARAMT : '0'));
            tableBanka.find('#WK_BANG_YEAR_RATE').text(numberWithComma(banka.ATTARATE?banka.ATTARATE:'0'));
        }
        if(trust) {
            $this.find('#trustAmtUnit').text("신탁 실적(단위 : "+ trust.AMT_UNIT+")");
            // 신탁 실적
            tableTrust.find('#WK_20_SIL1').text(commaNum(trust.BQ_AVGBL?trust.BQ_AVGBL:'0')); //전분기말평잔
            tableTrust.find('#WK_20_SIL2').text(commaNum(trust.BMONTH_AVGBL?trust.BMONTH_AVGBL:'0')); //전월말평잔
            tableTrust.find('#WK_20_SIL3').text(commaNum(trust.BMONTH_BYD?trust.BMONTH_BYD:'0')); //전월대비
            tableTrust.find('#WK_20_SIL4').text(commaNum(trust.BW1_AVGBL?trust.BW1_AVGBL:'0')); //금일평잔
        }

        if(fx) {
            $this.find('#fxAmtUnit').text("외환 실적(단위 : "+ fx.AMT_UNIT+")");
            // 외환 실적
            tableFx.find('#WK_FX_Q_MOK').text(commaNum(fx.TRGAMT?fx.TRGAMT:'0'));
            tableFx.find('#WK_FX_Q_PREM').text(commaNum(fx.ARAMT?fx.ARAMT:'0'));
            tableFx.find('#WK_FX_Q_RATE').text(numberWithComma(fx.ATTARATE?fx.ATTARATE:'0'));
        }

        if(fundP) {
            divFundP.removeClass('displayNone');
            $this.find('#fundPAmtUnit').text("개인영업점펀드 실적(단위 : "+ fundP.AMT_UNIT+")");
            // 펀드 실적(개인)
            tableFundP.find('#WK_FNDP_Q_MOK').text(commaNum(fundP.TRGAMT?fundP.TRGAMT:'0'));
            tableFundP.find('#WK_FNDP_PREM').text(commaNum(fundP.ARAMT?fundP.ARAMT:'0'));
            tableFundP.find('#WK_FNDP_RATE').text(numberWithComma(fundP.ATTARATE?fundP.ATTARATE:'0'));
        }else{
            divFundP.addClass('displayNone');
        }

        if(fundB) {
            divFundB.removeClass('displayNone');
            $this.find('#fundBAmtUnit').text("기업영업점펀드 실적(단위 : "+ fundB.AMT_UNIT+")");
            // 펀드 실적(기업)
            tableFundB.find('#WK_FNDB_Q_MOK').text(commaNum(fundB.TRGAMT?fundB.TRGAMT:'0'));
            tableFundB.find('#WK_FNDB_PREM').text(commaNum(fundB.ARAMT?fundB.ARAMT:'0'));
            tableFundB.find('#WK_FNDB_RATE').text(numberWithComma(fundB.ATTARATE?fundB.ATTARATE:'0'));
        }else{
            divFundB.addClass('displayNone');
        }

        item = null;
        _layout.refreshLayout(function(){
            dgbLoading(false);
        }, 200);
    }

	function displayError() {
		showAlert(Messages.msg030);
		dgbLoading(false);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function(){
            setContents();
        },
		pagebeforehide: function() {
			if( !locDetailview ) {
				$('#RESI005 table td').val('');
			}
		},
		selectbutton: function(param) {
			_menuId = param.menuId;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		parentpage :function (evt, param) {
			searchBranch = param.searchBranch;
			if(searchBranch.length == 1) searchBranch = "00" + searchBranch;
			else if(searchBranch.length == 2) searchBranch = "0" + searchBranch;

			$('#RESI005 #resiOrgNm').prev('span').find('.ui-btn-text').text(param.branchName);
			searchBranchName = param.branchName;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RESI005');
})();
