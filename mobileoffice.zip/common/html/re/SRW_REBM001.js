(function() {
	var $this = undefined;
	var brachNum = "";
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;
	var curPage = 1;
	var _pageSize = 50; // 한페이지 갯수
	var listSearch = null;
	var f1ilibr = undefined;
	var f1gmtot = undefined;
	var mapCode = undefined;
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;
		mapCode = new DGB.HashMap();
		mapCode.put("ATM","자동화");//자동화기기
		mapCode.put("BAT","배치");
		mapCode.put("CTC","센터컷");//센터컷서버
		mapCode.put("DMN","데몬");
		mapCode.put("EBC","전자금융채널");//전자금융채널
		mapCode.put("EBZ","전자금융서버");//전자금융서버
		mapCode.put("FRG","대외서버");
		mapCode.put("GON","공과금");//공과금서버
		mapCode.put("IVR","IVR");//IVR서버
		mapCode.put("TOD","단말");//통합단말기
		mapCode.put("UBS","단위업무");//단위업무서버
		_layout = new DGB.layout($this, _headerHeight);
		if(WL.Client.getEnvironment() == WL.Environment.IPHONE) {  // 폰트사이즈 조정
			$('#REBM001 table').css('font-size', '12px');
			$('.ui-grid-a div > h3').css('fontSize', '14px');
		}

        // BRBAS 없을시 초기화 작업
        USER_INFO.BRBAS = USER_INFO.BRBAS || [];

		// 영업점변경
		$this.find('#rebmOrgNm').off('vclick').on('vclick', function() {
			if( DGB.Common.isAdminMember() ) {
				var detailId ="RESI002";
				var args = {};
				args.menuId = _menuId;
				args.parentId = "REBM001";
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
				
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
			} else if(USER_INFO.GROUP_ID == "G003" && USER_INFO.BRBAS.length > 1 ){
				DGB.Log.d("[SRW_REBM001] USER_INFO.BRBAS.length : " +USER_INFO.BRBAS.length);
				var BRNames = [];
				
				for(var i=0; i<USER_INFO.BRBAS.length; i++){
					DGB.Log.d("[SRW_REBM001] Branch Name : " +JSON.stringify(USER_INFO.BRBAS[i]));
					BRNames.push(USER_INFO.BRBAS[i].BRC_NM);
				}
				
				DGB.Common.selectList("지점 선택", BRNames,
		                function(index) {
							brachNum = USER_INFO.BRBAS[index].BRNO;
							$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text(USER_INFO.BRBAS[index].BRC_NM);
		                },
		                function(err) {
		                    DGB.Log.e('[SRW_REBM001] ====>> Error : ' + err);
		                }
		            );
			} else {
				showAlert(Messages.msg009);
			}
		});
		
		if (WL.Client.getEnvironment() == WL.Environment.IPHONE || WL.Client.getEnvironment() == WL.Environment.IPAD) {
			$('#REBM001 .custIscroll').bind('tap', function() {
				$('#REBM001 input').blur();
				$('#REBM001 #rebmMoneySelectbox').blur();
			});
		}
		
		// 조회 버튼
		$this.find('#rebmSearch').off('vclick').on('vclick', function() {
			$('#REBM001 #rebmDate').blur();
            listSearch.call();
            return false;
		});
		
		// 이전 버튼
		$this.find('#rebmBeforeBtn').off('vclick').on('vclick', function() {
			curPage -= 1;
            listSearch.call();
            return false;
		});
		
		// 다음 버튼
		$this.find('#rebmAfterBtn').off('vclick').on('vclick', function() {
			curPage += 1;
            listSearch.call();
            return false;
		});
		
		// 조회금액 변경
		$this.find('#rebmMoneySelectbox').on('change', function(){
			f1gmtot = $('#rebmMoneySelectbox:visible option:selected').val();
			curPage = 1;
			listSearch.call();
            return false;
		});
		
		f1ilibr = nmf.utils.DateFormat.format(new Date(), 'yymmdd');
		$('#REBM001 #rebmDate').val(f1ilibr);
	};
	
	function setContents() {
		
		if(searchBranch != undefined && searchBranch != "999") {
			$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text(searchBranchName);
		} else if(searchBranch === "999") {
			$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text("영업점변경");
		}
		
		if( DGB.Common.isAdminMember() ) {
			brachNum = searchBranch;
		} else if(Number(USER_INFO.ORG_CD) > 900) {
			// 본부부서 직원의 경우 메뉴 안나옴
			showAlert(Messages.msg00B);
			return false;
		} else if(USER_INFO.MANAGE_CD != "11" && USER_INFO.MANAGE_CD != "5") {
			showAlert(Messages.msg00B);
			return false;
		} else {
			// 일반 영업점 직원의 경우 근무지점만 조회
			brachNum = USER_INFO.WORKORG_CD;
//			$('#rebmOrgNm').prop('disabled', true);
			$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text(USER_INFO.ORG_NM);
		}
		_layout.refreshLayout();
		
		if(brachNum == undefined || brachNum == "") {
			showAlert(Messages.msg05A);
			return false;
		}
        if(window.orientation != 0){
            $('#REBM001 .landshow').removeClass("displayNone");
        }
        else{
            $('#REBM001 .landshow').addClass("displayNone");
        }

		curPage = 1;
        listSearch.call();
	}

	listSearch = {
		options : {
			onSuccess : displayBigMoneyResult,
			onFailure : displayBigMoneyError,
			invocationContext : {}
		},

		call : function() {

			if(brachNum == undefined || brachNum == "") {
				showAlert(Messages.msg05A);
				return false;
			}

			if(f1ilibr != $('#REBM001 #rebmDate').val()) {
				curPage = 1;
			}
			f1ilibr = $('#REBM001 #rebmDate').val();
			if(f1ilibr.length != 8) {
				showAlert(Messages.msg05B);
				return false;
			}
			
			f1gmtot = $('#rebmMoneySelectbox:visible option:selected').val();
			
			var startNum = (curPage - 1) * _pageSize + 1;
			var endNum = curPage * _pageSize;
			dgbLoading(true);
			var inv = {
					adapter : 'SocketTransactionAdapter',
					procedure : "TRE00108",
					parameters : [{TELLER_NUM : USER_INFO.ENOB, ACITM_BRNO : brachNum, TDT : f1ilibr, TOT_TRNS_AMT : f1gmtot,
						START_NUM : startNum, END_NUM : endNum, CS_ID:_menuId}]
			};
			callProcedure(inv, this.options);
		}
	};
	
	function displayBigMoneyResult(data) {
		$('#REBM001 #rebmBigMoney tbody').html('');
		$('#rebmResultTitle').text("수신거액이동명세 - "+$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text());	
		
		var item = data.invocationResult.bigMoneyMove;
        var result = item.resultSet;
        if(item.PRCS_RSLT_DVCD != undefined && item.PRCS_RSLT_DVCD == "0") {
			var row_count = Number(item.ROW_COUNT);
			var html = "";
			var listItems = [];
			var custNm = "";
			for(var i=0; i<row_count; i++) {
				custNm = result[i].CUST_NM;
				
				html =	"<tr>" +
				"<td>"+result[i].TRNS_NM+"</td>" +
				"<td>"+result[i].VLD_VAL_NM+"</td>" +
				"<td>"+result[i].CUST_NM+"</td>";
				
				if(result[i].DEPOSIT != undefined && result[i].DEPOSIT != "0") {
					html += "<td><font color='#0000FF'>"+commaNum(result[i].TOT_TRNS_AMT)+"</font></td>";
				} else {
					html += "<td>"+commaNum(result[i].TOT_TRNS_AMT)+"</td>";
				}
				var codeName = mapCode.get(result[i].CHNL_TPCD);
				if(!codeName){
					codeName = result[i].CHNL_TPCD;
				}
				if(result[i].CHNL_TPCD != 'TOD')
					result[i].OPTOR_NAME = "";
				
                if(window.orientation == 0){
                    html  += "<td class='landshow displayNone'><a href='#' class='fikname' data-enob='"+result[i].OPTOR_ENOB+"' >"+result[i].OPTOR_NAME+"<a/></td>" +
                        "<td class='landshow displayNone'>"+codeName+"</td>";
                }
                else{
                    html  +=  "<td class='landshow'><a href='#' class='fikname' data-enob='"+result[i].OPTOR_ENOB+"' >"+result[i].OPTOR_NAME+"<a/></td>" +
                        "<td class='landshow'>"+codeName+"</td>";
                }

				html += "</tr>";
				listItems[i] = html;
                html = "";
			}

			_layout.resetLayout();
			
			$('#REBM001 #rebmBigMoney tbody').append(listItems.join(''));
			listItems = null;

			if(result[i-1].RNUM === result[i-1].TOTCNT) {
				$('#REBM001 #rebmAfterBtn').button('disable');
			} else {
				$('#REBM001 #rebmAfterBtn').button('enable');
			}

			if(curPage === 1) {
				$('#REBM001 #rebmBeforeBtn').button('disable');
			} else {
				$('#REBM001 #rebmBeforeBtn').button('enable');
			}
            //리스트클릭 이벤트
            $('#REBM001 #rebmBigMoney tbody').find('a.fikname').off('vclick').on('click',function(){
                var sabun = $(this).attr('data-enob');
                var detailId ="EMST002";
                var args={};
                args.menuId = _menuId;
                args.sabun = sabun;

                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
                setTimeout(function () {
                    DGB.Page.changePage('#'+detailId);
                },400);
                return false;
            });
            if(window.orientation == 0){
                showAlert(Messages.msg00E);
            }



		} else {
			eaiSocketErrorDisplay(item.STD_GRAM_ERRC);
			dgbLoading(false);
		}
        item = null;
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	}
	
	function displayBigMoneyError() {
		dgbLoading(false);
        showAlert(Messages.msg030);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function() {
            setContents();
        },
		pagebeforehide: function() {
			if( !locDetailview ) {
				$('#REBM001 table td').val('');
			}
		},
		selectbutton: function(param) {
			_menuId = param.menuId;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		parentpage :function (evt, param) {
			searchBranch = param.searchBranch;
			if(searchBranch.length == 1) searchBranch = "00" + searchBranch;
			else if(searchBranch.length == 2) searchBranch = "0" + searchBranch;
			
			$('#REBM001 #rebmOrgNm').prev('span').find('.ui-btn-text').text(param.branchName);
			searchBranchName = param.branchName;

		},
		orientationchange : function(evt) {
            if(evt.orientation == 'landscape'){
                $('#REBM001 .landshow').removeClass("displayNone");
            }
            else{
                $('#REBM001 .landshow').addClass("displayNone");
            }
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REBM001');
})();