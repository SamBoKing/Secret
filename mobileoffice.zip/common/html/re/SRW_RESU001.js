(function() {
	var $this, _menuId, _layout;
	var jumin, password, jumin_list, mobile, tel;
	var convertImg, baseImg;
	var btn_submit, btn_masking;
	var isTakeFrontPhoto;
	var canvas, context;

	function init(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		// Canvas Object
		canvas = $this.find('#resu01CanvasTemp1')[0];
		context = canvas.getContext("2d");

		// Control Object
		jumin = $this.find('#resu01Jumin');
		password = $this.find('#resu01Password');
		mobile = $this.find('#resu01Moibleph');
		tel = $this.find('#resu01Homeph');
		jumin_list = $this.find('#resu01JuminList');
		btn_submit = $this.find('#resu01Submit');
		btn_masking = $this.find('#resu01Masking');

		// Image Object
		convertImg = $this.find("#resu01frontImg");
		baseImg = $this.find("#resu01frontImgBase");

		// Masking Check init
		$this.data('isMasking', false);

		// Image Setting
		convertImg.attr("data-flag","false");
		baseImg.attr("data-flag","false");

		// Control Event
        jumin.off('touchstart vclick').on({
            'touchstart' : function() { $this.blur(); },
            'vclick' : function() { onE2K('num','resu01Jumin', '13', '13', '주민번호 입력', '1'); return false; }
        });
		password.off('touchstart vclick').on({
			'touchstart' : function() { $this.blur(); },
			'vclick' : function() { onE2K('num@2x','resu01Password', '4', '4', '계좌비밀번호', '1'); return false; }
		});

		// Image Event
		convertImg.off('vclick').on('vclick',onClickPhoto);

		// Button Event
		btn_submit.off('vclick').on('vclick', onClickSubmit);
		btn_masking.off('vclick').on('vclick', onClickMasking);
		
		if ( DGB.isIPhone() ) {
			$this.find('.pinpadBox').bind('tap', function() {
				$this.find('input').blur();
				jumin_list.blur();
			});
		}
	}

	function onClickSubmit() {
		var msg;
		if ( !jumin_list.val() ) msg = Messages.msg046; 		// 실명증표종류 선택 하지 않은 경우
		else if( !jumin.val() )  msg = Messages.msg048;        	// 주민번호 입력하지 않은 경우
		else if( !mobile.val() ) msg = Messages.msg049;   		// 휴대폰번호 입력하지 않은 경우
		else if( !tel.val() ) msg = Messages.msg04A;			// 전화번호를 입력하지 않은 경우
		else if( !password.val() ) msg = Messages.msg04B;		// 비밀번호를 입력하지 않은 경우
		else if( !isTakeFrontPhoto ) msg = Messages.msg047;		// 실명증표를 촬영하지 않은 경우
        /*
        수신은 마스킹 하지않음
		else if( !$this.data('isMasking') ) {                   // 실명증표 마스킹을 하지않은 경우
			showConfirm(function(btn) {
				if (btn == '1') {
					DGB.Page.changePage('#RESU002');
				}
			}, Messages.msg211);
			return false;
		}
		*/

		// Error Message
		if( msg ) {
			mobile.blur();
			tel.blur();
			showAlert(msg);
			return false;
		}

		sendImage();
		return false;
	}

	function onClickMasking() {
		if( !isTakeFrontPhoto ) {
			showAlert(Messages.msg047);
			return false;
		}

        DGB.Page.triggerPage("#RESU002", "parentpage", [{
            parent : $this,
            canvas : canvas,
            context : context,
            img : convertImg,
            img_base : baseImg
        }]);
		DGB.Page.changePage('#RESU002');
		return false;
	}

	function onClickPhoto() {
		if ( !jumin_list.val() ) {
			showAlert(Messages.msg012);
			return false;
		}

		// 사진촬영
		capturePhoto(onPhotoSuccess);
		return false;
	}

	function onPhotoSuccess(imageData) {
		convertImg.attr("src", "data:image/jpeg;base64," + imageData);

		var image = new Image();
		image.src = convertImg.attr("src");
		image.onload = function() {
			var imgWidth =  image.width;
			var imgHeight = image.height;

			canvas.width = imgWidth;
			canvas.height = imgHeight;

			// height가 클 경우 90도 변경
			if (imgWidth < imgHeight) {
				canvas.width = imgHeight;
				canvas.height = imgWidth;
				rotateImg(context, image, canvas);
			}else {
				rotateImg(context, image, canvas, {rotate:0});
			}

			// convertImg.attr({"src" : canvas.toDataURL('image/JPEG'), width : "45%"});
			convertImg.attr({"src" : canvas.toDataURL('image/JPEG'), width : "100%"});
			baseImg.attr({"src" : canvas.toDataURL('image/JPEG'), width : "100%"});

			isTakeFrontPhoto = true;
			$this.data('isMasking', false);
			_layout.refreshLayout(function() {
				dgbLoading(false);
			}, 500);
		};
	}

	function sendImage() {
		// 텍스트 배경.
		context.fillStyle = 'black';
		context.fillRect(0, 0, 320, 23);
		context.restore();

		// 텍스트 입력
		var data = getYYYYMMDDHHmmss() + "-" + USER_INFO.WORKORG_CD + USER_INFO.ENOB;
		context.fillStyle = 'white';
		context.font = '15pt Arial';
		context.fillText(data, 5, 17);
		context.restore();

		var inv = {
			adapter : 'SocketTransactionAdapter',
			procedure : 'TRE00103',
			parameters : [{
				BIZ_DVCD : "CU",
				RNNO : jumin.attr('data-enc'),
				MOB_NUMBER : mobile.val(),						// 휴대폰번호
				HOME_NUMBER : tel.val(),						// 집전화번호
				SCAN_DVCD : jumin_list.val(),					// 실명증표종류
				CNNT_PSWD : password.attr('data-enc'),	    		// 계좌비밀번호(보안키패드 암호화값)
				ENCODE_NUM : "RNNO,CNNT_PSWD",
				IMG_COMBINE : canvas.toDataURL('image/JPEG'),	// 병합된 최종 이미지
				TELLER_NUM : USER_INFO.ENOB,
				TELLER_BRNO : USER_INFO.WORKORG_CD,
				CS_ID:_menuId,
				ENCODE_STR : "",
				TRANS_KEY : IS_TRANS_KEY
			}]
		};

		var opt = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};
		dgbLoading(true);
		callProcedure(inv, opt);
	}

	// 스마트핀패드 업로드 콜백함수
	function displayResult(data) {
		var result = data.invocationResult;

		dgbLoading(false);
		if( result.success === "no" ) {
			showAlert(Messages[result.MSG_CD]);
			if( result.MSG_CD === "msg045" ) {
				jumin.attr('data-enc','');
				jumin.val('');
			} else {
				password.attr('data-enc','');
				password.val('');
			}
			_layout.refreshLayout();
			return false;
		}
		if( result.PRCS_RSLT_DVCD == "9" || result.CMMT_YN == 'N') {
			showAlert(result.ERR_MSG);
			return false;
		}

		showAlert(Messages.msg04C);
		jumin.attr('data-enc','');
		jumin.val('');
		password.attr('data-enc','');
		password.val('');
		clearData(false);
		_layout.refreshLayout();
	}

	function displayError() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	// 이미지 회전
	function rotateImg (ctx, image, canvas, option) {
		var DEGREES_TO_ROTATE = -90;	//기본값
		var POSITION_Y = 0;			//기본값
		if (option != undefined) {
			if (option.rotate != undefined) {	DEGREES_TO_ROTATE = option.rotate;	}
			if (option.y != undefined) {	POSITION_Y = option.y;	}
		}

		var canvasWidthHalf = Math.floor( canvas.width / 2 );
		var canvasHeightHalf = Math.floor( canvas.height / 2 );
		var widthHalf = Math.floor( image.width / 2 );
		var heightHalf = Math.floor( image.height / 2 );

		ctx.save();
		ctx.translate( canvasWidthHalf, canvasHeightHalf + POSITION_Y);
		ctx.rotate( ( Math.PI / 180 ) * DEGREES_TO_ROTATE );
		ctx.drawImage( image, -widthHalf, -heightHalf );
		ctx.restore();
	}

	
	function clearData(isFirst) {
		isTakeFrontPhoto = false;
		$this.data('isMasking', false);
		convertImg.removeAttr('src');
		baseImg.removeAttr('src');

		$this.find('.pinpadReset').val('');
		jumin_list.selectmenu("refresh");
	}

	$(document).on({
		pageinit: function() {
			init($(this));
		},
		pagebeforeshow : function() {
			DGB.Common.backMenu();
			DGB.Common.refreshLayout(_layout);
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			clearData(true);
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
		,resize : function() {
			DGB.Common.refreshLayout(_layout);
		}
	}, '#RESU001');
})();
