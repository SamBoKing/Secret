(function() {
	var $this = undefined;
	var inqDvcd = "3";  // 조회구분 : 전체(1), 성명(2), 부점(3), 행번(4), 전화번호(5)
	var _keyword = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수	
	var locDetailview = false;	// 상세조회에서 돌아왔을때 목록을 남겨둘지 체크 default:false

    function search(param1, param2, param3) {
        dgbLoading(true);

        if (arguments.length != 3) {
            param2 = 1; // START_NUM 기본값
            param3 = _pageSize; // EDD_NUM 기본값
            /* 페이징 */
            $('#resi03StNum').val(param2), $('#resi03EdNum').val(param3);
            /* //페이징 */
        }

        var opt = {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        };

        var inv = {
            adapter : 'DBTransactionAdapter',
            procedure : 'TEM00001',
            parameters : [{SEARCH : param1
                , START_NUM : param2
                , END_NUM : param3
                , INQ_DVCD : inqDvcd
                , CS_ID:_menuId}]
        };
        callProcedure(inv, opt);
    }

	function displayResult(data) {
		var item = data.invocationResult.resultSet;
		if(item.length === 0) {
			_layout.refreshLayout(function(){
				dgbLoading(false);
				$("#resiStaffListview").html('');
				$('#resi03pullUp').css("display", "none");
                $("#resi03Noresult").removeClass("displayNone");
                $("#resi03InputText").text($('#resiInputSearch').val());
				_iscrollEnd = false;
			}, 500);
			
		} else {
			var html = "";
			var listItems = [];
			for (var i=0; i<item.length; i++) {
				var officeTel = item[i].OFFICE_TEL.split(" "); 
				var displayTel = officeTel[0]; 
				html =  "<li>" +
						"<a href='#'  class='resi003List downHeight' data-enob='"+item[i].SABUN+"' >" + 
							"<fieldset class='ui-grid-b'> " +
								"<div class='ui-block-a'> " +
									"<b><h3>"+item[i].NAME+"</h3></b>"+
									"<p><font color=darkblue><strong>"+item[i].JIKCHAK+"</strong></font></p>"+
								"</div> " +
								"<div class='ui-block-b'> " +
									"<p>&nbsp;</p>"+
									"<p>"+item[i].ORG_NM+"</p>"+
									"<p>"+displayTel+"</p>"+
								"</div> " +
							"</fieldset> " +
						"</a>"+
						"</li>";
				listItems[i] = html;
			}
				
			/* 페이징 */
			if (item.length == _pageSize) {
				if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
					$('#resi03pullUp').css("display", "none");
					_iscrollEnd = true;

				} else {
					$('#resi03pullUp').css("display", "block");
					$('#resi03StNum').val(
							parseInt($('#resi03StNum').val()) + _pageSize);
					$('#resi03EdNum').val(
							parseInt($('#resi03EdNum').val()) + _pageSize);
				}
			} else {
				_iscrollEnd = true;
				$('#resi03pullUp').css("display", "none");
			}
			/* //페이징 */

			$("#resiStaffListview").append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			$("#resiStaffListview").listview( "refresh" );
			$("#resiStaffListview").trigger("updatelayout");

			//리스트클릭 이벤트  
			$('#resiStaffListview').find('li a.resi003List').off('vclick').on('click',function(){
				var sabun = $(this).attr('data-enob');
				var detailId ="EMST002";
				var args={};
				args.menuId = _menuId;
				args.sabun = sabun;
				
				locDetailview = true;
                DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
				setTimeout(function () {
					DGB.Page.changePage('#'+detailId);
				},400);
				return false;
			});

			_layout.refreshLayout(function(){
			   dgbLoading(false);
			}, 500);
		}
	}

	function displayError() {
		dgbLoading(false);
        showAlert(Messages.err001);
	}
	
	function initPageDOM() {
		if(locDetailview == false) {
			//화면 초기화
			$("#resiStaffListview").html('');
			$("#resi03Noresult").addClass("displayNone");
			$('#resi03pullUp').css("display", "none");
			_iscrollEnd = false;
		}
	}

	function _pageshow() {
        //android back 버튼 동작
        DGB.Common.backPage();

		initPageDOM();
		$("#resi03Noresult").addClass("displayNone");

		if(locDetailview == false) {
			setTimeout(function () {
				search(_keyword);
			}, 300);
		}
		locDetailview = false;
		_layout.refreshLayout();
		dgbLoading(false);
	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = _keyword,
			param2 = $('#resi03StNum').val(),
			param3 = $('#resi03EdNum').val();
		if(_keyword != "") {
            search(param1, param2, param3);
		}
	}

	$(document).on({
		pageinit: function() {
            _layout = new DGB.layout($(this), COMMON_PAGE_HEADER_HEIGHT);
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
			var options = param.options;
			if (options) {
				inqDvcd = options.type;
				_keyword = options.keyword;
			}
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#RESI003');
})();