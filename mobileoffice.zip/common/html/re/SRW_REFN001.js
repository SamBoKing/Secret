(function() {
	var $this, _menuId, _menuItem, _layout;
	var txt_jumin, txt_id, txt_pw, title;
    var layout_id, line_id;
    var checkOTP;
    var _biz_dvcd;
    var _efn_mdm_dvcd;
    var btn_submit;
    var pass_info;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        title = $this.find('#title');
		txt_jumin = $this.find('#refn01_jumin');
        txt_id = $this.find('#refn01_id');
        txt_pw = $this.find('#refn01_pw');
        layout_id = $this.find('#layout_id');
        line_id = $this.find('#line_id');
        checkOTP = $this.find('#ckbOTPUseYn');
        btn_submit = $this.find('#btn_submit');
        pass_info = $this.find('#pass_info');


        txt_jumin.on({
            'touchstart' : function() { $this.blur(); },
            'vclick' : function() { onE2K('num','refn01_jumin', '13', '13', '주민번호 입력', '1'); return false; }
        });
        txt_pw.on({
            'touchstart' : function() { $this.blur(); },
            'vclick' : function() { onE2K('num@2x','refn01_pw', '6', (_biz_dvcd=='EF1')?'8':'6', '접속비밀번호', '1'); return false; }
        });
        btn_submit.on('vclick', onClickSubmit);

		if ( DGB.isIPhone() ) {
			$this.find('.pinpadBox').bind('tap', function() {
				$this.find('input').blur();
			});
		}
	}

    function onClickSubmit() {
        var msg;
        if ( !txt_jumin.val() ) msg = "주민등록번호를 입력해 주세요.";
        else if( txt_jumin.val().length != 13 && DGB.isAndroid() )  msg = "주민등록번호가 잘못되었습니다. 다시 입력해 주세요.";
        else if( _biz_dvcd == 'EF1' && !txt_id.val() ) { msg = "신규이용자ID를 입력해 주세요."; txt_id.focus(); }
        else if( _biz_dvcd == 'EF1' && (txt_id.val().length < 6 || txt_id.val().length > 10) ) msg = "신규이용자ID를 올바르게 입력해 주세요.(6~10자)";
        else if( !txt_pw.val() ) msg = "접속비밀번호를 입력해주세요.";

        // Error Message
        if( msg ) {
            showAlert(msg);
            return false;
        }

        onSubmit();
        return false;
    }

    function onSubmit() {
        var checked = checkOTP.prop('checked');
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00201',
            parameters : [{              
            	EFN_MDM_DVCD : _efn_mdm_dvcd, // INT(인터넷) or PON(폰뱅킹)
            	USPS_ID : txt_id.val().toUpperCase(), //
				RNNO : txt_jumin.attr('data-enc'),
				CNNT_PSWD : txt_pw.attr('data-enc'),
				ENCODE_NUM : "RNNO,CNNT_PSWD",
				TELLER_NUM : USER_INFO.ENOB,
				TELLER_BRNO : USER_INFO.WORKORG_CD,
				CS_ID:_menuId,
				ENCODE_STR : "",
				OTP_CHECK : checked,
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessSubmit,
            onFailure : onFailureSubmit,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
        return false;
    }

	function onSuccessSubmit(data) {
		dgbLoading(false);
	
        var result = data.invocationResult;    
        if( result.PRCS_RSLT_DVCD == "9") {
            showAlert(result.ERR_MSG);
            return false;
        }

        //var checked = checkOTP.prop('checked');
        //( !checked ) {
            if(result.EF_REG_MSG){
                showAlert(result.EF_REG_MSG);
            }
        //}

        var args = {
            biz_dvcd : _biz_dvcd,
            cust_id : txt_id.val().toUpperCase(),
            rnno : txt_jumin.attr('data-enc'),
            cnnt_pswd : txt_pw.attr('data-enc'),
            menuId : _menuId
        };
        DGB.Page.triggerPage("#REFN002", "parentpage", [args]);
        DGB.Page.changePage('#REFN002');
	}

	function onFailureSubmit() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

    function initData() {
        txt_id.val('');
        txt_jumin.val('').attr('data-enc','');
        txt_pw.val('').attr('data-enc','');
        checkOTP.prop('checked', false).checkboxradio('refresh');
        _layout.refreshLayout();

        if( _menuItem  ) {
            title.text('전자금융-' + _menuItem.data('title'));
            _biz_dvcd = _menuItem.attr('data-biz_dvcd') || '';
            switch( _biz_dvcd ) {
                case 'EF1':
                    _efn_mdm_dvcd = 'INT';
                    pass_info.text('(접속비밀번호는 6~8자리 입력)');
                    line_id.show();
                    layout_id.show();
                    break;
                case 'EF2':
                    _efn_mdm_dvcd = 'PON';
                    pass_info.text('(접속비밀번호는 6자리 입력)');
                    line_id.hide();
                    layout_id.hide();
                    break;
            }
        }
    }

	$(document).on({
		pageinit : _pageinit,
        pagebeforeshow : function() {
            DGB.Common.backMenu();
            initData();
        },
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
            _menuItem = param.menuItem;
            initData();
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REFN001');
})();
