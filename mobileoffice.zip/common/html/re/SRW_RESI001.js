(function() {
	var $this;
	var brachNum = "";
	var _menuId;
	var _layout;
    var _buttonText;
	var locDetailview = false;
	
	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _buttonText = $this.find('#resiOrgNm').prev('span').find('.ui-btn-text');

        // 모점, 자점 리스트 초기화
        USER_INFO.BRBAS = USER_INFO.BRBAS || [];

		if(WL.Client.getEnvironment() == WL.Environment.IPHONE) {  // 폰트사이즈 조정
            $this.find('table').css('font-size', '12px');
            $this.find('.ui-grid-a div > h3').css('fontSize', '14px');
		}

        // 영업점변경
        $this.find('#resiOrgNm').off('vclick').on('vclick', function() {
            clickGroup();
            return false;
        });

        // 본부직원이면서 임원이 아닌 경우엔 [소속직원보기], [영업점현황] 조회 권한 없음
        if(Number(USER_INFO.ORG_CD) > 900 && !DGB.Common.isAdminMember() ) {
            $this.find('.optionFunc').hide();
        } else {
            // 영업점현황 조회
            $this.find('#branchInfoBtn').off('vclick').on('vclick', function() {
                DGB.Page.triggerPage('#RESI004', "selectbutton", {'menuId':"RE0102"});
                DGB.Page.changePage('#RESI004');
                return false;
            });

            // 영업실적 조회
            $this.find('#businessResultBtn').off('vclick').on('vclick', function() {
                DGB.Page.triggerPage('#RESI005', "selectbutton", {'menuId':"RE0103"});
                DGB.Page.changePage('#RESI005');
                return false;
            });

            // 은행전체로 다시 조회
            $this.find('#bankInfoBtn').off('vclick').on('vclick', function() {
                searchBranch = "999";
                searchBranchName = "영업점변경";
                setContents();
                return false;
            });

            // 소속직원보기
            $this.find('#branchStaffBtn').off('vclick').on('vclick', function() {
                if(brachNum === "999") {		// 은행전체인 경우에는 소속직원 보기 안됨
                    showAlert(Messages.msg051);
                    return false;
                }
                locDetailview = true;
                DGB.Page.triggerPage('#RESI003', "selectmenu", {'menuId':"EM0101", options:{'type':'3', 'keyword':brachNum}});
                DGB.Page.changePage('#RESI003');
                return false;
            });
        }
	};

    function clickGroup() {
        if( DGB.Common.isAdminMember() ) {
            var args = {
                menuId : _menuId,
                parentId : "RESI001"
            };
            DGB.Page.triggerPage("#RESI002", "parentpage", [args]);
            setTimeout(function () { DGB.Page.changePage('#RESI002'); }, 200);

        } else if(USER_INFO.GROUP_ID == "G003" && USER_INFO.BRBAS.length > 1 ) {
            var BRNames = [];
            for(var i=0; i<USER_INFO.BRBAS.length; i++){
                BRNames.push(USER_INFO.BRBAS[i].BRC_NM);
            }

            DGB.Common.selectList("지점 선택", BRNames,
                function(index) {
                    searchBranch = USER_INFO.BRBAS[index].BRNO;
                    searchBranchName = USER_INFO.BRBAS[index].BRC_NM;
                    setContents();
                },
                function(err) { }
            );
        } else {
            showAlert(Messages.msg009);
        }
    }

	function setContents() {
		if( DGB.Common.isAdminMember() ) {
            brachNum = searchBranch || "999";
            _buttonText.text(brachNum == "999" ? "영업점변경" : searchBranchName);
		} else if(USER_INFO.GROUP_ID != "G003" && Number(USER_INFO.ORG_CD) > 900) {
			brachNum = "999";
			_buttonText.text("은행전체");
		} else {
			// 일반 영업점 직원의 경우 영업점현황, 소속직원보기 가능, 조회영업점변경 불가능
			brachNum = searchBranch || USER_INFO.WORKORG_CD;
            _buttonText.text(searchBranchName || USER_INFO.WORKORG_NM);
            $this.find('#bankInfoBtn').button('disable');
		}

        _layout.refreshLayout();

        var invocationData = {
                adapter : 'SocketTransactionAdapter',
                procedure : 'TRE00110',
                parameters : [{
                    SEARCH_BRANCH : brachNum,
                    TELLER_NUM : USER_INFO.ENOB,
					TELLER_BRNO : USER_INFO.ORG_CD,
                    CS_ID:_menuId,
                    ENCODE_STR : ""
                }]
            };
        var options = {
            onSuccess : displayFiguresResult,
            onFailure : displayFiguresError,
            invocationContext : {}
        };

        if( !locDetailview ) {
            dgbLoading(true);
            callProcedure(invocationData, options);
        }
        locDetailview = false;
	}

	// 영업현황 조회 콜백함수
	function displayFiguresResult(data) {
		if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
			dgbLoading(false);
			eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
			return false;
		}
		
		
//		_layout.resetLayout();
		var item = data.invocationResult.resultSet;
		var amt_unit = data.invocationResult.AMT_UNIT;
		var baseDate = (item[0].CRDT).replace(/^(\d{4})(\d{2})(\d{2})$/,"$1-$2-$3");
		var baseTime = (item[0].CTIME).replace(/^(\d{2})(\d{2})(\d{2})$/,"$1:$2:$3");
		$('#RESI001 #create_time').text('최초생성일시 :'+baseDate +' ' +baseTime +'(단위-'+amt_unit+')');
		$('#RESI001 #table-custom-1 tbody').html('');

		var html = "";
		var listItems = [];
		if(item.length != 0) {
			for(var i=0; i<item.length; i++) {
				item[i].COA_NM = item[i].COA_NM.replace("[","");
				item[i].COA_NM = item[i].COA_NM.replace("]","");

				if(i==0|| i==1 || i==4 || i==5){
					html  =	"<tr style='color:darkblue'>" +
					"<td style='text-align:left;'><b>"+item[i].COA_NM+"</b></td>"+
					"<td><b>"+item[i].CURBAL+"</b></td>" +
					"<td><b>"+item[i].YESBAL+"</b></td>" +
						//"<td><b>"+numberWithComma(item[i].CURBAL.replace(/[^\d]+/g,'')-item[i].YESBAL.replace(/[^\d]+/g,''))+"</b></td>" +
					"</tr>";
				}else{
					html  =	"<tr>" +
					"<td style='text-align:left;'>"+item[i].COA_NM+"</td>"+
					"<td>"+item[i].CURBAL+"</td>" +
					"<td>"+item[i].YESBAL+"</td>" +
						//"<td>"+numberWithComma(item[i].CURBAL.replace(/[^\d]+/g,'')-item[i].YESBAL.replace(/[^\d]+/g,''))+"</td>" +
					"</tr>";
				}
				listItems[i] = html;
			}

			_layout.resetLayout();

			$('#RESI001 #table-custom-1 tbody').append(listItems.join(''));
			listItems = null;
			item = null;
			html = "";
		} else {
			dgbLoading(false);
		}
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	}
	
	function displayFiguresError() {
		showAlert(Messages.msg030);
		dgbLoading(false);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function(){
            setContents();
        },
		pagebeforehide: function(evt, ui) {
			if(locDetailview == false) {
				$('#resiBranchInfo #table-custom-3 td').val('');
				$('#resiBranchInfo #table-custom-4 td').val('');
			}
			$('#resiBranchInfo').hide();
		},
		selectbutton: function(param) {
			_menuId = param.menuId;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		parentpage :function (evt, param) {
			searchBranch = param.searchBranch;
			if(searchBranch.length == 1) searchBranch = "00" + searchBranch;
			else if(searchBranch.length == 2) searchBranch = "0" + searchBranch;

			$('#RESI001 #resiOrgNm').prev('span').find('.ui-btn-text').text(param.branchName);
			searchBranchName = param.branchName;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RESI001');
	
})();
