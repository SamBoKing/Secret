(function() {
    // TEST
    var DGBANK_CODE = '031';


	var $this, _menuId, _layout;
    var _data = {
        biz_dvcd : '',          // 업무구분코드
        rnno : '',             // 실명번호
        cnnt_pswd : '',           // 카드비밀번호
        card_type : '',         // 카드종류
        bc_type : false,        // BC 회원여부
        bank_code : '',         // 은행코드
        account_num : ''        // 계좌번호
    };
    var _bnkCds=[];
    var _bnkNms=[];

	var select_card_type,
        select_bank_type,
        select_account_type,
        select_photo_type,
        txt_account_num,
        txt_account_pw,
        btn_submit,
        btn_masking;

    // layout
    var account_pw_layout, account_type_layout, label_account_num;

    var list_old_account = [], list_new_account = [];
    var nextKey;
    var canvas, context, img_photo, img_base, cdInfoText;
    var isTakeFrontPhoto, isDefaultImage = true, isMaskingPage;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        // Masking
        $this.data('isMasking', false);
        cdInfoText = $this.find('#cd_knd_info');
        canvas = $this.find('#canvas')[0];
        context = canvas.getContext("2d");
        img_photo = $this.find("#img_photo");
        img_base = $this.find("#img_photo_base");

        select_card_type = $this.find('#recd02_card_type');
        select_bank_type = $this.find('#recd02_bank_type');
        select_account_type = $this.find('#recd02_account_type');
        select_photo_type = $this.find('#recd02_photo_type');
        txt_account_num = $this.find('#recd02_account_num');
        txt_account_pw = $this.find('#recd02_account_pw');
        btn_submit = $this.find("#btn_submit");
        btn_masking = $this.find("#btn_masking");

        // layout
        account_pw_layout = $this.find(".account_pw_layout");       // class
        account_type_layout = $this.find("#account_type_layout");
        label_account_num = $this.find("#label_account_num");

        // convertImg.attr("data-flag","false");
        // baseImg.attr("data-flag","false");

        img_photo.on('vclick',onClickPhoto);
        btn_submit.on('vclick', onClickSubmit);
        btn_masking.on('vclick', onClickMasking);

        select_card_type.on('change', onChangeCardType );
        select_bank_type.on('change', onChangeBankType );
        select_account_type.on('change', onChangeAccountType );
        txt_account_num.on({ touchstart : function() { $this.blur(); }, vclick : onClickAccountNumber });
        txt_account_pw.on({ touchstart : function() { $this.blur(); }, vclick : onClickAccountPassword });

		if ( DGB.isIPhone() ) {
			$this.find('.pinpadBox').bind('tap', function() {
				$this.find('input').blur();
			});
		}
	}

    function _pageshow() {
        // 이전 버튼 재정의
        $this.find('.jqm-header .jqm-back-link').off('vclick').on('vclick', onBackPage);
        WL.App.overrideBackButton(onBackPage);
    }

    function onBackPage() {
        showConfirm(function(btn){
            if (btn == '1') {
                DGB.Page.backPage();
            }
        }, "입력하신 사용자정보가 [초기화] 됩니다!\n작성화면을 나가시겠습니까?");
        return false;
    }

    function initData() {
        nextKey ='';
        $this.data('isMasking', false);
        list_old_account = [];
        list_new_account = [];
        isTakeFrontPhoto = false;

        if( isDefaultImage ) {
            img_photo.removeAttr('src');
            // img_photo.attr('src', 'images/btn_pinpad_frontcam.png');
        }
        isDefaultImage = true;

        img_base.removeAttr('src');
        // img_base.attr('src', 'images/btn_pinpad_frontcam.png');

        // 현금겸용/단독 설정
        if( _data.card_type == '01' ) {       // 신용
            select_card_type.val('').selectmenu("refresh");
            select_card_type.prop('disabled', false);
        } else {
            select_card_type.val('01').selectmenu("refresh");
            select_card_type.prop('disabled', true);
        }
        // Init Data
        onChangeCardType();

        //select_account_type.val('').selectmenu("refresh");
        //select_photo_type.val('02').selectmenu("refresh");
        //txt_account_num.val('');
        //txt_account_pw.val('').attr('data-enc', '');
        _layout.refreshLayout();
    }

    // 사진촬영
    function onClickPhoto() {
        capturePhoto(onPhotoSuccess);
        return false;
    }

    function onPhotoSuccess(imageData) {
        img_photo.attr("src", "data:image/jpeg;base64," + imageData);

        var image = new Image();
        image.src = img_photo.attr("src");
        image.onload = function() {
            var w =  image.width;
            var h = image.height;

            // 높이가 클 경우 90도 변경
            canvas.width = Math.max(w, h);
            canvas.height = Math.min(w, h);
            rotateImage(context, image, canvas, (w >= h) ? {rotate:0} : undefined);

            img_photo.attr({"src" : canvas.toDataURL('image/JPEG'), width : "45%"});
            img_base.attr({"src" : canvas.toDataURL('image/JPEG')});

            isTakeFrontPhoto = true;
            $this.data('isMasking', false);
            _layout.refreshLayout(function() {
                dgbLoading(false);
            }, 500);
        };
    }

    // 이미지 회전
    function rotateImage (ctx, image, canvas, option) {

        var DEGREES_TO_ROTATE = -90;	//기본값
        var POSITION_Y = 0;			//기본값
        if (option != undefined) {
            if (option.rotate != undefined) {	DEGREES_TO_ROTATE = option.rotate;	}
            if (option.y != undefined) {	POSITION_Y = option.y;	}
        }

        var canvasWidthHalf = Math.floor( canvas.width / 2 );
        var canvasHeightHalf = Math.floor( canvas.height / 2 );
        var widthHalf = Math.floor( image.width / 2 );
        var heightHalf = Math.floor( image.height / 2 );

        ctx.save();
        ctx.translate( canvasWidthHalf, canvasHeightHalf + POSITION_Y);
        //ctx.rotate( ( Math.PI / 180 ) * DEGREES_TO_ROTATE );
        ctx.drawImage( image, -widthHalf, -heightHalf );
        ctx.restore();
    }

    function showAccountList() {
        var type = select_account_type.val();
        var title = select_account_type.find('option:selected').text();
        var data = type == '01' ? list_old_account : list_new_account;
        var items = [];
        for(var i=0; i<data.length ; i++){
        	if(type=='01')
        		items[i] = (i+1) +') - ' + data[i].ACNO;
        	else
        		items[i] = (i+1) +') - ' + data[i].DPO_SMRT_PBRL_RCPNO ;
        }
        var nextStr = '';
        if(nextKey && type=='01')  {
            items[data.length] = '계속 (다음 조회)';
            nextStr =' - 계속';
        }

        DGB.Common.selectList(title + ' [' + data.length + '건]'+nextStr ,
            items,
            function (index) {
        		if(data.length == index){ //Next Click
                    onClickContinueAccount();
        		}else{
            		if(type=='01')
            			txt_account_num.val(data[index].ACNO);
            		else
            			txt_account_num.val(data[index].DPO_SMRT_PBRL_RCPNO);
            		
        		}
            },
            function () { }
        );
    }

    function onChangeCardType() {
        // 신용
        if( _data.card_type == '01' ) {
            switch( select_card_type.val() ) {
                case '01': //현금겸용
                	if(_data.bank_code != DGBANK_CODE && _data.bc_type){
                		showAlert('타행 결제계좌가 등록이 되어 있어 현금겸욤이 불가 합니다.');
                		select_card_type.val('').selectmenu("refresh");
                		return;
                	}
                    select_bank_type.val(DGBANK_CODE).selectmenu("refresh");
                    select_bank_type.prop('disabled', true);
                    break;
                case '02': //단독
                    if( _data.bc_type ) {
                        select_bank_type.val(_data.bank_code).selectmenu("refresh");
                        select_bank_type.prop('disabled', true);
                    } else {
                        select_bank_type.val('').selectmenu("refresh");
                        select_bank_type.prop('disabled', false);
                    }
                    break;
                default:
                    select_bank_type.val('').selectmenu("refresh");
                    select_bank_type.prop('disabled', false);
                    break;
            }


            // 단독일때는 무조건 비번안보임
            if( select_card_type.val() == '02') {
                account_pw_layout.hide();
                
            } else {
                account_pw_layout.show();
            }

        } else {
        // 체크
            select_bank_type.val(DGBANK_CODE).selectmenu("refresh");
            select_bank_type.prop('disabled', true);
            account_pw_layout.show();
        }
        onChangeBankType();
    }

    function onChangeBankType() {
        switch( select_bank_type.val() ) {
            case '':
            case DGBANK_CODE:
                if( _data.card_type == '01' && _data.bc_type ) { //02 단독 , 신용카드이고 BC회원이며 단독카드
                    account_type_layout.hide();
                    label_account_num.text('결제계좌번호확인');
                    txt_account_num.attr("readonly", true);
                    
                } else {
                    account_type_layout.show();
                    label_account_num.text('결제계좌번호선택');
                    txt_account_num.attr("readonly", true);
                    
                }
                break;
            default:
                account_type_layout.hide();
                account_pw_layout.hide();
            	label_account_num.text('결제계좌번호입력');
                txt_account_num.attr("readonly", false);
                txt_account_num.focus();
                break;
        }

//        if(select_bank_type.val()==DGBANK_CODE &&  select_card_type.val() == '01' && _data.bc_type && _data.card_type=='01'){
//            select_account_type.val('01').selectmenu("refresh");
//            select_account_type.prop('disabled', true);
//        }else {
            select_account_type.val('').selectmenu("refresh");
            select_account_type.prop('disabled', false);
//        }
        onChangeAccountType();
    }

    function onChangeAccountType() {
        
        var accAutoSet = _data.card_type == '01' && _data.bc_type && select_card_type.val();
        if(  accAutoSet ) {
            txt_account_num.val(_data.account_num);
        } else {
            txt_account_num.val('');
        }

        txt_account_pw.val('').attr('data-enc', '');
   
        if( select_account_type.val() != '' )
            onClickAccountNumber();

        return false;
    }

    function onClickAccountNumber() {
        var type = select_account_type.val();
        switch( type ) {
            case '':
                if( _data.card_type == '01' && _data.bc_type /*&& select_card_type.val() == '02'*/ ) {
                    // ??
                } else if( select_bank_type.val() == DGBANK_CODE ) {
                    showAlert('출금계좌유형을 선택해 주세요.');
                }
                break;
            case '01':
                if( select_card_type.val() =='02')
                    account_pw_layout.hide();

                if( list_old_account.length == 0) {
                    onRequestAccountList();
                } else {
                    showAccountList();
                }
                break;
            case '02':
                account_pw_layout.show();
                if( list_new_account.length == 0 ) {
                    onRequestAccountList();
                } else {
                    showAccountList();
                }
                break;
        }
        return false;
    }
    function initBankSelection() {
        var html ="";
        var listItems=[];
        
        while($this.find('#recd02_bank_type option').size()){
        	$this.find('#recd02_bank_type option:first').remove();
        }
        
        html="<option value=''>[선 택]</option>";
        listItems[0] = html;
        for(var i=0; i<_bnkCds.length;i++){
        	html="<option value='" +_bnkCds[i]+"'>"+_bnkNms[i]+"("+_bnkCds[i]+")"+"</option>";
        	listItems[i+1] = html;
        }
        select_bank_type.append(listItems.join(''));
        select_bank_type.selectmenu('refresh');
    }
    function onClickContinueAccount() {
        onRequestAccountList();
        return false;
    }

	function onClickAccountPassword() {
		onE2K('num','recd02_account_pw', '4', '4', '결재계좌비밀번호', '1');
		return false;
	}

    function onClickMasking() {
        if( !DGB.isDebug() && !isTakeFrontPhoto ) {
            showAlert(Messages.msg047);
            return false;
        }

        isMaskingPage = true;
        DGB.Page.triggerPage("#RESU002", "parentpage", [{
            parent : $this,
            canvas : $(canvas),
            context : context,
            img_photo : img_photo,
            img_base : img_base
        }]);
        DGB.Page.changePage('#RESU002');
        return false;
    }

    function onClickSubmit() {
    	var isHidePasswd = account_pw_layout.css('display') =='none';
    	var isHideAccType = account_type_layout.css('display') =='none';
   	
        var msg;
        if ( !select_card_type.val())	msg = "현금겸용 구분을 선택해 주세요.";
        else if ( !select_bank_type.val())	msg = "결제게좌은행 코드를 선택해 주세요.";
        else if ( !select_account_type.val() && !isHideAccType)	msg = "출금계좌유형을 선택해 주세요.";
        else if( !txt_account_num.val() )  msg = "출금계좌를 선택해 주세요.";
        else if(!txt_account_pw.val() && !isHidePasswd) msg = "출금계좌 비밀번호를 입력해 주세요.";
        else if( !select_photo_type.val() ) msg = "실명증표종류를 선택해 주세요.";
        else if( !DGB.isDebug() && !isTakeFrontPhoto ) msg = Messages.msg047;		// 실명증표를 촬영하지 않은 경우
        else if( !$this.data('isMasking') ) {                   // 실명증표 마스킹을 하지않은 경우
            showConfirm(function(btn) {
                if (btn == '1') {
                    onClickMasking();
                }
            }, Messages.msg211);
            return false;
        }


        // Error Message
        if( msg ) {
            showAlert(msg);
            return false;
        }

        onSubmit();
        return false;
    }

    function onSubmit() {
        // 텍스트 배경.
        context.fillStyle = 'black';
        context.fillRect(0, 0, 320, 23);
        context.restore();

        // 텍스트 입력
        var data = getYYYYMMDDHHmmss() + "-" + USER_INFO.WORKORG_CD + USER_INFO.ENOB;
        context.fillStyle = 'white';
        context.font = '15pt Arial';
        context.fillText(data, 5, 17);
        context.restore();

        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00103',
            parameters : [{
            	BIZ_DVCD : "CD",
                TELLER_NUM : USER_INFO.ENOB,
                TELLER_BRNO : USER_INFO.WORKORG_CD,       
                AC_TYPE : select_account_type.val(), 				//01-기존계좌, 02-신규예정
                SCAN_DVCD : select_photo_type.val(),				// 실명증표종류
                IMG_COMBINE : canvas.toDataURL('image/JPEG'),	    // 병합된 최종 이미지
        		DPO_SMRT_PBRL_RCPNO :txt_account_num.val(),
        		CARD_KND_DVCD : _data.card_type,  					//신용 01, 체크 02
        		CSH_CARD_BUSE_YN : select_card_type.val()=='01'?'Y':'N', 			//현금겸용 여부
        		STLM_ACNT_BNKCD : select_bank_type.val(),
        		CNNT_PSWD : _data.cnnt_pswd, 					    // 접속 비밀번호
        		CSH_CARD_PSWD : txt_account_pw.attr('data-enc'),	//     계좌(신규예정)비밀번호
        		RNNO : _data.rnno,
        		ENCODE_NUM : "CNNT_PSWD, CSH_CARD_PSWD, RNNO",
                ENCODE_STR : "",
                CS_ID : _menuId,
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessSubmit,
            onFailure : onFailureSubmit,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    // 스마트핀패드 업로드 콜백함수
    function onSuccessSubmit(data) {
        var result = data.invocationResult;

        dgbLoading(false);
        if(result.PRCS_RSLT_DVCD =="9") {
            showAlert(result.ERR_MSG);
            return false;
        }

        if( result.success === "no" ) {
            showAlert(Messages[result.MSG_CD]);
        } else {
            showAlert(Messages.msg04G);
            initData();
            DGB.Page.backPage();
        }
        _layout.refreshLayout();
    }

    function onFailureSubmit() {
        dgbLoading(false);
        showAlert(Messages.err001);
    }

    function onRequestAccountList() {
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00202',
            parameters : [{
                TELLER_NUM : USER_INFO.ENOB,
                TELLER_BRNO : USER_INFO.WORKORG_CD,
                NEXT_KEY : nextKey,
                TOTCNT : 50,
                AC_TYPE : select_account_type.val(), //01-기존계좌, 02-신규예정
                RNNO : _data.rnno,
                ENCODE_NUM : "RNNO",
                ENCODE_STR : "",
                CS_ID : _menuId,
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessAccountList,
            onFailure : onFailureAccountList,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

	// 스마트핀패드 업로드 콜백함수
	function onSuccessAccountList(data) {
        dgbLoading(false);

		var result = data.invocationResult;
        if( result.PRCS_RSLT_DVCD == "9") {
            showAlert(result.ERR_MSG);
            return false;
        }
        var arr_data = [];

        if( result.type == '01' ) {
            nextKey = result.NEXT_KEY||'';
            arr_data = list_old_account = list_old_account.concat(result.resultSet);
        }
        else
            arr_data = list_new_account = result.resultSet;

        if( arr_data.length )
            showAccountList();
        else
            showAlert(result.ERR_MSG);
	}

	function onFailureAccountList() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	$(document).on({
		pageinit : _pageinit,
        pagebeforeshow : function() {
            if( !isMaskingPage )
                initData();

            isMaskingPage = false;
        },
        pageshow : _pageshow,
        parentpage : function(evt, param) {
            if( param ) {
                _data.biz_dvcd = param.biz_dvcd;
                _data.rnno = param.jumin;
                _data.cnnt_pswd = param.card_pw;
                _data.card_type = param.card_type;
                _data.bc_type = param.bc_type;
                _data.bank_code = param.bank_code;
                _data.account_num = param.account_num;
                _bnkCds = param.bnkCds;
                _bnkNms = param.bnkNms;
                _menuId = param.menuId;
                if(param.card_type == '01')
                	cdInfoText.text("신용카드 선택("+(param.bc_type?'BC회원 YES - '+_data.bank_code:'BC회원 NO')+")");
                else
                	cdInfoText.text("체크카드 선택("+(param.bc_type?'BC회원 YES - '+_data.bank_code:'BC회원 NO')+")");
                initBankSelection();
            } else {
                showAlert(Messages.err001);
                DGB.Page.backPage();
            }
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RECD002');
})();
