(function() {
	var $this, _menuId, _menuItem, _layout;
	var txt_jumin, txt_pw, select_card_type;
    var _efn_mdm_dvcd;
    var btn_submit;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		txt_jumin = $this.find('#recd01_jumin');
        txt_pw = $this.find('#recd01_pw');
        select_card_type = $this.find('#recd01_card_type');
        btn_submit = $this.find('#btn_submit');

        txt_jumin.on({
            'touchstart' : function() { $this.blur(); },
            'vclick' : function() { onE2K('num','recd01_jumin', '13', '13', '주민번호 입력', '1'); return false; }
        });
        txt_pw.on({
            'touchstart' : function() { $this.blur(); },
            'vclick' : function() { onE2K('num@2x','recd01_pw', '4', '4', '카드비밀번호', '1'); return false; }
        });
        btn_submit.on('vclick', onClickSubmit);

		if ( DGB.isIPhone() ) {
			$this.find('.pinpadBox').bind('tap', function() {
				$this.find('input').blur();
			});
		}
	}

    function onClickSubmit() {
        var msg;
        if ( !txt_jumin.val() ) msg = "주민등록번호를 입력해 주세요.";
        else if( txt_jumin.val().length != 13 && DGB.isAndroid() )  msg = "주민등록번호가 잘못되었습니다. 다시 입력해 주세요.";
        else if( !txt_pw.val() ) msg = "카드비밀번호를 입력해주세요.";
        else if( !select_card_type.val() ) msg = "카드유형을 선택해 주세요.";

        // Error Message
        if( msg ) {
            showAlert(msg);
            return false;
        }

        onSubmit();
        return false;
    }

    function onSubmit() {
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00203',
            parameters : [{
            	INPUT_DVCD : '1', //
				RNNO : txt_jumin.attr('data-enc'),
				CNNT_PSWD : txt_pw.attr('data-enc'),
				CARD_KND_DVCD : select_card_type.val(),
				ENCODE_NUM : "RNNO,CNNT_PSWD",
				TELLER_NUM : USER_INFO.ENOB,
				TELLER_BRNO : USER_INFO.WORKORG_CD,
				CS_ID:_menuId,
				ENCODE_STR : "",
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessSubmit,
            onFailure : onFailureSubmit,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
        return false;
    }

	function onSuccessSubmit(data) {
		dgbLoading(false);

        var result = data.invocationResult;
        if( result.PRCS_RSLT_DVCD == "9") {
            showAlert(result.ERR_MSG);
            return false;
        }
        var isBCCard = false;
        var bankCode = '';
        var account ='';
        
        if(result.STLM_ACNT_BNKCD){
        	isBCCard = true;
        	bankCode = result.STLM_ACNT_BNKCD;
        	account = result.ACNO;
        }
        var args = {
            biz_dvcd : 'CD',
            jumin : txt_jumin.attr('data-enc'),
            card_pw : txt_pw.attr('data-enc'),
            card_type : select_card_type.val(),
            bc_type : isBCCard,
            bank_code : bankCode,
            account_num : account,
            bnkCds : result.BNK_CD,
            bnkNms : result.BNK_NM,
            menuId : _menuId
        };
        DGB.Page.triggerPage("#RECD002", "parentpage", [args]);
        DGB.Page.changePage('#RECD002');
	}

	function onFailureSubmit() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

    function initData() {
        txt_jumin.val('').attr('data-enc','');
        txt_pw.val('').attr('data-enc','');
        select_card_type.val('').selectmenu("refresh");
        _layout.refreshLayout();
    }

	$(document).on({
		pageinit : _pageinit,
        pagebeforeshow : function() {
            DGB.Common.backMenu();
            initData();
        },
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
            _menuItem = param.menuItem;
            initData();
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RECD001');
})();
