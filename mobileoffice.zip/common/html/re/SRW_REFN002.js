(function() {
	var $this, _menuId, _layout;
    var _data = {
        biz_dvcd : '',          // 업무구분코드
        cust_id : '',           // 신규이용자 ID
        efn_mdm_dvcd : 'MOF',   // 전자금융매체구분코드
        rnno : '',              // 실명번호
        smrt_pbrl_rcpno : '',   // 스마트섭외접수번호
        cnnt_pswd : '',         // 접속비밀번호
        acno : ''               // 계좌번호
    };

	var select_account_type,
        select_photo_type,
        txt_account_num,
        txt_account_pw,
        btn_submit,
        btn_masking;

    var list_old_account = [], list_new_account = [];
    var nextKey;
    var canvas, context, img_photo, img_base;
    var title;
    var isTakeFrontPhoto, isDefaultImage = true, isMaskingPage;

	function _pageinit() {
		$this = $(this);
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        title = $this.find('#title');

        // Masking
        $this.data('isMasking', false);
        canvas = $this.find('#canvas')[0];
        context = canvas.getContext("2d");
        img_photo = $this.find("#img_photo");
        img_base = $this.find("#img_photo_base");

        select_account_type = $this.find('#select_account_type');
        select_photo_type = $this.find('#select_photo_type');
        txt_account_num = $this.find('#refn02_account_num');
        txt_account_pw = $this.find('#refn02_account_pw');
        btn_submit = $this.find("#btn_submit");
        btn_masking = $this.find("#btn_masking");

        // convertImg.attr("data-flag","false");
        // baseImg.attr("data-flag","false");

        img_photo.on('vclick',onClickPhoto);
        btn_submit.on('vclick', onClickSubmit);
        btn_masking.on('vclick', onClickMasking);
        select_account_type.on('change', onChangeAccountType );
        txt_account_num.on({ touchstart : function() { $this.blur(); }, vclick : onClickAccountNumber });
        txt_account_pw.on({ touchstart : function() { $this.blur(); }, vclick : onClickAccountPassword });

		if ( DGB.isIPhone() ) {
			$this.find('.pinpadBox').bind('tap', function() {
				$this.find('input').blur();
			});
		}
	}

    function _pageshow() {
        // 이전 버튼 재정의
        $this.find('.jqm-header .jqm-back-link').off('vclick').on('vclick', onBackPage);
        WL.App.overrideBackButton(onBackPage);
    }

    function onBackPage() {
        showConfirm(function(btn){
            if (btn == '1') {
                DGB.Page.backPage();
            }
        }, "입력하신 사용자정보가 [초기화] 됩니다!\n작성화면을 나가시겠습니까?");
        return false;
    }

    function initData() {
        switch( _data.biz_dvcd ) {
            case 'EF1':
                title.text('인터넷뱅킹-상세입력');
                break;
            case 'EF2':
                title.text('폰뱅킹-상세입력');
                break;
        }
        nextKey ='';
        $this.data('isMasking', false);
        list_old_account = [];
        list_new_account = [];
        isTakeFrontPhoto = false;

        if( isDefaultImage ) {
            img_photo.removeAttr('src');
            //img_photo.attr('src', '../images/btn_pinpad_frontcam.png');
        }
        isDefaultImage = true;

        if(DGB.isDebug()){
            img_base.removeAttr('src');
        	//img_base.attr('src', 'images/btn_pinpad_frontcam.png');
        }
        
        
        select_account_type.val('').selectmenu("refresh");
        select_photo_type.val('02').selectmenu("refresh");
        txt_account_num.val('');
        txt_account_pw.val('').attr('data-enc', '');
        _layout.refreshLayout();
    }

    // 사진촬영
    function onClickPhoto() {
        capturePhoto(onPhotoSuccess);
        return false;
    }

    function onPhotoSuccess(imageData) {
        img_photo.attr("src", "data:image/jpeg;base64," + imageData);

        var image = new Image();
        image.src = img_photo.attr("src");
        image.onload = function() {
            var w =  image.width;
            var h = image.height;

            // 높이가 클 경우 90도 변경
            canvas.width = Math.max(w, h);
            canvas.height = Math.min(w, h);
            rotateImage(context, image, canvas, (w >= h) ? {rotate:0} : undefined);

            img_photo.attr({"src" : canvas.toDataURL('image/JPEG'), width : "45%"});
            img_base.attr({"src" : canvas.toDataURL('image/JPEG')});

            isTakeFrontPhoto = true;
            $this.data('isMasking', false);
            _layout.refreshLayout(function() {
                dgbLoading(false);
            }, 500);
        };
    }

    // 이미지 회전
    function rotateImage (ctx, image, canvas, option) {

        var DEGREES_TO_ROTATE = -90;	//기본값
        var POSITION_Y = 0;			//기본값
        if (option != undefined) {
            if (option.rotate != undefined) {	DEGREES_TO_ROTATE = option.rotate;	}
            if (option.y != undefined) {	POSITION_Y = option.y;	}
        }

        var canvasWidthHalf = Math.floor( canvas.width / 2 );
        var canvasHeightHalf = Math.floor( canvas.height / 2 );
        var widthHalf = Math.floor( image.width / 2 );
        var heightHalf = Math.floor( image.height / 2 );

        ctx.save();
        ctx.translate( canvasWidthHalf, canvasHeightHalf + POSITION_Y);
        //ctx.rotate( ( Math.PI / 180 ) * DEGREES_TO_ROTATE );
        ctx.drawImage( image, -widthHalf, -heightHalf );
        ctx.restore();
    }

    function showAccountList() {
        var type = select_account_type.val();
        var title = select_account_type.find('option:selected').text();
        var data = type == '01' ? list_old_account : list_new_account;
        var items = [];
        for(var i=0; i<data.length ; i++){
        	if(type=='01')
        		items[i] = (i+1) +') - ' + data[i].ACNO ;
        	else
        		items[i] = (i+1) +') - ' + data[i].DPO_SMRT_PBRL_RCPNO ;
        }
        var nextStr = ''
        if(nextKey && type=='01')  {
            items[data.length] = '계속 (다음 조회)';
            nextStr =' - 계속';
        }

        DGB.Common.selectList(title + ' [' + data.length + '건]'+nextStr ,
            items,
            function (index) {
        		if(data.length == index){ //Next Click
                    onClickContinueAccount();
        		}else{
            		if(type=='01')
            			txt_account_num.val(data[index].ACNO);
            		else
            			txt_account_num.val(data[index].DPO_SMRT_PBRL_RCPNO);
        		}
            },
            function () { }
        );
    }

    function onChangeAccountType() {
        txt_account_num.val('');
        txt_account_pw.val('').attr('data-enc', '');
        onClickAccountNumber();
        return false;
    }

    function onClickAccountNumber() {
        var type = select_account_type.val();
        switch( type ) {
            case '':
                showAlert('출금계좌유형을 선택해 주세요.');
                break;
            case '01':
                if( list_old_account.length == 0) {
                    onRequestAccountList();
                } else {
                    showAccountList();
                }
                break;
            case '02':
                if( list_new_account.length == 0 ) {
                    onRequestAccountList();
                } else {
                    showAccountList();
                }
                break;
        }
        return false;
    }
    function onClickContinueAccount() {
        onRequestAccountList();
        return false;
    }

	function onClickAccountPassword() {
		onE2K('num','refn02_account_pw', '4', '4', '계좌비밀번호', '1');
		return false;
	}

    function onClickMasking() {
        if( !DGB.isDebug() && !isTakeFrontPhoto ) {
            showAlert(Messages.msg047);
            return false;
        }

        isMaskingPage = true;
        DGB.Page.triggerPage("#RESU002", "parentpage", [{
            parent : $this,
            canvas : $(canvas),
            context : context,
            img_photo : img_photo,
            img_base : img_base
        }]);
        DGB.Page.changePage('#RESU002');
        return false;
    }

    function onClickSubmit() {
        var msg;
        if ( !select_account_type.val() ) msg = "출금계좌유형을 선택해 주세요.";
        else if( !txt_account_num.val() )  msg = "출금계좌를 선택해 주세요.";
        else if( !txt_account_pw.val() ) msg = "출금계좌 비밀번호를 입력해 주세요.";
        else if( !select_photo_type.val() ) msg = "실명증표종류를 선택해 주세요.";
        else if( !DGB.isDebug() && !isTakeFrontPhoto ) msg = Messages.msg047;		// 실명증표를 촬영하지 않은 경우
        else if( !$this.data('isMasking') ) {                   // 실명증표 마스킹을 하지않은 경우
            showConfirm(function(btn) {
                if (btn == '1') {
                    onClickMasking();
                }
            }, Messages.msg211);
            return false;
        }


        // Error Message
        if( msg ) {
            showAlert(msg);
            return false;
        }

        onSubmit();
        return false;
    }

    function onSubmit() {
        // 텍스트 배경.
        context.fillStyle = 'black';
        context.fillRect(0, 0, 320, 23);
        context.restore();

        // 텍스트 입력
        var data = getYYYYMMDDHHmmss() + "-" + USER_INFO.WORKORG_CD + USER_INFO.ENOB;
        context.fillStyle = 'white';
        context.font = '15pt Arial';
        context.fillText(data, 5, 17);
        context.restore();

        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00103',
            parameters : [{
            	BIZ_DVCD : "EF",
                TELLER_NUM : USER_INFO.ENOB,
                TELLER_BRNO : USER_INFO.WORKORG_CD,       
                AC_TYPE : select_account_type.val(), 				//01-기존계좌, 02-신규예정
                SCAN_DVCD : select_photo_type.val(),				// 실명증표종류
                IMG_COMBINE : canvas.toDataURL('image/JPEG'),	    // 병합된 최종 이미지
        		DPO_SMRT_PBRL_RCPNO :txt_account_num.val(),
        		USPS_ID :_data.cust_id,
        		CNNT_PSWD : _data.cnnt_pswd, 					    // 접속 비밀번호
        		CSH_CARD_PSWD : txt_account_pw.attr('data-enc'),	//     계좌(신규예정)비밀번호
        		RNNO : _data.rnno,
        		ENCODE_NUM : "CNNT_PSWD, CSH_CARD_PSWD, RNNO",
                ENCODE_STR : "",
                CS_ID : _menuId,
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessSubmit,
            onFailure : onFailureSubmit,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    // 스마트핀패드 업로드 콜백함수
    function onSuccessSubmit(data) {
        var result = data.invocationResult;

        dgbLoading(false);
        if(result.PRCS_RSLT_DVCD =="9") {
            showAlert(result.ERR_MSG);
            return false;
        }

        if( result.success === "no" ) {
            showAlert(Messages[result.MSG_CD]);
        } else {
            showAlert(Messages.msg04F);
            initData();
            DGB.Page.backPage();
        }
        _layout.refreshLayout();
    }

    function onFailureSubmit() {
        dgbLoading(false);
        showAlert(Messages.err001);
    }

    function onRequestAccountList() {
        var inv = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00202',
            parameters : [{
                TELLER_NUM : USER_INFO.ENOB,
                TELLER_BRNO : USER_INFO.WORKORG_CD,
                NEXT_KEY : nextKey,
                TOTCNT : 50,
                AC_TYPE : select_account_type.val(), //01-기존계좌, 02-신규예정
                RNNO : _data.rnno,
                ENCODE_NUM : "RNNO",
                ENCODE_STR : "",
                CS_ID : _menuId,
                TRANS_KEY : IS_TRANS_KEY
            }]
        };

        var opt = {
            onSuccess : onSuccessAccountList,
            onFailure : onFailureAccountList,
            invocationContext : {}
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

	// 스마트핀패드 업로드 콜백함수
	function onSuccessAccountList(data) {
        dgbLoading(false);

		var result = data.invocationResult;
        if( result.PRCS_RSLT_DVCD == "9") {
            showAlert(result.ERR_MSG);
            return false;
        }
        var arr_data = [];

        if( result.type == '01' ) {
            nextKey = result.NEXT_KEY||'';
            arr_data = list_old_account = list_old_account.concat(result.resultSet);
        }
        else
            arr_data = list_new_account = result.resultSet;

        if( arr_data.length )
            showAccountList();
        else
            showAlert(result.ERR_MSG);
	}

	function onFailureAccountList() {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	$(document).on({
		pageinit : _pageinit,
        pagebeforeshow : function() {
            if( !isMaskingPage )
                initData();

            isMaskingPage = false;
        },
        pageshow : _pageshow,
        parentpage : function(evt, param) {
            if( param ) {
                _data.biz_dvcd = param.biz_dvcd;
                _data.cust_id = param.cust_id;
                _data.rnno = param.rnno;
                _data.cnnt_pswd = param.cnnt_pswd;
                _menuId = param.menuId;
            } else {
                showAlert(Messages.err001);
                DGB.Page.backPage();
            }
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REFN002');
})();
