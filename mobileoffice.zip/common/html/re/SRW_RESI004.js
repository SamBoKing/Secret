(function() {
	var $this;
	var brachNum = "";
	var _menuId;
	var _layout;
    var _buttonText;
	var locDetailview = false;
    var month_table_title;

	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _buttonText = $this.find('#resiOrgNm').prev('span').find('.ui-btn-text');

        month_table_title = $this.find('#MONTH_TABLE_TITLE');
        month_table_title.text( new Date().getFullYear() );

        // 모점, 자점 리스트 초기화
        USER_INFO.BRBAS = USER_INFO.BRBAS || [];

		if(WL.Client.getEnvironment() == WL.Environment.IPHONE) {  // 폰트사이즈 조정
            $this.find('table').css('font-size', '12px');
            $this.find('.ui-grid-a div > h3').css('fontSize', '14px');
		}

        // 영업점변경
        $this.find('#resiOrgNm').off('vclick').on('vclick', function() {
            clickGroup();
            return false;
        });

        // 본부직원이면서 임원이 아닌 경우엔 [소속직원보기], [영업점현황] 조회 권한 없음
        if(Number(USER_INFO.ORG_CD) > 900 && !DGB.Common.isAdminMember() ) {
            $this.find('.optionFunc').hide();
        } else {
            // 영업계수 조회
            $this.find('#businessFigureBtn').off('vclick').on('vclick', function() {
                DGB.Page.triggerPage("#RESI001", "selectbutton", {'menuId':"RE0101"});
                DGB.Page.changePage('#RESI001');
                return false;
            });

            // 영업실적 조회
            $this.find('#businessResultBtn').off('vclick').on('vclick', function() {
                DGB.Page.triggerPage("#RESI005", "selectbutton", {'menuId':"RE0103"});
                DGB.Page.changePage('#RESI005');
                return false;
            });

            // 소속직원보기
            $this.find('#branchStaffBtn').off('vclick').on('vclick', function() {
                if(brachNum === "999") {		// 은행전체인 경우에는 소속직원 보기 안됨
                    showAlert(Messages.msg051);
                    return false;
                }
                locDetailview = true;
                DGB.Page.triggerPage("#RESI003", "selectmenu", {'menuId':"EM0101", options:{'type':'3', 'keyword':brachNum}});
                DGB.Page.changePage('#RESI003');
                return false;
            });
        }
	};

    function clickGroup() {
        if( DGB.Common.isAdminMember() ) {
            var args = {
                menuId : _menuId,
                parentId : "RESI004"
            };
            DGB.Page.triggerPage("#RESI002", "parentpage", [args]);
            setTimeout(function () { DGB.Page.changePage('#RESI002'); }, 200);

        } else if(USER_INFO.GROUP_ID == "G003" && USER_INFO.BRBAS.length > 1 ) {
            var BRNames = [];
            for(var i=0; i<USER_INFO.BRBAS.length; i++){
                BRNames.push(USER_INFO.BRBAS[i].BRC_NM);
            }

            DGB.Common.selectList("지점 선택", BRNames,
                function(index) {
                    searchBranch = USER_INFO.BRBAS[index].BRNO;
                    searchBranchName = USER_INFO.BRBAS[index].BRC_NM;
                    setContents();
                },
                function(err) { }
            );
        } else {
            showAlert(Messages.msg009);
        }
    }
	
	function setContents() {
        // TODO 임원권한 조건 정의 필요
        if( Number(USER_INFO.ORG_CD) < 900 )
            brachNum = USER_INFO.ORG_CD;
        else
            brachNum = searchBranch || '999';

        // 은행전체 조회
        if(brachNum === "999") {
            showAlert(Messages.msg050);
            _layout.refreshLayout(function(){ }, 400);
            return;
        }

        if( DGB.Common.isAdminMember() ) {
            brachNum = searchBranch || "999";
            _buttonText.text(brachNum == "999" ? "영업점변경" : searchBranchName);
        } else if(USER_INFO.GROUP_ID != "G003" && Number(USER_INFO.ORG_CD) > 900) {
            brachNum = "999";
            _buttonText.text("은행전체");
        } else {
            // 일반 영업점 직원의 경우 영업점현황, 소속직원보기 가능, 조회영업점변경 불가능
            brachNum = searchBranch || USER_INFO.ORG_CD;
            _buttonText.text(searchBranchName || USER_INFO.ORG_NM);
        }

        _layout.refreshLayout();
        var invocationData = {
            adapter : 'SocketTransactionAdapter',
            procedure : 'TRE00109',
            parameters : [{
                SEARCH_BRANCH : brachNum,
                TELLER_NUM : USER_INFO.ENOB,
                TELLER_BRNO : USER_INFO.ORG_CD,
                CS_ID:_menuId,
                ENCODE_STR : ""
            }]
        };

        var options = {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        };

        if( !locDetailview ) {
            dgbLoading(true);
            callProcedure(invocationData, options);
        }
        locDetailview = false;
	}
	
	// 영업점현황 조회
	function displayResult(data) {
        if( data.resultSet == "-1" ) {
            showAlert(Messages.msg030);
            return;
        }

		var item = data.invocationResult;
        var Info = item.branchInfo || {};
        var PyPer = item.pyPerformance || {};
        var PyPer2012 = item.pyPerformance2 || {};
        var PmPer = item.pmPerformance || {};

		// 지점정보
		$this.find('#FNMBON').text(Info.FNMBON);
        $this.find('#FILOPN').text(Info.FILOPN);
        $this.find('#FNOTEL').text(Info.FNOTEL);
        $this.find('#FNMGRP').text(Info.FNMGRP);
        $this.find('#FNOFAX').text(Info.FNOFAX);
        $this.find('#FNMCHUL').text(Info.FNMCHUL);
        $this.find('#FNMJUSO').text(Info.FNMJUSO);
        $this.find('#FJMTGSO_U').text(Info.FJMTGSO_U);
        $this.find('#FJMMYUN_U').text(Info.FJMMYUN_U);
        $this.find('#FIMBO_U').text(Info.FIMBO_U);
        $this.find('#FIMDAE_U').text(Info.FIMDAE_U);
        $this.find('#FGUANRI_U').text(Info.FGUANRI_U);
        $this.find('#FJUTGSO_U').text(Info.FJUTGSO_U);
        $this.find('#FJUPYNG_U').text(Info.FJUPYNG_U);
        $this.find('#FJUDAESU_U').text(Info.FJUDAESU_U);
        $this.find('#GB365_IN').text(Number(Info.GB365_IN));
        $this.find('#GB365_OUT').text(Number(Info.GB365_OUT));

        // 월별 통계 테이블 년도 변경
        if( PmPer.YR ) {
            month_table_title.text( PmPer.YR );
        }

        // 당해년 전월
        for(var i = 1; i <= 12; i++) {
            var val = eval("PmPer." + ('F' + pad(i))) || '.';
            $this.find('#monVal' + i).text(val);
        }

        $this.find('#table-custom-4 tbody').html('');
		if( PyPer.PRCS_RSLT_DVCD == "0" ) {
			// 최근 3년간 성과평가
			for(var i in PyPer.resultSet) {
                $this.find('#table-custom-4 tbody').append(
                    "<tr>" +
                        "<td>"+PyPer.resultSet[i].FILIBR+"</td>" +
                        "<td>"+PyPer.resultSet[i].FYEAR+"</td>" +
                        "<td>"+PyPer.resultSet[i].FPRIZE+"</td>" +
                    "</tr>"
                );
			}
		}
        //2012년 이전
        if( PyPer2012.PRCS_RSLT_DVCD != undefined && PyPer2012.PRCS_RSLT_DVCD  == '0')  {
            // 최근 3년간 성과평가
            for(var i in PyPer2012.resultSet) {
                $this.find('#table-custom-4 tbody').append(
                    "<tr>" +
                    "<td>"+PyPer2012.resultSet[i].FILIBR+"</td>" +
                    "<td>"+PyPer2012.resultSet[i].FYEAR+"</td>" +
                    "<td>"+PyPer2012.resultSet[i].FPRIZE+"</td>" +
                    "</tr>"
                );
            }
        }
		$this.find('#resiBranchInfo').show();
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	}
	
	function displayError() {
		showAlert(Messages.msg030);
		dgbLoading(false);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backMenu();
		},
		pageshow: function(){
            setContents();
        },
		pagebeforehide: function( ) {
			if( !locDetailview ) {
				$this.find('#table-custom-3 .resiMonVal').val('');
                $this.find('#table-custom-4 td').val('');
			}
		},
		selectbutton: function(param) {
			_menuId = param.menuId;
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		parentpage :function (evt, param) {
			searchBranch = param.searchBranch;
			if(searchBranch.length == 1) searchBranch = "00" + searchBranch;
			else if(searchBranch.length == 2) searchBranch = "0" + searchBranch;

			$('#RESI004 #resiOrgNm').prev('span').find('.ui-btn-text').text(param.branchName);
			searchBranchName = param.branchName;
			brachNum = searchBranch;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RESI004');
	
})();
