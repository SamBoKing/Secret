(function() {
	var $this, _menuId, _layout, _item = {};
    var request_wfid, request_name, title, request_msg, request_date, send_btn;
    var prevPage;

	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        request_wfid = $this.find('#request_wfid');
        request_name = $this.find('#request_name');
        title = $this.find('#title');
        request_msg = $this.find('#request_msg');
        request_date = $this.find('#request_date');
        send_btn = $this.find("#send_btn");
        send_btn.off('vclick').on('vclick', onClickRequest);
	};

    var onClickRequest = function() {
        showConfirm(function(btn){
            if (btn == '1') {
                requestData();
            }
        }, Messages.msg611);
        return false;
    };

    var requestData = function() {
        var opt = {
            onSuccess : function(data) {
                dgbLoading(false);
                var result = JSON.parse(data.invocationResult.resultSet);
                if( result ) {
                    var msg = result.success ? Messages.msg612 : result.msg + ', Code : ' + result.value;
                    showAlert('긴급형상관리', msg, function () {
                        if (prevPage) {
                            prevPage.data('refresh', true);
                        }
                        DGB.Page.backPage();
                    });
                } else {
                    showAlert(Messages.err001);
                }
            },
            onFailure : function() {
                dgbLoading(false);
                showAlert(Messages.err001);
            },
            invocationContext : {}
        };

        var inv = {
            adapter : 'ExternalAdapter',
            procedure : 'ITMS0002',
            parameters : [{
                CS_ID : _menuId,
                Enob : USER_INFO.ENOB,
                wf_id : _item.request_wfid
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    };

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
            prevPage = $('#REIT001');
            DGB.Common.backPage();

            _layout.refreshLayout();
            _layout.resetLayout();     // 스크롤위치 초기화

            if( _item ) {
                request_wfid.text((_item.request_wfid || '') + ' - [' + _item.request_status + ']');
                request_name.text(
                        (_item.request_name || '') +
                        (_item.request_team ? ' - [' + _item.request_team + ']' : '')
                );
                title.text(_item.title || '');
                request_msg.text(_item.request_msg || ' ');
                request_date.text(_item.date || '');
             }
        },
        parentpage :function (evt, param) {
            _item = param.item || {};
            _menuId = param.menuId;
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REIT002');
})();
