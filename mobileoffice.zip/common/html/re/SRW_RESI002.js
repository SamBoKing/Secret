(function() {
	var $this;
	var _menuId, _layout, _search, _list;
	var parentId;

	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT);

		_search = $this.find('#resiInputSearch');
		_list = $this.find('#organizationListview');

		$this.find('#resiSearchBtn').on('vclick', function() {
			onSearch();
			return false;
		});
		$this.find('#resiInputSearch').on('keypress', function(e) {
			if( e.keyCode == 13 ) {
				onSearch();
				return false;
			}
		});
	};
	
	function onSearch() {
		$this.find('#resiSearchBtn').focus();

		var param = _search.val();
		if (param.length < 2) {
			showAlert(Messages.msg057);
			return;
		}

		dgbLoading(true);
		var inv = {
				adapter : 'DBTransactionAdapter',
				procedure : 'TRE00002',
				parameters : [{
					SEARCH_ORG_NM : param,
					CS_ID : _menuId
				}]
		};
		
		var opt = {
			onSuccess : onSuccess,
			onFailure : onFailure,
			invocationContext : {}
		};

		setTimeout(function () {
			callProcedure(inv, opt);
		}, 400);

	}

	function onSuccess(data) {
		var item = data.invocationResult.resultSet;
		var html = "";
		var listItems = [];
		if(item.length == 1) {
			var args = {
				searchBranch : item[0].ORG_CD,
				branchName : item[0].ORG_NM,
				menuId : _menuId
			};

            DGB.Page.triggerPage("#"+parentId, "parentpage", [args]);
			setTimeout(function () {
				DGB.Page.changePage('#'+parentId);
			}, 300);
		} else {
			for (var i=0; i<item.length; i++) {
				html =  "<li>"+
							"<a href='#' class='resi002List' id='resi002List_"+i+"' data-branch='"+item[i].ORG_CD+"' data-brnm='"+item[i].ORG_NM+"'>"+ 
								"<h3>"+item[i].ORG_NM+"</h3>"+
							"</a>"+
						"</li>";
				listItems[i] = html;
			}
			
			_list.html(listItems.join(''));
			_list.listview( "refresh" );
			_list.trigger("updatelayout");
			_layout.refreshLayout(function(){
				dgbLoading(false);
			}, 300);
		}

		_list.find('li a.resi002List').off('vclick').on('vclick', function() {
            DGB.Page.triggerPage("#"+parentId, "parentpage", [{
					searchBranch : $(this).attr('data-branch'),
					branchName : $(this).attr('data-brnm'),
					menuId : _menuId
			}]);
			setTimeout(function () {
				DGB.Page.changePage('#'+parentId);
			}, 300);
			return false;
		});
	}

	function onFailure() {
		dgbLoading(false);
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Common.backPage();
		},
		pageshow: function() {
			_layout.refreshLayout();
		},
		pagehide: function() {
			_list.html("");
			_search.val("");
		},
		parentpage :function (evt, param) {
			parentId = param.parentId;
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#RESI002');
})();
