(function() {
	var $this;
	var $parent;
	var _menuId;
	var _layout;

	var editor, editor_layout, editor_scroll;
	var canvas, context, img_photo, img_base;
	var isBase;

	// scroll
	var step1 = 80;
	var step2 = 40;

	var _pageinit = function() {
		$this = $(this);
		// _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
		// _layout.refreshLayout();

		editor_layout = $this.find("#editor_layout");
		editor_scroll = $this.find("#editor_scroll");

		$this.find('#btn_cancel').off('vclick').on('vclick',function() {
			editor.deleteShape(editor.shapes[0]);
			return false;
		});

		$this.find('#btn_restore').off('vclick').on('vclick',function() {
			restoreImage();
			return false;
		});

		$this.find('#btn_ok').off('vclick').on('vclick',function() {
			convertImage();
			DGB.Page.backPage();
			return false;
		});

		$this.find('#btn_left1').off('vclick').on('vclick', function() {
			scrollContent('left', step1);
			return false;
		});

		$this.find('#btn_left2').off('vclick').on('vclick', function() {
			scrollContent('left', step2);
			return false;
		});

		$this.find('#btn_right1').off('vclick').on('vclick', function() {
			scrollContent('right', step1);
			return false;
		});

		$this.find('#btn_right2').off('vclick').on('vclick', function() {
			scrollContent('right', step2);
			return false;
		});
	};

	function setMode(mode) {
		editor.setMode(mode == 'selectp' ? 'select+' : mode);
	}

	function _pageshow() {
		isBase = false;
		if( !img_photo[0] ) {
			showAlert('이미지 없음!');
			return;
		}

		var w = img_photo[0].naturalWidth;
		var h = img_photo[0].naturalHeight;

		// Edit Size
		editor_layout.width(w);
		editor_layout.height(h);

		// Canvas Size
		canvas.attr({width:w,height:h}).css({width:w,height:h});

		if( editor ) {
			editor.deleteAll();
		}
		editor = new VectorEditor(editor_layout[0], w, h);
		editor.container.style.position = '';

		// * 중요 * 상대경로로 넣을시 오류남(무조건 절대경로)
		if( DGB.isDebug() )
			editor.draw.image(img_photo[0].currentSrc, 0, 0, w, h);
		else
			editor.draw.image(img_photo[0].src, 0, 0, w, h);

		// Init Mode
		setMode("rect");
	}

	function restoreImage() {
		if( editor ) {
			isBase = true;
			var w = img_base[0].naturalWidth;
			var h = img_base[0].naturalHeight;
			editor.deleteAll();

			if( DGB.isDebug() )
                editor.draw.image(img_base[0].currentSrc, 0, 0, w, h);
            else
				editor.draw.image(img_base[0].src, 0, 0, w, h);
		} else {
			DGB.Log.e('Masking Image Restore - Editor Error!');
		}
	}

	function convertImage() {
		context.clearRect(0, 0, canvas.width(), canvas.height());
		if( isBase )
			context.drawImage(img_base[0], 0, 0);
		else
			context.drawImage(img_photo[0], 0, 0);
		context.restore();

		// 마스킹 처리
		var shape = editor.shapes[0];
		if( shape ) {
			context.fillStyle = shape.attrs.fill;
			context.fillRect(shape.attrs.x, shape.attrs.y, shape.attrs.width, shape.attrs.height);
			context.restore();

			// Parent Page Masking Checking
			$parent.data('isMasking', true);
		} else if( isBase ) {
			// Parent Page Masking Checking
			$parent.data('isMasking', false);
		}

		var src = canvas[0].toDataURL("image/JPEG");
        img_photo.attr({"src" : src, width : "45%"});
	}

	function scrollContent(direction, step) {
		var amount = (direction === "left" ? "-=" : "+=") + step + "px";
		editor_scroll.animate({ scrollLeft : amount });
	}

	$(document).on({
        pageinit : _pageinit,
		pagebeforeshow : function() {
			DGB.Common.backPage();
		},
		pageshow : _pageshow,
        parentpage : function(evt, param) {
            if( param ) {
                $parent = param.parent;
                canvas = param.canvas;
                context = param.context;
                img_photo = param.img_photo;
                img_base = param.img_base;
            } else {
                showAlert(Messages.err001);
                DGB.Page.backPage();
            }
        },
		selectmenu : function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            // DGB.Common.refreshLayout(_layout);
			return false;
		}
	}, '#RESU002');
})();
