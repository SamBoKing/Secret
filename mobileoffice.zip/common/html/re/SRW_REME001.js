(function() {
	var $this, _menuId, _layout, locDetailview; // 상세조회에서 돌아왔을때 목록을 남겨둘지 체크


	var pageinit = function(instance) {
		$this = instance;
		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
	};
	
	function setContents() {
		dgbLoading(true);
		var inv = {
			adapter : 'SocketTransactionAdapter',
			procedure : 'TRE00003',
			parameters : [{
				CS_ID:_menuId,
				TELLER_NUM : USER_INFO.ENOB
			}]
		};

		var opt = {
			onSuccess : displayResult,
			onFailure : displayError,
			invocationContext : {}
		};
		callProcedure(inv, opt);
	}
	
	function displayResult(data) {
		if(data.invocationResult.PRCS_RSLT_DVCD == "9") {
			dgbLoading(false);
			eaiSocketErrorDisplay(data.invocationResult.STD_GRAM_ERRC);
			return false;
		}
		
		var item = data.invocationResult.resultSet;
		var confDate = "";
		var html = "";
		var listItems = [];
		for (var i=0; i<item.length; i++) {
			html = "";
			if(confDate != item[i].CONF_DATE) {
				html = "<li data-role='list-divider'>"+item[i].CONF_DATE+" 회의자료</li>";
				confDate = item[i].CONF_DATE;
			}
			var daviewUrl = {};
			daviewUrl.fileNames = item[i].FILE_NAME;
			daviewUrl.baseUrl = item[i].CONF_URL;
			
			html += "<li>"+
						"<h3>"+item[i].CONF_ORG+" | "+item[i].CONF_TITLE+"</h3>"+
						"<p>최종수정일("+item[i].UPDATE_DATE+")</p>"+
						"<div class='custMainBg initContents' style='width:70%; letter-spacing:0; padding:8; font-size:15px;'>"+item[i].CONF_MEMO+""+
						"<div class='storyIcon'><a href='#' class='reme001DocList ui-link noTitle' data-callDaview='"+JSON.stringify(daviewUrl)+"'>" +
						"<img src='images/icn_filedown.png' class='reme-action-icon'></a></div></div>"+
					"</li>";
			listItems[i] = html;
		} 
		$("#remeConferencelistview").html(listItems.join(''));
		listItems = null;
        item = null;
        html = "";
		$("#remeConferencelistview").listview( "refresh" );
		$("#remeConferencelistview").trigger("updatelayout");
		
		//문서리스트 클릭 이벤트
		$('#remeConferencelistview').find('li a.reme001DocList').off('vclick').on('vclick',function(){

			var daviewUrls ={};
			var data = $(this).attr('data-callDaview');
			daviewUrls = JSON.parse(data);
			if(!daviewUrls.fileNames){
				showAlert(Messages.msg02L);
				return false;
			}

			var filelist = daviewUrls.fileNames.split(",");
			if(filelist.length == 1){
				daviewUrls.url = daviewUrls.baseUrl + "/" + filelist[0];
				callDaview(daviewUrls);
			}else{
				DGB.Common.selectList("임원회의자료",
					filelist,
					function (index) {
						daviewUrls.url = daviewUrls.baseUrl + "/" + filelist[index];
						callDaview(daviewUrls);
					},
					function () { }
				);
			}

			return false;
		});
		
		//상세조회에서 돌아와도 계속 조회되도록 수정.
		//locDetailview = true;
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	
	}

	function displayError() {
		dgbLoading(false);
		showAlert(Messages.msg002);
	}

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pagebeforeshow: function() {
			DGB.Alive.start();
			$("#remeConferencelistview").empty();
		},
		pageshow: function() {
            _layout.refreshLayout();
            if( !locDetailview ) {
                setContents();
            }
        },
		pagebeforehide : function() {
			DGB.Alive.end();
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REME001');
})();
