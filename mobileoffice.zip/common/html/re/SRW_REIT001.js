(function() {
	var $this, _menuId, _layout, _list;
    var empty_itmes = {itmes:[]};

	var pageinit = function(instance) {
		$this = instance;
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        $.Mustache.add('tmpl-list', $this.find('#tmpl-list').html());
        _list = $this.find('#list');
        _list.mustache('tmpl-list', empty_itmes);
        _layout.refreshLayout(function() {});
    };

    function request() {
        var opt = {
            onSuccess: onSuccess,
            onFailure: onFailure,
            invocationContext: {}
        };

        var inv = {
            adapter : 'ExternalAdapter',
            procedure : 'ITMS0001',
            parameters : [ { CS_ID : _menuId } ]
        };

        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var item = JSON.parse(data.invocationResult.resultSet) || empty_itmes;
        _list.empty()
            .mustache('tmpl-list', item)
            .listview('refresh')
            .trigger('updatelayout');
        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
        _layout.resetLayout();     // 스크롤위치 초기화

        _list.find('li a').off('vclick').on('vclick',function() {
            var _item = item.items[$(this).attr('data-item')];
            if( !_item ) {
                showAlert(Messages.err001);
                return false;
            }

            var args = {
                menuId : _menuId,
                item : _item
            };
            DGB.Page.triggerPage("#REIT002", "parentpage", [args]);
            DGB.Page.changePage('#REIT002');
            return false;
        });
    }

    function onFailure() {
        dgbLoading(false);
        showAlert(Messages.err001);
    }

	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
            DGB.Common.backMenu();
            if( $this.data('refresh') ) {
                $this.data('refresh', false);
                request();
            }
        },
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
            request();
		},
        pulldownrefresh :function(){
            request();
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#REIT001');
})();
