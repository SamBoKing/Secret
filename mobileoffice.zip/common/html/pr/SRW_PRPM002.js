
(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$('#PRPM002 #productSearchBtn2').off('vclick').on('vclick', function() {
			prpm02Search();
            return false;
		});
		
		
		$this.find('#prpmInputSearch2').on('keypress',function(e){
			if(e.keyCode == 13) {
				prpm02Search();
				return false;
			}
		});
		
		//리스트클릭 이벤트
		$('#prpmMinorListview').find('li a.prpm002List').off('vclick').on('vclick',function(){
			var item = $(this).attr('data-minor');
			var detailId ="PRPM003"; 
			
			var args={};
			args.menuId = _menuId;
			args.prPrvDvcd = "01";
			args.hmpgFnPdDvcd = item;
			
			// $("#"+detailId).trigger("parentpage",[args]);
            DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
            DGB.Page.changePage('#'+detailId);
			return false;
		});
		
	};
	
	function prpm02Search(){
		var productName = $('#PRPM002 #prpmInputSearch2').val().toUpperCase();
		if (productName == "") {
			showAlert(Messages.msg056);
			return;
		}

		var detailId ="PRPM003";
		var args={};
		args.menuId = _menuId;
		args.productName = productName;

        DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
        DGB.Page.changePage('#'+detailId);
		return false;
	}
	
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			DGB.Common.backPage();
			_layout.refreshLayout();
		},
		pagebeforehide: function(evt, ui) {
			$('#PRPM002 #prpmInputSearch2').val('');
		},
		parentpage :function (evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
			if ( DGB.isIPhone() ){
				$("#productSearchBtn2").focus();
			}
            return false;
		}
	}, '#PRPM002');
})();
