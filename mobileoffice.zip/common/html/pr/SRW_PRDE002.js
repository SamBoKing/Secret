(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;
	var depositCodeSearch = null;
	var listSearch = null;
	var inDate = undefined;
	var pdCd = undefined;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight);
		
		if(WL.Client.getEnvironment() == WL.Environment.IPHONE) {  // 폰트사이즈 조정
			$('#PRDE002 table').css('font-size', '12px');
			$('.ui-grid-a div > h3').css('fontSize', '14px');
		}
		
		if (WL.Client.getEnvironment() == WL.Environment.IPHONE || WL.Client.getEnvironment() == WL.Environment.IPAD) {
			$('#PRDE002 .custIscroll').bind('tap', function() {
				$('#PRDE002 input').blur();
				$('#PRDE002 #prde002Selectbox').blur();
			});
		}
		
		// 조회 버튼
		$this.find('#prde002Search').off('vclick').on('vclick', function() {
			$('#PRDE002 #prde002Date').blur();
			setTimeout(function () {
				listSearch.call();
			}, 300);
		});
		
		// 기준일자 변경
		$this.find('#prde002Selectbox').on('change', function(){
			pdCd = $('#prde002Selectbox:visible option:selected').val();
//			listSearch.call();
		});
		
		inDate = nmf.utils.DateFormat.format(new Date(), 'yymmdd');
		$('#PRDE002 #prde002Date').val(inDate);
		
		depositCodeSearch = {
				options : {
					onSuccess : displayDepositCodeResult,
					onFailure : displayDepositCodeError,
					invocationContext : {}
				},

				call : function() {
					dgbLoading(true);

					invocationData = {
							adapter : 'DBTransactionAdapter',
							procedure : "TPR00002",
							parameters : [{
                                CS_ID : 'PR0202',
                                ENOB : USER_INFO.ENOB,
                                INQ_DVCD : "1" // 예금:1, 적금:2
                            }]
					};
					callProcedure(invocationData, this.options);
				}
			};
		depositCodeSearch.call();
	};
	
	function displayDepositCodeResult(data) {
		var item = data.invocationResult.resultSet;
		var html = "";
		var listItems = [];
		if(item.length != 0) {			
			for(var i=0; i<item.length; i++) {
				html =	"<option value='" +
				item[i].PD_CD+"'>" +
				item[i].PD_NM+"</option>";
				listItems[i] = html;
			}
			$('#PRDE002 #prde002Selectbox').append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
		} else {
			dgbLoading(false);
		}
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
//		$('#PRDE002 #prde002Selectbox option:eq(0)').attr('selected', 'selected');
	}
	
	function displayDepositCodeError() {
		dgbLoading(false);
	}

	listSearch = {
		options : {
			onSuccess : displayDepositRateResult,
			onFailure : displayDepositRateError,
			invocationContext : {}
		},

		call : function() {
			if(inDate != $('#PRDE002 #prde002Date').val()) {
			}
			inDate = $('#PRDE002 #prde002Date').val();
			if(inDate.length != 8) {
				showAlert(Messages.msg05C);
				return false;
			}
			
			pdCd = $('#prde002Selectbox:visible option:selected').val();
			
			dgbLoading(true);

			invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : "TPR00003",
					parameters : [
					              {IN_DATE : inDate,
					               PD_CD : pdCd,
					               CS_ID:_menuId,
                                   ENOB : USER_INFO.ENOB,
					               AYR_EN_R_DVCD1:"K0",
					               AYR_EN_R_DVCD2:"K1"}
					             ]
			};
			callProcedure(invocationData, this.options);
		}
	};
	
	function displayDepositRateResult(data) {
		$('#PRDE002 #prde002RateTable tbody').html('');
		
		var item = data.invocationResult.resultSet;
		var html = "";
		var listItems = [];
		if(item.length != 0) {
			for(var i=0; i<item.length; i++) {
				html  =	"<tr>" +
				"<td>"+item[i].PD_KNM+"</td>" +
				"<td>"+item[i].DPO_JN_PRID_CN+"</td>" +
				"<td>"+item[i].BAS_NTRT+"</td>" +
				"<td>"+item[i].AYR_NTRT+"</td>" +
				"<td>"+item[i].SLBR_HI_INRST+"</td>" +
                "<td>"+item[i].ITN_HI_INRST+"</td>" ;
               if(window.orientation == 0)
                   html  += "<td class='rmark displayNone'>"+item[i].RMRK+"</td>" ;
                else
                   html  += "<td class='rmark'>"+item[i].RMRK+"</td>" ;
                html  += "</tr>";
				listItems[i] = html;
			}
			
			_layout.resetLayout();
			
			$('#PRDE002 #prde002RateTable tbody').append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			mergeSameRow('prde002RateTable');
		} else {
			dgbLoading(false);
		}
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	}
	
	function displayDepositRateError(data) {
		dgbLoading(false);
		showAlert(Messages.err001);
	}

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			DGB.Common.backMenu();
			_layout.refreshLayout();

            if(window.orientation != 0){
                $('#PRDE002 .rmark').removeClass("displayNone");
            }
            else{
                $('#PRDE002 .rmark').addClass("displayNone");
            }
			setTimeout(function () {
				listSearch.call();
			}, 300);

            if(window.orientation == 0){
                showAlert(Messages.msg05D);
            }
		},
		pagebeforehide: function(evt, ui) {
			if(locDetailview == false) {
				$('#PRDE002 table td').val('');
			}
		},
        selectmenu :function(evt, param) {
            _menuId = param.menuId;
        },
		parentpage :function (evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            if(evt.orientation == 'landscape'){
                $('#PRDE002 .rmark').removeClass("displayNone");
            } else {
                $('#PRDE002 .rmark').addClass("displayNone");
            }
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRDE002');
})();