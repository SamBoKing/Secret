(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight, _searchHeight);
		
		$('#PRPM001 #productSearchBtn1').off('vclick').on('vclick', function() {
			prpm01Search();
            return false;
		});

		$this.find('#prpmInputSearch1').on('keypress',function(e){
			if(e.keyCode == 13) {
				prpm01Search();
				return false;
			}
		});

		//리스트클릭 이벤트
		$('#prpmMajorListview').find('li a.prpm001List').off('vclick').on('vclick',function(){
			var item = $(this).attr('data-major');
			var detailId ="PRPM003"; 
			var args={};
			args.menuId = _menuId;
			args.prPrvDvcd = item;

            switch (item){
                case '03':
                    DGB.Page.triggerPage("#PRPM007", "parentpage", [args]);
                    DGB.Page.changePage('#PRPM007');
                    break;
                case '04':
                    DGB.Page.triggerPage("#PRPM008", "parentpage", [args]);
                    DGB.Page.changePage('#PRPM008');
                    break;
                default :
                    DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
                    DGB.Page.changePage('#'+detailId);
                    break;
            }
//            DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
//            DGB.Page.changePage('#'+detailId);
			return false;
		});
		
		//예금상품클릭 이벤트
		$this.find('li a.prpm002Loc').off('vclick').on('vclick',function(){
            DGB.Page.triggerPage("#PRPM002", "parentpage", [{ menuId: _menuId }]);
            DGB.Page.changePage('#PRPM002');
			return false;
		});

        //카드클릭 이벤트
        $this.find('li a.prpm002Card').off('vclick').on('vclick',function(){
//            window.open("https://www.dgb.co.kr/com_ebz_fnc_sub_main.jsp", "_blank", "location=yes");
//        	window.open("https://www.dgb.co.kr/com_ebz_fnc_sub_main.jsp", "_system", "location=no");
            window.open(Messages.url022, "_blank", "location=yes,EnableViewPortScale=yes");
            return false;
        });

		//내가본 상품설명서
		$this.find('li a.prpm005Loc').off('vclick').on('vclick',function(){
            DGB.Page.changePage('#PRPM005');
			return false;
		});

        $this.find('li a.prpm001Capital').off('vclick').on('vclick',function(){
            DGB.Page.changePage('#PRPM006');
        });

        //노란우산
        $this.find('li a.prpm001Yello').off('vclick').on('vclick',function(){
            window.open(Messages.url021, "_blank", "location=yes,EnableViewPortScale=yes");
        });
	};
	
	function prpm01Search(){
		var productName = $('#prpmInputSearch1').val().toUpperCase();
		if (productName == "") {
			showAlert(Messages.msg056);
			return;
		}
		var detailId ="PRPM003"; 
		
		var args={};
		args.menuId = _menuId;
		args.productName = productName;
		
		// $("#"+detailId).trigger("parentpage",[args]);
        DGB.Page.triggerPage("#"+detailId, "parentpage", [args]);
        DGB.Page.changePage('#'+detailId);

	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function() {
            DGB.Common.backMenu();
            _layout.refreshLayout();
        },
		pagebeforehide: function(evt, ui) {
			$('#PRPM001 #prpmInputSearch1').val('');
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            if ( DGB.isIPhone() ){
                $("#productSearchBtn1").focus();
            }
            return false;
		}
	}, '#PRPM001');
})();
