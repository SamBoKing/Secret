(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;
	var depositCodeSearch = null;
	var listSearch = null;
	var inDate = undefined;
	var pdCd = undefined;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;


		_layout = new DGB.layout($this, _headerHeight);

		if(WL.Client.getEnvironment() == WL.Environment.IPHONE) {  // 폰트사이즈 조정
			$('#PRDE004 table').css('font-size', '12px');
			$('.ui-grid-a div > h3').css('fontSize', '14px');
		}
		
		if (WL.Client.getEnvironment() == WL.Environment.IPHONE || WL.Client.getEnvironment() == WL.Environment.IPAD) {
			$('#PRDE004 .custIscroll').bind('tap', function() {
				$('#PRDE004 input').blur();
			});
		}
		
		// 조회 버튼
		$this.find('#prde004Search').off('vclick').on('vclick', function() {
			$('#PRDE004 #prde004Date').blur();
			setTimeout(function () {
				listSearch.call();
			}, 300);
		});
		
		// 기준일자 변경
		
		inDate = nmf.utils.DateFormat.format(new Date(), 'yymmdd');
		$('#PRDE004 #prde004Date').val(inDate);

	};
	
	function setContents() {
		_layout.refreshLayout();
		
		setTimeout(function () {
//			listSearch.call();
		}, 300);
	}
	listSearch = {
		options : {
			onSuccess : displayDepositRateResult,
			onFailure : displayDepositRateError,
			invocationContext : {}
		},

		call : function() {
			if(inDate != $('#PRDE004 #prde004Date').val()) {
			}
			inDate = $('#PRDE004 #prde004Date').val();
			if(inDate.length != 8) {
				showAlert(Messages.msg05C);
				return false;
			}
			dgbLoading(true);
			invocationData = {
					adapter : 'DBTransactionAdapter',
					procedure : "TPR00004",
					parameters : [{CS_ID:_menuId,RGDT : inDate}]
			};
			callProcedure(invocationData, this.options);
		}
	};
	
	function displayDepositRateResult(data) {
		$('#PRDE004 #prde004RateTable tbody').html('');
		
		var item = data.invocationResult.resultSet;
		var html = "";
		var listItems = [];
		if(item.length != 0) {
			
			for(var i=0; i<item.length; i++) {
				var period ;
				
				if($.isNumeric(item[i].HMPG_LO_INRST_APY_PRID_CD)){
					if(item[i].HMPG_LO_INRST_APY_PRID_CD == '99')
						period = "1일"; //99
					else
						period = parseInt(item[i].HMPG_LO_INRST_APY_PRID_CD) +"개월";//01,02,03
				}else
					period = parseInt(item[i].HMPG_LO_INRST_APY_PRID_CD) + "년";  //1T, 2T, 3Y?

                item[i].APY_INRST = parseFloat( item[i].APY_INRST);

				html  =	"<tr>" +
				"<td>"+item[i].CRI_INRST_SST_NM+"</td>" +
				"<td>"+period+"</td>" +
				"<td>"+item[i].APY_INRST+"%</td>" +
				"</tr>";
				listItems[i] = html;
			}
			$("#prde004NoResult").addClass("displayNone");
			_layout.resetLayout();
			
			$('#PRDE004 #prde004RateTable tbody').append(listItems.join(''));
			listItems = null;
            item = null;
            html = "";
			mergeSameRow('prde004RateTable');
		} else {
			dgbLoading(false);
			$("#prde004NoResult").removeClass("displayNone");
		}
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
	}
	
	function displayDepositRateError() {
		dgbLoading(false);
		$("#prde004NoResult").removeClass("displayNone");
	}
	
	$(document).on({
		pageinit: function() {
			pageinit($(this));
		},
		pageshow: function() {
			DGB.Common.backMenu();
			
			_layout.refreshLayout();
			setTimeout(function () {
				listSearch.call();
			}, 300);
		},
		pagebeforehide: function() {
			if( !locDetailview ) {
				$('#PRDE004 table td').val('');
			}
		},
		parentpage :function (evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRDE004');
})();