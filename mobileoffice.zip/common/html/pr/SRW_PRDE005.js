(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;
	var locDetailview = false;
	var listSearch = null;
	var exchangeSortMap = undefined;
	var jisuSortMap = undefined;
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;

		//환율 정렬
		exchangeSortMap = new DGB.HashMap();
		exchangeSortMap.put("USD",0);
		exchangeSortMap.put("JPY",1);
		exchangeSortMap.put("EUR",2);
		exchangeSortMap.put("CNY",3);

		//주가 정렬
		jisuSortMap = new DGB.HashMap();
		jisuSortMap.put("KOSPI",0);
		jisuSortMap.put("KOSPI200",1);
		jisuSortMap.put("KOSDAQ",2);
		jisuSortMap.put("DOWJON",3);
		jisuSortMap.put("XAUFIX",4);
		
		_layout = new DGB.layout($this, _headerHeight);
        setContents();
        
		// 조회 버튼
		$this.find('#prde005Refresh').off('vclick').on('vclick', function() {
            listSearch.call();
            return false;
		});
	};

    function setContents() {
        _layout.refreshLayout();
    }

    listSearch = {
        options : {
            onSuccess : displayResult,
            onFailure : displayError,
            invocationContext : {}
        },

        call : function() {

            var d = new Date();
            var year = d.getFullYear();
            var month = pad(d.getMonth()+1);
            var date = pad(d.getDate());

            var today = year+month+date;
            //var today ='20140325';
            dgbLoading(true);

            DGB.Log.i("SRW_PRDE005  today : " +today);
            var inv = {
                adapter : 'SocketTransactionAdapter',
                procedure : "TPR00005",
                parameters : [{REQDT : today, CS_ID:_menuId}]
            };
            callProcedure(inv, this.options);
        }
    };

    function displayResult(data) {
        var item = data.invocationResult;

        DGB.Log.d("SRW_PRDE005 item.stock.length : " +item.stock.length);
        DGB.Log.d("SRW_PRDE005 item.exchangeRate.length : " +item.exchangeRate.length);
        $("#PRDE005 #exchangePrice").text("");
        var html = "";
        var listItems = [];
        
        //환율 정보
        if(item.exchangeRate.length < 2) {
        	$("#prde05Noresult_1").removeClass("displayNone");
        	$("#prde05Table_1").addClass("displayNone");
        }else{
        	$("#prde05Noresult_1").addClass("displayNone");
        	$("#prde05Table_1").removeClass("displayNone");
        	
        	var yDate = (item.exchangeRate[0].TRANDT.substring(0,8)).replace(/^(\d{4})(\d{2})(\d{2})$/,"($1년 $2월 $3일)");
        	var curTime = (item.exchangeRate[0].HOSTTM.substring(0,6)).replace(/^(\d{2})(\d{2})(\d{2})$/,"($1시 $2분 $3초 기준)");
        	$('#PRDE005 #exTday').text(curTime);
            $('#PRDE005 #exYday').text(yDate);

            var sortIndex = -1;
            for ( var i = 0; i < item.exchangeRate.length; i++) {
                 html  =   "<tr><td>"+ item.exchangeRate[i].CURRCD + "</td>"
                 +" <td>"+ numberWithComma(item.exchangeRate[i].TBASERATE) + "<br>"+ getDiffString(item.exchangeRate[i].TDIFFRATE) + "</td>"
                 +   "  <td>"+ numberWithComma(item.exchangeRate[i].YBASERATE) + "<br>"+ getDiffString(item.exchangeRate[i].YDIFFRATE)  + "</td>  "
                 +   " </tr>  " ;

                 sortIndex = exchangeSortMap.get(item.exchangeRate[i].CURRCD);
                 if(sortIndex>-1)
        			listItems[sortIndex] = html;	
            }

            $("#PRDE005 #exchangePrice").append(listItems.join(''));
        }
        //주가 정보
        $("#PRDE005 #stock").text("");
        listItems = [];
        html = "";
        if(item.stock.length < 2) {
        	$("#prde05Noresult_2").removeClass("displayNone");
        	$("#prde05Table_2").addClass("displayNone");
        }else{
        	$("#prde05Noresult_2").addClass("displayNone");
        	$("#prde05Table_2").removeClass("displayNone");
        	
        	var yDate = (item.stock[0].GOSIDT.substring(0,8)).replace(/^(\d{4})(\d{2})(\d{2})$/,"($1년 $2월 $3일)");
        	var curTime = (item.stock[0].GOSITM.substring(0,4)).replace(/^(\d{2})(\d{2})$/,"($1시 $2분 기준)");
        	$('#PRDE005 #stTday').text(curTime);
        	$('#PRDE005 #stYday').text(yDate);
        	var sortIndex = -1;
        	var stockName = undefined;
        	for ( var i = 0; i < item.stock.length; i++) {
        		if(item.stock[i].STOCKCD=='DOWJON'){//DOWJON --> DOW
        			stockName = "DOW";
        		}else{
        			stockName = item.stock[i].STOCKCD;
        		}
        		if(item.stock[i].STOCKCD=='XAUFIX'){
            		html  =   "<tr><td>런던금지수</td>"
            		+" <td>USD<br>"+numberWithComma(item.stock[i].TPRICE) + "<br>"+ getDiffString(item.stock[i].TNETCHG) +"</td>"
            		+   "  <td>USD<br>"+ numberWithComma(item.stock[i].YPRICE) + "<br>"+ getDiffString(item.stock[i].YNETCHG) + "</td>  "
            		+   " </tr>  " ;
        		}else{
            		html  =   "<tr><td>"+ stockName + "</td>"
            		+" <td>"+numberWithComma(item.stock[i].TPRICE) + "<br>"+ getDiffString(item.stock[i].TNETCHG) +"</td>"
            		+   "  <td>"+ numberWithComma(item.stock[i].YPRICE) + "<br>"+ getDiffString(item.stock[i].YNETCHG) + "</td>  "
            		+   " </tr>  " ;
        		}
        		sortIndex = jisuSortMap.get(item.stock[i].STOCKCD);
        		if(sortIndex>-1)
        			listItems[sortIndex] = html;
        	}
        	$("#PRDE005 #stock").append(listItems.join(''));
        }

        listItems = null;
        html = "";
        item = null;

        _layout.refreshLayout(function(){
            dgbLoading(false);
        }, 500);
    }
    //변동폭 html 문자열.
    function getDiffString(value){
    	if(!value) return "<span style='color: black;'>-</span>";
    	var diffValue = parseFloat(value);
    	var diffString;
        if(diffValue >0){
        	diffString  = "<span style='color: red;'>▲ "+ diffValue.toFixed(2) + "</span>";
        }else if(diffValue < 0){
        	diffString  = "<span style='color: blue;'>▼ "+ diffValue.toFixed(2) + "</span>";
        }else{
        	diffString  = "<span style='color: black;'>"+ diffValue.toFixed(2) + "</span>";
        }
        DGB.Log.d("SRW_PRDE005 getDiffString : " +diffValue.toFixed(2));
        return diffString;
    }

    function displayError() {
        dgbLoading(false);
        showAlert(Messages.msg030);
    }

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
		       listSearch.call();
		},
		pagebeforehide: function(evt, ui) {
			if(locDetailview == false) {
				$('#PRDE005 table td').val('');
			}
		},
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRDE005');
})();