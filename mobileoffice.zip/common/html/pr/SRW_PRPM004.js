(function() {
	var _layout = undefined;
	$(document).on({
		pageinit: function() {
            _layout = new DGB.layout($(this), COMMON_PAGE_HEADER_HEIGHT);
		},
		pageshow: function(){
            _layout.refreshLayout();
        },
		orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRPM004');
})();
