
(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _productName = "";
	var _prPrvDvcd = "";
	var _hmpgFnPdDvcd = "";
	var _layout = undefined;
	var listSearch = null;
	var _iscrollEnd = false; //마지막 페이지
	var _pageSize = 20; // 한페이지 갯수
	
	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;
	var _navbarHeight = COMMON_NAVBAR_HEIGHT;
	var _searchHeight = COMMON_SEARCH_HEIGHT;
	
	var pageinit = function(instance) {
		$this = instance;

		_layout = new DGB.layout($this, _headerHeight, _navbarHeight+_searchHeight);
		
		$('#PRPM003 #productSearchBtn3').off('vclick').on('vclick', function() {
			prpm03Search();
            return false;
		});
		
		$this.find('#prpmInputSearch3').on('keypress',function(e){
			if(e.keyCode == 13) {
				$this.find('#productSearchBtn3').focus();
				prpm03Search();
				return false;
			}
		});
		
		listSearch = {	
				options : {
					onSuccess : displayResult,
					onFailure : displayError,
					invocationContext : {}
				},

				call : function(param1, param2, param3) {

					dgbLoading(true);
					
					if(param1 == "")
					{
						param1 = _productName;
					}	
					
					if (arguments.length != 3) {
						param2 = 1; // START_NUM 기본값
						param3 = _pageSize; // EDD_NUM 기본값
						/* 페이징 */
						$('#prpm03StNum').val(param2), $('#prpm03EdNum').val(param3);
						/* //페이징 */
					}

					var invocationData = {
						adapter : 'DBTransactionAdapter',
						procedure : 'TPR00001',
					
						parameters : [{PRODUCT_NAME : param1, 
							START_NUM : param2,
							END_NUM : param3,
							PD_PRV_DVCD : _prPrvDvcd, 
							HMPG_FN_PD_DVCD : _hmpgFnPdDvcd,
							CS_ID:_menuId, 
							ENCODE_STR : ""}]
					};

					callProcedure(invocationData, this.options);
				}

			};
		
	};
	
	
	function prpm03Search(){
		var param = $('#PRPM003 #prpmInputSearch3').val().toUpperCase();
		if (param == "") {
			showAlert(Messages.msg056);
			return;
		}
		
		_layout.resetLayout(); //스크롤위치 초기화
		_iscrollEnd = false;
		$("#prpm03Noresult").addClass("displayNone");
		$("#productListview").empty();

        DGB.Common.hideKeyboard();

		setTimeout(function () {
			listSearch.call(param);
		}, 300);
		return false;
	
	}
	
	function displayResult(data) {
		var item = data.invocationResult.resultSet;
		if(item.length === 0)
		{			
			if($('#PRPM003 #prpmInputSearch3').val() == "")
			{
				$("#prpm03Noresult").removeClass("displayNone");
				$("#prpm03InputText").text(_productName);
			}
			else
			{
				$("#prpm03Noresult").removeClass("displayNone");
				$("#prpm03InputText").text($('#PRPM003 #prpmInputSearch3').val());
				$('#PRPM003 #prpmInputSearch3').val("");
			}
			
		}
		
		var html = "";
		var listItems = [];
		for (var i=0; i<item.length; i++) {
			
			html =  "<li>"+
						"<a class='downHeight' href='"+ DGB.dgbHost() + item[i].FILE_PATH+"' target='_blank'>"+
							"<h3>"+item[i].PUTUP_WRIT_TIT_NM+"</h3>"+
							"<p><strong style='color:darkblue;'>"+item[i].LT_CH_DTL_DTTI+"</strong></p>"+
						"</a>"+
					"</li>";
			listItems[i] = html;
		}
		
		/* 페이징 */
		if (item.length == _pageSize) {
			if (item[item.length - 1].RNUM == item[item.length - 1].TOTCNT) { // 마지막페이지
				$('#prpm03pullUp').css("display", "none");
				_iscrollEnd = true;

			} else {
				$('#prpm03pullUp').css("display", "block");
				$('#prpm03StNum').val(
						parseInt($('#prpm03StNum').val()) + _pageSize);
				$('#prpm03EdNum').val(
						parseInt($('#prpm03EdNum').val()) + _pageSize);
			}
		} else {
			_iscrollEnd = true;
			$('#prpm03pullUp').css("display", "none");
		}
		/* //페이징 */

		$("#productListview").append(listItems.join(''));

        switch ($this.find('.ui-state-persist').attr('id')) {
            case 'prpm03NavName':
                listviewSorting("#productListview", "h3", "asc");
                break;
            case 'prpm03NavUp':
                listviewSorting("#productListview", "p", "desc");
                break;
            default:
                break;
        }

		listItems = null;
        item = null;
        html = "";
		$("#productListview").listview( "refresh" );
		$("#productListview").trigger("updatelayout");
		
		$('#productListview li a[target="_blank"]').off('vclick').on("vclick", function(e) {
			e.preventDefault();//href이벤트 막기
			
			var url = $(this).attr("href");
			var title =  $(this).find("h3").text().trim();
			var downPath = "";
			var file = {"url" :url, "title":title, "downPath":downPath};
			downloadFile(file);
			return false;
		});
		
		//android back 버튼 동작
		DGB.Common.backPage();
		
		_layout.refreshLayout(function(){
			dgbLoading(false);
		}, 500);
		
	}
	function displayError() {
		dgbLoading(false);
	}

	function _pageshow() {
		_layout.refreshLayout();
		
		$("#productListview").empty();
		$('#prpm03pullUp').css("display", "none");

		_iscrollEnd = false;
		listSearch.call("");

	}
	// 당겨서 추가
	function pullUpAdd() {
		var param1 = $('#PRPM003 #prpmInputSearch3').val().toUpperCase(),
			param2 = $('#prpm03StNum').val(),
			param3 = $('#prpm03EdNum').val();

		listSearch.call(param1, param2, param3);
	}

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pagebeforeshow: function(evt, ui) {
			$this.find('#prpmNavbar').on('vclick','a', function () {
				var currentNav = $(this).text();
				switch (currentNav) {
                    case "상품명순":
                        listviewSorting("#productListview", "h3", "asc");
                        break;
                    case "업데이트순":
                        listviewSorting("#productListview", "p", "desc");
                        break;
				}
				$("#productListview").listview( "refresh" );
			});			
		},
		pageshow: _pageshow,
		pagebeforehide: function(evt, ui) {
			//초기화
			$("#productListview").empty();
			$("#prpm03Noresult").addClass("displayNone");
			$('#prpmInputSearch3').val("");
			_iscrollEnd = false;
		},
		parentpage :function (evt, param) {
			_productName = param.productName;
			_menuId = param.menuId;
			_prPrvDvcd = param.prPrvDvcd;
			_hmpgFnPdDvcd = param.hmpgFnPdDvcd;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
			if ( DGB.isIPhone() ){
				$("#productSearchBtn3").focus();
			}
            return false;
		},
		pulluprefresh : function() {
			if( !_iscrollEnd ) {
				pullUpAdd();
			}
		}
	}, '#PRPM003');
	
})();
