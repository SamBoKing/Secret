(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;

    var _item = {};
    var _aptname,
        _jutaparea,
        _allarea,
        _lowval,
        _avghval;

    var input_1,input_2,input_3,input_4,input_5,radioField,rd_name,rd_Noname;

	var pageinit = function(instance) {
		$this = instance;

        var data = $this.data('aptdata');

		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

        input_1 = $this.find('#input_1');
        input_2 = $this.find('#input_2');
        input_3 = $this.find('#input_3');
        input_4 = $this.find('#input_4');
        input_5 = $this.find('#input_5');
        radioField = $this.find('#radioField');
        rd_name =  $this.find('#rd_name');
        rd_Noname =  $this.find('#rd_Noname');

        radioField.on('change', onClickRadio);
	};

    var onClickRadio = function(event) {
        DGB.Common.hideKeyboard();
        initInputBox();
        setInput_1Val();
        return false;
    };

    var initInputBox = function(){
        input_2.val('');
        input_3.val('');
        input_4.val('');
        input_5.val('');
    }

    var setInput_1Val = function(){
        var radiovalue = $this.find('input:radio[name=radio-choice]:checked');
        var input_val =radiovalue.val();
        input_1.val( commaNum(input_val) );
    }

    var initRadioBtn = function(){
        rd_Noname.prop("checked",true).checkboxradio("refresh");
        rd_name.prop("checked",false).checkboxradio("refresh");
    }

    var calcResult = function() {

        var val1 = input_1.val() || '0';
        var val2 = input_2.val() || '0';
        var val3 = input_3.val() || '0';
        var val4 = input_4.val() || '0';

        val1 = val1.replace( /(\,)/g,'');
        val3 = val3.replace( /(\,)/g,'');
        val4 = val4.replace( /(\,)/g,'');

        val1 = parseInt(val1);
        val2 = parseInt(val2) * 0.01;
        val3 = parseInt(val3);
        val4 = parseInt(val4);

        var result = (val1 * val2) - (val3 + val4);

        result = Math.round(result);

        input_5.val( commaNum( result.toString() ) );

    }

    var initinputbox = function(){
        input_2.val("");
        input_3.val("");
        input_4.val("");
        input_5.val("");

    }

    var inputboxAddText = function(inputbox){

        inputbox.each(function(i,el){
            el.type = "text";
            el.onfocus = function(){
                $(this).val("");      //jkhtest
                this.type="number";
            };
            el.onblur = function(){

                var me = $(this);
                var val = me.val();
                this.type="text";
                val = val.replace(/(\,)/g,'');
                me.val(commaNum( val.toString() ));     //jkhtest
            };
            el.onkeyup = function(){
                 var text = $(this).val();

                 var maxlength = $(this).data('maxlength');
                    if(maxlength > 0) {
                        $(this).val(text.substr(0, maxlength));
                    }

                calcResult();
             };

        });
    }

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function() {

            initinputbox();

            inputboxAddText(input_2);
            inputboxAddText(input_3);
            inputboxAddText(input_4);


            DGB.Common.backPage();

            _layout.refreshLayout();
            _layout.resetLayout(); //스크롤위치 초기화
            initRadioBtn();

            $this.find('#aptName').text(_aptname);
            $this.find('#jutapArea').text(_jutaparea);
            $this.find('#allArea').text(_allarea);
            $this.find('#rd_name').val(_lowval);
            $this.find('#rd_Noname').val(_avghval);

            setInput_1Val();

        },
		pagebeforehide: function(evt, ui) {
		},
        parentpage :function (evt, param) {

            _item = JSON.parse(param.item);
            _menuId = param.menuId;

            _aptname = _item.APTS_NAME;
            _jutaparea = _item.SP_JT_M2;
            _allarea = _item.SP_USEAREA;
            _lowval = _item.APTP_S_LOWER;
            _avghval = _item.APTP_S_MIDDLE;

        },
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRAP002');
})();
