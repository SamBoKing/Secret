
(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;

    var listview;

	var pageinit = function(instance) {
		$this = instance;

        listview = $this.find('#prpmListview');

		_layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);

		//리스트클릭 이벤트
        listview.find('li a.prpm002List').off('vclick').on('vclick',function(){
			var item = $(this).attr('data-minor');
            var url = "";
            switch (item) {
                case '1':
                    url = Messages.url014;
                    break;
                case '2':
                    url = Messages.url015;
                    break;
            }
            window.open(url, "_blank", "location=yes,EnableViewPortScale=yes");
			return false;
		});
		
	};

	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: function(evt, ui) {
			DGB.Common.backPage();
			_layout.refreshLayout();
		},
		parentpage :function (evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRPM007');
})();
