(function() {
	var $this = undefined;
	var _menuId = undefined;
	var _layout = undefined;

	// Fixed height
	var _headerHeight = COMMON_PAGE_HEADER_HEIGHT;

	var pageinit = function(instance) {
		$this = instance;
		

		_layout = new DGB.layout($this, _headerHeight);

		//리스트클릭 이벤트
		$('#prdeMajorListview').find('li a.prde001List').off('vclick').on('vclick',function(){
			 
			var pageId =$(this).attr('data-pageId'); 
			var args ={};
			args.menuId = $(this).attr('data-menuId');
			
			if(pageId){
				// $("#"+pageId).trigger("parentpage",[args]);
                DGB.Page.triggerPage("#"+pageId, "parentpage", [args]);
				setTimeout(function () {
					DGB.Page.changePage('#'+pageId);
				},400);
			} else {
                window.open("https://www.dgb.co.kr/cms/fnm/deposit/rate/03/index.html", "_blank", "location=yes");
			}
			return false;
		});
	};

	function _pageshow() {
		DGB.Common.backMenu();
		_layout.refreshLayout();
	}
	
	$(document).on({
		pageinit: function(evt, ui) {
			pageinit($(this));
		},
		pageshow: _pageshow,
		selectmenu :function(evt, param) {
			_menuId = param.menuId;
		},
		orientationchange : function(evt) {
            DGB.Common.refreshLayout(_layout);
            return false;
		}
	}, '#PRDE001');
})();