(function() {
    var $this, _layout, _view, _menuId, _rd_tab1, _tabs, _date, _init_show;

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT + 65);
        _view = $this.find('#view');
        _date = $this.find('#datePicker');
        _rd_tab1 = $this.find('#pay_total');

        _date.val(getMonth());
        $this.find('#rd_tab').on('change', onClickItem);
        $this.find('#search').on('vclick', onSearch);

        $.Mustache.add('EHR0001_tmpl-list', $this.find('#tmpl_view').html());
        _view.mustache('EHR0001_tmpl-list', { });
        _layout.refreshLayout();
    }

    function _pageshow() {
        DGB.Common.backMenu();
        if( !_init_show ) {
            _init_show = true;
            onSearch();
        }
    }

    function getMonth() {
        var d = new Date();
        var y = d.getFullYear();
        var m = DGB.Util.pad( d.getMonth() + 1 );
        return (y + '-' + m);
    }

    function onClickItem(e) {
        var index = $(e.target).data('value');
        _view.empty().mustache('EHR0001_tmpl-list', {tabs : _tabs[index]});
        _layout.scrollTo(0,0);
        _layout.resetLayout();
        _layout.refreshLayout();
    }

    function onSearch() {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'EAIAdapter',
            procedure : 'EHR0001',
            parameters : [{
                CS_ID : _menuId,
                ENOB : GLOBAL.ENOB,
                PAYMENT_YM : _date.val().replace('-','')
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var result = data.invocationResult || {};
        if( !result.success ) {
            showAlert(result.msg);
        }

        _tabs = result.tabs || [];
        _rd_tab1.prop("checked", true);
        _rd_tab1.click();
        dgbLoading(false);
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#EHR0001');
})();