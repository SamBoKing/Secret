(function() {
    var $this, _layout, _view, _menuId, _prevPage, _row = {};

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, COMMON_SEARCH_HEIGHT);
        _view = $this.find('#view');
        _prevPage = $('#BPR0001');

        $this.find('.cust_btn').on('vclick', onClick);
        $.Mustache.add('BPR0002_tmpl-view', $this.find('#tmpl_list').html());
    }

    function _pageshow() {
        DGB.Common.backPage();

        _view.empty().mustache('BPR0002_tmpl-view', _row);
        _layout.resetLayout();
        _layout.refreshLayout();
    }

    function _parentpage(evt, param) {
        _menuId = param.menuId;
        _row = param.row || {};
    }

    function request(cmd) {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'EAIAdapter',
            procedure : 'BPR0001',
            parameters : [{
                CS_ID : _menuId,
                ENOB : USER_INFO.ENOB,
                UPGB : cmd,
                INDEX_KEY : _row.ID
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var result = data.invocationResult || {};
        if( !result.success ) {
            dgbLoading(false);
            showAlert(result.msg);
            return;
        }

        showAlert('본부금리승인', result.msg, function() {
            if( _prevPage ) {
                _prevPage.data('refresh', true);
            }
            DGB.Page.backPage();
        });
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function onClick() {
        var cmd = $(this).data('cmd');
        var msg = '[' + $(this).text().trim() + '] 상태로 변경하시겠습니까?';
        showCusConfirm(function(btn) {
            if( btn == '1' ) {
                request(cmd);
            }
        }, '알림', msg);
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        parentpage : _parentpage,
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }

    }, '#BPR0002');
})();