(function() {
    var $this, _layout, _list, _menuId, _refresh= true, _page, _pullUp;
    var _items = [];

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _list = $this.find('#list');
        _pullUp = $this.find('.pullUp');

        $.Mustache.add('BPR0001_tmpl-list', $this.find('#tmpl_list').html());
        _list.mustache('BPR0001_tmpl-list', { row : [] });
        _layout.refreshLayout();
        _page = 1;
    }

    function _pageshow() {
        DGB.Common.backMenu();
        if(_refresh || $this.data('refresh') ) {
            _page = 1;
            $this.data('refresh', false);
            _refresh = false;
            request();
        }
    }

    function request() {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'EAIAdapter',
            procedure : 'BPR0001',
            parameters : [{
                CS_ID : _menuId,
                ENOB : USER_INFO.ENOB,
                PAGE : _page,
                UPGB : '01'
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var result = data.invocationResult || {};
        if( !result.success ) {
            // dgbLoading(false);
            showAlert(result.msg);
            // return;
        }

        if( result.is_pull ) {
            _pullUp.show();
        } else {
            _pullUp.hide();
        }

        if ( _page == 1 ) {
            _items = result.row || [];
            _list.empty().mustache('BPR0001_tmpl-list', result);
            _layout.resetLayout();
        } else if(result.row.length > 0 ) {
            for(var i in result.row) {
                _items.push(result.row[i]);
            }
            _list.mustache('BPR0001_tmpl-list', result);
        }

        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function onClickItem() {
        var index = $this.find('.inner_list').index($(this));
        var param = [{ menuId : _menuId, row : _items[index] }];
        DGB.Page.triggerPage("#BPR0002", "parentpage", param);
        DGB.Page.changePage('#BPR0002');
        return false;
    }

    function _pulluprefresh() {
        if ( _pullUp.is(':visible') ) {
            _page++;
            request();
        }
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        selectmenu : function() { _refresh = true;  },
        pulluprefresh : _pulluprefresh,
        pulldownrefresh :function() {
            _page = 1;
            request();
        },
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#BPR0001');

    $(document).on('vclick', '#BPR0001 .inner_list', onClickItem);
})();