(function() {
    var $this, _page, _menuId, _pullUp, _layout, _list, _refresh = true;
    var _config, _loc, _type, _sort, _name, _sort_val, _popup_sort;

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT, (COMMON_SEARCH_HEIGHT * 2) - 4);
        _list = $this.find('#list');
        _loc = $this.find('#loc');
        _type = $this.find('#type');
        _sort = $this.find('#sort');
        _name = $this.find('#name');
        _pullUp = $this.find('.pullUp');
        _popup_sort = $this.find('#popupSort');

        _name.on('keypress',search);
        $this.find('#search').on('vclick', search);

        $.Mustache.add('FOOD001_tmpl-list', $this.find('#tmpl_list').html());
        _list.mustache('FOOD001_tmpl-list', { row : [] });
        _layout.refreshLayout();
        _page = 1;
    }

    function search() {
        _page = 1;
        DGB.Common.hideKeyboard();
        $this.find('#search').focus();
        setTimeout(request, 300);
        return false;
    }

    function onBackPage() {
        if( _popup_sort.parent().hasClass('in') ) {
            _popup_sort.popup('close');
            $this.focus();
            return;
        }

        if( DGB.Menu.isOpen('leftPanel') ) {
            //종료 토스트 팝업
            var preTime = GLOBAL.EXIT_PRETIME || 0;
            var curTime = Date.now();
            var doExit = !((curTime - preTime) > 3500);
            if(doExit) {
                AndroidNative.exitApp();
            } else {
                GLOBAL.EXIT_PRETIME = Date.now();
                WL.Toast.show(Messages.msg624);
            }
        } else {
            DGB.Menu.open('leftPanel');
        }
    }

    function _pageshow() {
        WL.App.overrideBackButton(onBackPage);

        if( _config ){
            if( _refresh ) {
                _refresh = false;
                _page = 1;
                request();
            }
        } else {
            config();
        }
    }

    function _pulluprefresh() {
        if ( _pullUp.is(':visible') ) {
            _page++;
            request();
        }
    }

    function config() {
        var opt = {
            onSuccess : onSuccessConfig,
            onFailure : onFailureConfig,
            invocationContext : {}
        };

        var inv = {
            adapter : 'FoodAdapter',
            procedure : 'FOOD002',
            parameters : [{
                CS_ID : _menuId
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessConfig(data) {
        var result = data.invocationResult || {};
        _config = result.config || {};
        $.each(_config.FOOD_LOCATION, function(i, e) {
            var selected = e.SELECTED ? ' selected="selected"' : '';
            _loc.append('<option value="' + e.VALUE + '"' + selected + '>' + e.TEXT + '</option>');
        });
        $.each(_config.FOOD_TYPE, function(i, e) {
            var selected = e.SELECTED ? ' selected="selected"' : '';
            _type.append('<option value="' + e.VALUE + '"' + selected + '>' + e.TEXT + '</option>');
        });
        _loc.selectmenu( "refresh",true );
        _type.selectmenu( "refresh",true );

        $.each(_config.SORT_TYPE, function(i, e) {
            var selected = '';
            if( e.SELECTED ) {
                _sort_val = e.VALUE;
                selected = 'sort_select';
            }
            _sort.append('<li class="sort_item ' + selected +'" data-value="' + e.VALUE +  '">' + e.TEXT + '</li>');
        });
        _sort.listview( "refresh" );

        _sort.find('.sort_item').on('vclick', function() {
            _sort.find('.sort_item').removeClass('sort_select');

            var me = $(this);
            me.addClass('sort_select');
            _sort_val = me.data('value');
            _popup_sort.popup('close');
            _page = 1;
            request();
            return false;
        });
        request();
    }

    function onFailureConfig(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function request() {
        var opt = {
            onSuccess : onSuccess,
            onFailure : onFailure,
            invocationContext : {}
        };

        var inv = {
            adapter : 'FoodAdapter',
            procedure : 'FOOD001',
            parameters : [{
                CS_ID : _menuId,
                PAGE : _page + '',
                NAME : _name.val(),
                LOC : _loc.val(),
                TYPE : _type.val(),
                SORT : _sort_val,
                ID : GLOBAL.ENOB
            }]
        };

        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccess(data) {
        var obj = data.invocationResult || {};

        if( !obj.success ) {
            dgbLoading(false);
            showAlert(result.msg);
            return;
        }

        if( obj.row.length < (_config.PAGE_COUNT || 5) ) {
            _pullUp.hide();
        } else {
            _pullUp.show();
        }

        if ( _page == 1){
            _list.empty().mustache('FOOD001_tmpl-list', obj);
            _layout.resetLayout();
        } else if(obj.row.length > 0 ) {
            _list.mustache('FOOD001_tmpl-list', obj);
        }

        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
    }

    function onFailure(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function requestSymp(id, symp) {
        var opt = {
            onSuccess : onSuccessSymp,
            onFailure : onFailureSymp,
            invocationContext : {}
        };

        var inv = {
            adapter : 'FoodAdapter',
            procedure : 'FOOD003',
            parameters : [{
                CS_ID : _menuId,
                ENOB : GLOBAL.ENOB,
                ID : id,
                SYMP : symp
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessSymp(data) {
        var obj = data.invocationResult || {};
        if( !obj.success ) {
            dgbLoading(false);
            showAlert(obj.msg);
            return;
        }

        var item = obj.item || {};
        $this.find(".good_" + item.F_OID).text(item.F_SYMP1);
        $this.find(".bad_" + item.F_OID).text(item.F_SYMP4);
        $this.find(".btn_" + item.F_OID).data("use","Y");
        dgbLoading(false);
        showAlert("정상처리되었습니다");
    }

    function onFailureSymp(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function symp(){
        var me = $(this);
        var use = me.data("use");
        if( use == 'Y' ) {
            showAlert("이미 평가하셨습니다!");
            return false;
        }
        var id = me.data("id");
        var val = me.data("value");
        var symp = val == 'g' ? '좋아요' : '별로요';
        showCusConfirm(
            function(btn) {
                if( btn == '1' ) {
                    requestSymp(id,val);
                }
            }, '알림', '"' + symp + '" 로 평가하시겠습니까?'+'\n'+'[중요] "평가" 클릭 시 변경이 불가능 합니다!!', '평가,취소'
        );
        return false;
    }

    function naverSearch(){
        var url = $(this).data("url");
        window.open(encodeURI(url), "_system", "location=yes,EnableViewPortScale=yes");
        return false;
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        selectmenu : function(evt, param) {
            _menuId = param.menuId;
            _refresh = !param.activePage;
        },
        pulluprefresh : _pulluprefresh,
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#FOOD001');

    $(document).on('vclick', '#FOOD001 .btn_symp', symp);
    $(document).on('vclick', '#FOOD001 .naver_search', naverSearch);

})();
