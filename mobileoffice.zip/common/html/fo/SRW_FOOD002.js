(function() {

    var $this, _layout, _menuId, _list;
    var  _items, index;

    function _pageinit() {
        $this = $(this);
        _layout = new DGB.layout($this, COMMON_PAGE_HEADER_HEIGHT);
        _list = $this.find('#list');

        $.Mustache.add('FOOD002_tmpl-list', $this.find('#tmpl_list').html());
    }

    function _pageshow() {
        if( !_items || _items.length == 0 ) {
            requestMenu();
        }
    }

    function requestMenu() {
        var opt = {
            onSuccess : onSuccessMenu,
            onFailure : onFailureMenu,
            invocationContext : {}
        };

        var inv = {
            adapter : 'FoodAdapter',
            procedure : 'FOOD004',
            parameters : [{
                CS_ID : _menuId
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessMenu(data) {
        var result = data.invocationResult || {};
        _items = result.menu_type || [];
        refreshList();
    }

    function onFailureMenu(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function refreshList() {
        _list.mustache('FOOD002_tmpl-list', { menu_type : _items } );
        _layout.refreshLayout(function() {
            dgbLoading(false);
        });
    }

    function requestInfo(val) {
        var opt = {
            onSuccess : onSuccessInfo,
            onFailure : onFailureInfo,
            invocationContext : {}
        };

        var inv = {
            adapter : 'FoodAdapter',
            procedure : 'FOOD005',
            parameters : [{
                CS_ID : _menuId,
                ZZZUSER00 : val
            }]
        };
        dgbLoading(true);
        callProcedure(inv, opt);
    }

    function onSuccessInfo(data) {
        dgbLoading(false);

        var result = data.invocationResult || {};
        if( !result.success ) {
            showAlert(result.msg);
            return
        }
        _items[index].ATTACHS = result.ATTACHS;
        _items[index].TITLE = result.TITLE;
        makeCallDaview(result.TITLE, result.ATTACHS);
    }

    function onFailureInfo(data) {
        dgbLoading(false);
        showAlert(Messages.err001 + "\n\nError : " + JSON.stringify(data));
    }

    function onClickItem() {
        index = $this.find('.type').index($(this));
        var data = _items[index] || {};
        if( data.ATTACHS && data.ATTACHS.length > 0 ) {
            makeCallDaview(data.TITLE, data.ATTACHS);
        } else {
            requestInfo(data.VALUE);
        }
    }

    function makeCallDaview(title, attachs) {
        switch( attachs.length ) {
            case 0:
                showAlert(Messages.msg02L);
                break;
            case 1:
                callDaview({url : attachs[0].URL}, attachs[0].TITLE);
                break;
            default:
                var file_title = [];
                for(var i in attachs) {
                    file_title.push(attachs[i].TITLE);
                }
                DGB.Common.selectList(title, file_title,
                    function(index) {
                        callDaview({url : attachs[index].URL}, attachs[index].TITLE);
                    },
                    function(err) {
                        DGB.Log.e('[SRW_FOOD002] ====>> Error : ' + err);
                    }
                );
                break;
        }
    }

    $(document).on({
        pageinit : _pageinit,
        pageshow : _pageshow,
        orientationchange : function() {
            DGB.Common.refreshLayout(_layout);
            return false;
        }
    }, '#FOOD002');

    $(document).on('vclick', '#FOOD002 .type', onClickItem);

})();