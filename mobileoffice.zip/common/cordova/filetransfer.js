/*
 * Cordova is available under *either* the terms of the modified BSD license *or* the
 * MIT License (2008). See http://opensource.org/licenses/alphabetical for full text.
 *
 * Copyright (c) 2005-2010, Nitobi Software Inc.
 * Copyright (c) 2010, IBM Corporation
 */

if (!Cordova.hasResource("filetransfer")) {
    Cordova.addResource("filetransfer");

    /**
     * FileTransferError
     * @constructor
     */
    var FileTransferError = function(code, source, target, status) {
        this.code = code || null;
        this.source = source || null;
        this.target = target || null;
        this.http_status = status || null;
    };

    FileTransferError.FILE_NOT_FOUND_ERR = 1;
    FileTransferError.INVALID_URL_ERR = 2;
    FileTransferError.CONNECTION_ERR = 3;
    FileTransferError.ABORT_ERR = 4;

    /**
     * ProgressEvent
     * @constructor
     */
    var ProgressEvent = (function() {
        /*
         var createEvent = function(data) {
         var event = document.createEvent('Events');
         event.initEvent('ProgressEvent', false, false);
         if (data) {
         for (var i in data) {
         if (data.hasOwnProperty(i)) {
         event[i] = data[i];
         }
         }
         if (data.target) {
         // TODO: cannot call <some_custom_object>.dispatchEvent
         // need to first figure out how to implement EventTarget
         }
         }
         return event;
         };
         try {
         var ev = createEvent({type:"abort",target:document});
         return function ProgressEvent(type, data) {
         data.type = type;
         return createEvent(data);
         };
         } catch(e){
         */
        return function ProgressEvent(type, dict) {
            this.type = type;
            this.bubbles = false;
            this.cancelBubble = false;
            this.cancelable = false;
            this.lengthComputable = false;
            this.loaded = dict && dict.loaded ? dict.loaded : 0;
            this.total = dict && dict.total ? dict.total : 0;
            this.target = dict && dict.target ? dict.target : null;
        };
        //}
    })();

    function newProgressEvent(result) {
        var pe = new ProgressEvent();
        pe.lengthComputable = result.lengthComputable;
        pe.loaded = result.loaded;
        pe.total = result.total;
        return pe;
    }

    var idCounter = 0;

    /**
     * FileTransfer uploads a file to a remote server.
     * @constructor
     */
    var FileTransfer = function() {
        this._id = ++idCounter;
        this.onprogress = null; // optional callback
    };

    /**
     * Given an absolute file path, uploads a file on the device to a remote server
     * using a multipart HTTP request.
     * @param filePath {String}           Full path of the file on the device
     * @param server {String}             URL of the server to receive the file
     * @param successCallback (Function}  Callback to be invoked when upload has completed
     * @param errorCallback {Function}    Callback to be invoked upon error
     * @param options {FileUploadOptions} Optional parameters such as file name and mimetype
     * @param trustAllHosts {Boolean} Optional trust all hosts (e.g. for self-signed certs), defaults to false
     */
    FileTransfer.prototype.upload = function(filePath, server, successCallback, errorCallback, options, trustAllHosts) {
        // sanity parameter checking
        if (!filePath || !server) throw new Error("FileTransfer.upload requires filePath and server URL parameters at the minimum.");
        // check for options
        var fileKey = null;
        var fileName = null;
        var mimeType = null;
        var params = null;
        var chunkedMode = true;
        var headers = null;
        if (options) {
            fileKey = options.fileKey;
            fileName = options.fileName;
            mimeType = options.mimeType;
            headers = options.headers;
            if (options.chunkedMode !== null || typeof options.chunkedMode != "undefined") {
                chunkedMode = options.chunkedMode;
            }
            if (options.params) {
                params = options.params;
            }
            else {
                params = {};
            }
        }

        var fail = function(e) {
            var error = new FileTransferError(e.code, e.source, e.target, e.http_status);
            errorCallback(error);
        };

        var self = this;
        var win = function(result) {
            if (typeof result.lengthComputable != "undefined") {
                if (self.onprogress) {
                    return self.onprogress(newProgressEvent(result));
                }
            } else {
                return successCallback(result);
            }
        };
        Cordova.exec(win, fail, 'FileTransfer', 'upload', [filePath, server, fileKey, fileName, mimeType, params, trustAllHosts, chunkedMode, headers, this._id]);
    };

    /**
     * Downloads a file form a given URL and saves it to the specified directory.
     * @param source {String}          URL of the server to receive the file
     * @param target {String}         Full path of the file on the device
     * @param successCallback (Function}  Callback to be invoked when upload has completed
     * @param errorCallback {Function}    Callback to be invoked upon error
     * @param trustAllHosts {Boolean} Optional trust all hosts (e.g. for self-signed certs), defaults to false
     */
    FileTransfer.prototype.download = function(source, target, successCallback, errorCallback, trustAllHosts) {
        // sanity parameter checking
        if (!source || !target) throw new Error("FileTransfer.download requires source URI and target URI parameters at the minimum.");
        var self = this;
        var win = function(result) {
            if (typeof result.lengthComputable != "undefined") {
                if (self.onprogress) {
                    return self.onprogress(newProgressEvent(result));
                }
            } else {
                var entry = null;
                if (result.isDirectory) {
                    entry = new DirectoryEntry();
                }
                else if (result.isFile) {
                    entry = new FileEntry();
                }
                entry.isDirectory = result.isDirectory;
                entry.isFile = result.isFile;
                entry.name = result.name;
                entry.fullPath = result.fullPath;
                successCallback(entry);
            }
        };

        var fail = function(e) {
            var error = new FileTransferError(e.code, e.source, e.target, e.http_status);
            errorCallback(error);
        };

        Cordova.exec(win, errorCallback, 'FileTransfer', 'download', [source, target, trustAllHosts, this._id]);
    };

    /**
     * Aborts the ongoing file transfer on this object
     * @param successCallback {Function}  Callback to be invoked upon success
     * @param errorCallback {Function}    Callback to be invoked upon error
     */
    FileTransfer.prototype.abort = function(successCallback, errorCallback) {
        Cordova.exec(successCallback, errorCallback, 'FileTransfer', 'abort', [this._id]);
    };

    /**
     * Options to customize the HTTP request used to upload files.
     * @constructor
     * @param fileKey {String}   Name of file request parameter.
     * @param fileName {String}  Filename to be used by the server. Defaults to image.jpg.
     * @param mimeType {String}  Mimetype of the uploaded file. Defaults to image/jpeg.
     * @param params {Object}    Object with key: value params to send to the server.
     * @param headers {Object}   Keys are header names, values are header values. Multiple
     *                           headers of the same name are not supported.
     */
    var FileUploadOptions = function(fileKey, fileName, mimeType, params, headers) {
        this.fileKey = fileKey || null;
        this.fileName = fileName || null;
        this.mimeType = mimeType || null;
        this.params = params || null;
        this.headers = headers || null;
    };

    /**
     * FileUploadResult
     * @constructor
     */
    var FileUploadResult = function() {
        this.bytesSent = 0;
        this.responseCode = null;
        this.response = null;
    };

};