

//------------------------------------------------------------------------------
// The logger module exports the following properties/functions:
//
// LOG                          - constant for the level LOG
// ERROR                        - constant for the level ERROR
// WARN                         - constant for the level WARN
// INFO                         - constant for the level INFO
// DEBUG                        - constant for the level DEBUG
// logLevel()                   - returns current log level
// logLevel(value)              - sets and returns a new log level
// useConsole()                 - returns whether logger is using console
// useConsole(value)            - sets and returns whether logger is using console
// log(message,...)             - logs a message at level LOG
// error(message,...)           - logs a message at level ERROR
// warn(message,...)            - logs a message at level WARN
// info(message,...)            - logs a message at level INFO
// debug(message,...)           - logs a message at level DEBUG
// logLevel(level,message,...)  - logs a message specified level
//
//------------------------------------------------------------------------------

if (!Cordova.hasResource("Logger")) {
    Cordova.addResource("Logger");

    if (typeof logger === "undefined") {
        cordova.logger = new Object();
        Cordova.logger = cordova.logger;
        var logger = cordova.logger;

        var UseConsole   = true;
        var Queued       = [];
        var DeviceReady  = false;
        var CurrentLevel;

        /**
         * Logging levels
         */

        var Levels = [
            "LOG",
            "ERROR",
            "WARN",
            "INFO",
            "DEBUG"
        ];

        /*
         * add the logging levels to the logger object and
         * to a separate levelsMap object for testing
         */

        var LevelsMap = {};
        for (var i=0; i<Levels.length; i++) {
            var level = Levels[i];
            LevelsMap[level] = i;
            logger[level]    = level;
        }

        CurrentLevel = LevelsMap.WARN;

        /**
         * Getter/Setter for the logging level
         *
         * Returns the current logging level.
         *
         * When a value is passed, sets the logging level to that value.
         * The values should be one of the following constants:
         *    logger.LOG
         *    logger.ERROR
         *    logger.WARN
         *    logger.INFO
         *    logger.DEBUG
         *
         * The value used determines which messages get printed.  The logging
         * values above are in order, and only messages logged at the logging
         * level or above will actually be displayed to the user.  E.g., the
         * default level is WARN, so only messages logged with LOG, ERROR, or
         * WARN will be displayed; INFO and DEBUG messages will be ignored.
         */
        logger.level = function (value) {
            if (arguments.length) {
                if (LevelsMap[value] === null) {
                    throw new Error("invalid logging level: " + value);
                }
                CurrentLevel = LevelsMap[value];
            }

            return Levels[CurrentLevel];
        };

        /**
         * Getter/Setter for the useConsole functionality
         *
         * When useConsole is true, the logger will log via the
         * browser 'console' object.  Otherwise, it will use the
         * native Logger plugin.
         */
        logger.useConsole = function (value) {
            if (arguments.length) UseConsole = !!value;

            if (UseConsole) {
                if (typeof console == "undefined") {
                    throw new Error("global console object is not defined");
                }

                if ((typeof console.log != "function")
                    && (typeof console.log != "object")) { // IE sees console functions as an objects.
                    throw new Error("global console object does not have a log function");
                }

                if ((typeof console.useLogger == "function")
                    || (typeof console.useLogger == "object")) { // IE IE sees console functions as an objects.
                    if (console.useLogger()) {
                        throw new Error("console and logger are too intertwingly");
                    }
                }
            }

            return UseConsole;
        };

        /**
         * Logs a message at the LOG level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.log   = function(message) { logWithArgs("LOG",   arguments); };

        /**
         * Logs a message at the ERROR level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.error = function(message) { logWithArgs("ERROR", arguments); };

        /**
         * Logs a message at the WARN level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.warn  = function(message) { logWithArgs("WARN",  arguments); };

        /**
         * Logs a message at the INFO level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.info  = function(message) { logWithArgs("INFO",  arguments); };

        /**
         * Logs a message at the DEBUG level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.debug = function(message) { logWithArgs("DEBUG", arguments); };

        // log at the specified level with args
        function logWithArgs(level, args) {
            args = [level].concat([].slice.call(args));
            logger.logLevel.apply(logger, args);
        }

        /**
         * Logs a message at the specified level.
         *
         * Parameters passed after message are used applied to
         * the message with utils.format()
         */
        logger.logLevel = function(level, message /* , ... */) {
            // format the message with the parameters
            var formatArgs = [].slice.call(arguments, 2);
            message    = Cordova.utils.vformat(message, formatArgs);

            if (LevelsMap[level] === null) {
                throw new Error("invalid logging level: " + level);
            }

            if (LevelsMap[level] > CurrentLevel) return;

            // queue the message if not yet at deviceready
            if (!DeviceReady && !UseConsole) {
                Queued.push([level, message]);
                return;
            }

            // if not using the console, use the native logger
            if (!UseConsole) {
                //exec(null, null, "Logger", "logLevel", [level, message]);
                //return;
                // as we have no native logger in the simulation code, we now will use the console instead.
                message = message + " (Message supposed to be handled by the native logger)";
            }

            // make sure console is not using logger
            if (console.__usingCordovaLogger) {
                throw new Error("console and logger are too intertwingly");
            }

            // log to the console
            switch (level) {
                case logger.LOG:   console.log(message); break;
                case logger.ERROR: console.log("ERROR: " + message); break;
                case logger.WARN:  console.log("WARN: "  + message); break;
                case logger.INFO:  console.log("INFO: "  + message); break;
                case logger.DEBUG: console.log("DEBUG: " + message); break;
            }
        };

        // when deviceready fires, log queued messages
        logger.__onDeviceReady = function() {
            if (DeviceReady) return;

            DeviceReady = true;

            for (var i=0; i<Queued.length; i++) {
                var messageArgs = Queued[i];
                logger.logLevel(messageArgs[0], messageArgs[1]);
            }

            Queued = null;
        };

        // add a deviceready event to log queued messages
        document.addEventListener("deviceready", logger.__onDeviceReady, false);
    }
}