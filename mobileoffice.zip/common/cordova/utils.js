if (!Cordova.hasResource("utils")) {
    Cordova.addResource("utils");

    if (typeof Cordova.utils === "undefined") {
        Cordova.utils = new Object();

        /**
         * Defines a property getter for obj[key].
         */
        Cordova.utils.defineGetter = function(obj, key, func) {
            if (Object.defineProperty) {
                Object.defineProperty(obj, key, { get: func });
            } else {
                obj.__defineGetter__(key, func);
            }
        };

        /**
         * Returns an indication of whether the argument is an array or not
         */
        Cordova.utils.isArray = function(a) {
            return Object.prototype.toString.call(a) == '[object Array]';
        };

        /**
         * Returns an indication of whether the argument is a Date or not
         */
        Cordova.utils.isDate = function(d) {
            return Object.prototype.toString.call(d) == '[object Date]';
        };

        /**
         * Does a deep clone of the object.
         */
        Cordova.utils.clone = function(obj) {
            if(!obj || typeof obj == 'function' || Cordova.utils.isDate(obj) || typeof obj != 'object') {
                return obj;
            }

            var retVal, i;

            if(Cordova.utils.isArray(obj)){
                retVal = [];
                for(i = 0; i < obj.length; ++i){
                    retVal.push(utils.clone(obj[i]));
                }
                return retVal;
            }

            retVal = {};
            for(i in obj){
                if(!(i in retVal) || retVal[i] != obj[i]) {
                    retVal[i] = utils.clone(obj[i]);
                }
            }
            return retVal;
        };

        /**
         * Returns a wrapped version of the function
         */
        Cordova.utils.close = function(context, func, params) {
            if (typeof params == 'undefined') {
                return function() {
                    return func.apply(context, arguments);
                };
            } else {
                return function() {
                    return func.apply(context, params);
                };
            }
        };

        /**
         * Create a UUID
         */
        Cordova.utils.createUUID = function() {
            return UUIDcreatePart(4) + '-' +
                UUIDcreatePart(2) + '-' +
                UUIDcreatePart(2) + '-' +
                UUIDcreatePart(2) + '-' +
                UUIDcreatePart(6);
        };

        /**
         * Extends a child object from a parent object using classical inheritance
         * pattern.
         */
        Cordova.utils.extend = (function() {
            // proxy used to establish prototype chain
            var F = function() {};
            // extend Child from Parent
            return function(Child, Parent) {
                F.prototype = Parent.prototype;
                Child.prototype = new F();
                Child.__super__ = Parent.prototype;
                Child.prototype.constructor = Child;
            };
        }());

        /**
         * Alerts a message in any available way: alert or console.log.
         */
        Cordova.utils.alert = function(msg) {
            if (window.alert) {
                window.alert(msg);
            } else if (console && console.log) {
                console.log(msg);
            }
        };

        /**
         * Formats a string and arguments following it ala sprintf()
         *
         * see utils.vformat() for more information
         */
        Cordova.utils.format = function(formatString /* ,... */) {
            var args = [].slice.call(arguments, 1);
            return utils.vformat(formatString, args);
        };

        /**
         * Formats a string and arguments following it ala vsprintf()
         *
         * format chars:
         *   %j - format arg as JSON
         *   %o - format arg as JSON
         *   %c - format arg as ''
         *   %% - replace with '%'
         * any other char following % will format it's
         * arg via toString().
         *
         * for rationale, see FireBug's Console API:
         *    http://getfirebug.com/wiki/index.php/Console_API
         */
        Cordova.utils.vformat = function(formatString, args) {
            if (formatString === null || formatString === undefined) return "";
            if (arguments.length == 1) return formatString.toString();
            if (typeof formatString != "string") return formatString.toString();

            var pattern = /(.*?)%(.)(.*)/;
            var rest    = formatString;
            var result  = [];

            while (args.length) {
                var arg   = args.shift();
                var match = pattern.exec(rest);

                if (!match) break;

                rest = match[3];

                result.push(match[1]);

                if (match[2] == '%') {
                    result.push('%');
                    args.unshift(arg);
                    continue;
                }

                result.push(formatted(arg, match[2]));
            }

            result.push(rest);

            return result.join('');
        };

        //------------------------------------------------------------------------------
        function UUIDcreatePart(length) {
            var uuidpart = "";
            for (var i=0; i<length; i++) {
                var uuidchar = parseInt((Math.random() * 256), 10).toString(16);
                if (uuidchar.length == 1) {
                    uuidchar = "0" + uuidchar;
                }
                uuidpart += uuidchar;
            }
            return uuidpart;
        }

        //------------------------------------------------------------------------------
        function formatted(object, formatChar) {

            try {
                switch(formatChar) {
                    case 'j':
                    case 'o': return JSON.stringify(object);
                    case 'c': return '';
                }
            }
            catch (e) {
                return "error JSON.stringify()ing argument: " + e;
            }

            if ((object === null) || (object === undefined)) {
                return Object.prototype.toString.call(object);
            }

            return object.toString();
        }
    }
}
